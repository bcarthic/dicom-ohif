"use strict";
(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([[722],{

/***/ 23722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  fX: () => (/* reexport */ enums_namespaceObject),
  Mr: () => (/* reexport */ esm_cornerstoneStreamingDynamicImageVolumeLoader),
  FC: () => (/* reexport */ esm_cornerstoneStreamingImageVolumeLoader),
  helpers: () => (/* binding */ helpers)
});

// UNUSED EXPORTS: StreamingDynamicImageVolume, StreamingImageVolume

// NAMESPACE OBJECT: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/enums/index.js
var enums_namespaceObject = {};
__webpack_require__.r(enums_namespaceObject);
__webpack_require__.d(enums_namespaceObject, {
  s: () => (enums_Events)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var gl_matrix_esm = __webpack_require__(44753);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/getVolumeInfo.js


const { createUint8SharedArray, createFloat32SharedArray } = esm.utilities;
function getVolumeInfo(imageIds) {
    const volumeMetadata = esm.utilities.makeVolumeMetadata(imageIds);
    const { BitsAllocated, PixelRepresentation, PhotometricInterpretation, ImageOrientationPatient, PixelSpacing, Columns, Rows, } = volumeMetadata;
    const rowCosineVec = gl_matrix_esm/* vec3.fromValues */.eR.fromValues(ImageOrientationPatient[0], ImageOrientationPatient[1], ImageOrientationPatient[2]);
    const colCosineVec = gl_matrix_esm/* vec3.fromValues */.eR.fromValues(ImageOrientationPatient[3], ImageOrientationPatient[4], ImageOrientationPatient[5]);
    const scanAxisNormal = gl_matrix_esm/* vec3.create */.eR.create();
    gl_matrix_esm/* vec3.cross */.eR.cross(scanAxisNormal, rowCosineVec, colCosineVec);
    const { zSpacing, origin, sortedImageIds } = esm.utilities.sortImageIdsAndGetSpacing(imageIds, scanAxisNormal);
    const numFrames = imageIds.length;
    const spacing = [PixelSpacing[1], PixelSpacing[0], zSpacing];
    const dimensions = [Columns, Rows, numFrames];
    const direction = [
        ...rowCosineVec,
        ...colCosineVec,
        ...scanAxisNormal,
    ];
    const signed = PixelRepresentation === 1;
    const bytesPerVoxel = BitsAllocated === 16 ? 4 : 1;
    const sizeInBytesPerComponent = bytesPerVoxel * dimensions[0] * dimensions[1] * dimensions[2];
    let numComponents = 1;
    if (PhotometricInterpretation === 'RGB') {
        numComponents = 3;
    }
    const sizeInBytes = sizeInBytesPerComponent * numComponents;
    const isCacheable = esm.cache.isCacheable(sizeInBytes);
    if (!isCacheable) {
        throw new Error(esm.Enums.Events.CACHE_SIZE_EXCEEDED);
    }
    esm.cache.decacheIfNecessaryUntilBytesAvailable(sizeInBytes);
    let scalarData;
    switch (BitsAllocated) {
        case 8:
            if (signed) {
                throw new Error('8 Bit signed images are not yet supported by this plugin.');
            }
            else {
                scalarData = createUint8SharedArray(dimensions[0] * dimensions[1] * dimensions[2]);
            }
            break;
        case 16:
            scalarData = createFloat32SharedArray(dimensions[0] * dimensions[1] * dimensions[2]);
            break;
        case 24:
            scalarData = createUint8SharedArray(dimensions[0] * dimensions[1] * dimensions[2] * numComponents);
            break;
    }
    return {
        metadata: volumeMetadata,
        sortedImageIds,
        dimensions,
        spacing,
        origin,
        direction,
        scalarData,
        sizeInBytes,
    };
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/splitImageIdsBy4DTags.js

const groupBy = (array, key) => {
    return array.reduce((rv, x) => {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
    }, {});
};
function getIPPGroups(imageIds) {
    const ippMetadata = imageIds.map((imageId) => {
        const { imagePositionPatient } = esm.metaData.get('imagePlaneModule', imageId);
        return { imageId, imagePositionPatient };
    });
    if (!ippMetadata.every((item) => item.imagePositionPatient)) {
        return null;
    }
    const positionGroups = groupBy(ippMetadata, 'imagePositionPatient');
    const positions = Object.keys(positionGroups);
    const frame_count = positionGroups[positions[0]].length;
    if (frame_count === 1) {
        return null;
    }
    const frame_count_equal = positions.every((k) => positionGroups[k].length === frame_count);
    if (!frame_count_equal) {
        return null;
    }
    return positionGroups;
}
function test4DTag(IPPGroups, value_getter) {
    const frame_groups = {};
    let first_frame_value_set = [];
    const positions = Object.keys(IPPGroups);
    for (let i = 0; i < positions.length; i++) {
        const frame_value_set = new Set();
        const frames = IPPGroups[positions[i]];
        for (let j = 0; j < frames.length; j++) {
            const frame_value = value_getter(frames[j].imageId) || 0;
            frame_groups[frame_value] = frame_groups[frame_value] || [];
            frame_groups[frame_value].push({ imageId: frames[j].imageId });
            frame_value_set.add(frame_value);
            if (frame_value_set.size - 1 < j) {
                return undefined;
            }
        }
        if (i == 0) {
            first_frame_value_set = Array.from(frame_value_set);
        }
        else if (!setEquals(first_frame_value_set, frame_value_set)) {
            return undefined;
        }
    }
    return frame_groups;
}
function getTagValue(imageId, tag) {
    const value = esm.metaData.get(tag, imageId);
    try {
        return parseFloat(value);
    }
    catch {
        return undefined;
    }
}
function getPhilipsPrivateBValue(imageId) {
    const value = esm.metaData.get('20011003', imageId);
    try {
        const { InlineBinary } = value;
        if (InlineBinary) {
            const value_bytes = atob(InlineBinary);
            const ary_buf = new ArrayBuffer(value_bytes.length);
            const dv = new DataView(ary_buf);
            for (let i = 0; i < value_bytes.length; i++) {
                dv.setUint8(i, value_bytes.charCodeAt(i));
            }
            return new Float32Array(ary_buf)[0];
        }
        return parseFloat(value);
    }
    catch {
        return undefined;
    }
}
function getSiemensPrivateBValue(imageId) {
    let value = esm.metaData.get('0019100c', imageId) || esm.metaData.get('0019100C', imageId);
    try {
        const { InlineBinary } = value;
        if (InlineBinary) {
            value = atob(InlineBinary);
        }
        return parseFloat(value);
    }
    catch {
        return undefined;
    }
}
function getGEPrivateBValue(imageId) {
    let value = esm.metaData.get('00431039', imageId);
    try {
        const { InlineBinary } = value;
        if (InlineBinary) {
            value = atob(InlineBinary).split('//');
        }
        return parseFloat(value[0]) % 100000;
    }
    catch {
        return undefined;
    }
}
function setEquals(set_a, set_b) {
    if (set_a.length != set_b.size) {
        return false;
    }
    for (let i = 0; i < set_a.length; i++) {
        if (!set_b.has(set_a[i])) {
            return false;
        }
    }
    return true;
}
function getPetFrameReferenceTime(imageId) {
    const moduleInfo = esm.metaData.get('petImageModule', imageId);
    return moduleInfo ? moduleInfo['frameReferenceTime'] : 0;
}
function splitImageIdsBy4DTags(imageIds) {
    const positionGroups = getIPPGroups(imageIds);
    if (!positionGroups) {
        return { imageIdsGroups: [imageIds], splittingTag: null };
    }
    const tags = [
        'TemporalPositionIdentifier',
        'DiffusionBValue',
        'TriggerTime',
        'EchoTime',
        'EchoNumber',
        'PhilipsPrivateBValue',
        'SiemensPrivateBValue',
        'GEPrivateBValue',
        'PetFrameReferenceTime',
    ];
    const fncList2 = [
        (imageId) => getTagValue(imageId, tags[0]),
        (imageId) => getTagValue(imageId, tags[1]),
        (imageId) => getTagValue(imageId, tags[2]),
        (imageId) => getTagValue(imageId, tags[3]),
        (imageId) => getTagValue(imageId, tags[4]),
        getPhilipsPrivateBValue,
        getSiemensPrivateBValue,
        getGEPrivateBValue,
        getPetFrameReferenceTime,
    ];
    for (let i = 0; i < fncList2.length; i++) {
        const frame_groups = test4DTag(positionGroups, fncList2[i]);
        if (frame_groups) {
            const sortedKeys = Object.keys(frame_groups)
                .map(Number.parseFloat)
                .sort((a, b) => a - b);
            const imageIdsGroups = sortedKeys.map((key) => frame_groups[key].map((item) => item.imageId));
            return { imageIdsGroups, splittingTag: tags[i] };
        }
    }
    return { imageIdsGroups: [imageIds], splittingTag: null };
}
/* harmony default export */ const helpers_splitImageIdsBy4DTags = (splitImageIdsBy4DTags);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/getDynamicVolumeInfo.js

function getDynamicVolumeInfo(imageIds) {
    const { imageIdsGroups: timePoints, splittingTag } = helpers_splitImageIdsBy4DTags(imageIds);
    const isDynamicVolume = timePoints.length > 1;
    return { isDynamicVolume, timePoints, splittingTag };
}
/* harmony default export */ const helpers_getDynamicVolumeInfo = (getDynamicVolumeInfo);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/autoLoad.js

const autoLoad = (volumeId) => {
    const renderingEngineAndViewportIds = getRenderingEngineAndViewportsContainingVolume(volumeId);
    if (!renderingEngineAndViewportIds || !renderingEngineAndViewportIds.length) {
        return;
    }
    renderingEngineAndViewportIds.forEach(({ renderingEngine, viewportIds }) => {
        if (!renderingEngine.hasBeenDestroyed) {
            renderingEngine.renderViewports(viewportIds);
        }
    });
};
function getRenderingEngineAndViewportsContainingVolume(volumeId) {
    const renderingEnginesArray = (0,esm.getRenderingEngines)();
    const renderingEngineAndViewportIds = [];
    for (let i = 0; i < renderingEnginesArray.length; i++) {
        const renderingEngine = renderingEnginesArray[i];
        const viewports = esm.utilities.getViewportsWithVolumeId(volumeId, renderingEngine.id);
        if (viewports.length) {
            renderingEngineAndViewportIds.push({
                renderingEngine,
                viewportIds: viewports.map((viewport) => viewport.id),
            });
        }
    }
    return renderingEngineAndViewportIds;
}
/* harmony default export */ const helpers_autoLoad = (autoLoad);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/scaleArray.js
function scaleArray(array, scalingParameters) {
    const arrayLength = array.length;
    const { rescaleSlope, rescaleIntercept, suvbw } = scalingParameters;
    if (scalingParameters.modality === 'PT' && typeof suvbw === 'number') {
        for (let i = 0; i < arrayLength; i++) {
            array[i] = suvbw * (array[i] * rescaleSlope + rescaleIntercept);
        }
    }
    else {
        for (let i = 0; i < arrayLength; i++) {
            array[i] = array[i] * rescaleSlope + rescaleIntercept;
        }
    }
    return array;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/helpers/index.js







;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/BaseStreamingImageVolume.js


const requestTypeDefault = esm.Enums.RequestType.Prefetch;
const { ProgressiveIterator, imageRetrieveMetadataProvider, hasFloatScalingParameters, } = esm.utilities;
const { ImageQualityStatus } = esm.Enums;
class BaseStreamingImageVolume extends esm.ImageVolume {
    constructor(imageVolumeProperties, streamingProperties) {
        super(imageVolumeProperties);
        this.framesLoaded = 0;
        this.framesProcessed = 0;
        this.framesUpdated = 0;
        this.autoRenderOnLoad = true;
        this.cachedFrames = [];
        this.reRenderTarget = 0;
        this.reRenderFraction = 2;
        this.imagesLoader = this;
        this.cancelLoading = () => {
            const { loadStatus } = this;
            if (!loadStatus || !loadStatus.loading) {
                return;
            }
            loadStatus.loading = false;
            loadStatus.cancelled = true;
            this.clearLoadCallbacks();
            const filterFunction = ({ additionalDetails }) => {
                return additionalDetails.volumeId !== this.volumeId;
            };
            esm.imageLoadPoolManager.filterRequests(filterFunction);
        };
        this.load = (callback) => {
            const { imageIds, loadStatus, numFrames } = this;
            const { transferSyntaxUID } = esm.metaData.get('transferSyntax', imageIds[0]) || {};
            const imageRetrieveConfiguration = esm.metaData.get(imageRetrieveMetadataProvider.IMAGE_RETRIEVE_CONFIGURATION, this.volumeId, transferSyntaxUID, 'volume');
            this.imagesLoader = imageRetrieveConfiguration
                ? (imageRetrieveConfiguration.create ||
                    esm.ProgressiveRetrieveImages.createProgressive)(imageRetrieveConfiguration)
                : this;
            if (loadStatus.loading === true) {
                return;
            }
            const { loaded } = this.loadStatus;
            const totalNumFrames = imageIds.length;
            if (loaded) {
                if (callback) {
                    callback({
                        success: true,
                        framesLoaded: totalNumFrames,
                        framesProcessed: totalNumFrames,
                        numFrames,
                        totalNumFrames,
                    });
                }
                return;
            }
            if (callback) {
                this.loadStatus.callbacks.push(callback);
            }
            this._prefetchImageIds();
        };
        this.loadStatus = streamingProperties.loadStatus;
    }
    invalidateVolume(immediate) {
        const { imageData, vtkOpenGLTexture } = this;
        const { numFrames } = this;
        for (let i = 0; i < numFrames; i++) {
            vtkOpenGLTexture.setUpdatedFrame(i);
        }
        imageData.modified();
        if (immediate) {
            helpers_autoLoad(this.volumeId);
        }
    }
    clearLoadCallbacks() {
        this.loadStatus.callbacks = [];
    }
    callLoadStatusCallback(evt) {
        const { framesUpdated, framesProcessed, totalNumFrames } = evt;
        const { volumeId, reRenderFraction, loadStatus, metadata } = this;
        const { FrameOfReferenceUID } = metadata;
        if (this.autoRenderOnLoad) {
            if (framesUpdated > this.reRenderTarget ||
                framesProcessed === totalNumFrames) {
                this.reRenderTarget += reRenderFraction;
                helpers_autoLoad(volumeId);
            }
        }
        if (framesProcessed === totalNumFrames) {
            loadStatus.callbacks.forEach((callback) => callback(evt));
            const eventDetail = {
                FrameOfReferenceUID,
                volumeId: volumeId,
            };
            (0,esm.triggerEvent)(esm.eventTarget, esm.Enums.Events.IMAGE_VOLUME_LOADING_COMPLETED, eventDetail);
        }
    }
    updateTextureAndTriggerEvents(imageIdIndex, imageId, imageQualityStatus = ImageQualityStatus.FULL_RESOLUTION) {
        const frameIndex = this.imageIdIndexToFrameIndex(imageIdIndex);
        const { cachedFrames, numFrames, totalNumFrames } = this;
        const { FrameOfReferenceUID } = this.metadata;
        const currentStatus = cachedFrames[frameIndex];
        if (currentStatus > imageQualityStatus) {
            return;
        }
        if (cachedFrames[frameIndex] === ImageQualityStatus.FULL_RESOLUTION) {
            return;
        }
        const complete = imageQualityStatus === ImageQualityStatus.FULL_RESOLUTION;
        cachedFrames[imageIdIndex] = imageQualityStatus;
        this.framesUpdated++;
        if (complete) {
            this.framesLoaded++;
            this.framesProcessed++;
        }
        this.vtkOpenGLTexture.setUpdatedFrame(frameIndex);
        this.imageData.modified();
        const eventDetail = {
            FrameOfReferenceUID,
            imageVolume: this,
            numberOfFrames: numFrames,
            framesProcessed: this.framesProcessed,
        };
        (0,esm.triggerEvent)(esm.eventTarget, esm.Enums.Events.IMAGE_VOLUME_MODIFIED, eventDetail);
        if (complete && this.framesProcessed === this.totalNumFrames) {
            this.loadStatus.loaded = true;
            this.loadStatus.loading = false;
        }
        this.callLoadStatusCallback({
            success: true,
            imageIdIndex,
            imageId,
            framesLoaded: this.framesLoaded,
            framesProcessed: this.framesProcessed,
            framesUpdated: this.framesUpdated,
            numFrames,
            totalNumFrames,
            complete,
            imageQualityStatus,
        });
        if (this.loadStatus.loaded) {
            this.loadStatus.callbacks = [];
        }
    }
    successCallback(imageId, image) {
        const imageIdIndex = this.getImageIdIndex(imageId);
        const options = this.getLoaderImageOptions(imageId);
        const scalarData = this.getScalarDataByImageIdIndex(imageIdIndex);
        handleArrayBufferLoad(scalarData, image, options);
        const { scalingParameters } = image.preScale || {};
        const { imageQualityStatus } = image;
        const frameIndex = this.imageIdIndexToFrameIndex(imageIdIndex);
        const cachedImage = esm.cache.getCachedImageBasedOnImageURI(imageId);
        const cachedVolume = esm.cache.getVolumeContainingImageId(imageId);
        if (this.loadStatus.cancelled) {
            console.warn('volume load cancelled, returning for imageIdIndex: ', imageIdIndex);
            return;
        }
        if (!cachedImage && !(cachedVolume && cachedVolume.volume !== this)) {
            return this.updateTextureAndTriggerEvents(imageIdIndex, imageId, imageQualityStatus);
        }
        const isFromImageCache = !!cachedImage;
        if (isFromImageCache && options.targetBuffer) {
            this.imageCacheOffsetMap.set(imageId, {
                imageIdIndex,
                frameIndex,
                offset: options.targetBuffer?.offset || 0,
                length: options.targetBuffer?.length,
            });
        }
        const cachedImageOrVolume = cachedImage || cachedVolume.volume;
        this.handleImageComingFromCache(cachedImageOrVolume, isFromImageCache, scalingParameters, scalarData, frameIndex, scalarData.buffer, imageIdIndex, imageId);
    }
    errorCallback(imageId, permanent, error) {
        if (!permanent) {
            return;
        }
        const { totalNumFrames, numFrames } = this;
        const imageIdIndex = this.getImageIdIndex(imageId);
        this.framesProcessed++;
        if (this.framesProcessed === totalNumFrames) {
            this.loadStatus.loaded = true;
            this.loadStatus.loading = false;
        }
        this.callLoadStatusCallback({
            success: false,
            imageId,
            imageIdIndex,
            error,
            framesLoaded: this.framesLoaded,
            framesProcessed: this.framesProcessed,
            framesUpdated: this.framesUpdated,
            numFrames,
            totalNumFrames,
        });
        if (this.loadStatus.loaded) {
            this.loadStatus.callbacks = [];
        }
        const eventDetail = {
            error,
            imageIdIndex,
            imageId,
        };
        (0,esm.triggerEvent)(esm.eventTarget, esm.Enums.Events.IMAGE_LOAD_ERROR, eventDetail);
    }
    getLoaderImageOptions(imageId) {
        const { transferSyntaxUID: transferSyntaxUID } = esm.metaData.get('transferSyntax', imageId) || {};
        const imagePlaneModule = esm.metaData.get('imagePlaneModule', imageId) || {};
        const { rows, columns } = imagePlaneModule;
        const imageIdIndex = this.getImageIdIndex(imageId);
        const scalarData = this.getScalarDataByImageIdIndex(imageIdIndex);
        if (!scalarData) {
            return null;
        }
        const arrayBuffer = scalarData.buffer;
        const { type, length, lengthInBytes } = getScalarDataType(scalarData, this.numFrames);
        const modalityLutModule = esm.metaData.get('modalityLutModule', imageId) || {};
        const generalSeriesModule = esm.metaData.get('generalSeriesModule', imageId) || {};
        const scalingParameters = {
            rescaleSlope: modalityLutModule.rescaleSlope,
            rescaleIntercept: modalityLutModule.rescaleIntercept,
            modality: generalSeriesModule.modality,
        };
        if (scalingParameters.modality === 'PT') {
            const suvFactor = esm.metaData.get('scalingModule', imageId);
            if (suvFactor) {
                this._addScalingToVolume(suvFactor);
                scalingParameters.suvbw = suvFactor.suvbw;
            }
        }
        const floatAfterScale = hasFloatScalingParameters(scalingParameters);
        const allowFloatRendering = (0,esm.canRenderFloatTextures)();
        this.isPreScaled = true;
        if (scalingParameters &&
            scalingParameters.rescaleSlope !== undefined &&
            scalingParameters.rescaleIntercept !== undefined) {
            const { rescaleSlope, rescaleIntercept } = scalingParameters;
            this.isPreScaled =
                typeof rescaleSlope === 'number' &&
                    typeof rescaleIntercept === 'number';
        }
        if (!allowFloatRendering && floatAfterScale) {
            this.isPreScaled = false;
        }
        const frameIndex = this.imageIdIndexToFrameIndex(imageIdIndex);
        return {
            targetBuffer: {
                arrayBuffer: arrayBuffer instanceof ArrayBuffer ? undefined : arrayBuffer,
                offset: frameIndex * lengthInBytes,
                length,
                type,
                rows,
                columns,
            },
            skipCreateImage: true,
            allowFloatRendering,
            preScale: {
                enabled: this.isPreScaled,
                scalingParameters,
            },
            transferPixelData: true,
            transferSyntaxUID,
            loader: esm.imageLoader.loadImage,
            additionalDetails: {
                imageId,
                imageIdIndex,
                volumeId: this.volumeId,
            },
        };
    }
    callLoadImage(imageId, imageIdIndex, options) {
        const { cachedFrames } = this;
        if (cachedFrames[imageIdIndex] === ImageQualityStatus.FULL_RESOLUTION) {
            return;
        }
        const uncompressedIterator = ProgressiveIterator.as(esm.imageLoader.loadImage(imageId, options));
        return uncompressedIterator.forEach((image) => {
            this.successCallback(imageId, image);
        }, this.errorCallback.bind(this, imageIdIndex, imageId));
    }
    getImageIdsRequests(imageIds, priorityDefault) {
        this.totalNumFrames = this.imageIds.length;
        const autoRenderPercentage = 2;
        if (this.autoRenderOnLoad) {
            this.reRenderFraction =
                this.totalNumFrames * (autoRenderPercentage / 100);
            this.reRenderTarget = this.reRenderFraction;
        }
        const requests = imageIds.map((imageId) => {
            const imageIdIndex = this.getImageIdIndex(imageId);
            const requestType = requestTypeDefault;
            const priority = priorityDefault;
            const options = this.getLoaderImageOptions(imageId);
            return {
                callLoadImage: this.callLoadImage.bind(this),
                imageId,
                imageIdIndex,
                options,
                priority,
                requestType,
                additionalDetails: {
                    volumeId: this.volumeId,
                },
            };
        });
        return requests;
    }
    handleImageComingFromCache(cachedImageOrVolume, isFromImageCache, scalingParameters, scalarData, frameIndex, arrayBuffer, imageIdIndex, imageId) {
        const imageLoadObject = isFromImageCache
            ? cachedImageOrVolume.imageLoadObject
            : cachedImageOrVolume.convertToCornerstoneImage(imageId, imageIdIndex);
        imageLoadObject.promise
            .then((cachedImage) => {
            const imageScalarData = this._scaleIfNecessary(cachedImage, scalingParameters);
            const { pixelsPerImage, bytesPerImage } = this.cornerstoneImageMetaData;
            const TypedArray = scalarData.constructor;
            let byteOffset = bytesPerImage * frameIndex;
            const bytePerPixel = bytesPerImage / pixelsPerImage;
            if (scalarData.BYTES_PER_ELEMENT !== bytePerPixel) {
                byteOffset *= scalarData.BYTES_PER_ELEMENT / bytePerPixel;
            }
            const volumeBufferView = new TypedArray(arrayBuffer, byteOffset, pixelsPerImage);
            volumeBufferView.set(imageScalarData);
            this.updateTextureAndTriggerEvents(imageIdIndex, imageId, cachedImage.imageQualityStatus);
        })
            .catch((err) => {
            this.errorCallback(imageId, true, err);
        });
    }
    getImageLoadRequests(_priority) {
        throw new Error('Abstract method');
    }
    getImageIdsToLoad() {
        throw new Error('Abstract method');
    }
    loadImages(imageIds, listener) {
        this.loadStatus.loading = true;
        const requests = this.getImageLoadRequests(5);
        requests.reverse().forEach((request) => {
            if (!request) {
                return;
            }
            const { callLoadImage, imageId, imageIdIndex, options, priority, requestType, additionalDetails, } = request;
            esm.imageLoadPoolManager.addRequest(callLoadImage.bind(this, imageId, imageIdIndex, options), requestType, additionalDetails, priority);
        });
        return Promise.resolve(true);
    }
    _prefetchImageIds() {
        this.loadStatus.loading = true;
        const imageIds = [...this.getImageIdsToLoad()];
        imageIds.reverse();
        this.totalNumFrames = this.imageIds.length;
        const autoRenderPercentage = 2;
        if (this.autoRenderOnLoad) {
            this.reRenderFraction =
                this.totalNumFrames * (autoRenderPercentage / 100);
            this.reRenderTarget = this.reRenderFraction;
        }
        return this.imagesLoader.loadImages(imageIds, this).catch((e) => {
            console.debug('progressive loading failed to complete', e);
        });
    }
    _scaleIfNecessary(image, scalingParametersToUse) {
        if (!image.preScale?.enabled) {
            return image.getPixelData().slice(0);
        }
        const imageIsAlreadyScaled = image.preScale?.scaled;
        const noScalingParametersToUse = !scalingParametersToUse ||
            !scalingParametersToUse.rescaleIntercept ||
            !scalingParametersToUse.rescaleSlope;
        if (!imageIsAlreadyScaled && noScalingParametersToUse) {
            return image.getPixelData().slice(0);
        }
        if (!imageIsAlreadyScaled &&
            scalingParametersToUse &&
            scalingParametersToUse.rescaleIntercept !== undefined &&
            scalingParametersToUse.rescaleSlope !== undefined) {
            const pixelDataCopy = image.getPixelData().slice(0);
            const scaledArray = scaleArray(pixelDataCopy, scalingParametersToUse);
            return scaledArray;
        }
        const { rescaleSlope: rescaleSlopeToUse, rescaleIntercept: rescaleInterceptToUse, suvbw: suvbwToUse, } = scalingParametersToUse;
        const { rescaleSlope: rescaleSlopeUsed, rescaleIntercept: rescaleInterceptUsed, suvbw: suvbwUsed, } = image.preScale.scalingParameters;
        const rescaleSlopeIsSame = rescaleSlopeToUse === rescaleSlopeUsed;
        const rescaleInterceptIsSame = rescaleInterceptToUse === rescaleInterceptUsed;
        const suvbwIsSame = suvbwToUse === suvbwUsed;
        if (rescaleSlopeIsSame && rescaleInterceptIsSame && suvbwIsSame) {
            return image.getPixelData();
        }
        const pixelDataCopy = image.getPixelData().slice(0);
        const newSuvbw = suvbwToUse / suvbwUsed;
        const newRescaleSlope = rescaleSlopeToUse / rescaleSlopeUsed;
        const newRescaleIntercept = rescaleInterceptToUse - rescaleInterceptUsed * newRescaleSlope;
        const newScalingParameters = {
            ...scalingParametersToUse,
            rescaleSlope: newRescaleSlope,
            rescaleIntercept: newRescaleIntercept,
            suvbw: newSuvbw,
        };
        const scaledArray = scaleArray(pixelDataCopy, newScalingParameters);
        return scaledArray;
    }
    _addScalingToVolume(suvFactor) {
        if (this.scaling) {
            return;
        }
        const { suvbw, suvlbm, suvbsa } = suvFactor;
        const petScaling = {};
        if (suvlbm) {
            petScaling.suvbwToSuvlbm = suvlbm / suvbw;
        }
        if (suvbsa) {
            petScaling.suvbwToSuvbsa = suvbsa / suvbw;
        }
        if (suvbw) {
            petScaling.suvbw = suvbw;
        }
        this.scaling = { PT: petScaling };
    }
}
function getScalarDataType(scalarData, numFrames) {
    let type, byteSize;
    if (scalarData instanceof Uint8Array) {
        type = 'Uint8Array';
        byteSize = 1;
    }
    else if (scalarData instanceof Float32Array) {
        type = 'Float32Array';
        byteSize = 4;
    }
    else if (scalarData instanceof Uint16Array) {
        type = 'Uint16Array';
        byteSize = 2;
    }
    else if (scalarData instanceof Int16Array) {
        type = 'Int16Array';
        byteSize = 2;
    }
    else {
        throw new Error('Unsupported array type');
    }
    const length = scalarData.length / numFrames;
    const lengthInBytes = length * byteSize;
    return { type, byteSize, length, lengthInBytes };
}
function handleArrayBufferLoad(scalarData, image, options) {
    if (!(scalarData.buffer instanceof ArrayBuffer)) {
        return;
    }
    const offset = options.targetBuffer.offset;
    const length = options.targetBuffer.length;
    const pixelData = image.pixelData ? image.pixelData : image.getPixelData();
    try {
        if (scalarData instanceof Float32Array) {
            const bytesInFloat = 4;
            const floatView = new Float32Array(pixelData);
            if (floatView.length !== length) {
                throw 'Error pixelData length does not match frame length';
            }
            scalarData.set(floatView, offset / bytesInFloat);
        }
        if (scalarData instanceof Int16Array) {
            const bytesInInt16 = 2;
            const intView = new Int16Array(pixelData);
            if (intView.length !== length) {
                throw 'Error pixelData length does not match frame length';
            }
            scalarData.set(intView, offset / bytesInInt16);
        }
        if (scalarData instanceof Uint16Array) {
            const bytesInUint16 = 2;
            const intView = new Uint16Array(pixelData);
            if (intView.length !== length) {
                throw 'Error pixelData length does not match frame length';
            }
            scalarData.set(intView, offset / bytesInUint16);
        }
        if (scalarData instanceof Uint8Array) {
            const bytesInUint8 = 1;
            const intView = new Uint8Array(pixelData);
            if (intView.length !== length) {
                throw 'Error pixelData length does not match frame length';
            }
            scalarData.set(intView, offset / bytesInUint8);
        }
    }
    catch (e) {
        console.error(e);
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/StreamingImageVolume.js

class StreamingImageVolume extends BaseStreamingImageVolume {
    constructor(imageVolumeProperties, streamingProperties) {
        if (!imageVolumeProperties.imageIds) {
            imageVolumeProperties.imageIds = streamingProperties.imageIds;
        }
        super(imageVolumeProperties, streamingProperties);
        this.getImageIdsToLoad = () => {
            const { imageIds } = this;
            this.numFrames = imageIds.length;
            return imageIds;
        };
    }
    getScalarData() {
        return this.scalarData;
    }
    getImageLoadRequests(priority) {
        const { imageIds } = this;
        return this.getImageIdsRequests(imageIds, priority);
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/cornerstoneStreamingImageVolumeLoader.js


function cornerstoneStreamingImageVolumeLoader(volumeId, options) {
    if (!options || !options.imageIds || !options.imageIds.length) {
        throw new Error('ImageIds must be provided to create a streaming image volume');
    }
    async function getStreamingImageVolume() {
        if (options.imageIds[0].split(':')[0] === 'wadouri') {
            const [middleImageIndex, lastImageIndex] = [
                Math.floor(options.imageIds.length / 2),
                options.imageIds.length - 1,
            ];
            const indexesToPrefetch = [0, middleImageIndex, lastImageIndex];
            await Promise.all(indexesToPrefetch.map((index) => {
                return new Promise((resolve, reject) => {
                    const imageId = options.imageIds[index];
                    esm.imageLoadPoolManager.addRequest(async () => {
                        esm.imageLoader.loadImage(imageId)
                            .then(() => {
                            console.log(`Prefetched imageId: ${imageId}`);
                            resolve(true);
                        })
                            .catch((err) => {
                            reject(err);
                        });
                    }, esm.Enums.RequestType.Prefetch, { volumeId }, 1);
                });
            })).catch(console.error);
        }
        const { dimensions, spacing, origin, scalarData, direction, sizeInBytes, metadata, imageIds, } = esm.utilities.generateVolumePropsFromImageIds(options.imageIds, volumeId);
        const streamingImageVolume = new StreamingImageVolume({
            volumeId,
            metadata,
            dimensions,
            spacing,
            origin,
            direction,
            scalarData,
            sizeInBytes,
            imageIds,
        }, {
            imageIds,
            loadStatus: {
                loaded: false,
                loading: false,
                cancelled: false,
                cachedFrames: [],
                callbacks: [],
            },
        });
        return streamingImageVolume;
    }
    const streamingImageVolumePromise = getStreamingImageVolume();
    return {
        promise: streamingImageVolumePromise,
        decache: () => {
            streamingImageVolumePromise.then((streamingImageVolume) => {
                streamingImageVolume.destroy();
                streamingImageVolume = null;
            });
        },
        cancel: () => {
            streamingImageVolumePromise.then((streamingImageVolume) => {
                streamingImageVolume.cancelLoading();
            });
        },
    };
}
/* harmony default export */ const esm_cornerstoneStreamingImageVolumeLoader = (cornerstoneStreamingImageVolumeLoader);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/enums/Events.js
var Events;
(function (Events) {
    Events["DYNAMIC_VOLUME_TIME_POINT_INDEX_CHANGED"] = "DYNAMIC_VOLUME_TIME_POINT_INDEX_CHANGED";
})(Events || (Events = {}));
/* harmony default export */ const enums_Events = (Events);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/enums/index.js



;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/StreamingDynamicImageVolume.js



class StreamingDynamicImageVolume extends BaseStreamingImageVolume {
    constructor(imageVolumeProperties, streamingProperties) {
        StreamingDynamicImageVolume._ensureValidData(imageVolumeProperties, streamingProperties);
        super(imageVolumeProperties, streamingProperties);
        this._timePointIndex = 0;
        this._getTimePointRequests = (timePoint, priority) => {
            const { imageIds } = timePoint;
            return this.getImageIdsRequests(imageIds, priority);
        };
        this._getTimePointsRequests = (priority) => {
            const timePoints = this._getTimePointsToLoad();
            let timePointsRequests = [];
            timePoints.forEach((timePoint) => {
                const timePointRequests = this._getTimePointRequests(timePoint, priority);
                timePointsRequests = timePointsRequests.concat(timePointRequests);
            });
            return timePointsRequests;
        };
        this.getImageLoadRequests = (priority) => {
            return this._getTimePointsRequests(priority);
        };
        this._numTimePoints = this.scalarData.length;
        this._timePoints = this._getTimePointsData();
        this._splittingTag = imageVolumeProperties.splittingTag;
    }
    static _ensureValidData(imageVolumeProperties, streamingProperties) {
        const imageIds = streamingProperties.imageIds;
        const scalarDataArrays = (imageVolumeProperties.scalarData);
        if (imageIds.length % scalarDataArrays.length !== 0) {
            throw new Error(`Number of imageIds is not a multiple of ${scalarDataArrays.length}`);
        }
    }
    _getTimePointsData() {
        const { imageIds } = this;
        const scalarData = this.scalarData;
        const { numFrames } = this;
        const numTimePoints = scalarData.length;
        const timePoints = [];
        for (let i = 0; i < numTimePoints; i++) {
            const start = i * numFrames;
            const end = start + numFrames;
            timePoints.push({
                imageIds: imageIds.slice(start, end),
                scalarData: scalarData[i],
            });
        }
        return timePoints;
    }
    _getTimePointsToLoad() {
        const timePoints = this._timePoints;
        const initialTimePointIndex = this._timePointIndex;
        const timePointsToLoad = [timePoints[initialTimePointIndex]];
        let leftIndex = initialTimePointIndex - 1;
        let rightIndex = initialTimePointIndex + 1;
        while (leftIndex >= 0 || rightIndex < timePoints.length) {
            if (leftIndex >= 0) {
                timePointsToLoad.push(timePoints[leftIndex--]);
            }
            if (rightIndex < timePoints.length) {
                timePointsToLoad.push(timePoints[rightIndex++]);
            }
        }
        return timePointsToLoad;
    }
    getImageIdsToLoad() {
        const timePoints = this._getTimePointsToLoad();
        let imageIds = [];
        timePoints.forEach((timePoint) => {
            const { imageIds: timePointIds } = timePoint;
            imageIds = imageIds.concat(timePointIds);
        });
        return imageIds;
    }
    isDynamicVolume() {
        return true;
    }
    get timePointIndex() {
        return this._timePointIndex;
    }
    set timePointIndex(newTimePointIndex) {
        if (newTimePointIndex < 0 || newTimePointIndex >= this.numTimePoints) {
            throw new Error(`Invalid timePointIndex (${newTimePointIndex})`);
        }
        if (this._timePointIndex === newTimePointIndex) {
            return;
        }
        const { imageData } = this;
        this._timePointIndex = newTimePointIndex;
        imageData.getPointData().setActiveScalars(`timePoint-${newTimePointIndex}`);
        this.invalidateVolume(true);
        (0,esm.triggerEvent)(esm.eventTarget, enums_Events.DYNAMIC_VOLUME_TIME_POINT_INDEX_CHANGED, {
            volumeId: this.volumeId,
            timePointIndex: newTimePointIndex,
            numTimePoints: this.numTimePoints,
            splittingTag: this.splittingTag,
        });
    }
    get splittingTag() {
        return this._splittingTag;
    }
    get numTimePoints() {
        return this._numTimePoints;
    }
    getScalarData() {
        return this.scalarData[this._timePointIndex];
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/cornerstoneStreamingDynamicImageVolumeLoader.js


function get4DVolumeInfo(imageIds) {
    const { imageIdsGroups, splittingTag } = helpers_splitImageIdsBy4DTags(imageIds);
    return {
        volumesInfo: imageIdsGroups.map((imageIds) => getVolumeInfo(imageIds)),
        splittingTag,
    };
}
function cornerstoneStreamingDynamicImageVolumeLoader(volumeId, options) {
    if (!options || !options.imageIds || !options.imageIds.length) {
        throw new Error('ImageIds must be provided to create a 4D streaming image volume');
    }
    const { imageIds } = options;
    const { volumesInfo, splittingTag } = get4DVolumeInfo(imageIds);
    const { metadata: volumeMetadata, dimensions, spacing, origin, direction, sizeInBytes, } = volumesInfo[0];
    const sortedImageIdsArrays = [];
    const scalarDataArrays = [];
    volumesInfo.forEach((volumeInfo) => {
        sortedImageIdsArrays.push(volumeInfo.sortedImageIds);
        scalarDataArrays.push(volumeInfo.scalarData);
    });
    const sortedImageIds = sortedImageIdsArrays.flat();
    let streamingImageVolume = new StreamingDynamicImageVolume({
        volumeId,
        metadata: volumeMetadata,
        dimensions,
        spacing,
        origin,
        direction,
        scalarData: scalarDataArrays,
        sizeInBytes,
        imageIds: sortedImageIds,
        splittingTag,
    }, {
        imageIds: sortedImageIds,
        loadStatus: {
            loaded: false,
            loading: false,
            cancelled: false,
            cachedFrames: [],
            callbacks: [],
        },
    });
    return {
        promise: Promise.resolve(streamingImageVolume),
        decache: () => {
            streamingImageVolume.destroy();
            streamingImageVolume = null;
        },
        cancel: () => {
            streamingImageVolume.cancelLoading();
        },
    };
}
/* harmony default export */ const esm_cornerstoneStreamingDynamicImageVolumeLoader = (cornerstoneStreamingDynamicImageVolumeLoader);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/streaming-image-volume-loader/dist/esm/index.js






const helpers = {
    getDynamicVolumeInfo: helpers_getDynamicVolumeInfo,
};



/***/ })

}]);