(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([[117,483],{

/***/ 25271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
async function addImageSlicesToViewports(renderingEngine, stackInputs, viewportIds) {
    for (const viewportId of viewportIds) {
        const viewport = renderingEngine.getViewport(viewportId);
        if (!viewport) {
            throw new Error(`Viewport with Id ${viewportId} does not exist`);
        }
        if (!viewport.addImages) {
            console.warn(`Viewport with Id ${viewportId} does not have addImages. Cannot add image segmentation to this viewport.`);
            return;
        }
    }
    const addStackPromises = viewportIds.map(async (viewportId) => {
        const viewport = renderingEngine.getViewport(viewportId);
        return viewport.addImages(stackInputs);
    });
    await Promise.all(addStackPromises);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addImageSlicesToViewports);


/***/ }),

/***/ 74260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _BaseVolumeViewport__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6203);

async function addVolumesToViewports(renderingEngine, volumeInputs, viewportIds, immediateRender = false, suppressEvents = false) {
    for (const viewportId of viewportIds) {
        const viewport = renderingEngine.getViewport(viewportId);
        if (!viewport) {
            throw new Error(`Viewport with Id ${viewportId} does not exist`);
        }
        if (!(viewport instanceof _BaseVolumeViewport__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)) {
            console.warn(`Viewport with Id ${viewportId} is not a BaseVolumeViewport. Cannot add volume to this viewport.`);
            return;
        }
    }
    const addVolumePromises = viewportIds.map(async (viewportId) => {
        const viewport = renderingEngine.getViewport(viewportId);
        await viewport.addVolumes(volumeInputs, immediateRender, suppressEvents);
    });
    await Promise.all(addVolumePromises);
    return;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addVolumesToViewports);


/***/ }),

/***/ 78988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Settings)
/* harmony export */ });
const DEFAULT_SETTINGS = Symbol('DefaultSettings');
const RUNTIME_SETTINGS = Symbol('RuntimeSettings');
const OBJECT_SETTINGS_MAP = Symbol('ObjectSettingsMap');
const DICTIONARY = Symbol('Dictionary');
class Settings {
    constructor(base) {
        const dictionary = Object.create((base instanceof Settings && DICTIONARY in base
            ? base[DICTIONARY]
            : null));
        Object.seal(Object.defineProperty(this, DICTIONARY, {
            value: dictionary,
        }));
    }
    set(key, value) {
        return set(this[DICTIONARY], key, value, null);
    }
    get(key) {
        return get(this[DICTIONARY], key);
    }
    unset(key) {
        return unset(this[DICTIONARY], key + '');
    }
    forEach(callback) {
        iterate(this[DICTIONARY], callback);
    }
    extend() {
        return new Settings(this);
    }
    import(root) {
        if (isPlainObject(root)) {
            Object.keys(root).forEach((key) => {
                set(this[DICTIONARY], key, root[key], null);
            });
        }
    }
    dump() {
        const context = {};
        iterate(this[DICTIONARY], (key, value) => {
            if (typeof value !== 'undefined') {
                deepSet(context, key, value);
            }
        });
        return context;
    }
    static assert(subject) {
        return subject instanceof Settings
            ? subject
            : Settings.getRuntimeSettings();
    }
    static getDefaultSettings(subfield = null) {
        let defaultSettings = Settings[DEFAULT_SETTINGS];
        if (!(defaultSettings instanceof Settings)) {
            defaultSettings = new Settings();
            Settings[DEFAULT_SETTINGS] = defaultSettings;
        }
        if (subfield) {
            const settingObj = {};
            defaultSettings.forEach((name) => {
                if (name.startsWith(subfield)) {
                    const setting = name.split(`${subfield}.`)[1];
                    settingObj[setting] = defaultSettings.get(name);
                }
            });
            return settingObj;
        }
        return defaultSettings;
    }
    static getRuntimeSettings() {
        let runtimeSettings = Settings[RUNTIME_SETTINGS];
        if (!(runtimeSettings instanceof Settings)) {
            runtimeSettings = new Settings(Settings.getDefaultSettings());
            Settings[RUNTIME_SETTINGS] = runtimeSettings;
        }
        return runtimeSettings;
    }
    static getObjectSettings(subject, from) {
        let settings = null;
        if (subject instanceof Settings) {
            settings = subject;
        }
        else if (typeof subject === 'object' && subject !== null) {
            let objectSettingsMap = Settings[OBJECT_SETTINGS_MAP];
            if (!(objectSettingsMap instanceof WeakMap)) {
                objectSettingsMap = new WeakMap();
                Settings[OBJECT_SETTINGS_MAP] = objectSettingsMap;
            }
            settings = objectSettingsMap.get(subject);
            if (!(settings instanceof Settings)) {
                settings = new Settings(Settings.assert(Settings.getObjectSettings(from)));
                objectSettingsMap.set(subject, settings);
            }
        }
        return settings;
    }
    static extendRuntimeSettings() {
        return Settings.getRuntimeSettings().extend();
    }
}
function unset(dictionary, name) {
    if (name.endsWith('.')) {
        let deleteCount = 0;
        const namespace = name;
        const base = namespace.slice(0, -1);
        const deleteAll = base.length === 0;
        for (const key in dictionary) {
            if (Object.prototype.hasOwnProperty.call(dictionary, key) &&
                (deleteAll || key.startsWith(namespace) || key === base)) {
                delete dictionary[key];
                ++deleteCount;
            }
        }
        return deleteCount > 0;
    }
    return delete dictionary[name];
}
function iterate(dictionary, callback) {
    for (const key in dictionary) {
        callback(key, dictionary[key]);
    }
}
function setAll(dictionary, prefix, record, references) {
    let failCount;
    if (references.has(record)) {
        return set(dictionary, prefix, null, references);
    }
    references.add(record);
    failCount = 0;
    for (const field in record) {
        if (Object.prototype.hasOwnProperty.call(record, field)) {
            const key = field.length === 0 ? prefix : `${prefix}.${field}`;
            if (!set(dictionary, key, record[field], references)) {
                ++failCount;
            }
        }
    }
    references.delete(record);
    return failCount === 0;
}
function set(dictionary, key, value, references) {
    if (isValidKey(key)) {
        if (isPlainObject(value)) {
            return setAll(dictionary, key, value, references instanceof WeakSet ? references : new WeakSet());
        }
        dictionary[key] = value;
        return true;
    }
    return false;
}
function get(dictionary, key) {
    return dictionary[key];
}
function isValidKey(key) {
    let last, current, previous;
    if (typeof key !== 'string' || (last = key.length - 1) < 0) {
        return false;
    }
    previous = -1;
    while ((current = key.indexOf('.', previous + 1)) >= 0) {
        if (current - previous < 2 || current === last) {
            return false;
        }
        previous = current;
    }
    return true;
}
function isPlainObject(subject) {
    if (typeof subject === 'object' && subject !== null) {
        const prototype = Object.getPrototypeOf(subject);
        if (prototype === Object.prototype || prototype === null) {
            return true;
        }
    }
    return false;
}
function deepSet(context, key, value) {
    const separator = key.indexOf('.');
    if (separator >= 0) {
        const subKey = key.slice(0, separator);
        let subContext = context[subKey];
        if (typeof subContext !== 'object' || subContext === null) {
            const subContextValue = subContext;
            subContext = {};
            if (typeof subContextValue !== 'undefined') {
                subContext[''] = subContextValue;
            }
            context[subKey] = subContext;
        }
        deepSet(subContext, key.slice(separator + 1, key.length), value);
    }
    else {
        context[key] = value;
    }
}
Settings.getDefaultSettings().set('useCursors', true);


/***/ }),

/***/ 88903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  EPSILON: () => (/* reexport */ epsilon),
  MPR_CAMERA_VALUES: () => (/* reexport */ mprCameraValues/* default */.A),
  RENDERING_DEFAULTS: () => (/* reexport */ rendering),
  VIEWPORT_PRESETS: () => (/* reexport */ viewportPresets/* default */.A)
});

// UNUSED EXPORTS: BACKGROUND_COLORS, CPU_COLORMAPS

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/cpuColormaps.js
var cpuColormaps = __webpack_require__(21301);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/rendering.js
const RENDERING_DEFAULTS = {
    MINIMUM_SLAB_THICKNESS: 5e-2,
    MAXIMUM_RAY_DISTANCE: 1e6,
};
Object.freeze(RENDERING_DEFAULTS);
/* harmony default export */ const rendering = (RENDERING_DEFAULTS);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/epsilon.js
const EPSILON = 1e-3;
/* harmony default export */ const epsilon = (EPSILON);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/mprCameraValues.js + 1 modules
var mprCameraValues = __webpack_require__(99753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/viewportPresets.js
var viewportPresets = __webpack_require__(59845);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/backgroundColors.js
var backgroundColors = __webpack_require__(61507);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/index.js









/***/ }),

/***/ 15453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var RequestType;
(function (RequestType) {
    RequestType["Interaction"] = "interaction";
    RequestType["Thumbnail"] = "thumbnail";
    RequestType["Prefetch"] = "prefetch";
    RequestType["Compute"] = "compute";
})(RequestType || (RequestType = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RequestType);


/***/ }),

/***/ 17702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ViewportStatus;
(function (ViewportStatus) {
    ViewportStatus["NO_DATA"] = "noData";
    ViewportStatus["LOADING"] = "loading";
    ViewportStatus["PRE_RENDER"] = "preRender";
    ViewportStatus["RESIZE"] = "resize";
    ViewportStatus["RENDERED"] = "rendered";
})(ViewportStatus || (ViewportStatus = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ViewportStatus);


/***/ }),

/***/ 98362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BlendModes: () => (/* reexport */ enums_BlendModes),
  CalibrationTypes: () => (/* reexport */ enums_CalibrationTypes),
  DynamicOperatorType: () => (/* reexport */ enums_DynamicOperatorType),
  Events: () => (/* reexport */ Events/* default */.A),
  GeometryType: () => (/* reexport */ enums_GeometryType),
  ImageQualityStatus: () => (/* reexport */ ImageQualityStatus/* default */.A),
  InterpolationType: () => (/* reexport */ InterpolationType/* default */.A),
  MetadataModules: () => (/* reexport */ MetadataModules/* default */.A),
  OrientationAxis: () => (/* reexport */ OrientationAxis/* default */.A),
  RequestType: () => (/* reexport */ RequestType/* default */.A),
  SharedArrayBufferModes: () => (/* reexport */ SharedArrayBufferModes/* default */.A),
  VOILUTFunctionType: () => (/* reexport */ VOILUTFunctionType/* default */.A),
  VideoEnums: () => (/* reexport */ VideoEnums),
  ViewportStatus: () => (/* reexport */ ViewportStatus/* default */.A),
  ViewportType: () => (/* reexport */ ViewportType/* default */.A)
});

// UNUSED EXPORTS: ContourType

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/Events.js
var Events = __webpack_require__(11731);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/RequestType.js
var RequestType = __webpack_require__(15453);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ViewportType.js
var ViewportType = __webpack_require__(21432);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/InterpolationType.js
var InterpolationType = __webpack_require__(67342);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Rendering/Core/VolumeMapper/Constants.js
var Constants = __webpack_require__(16265);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/BlendModes.js

const { BlendMode } = Constants/* default */.Ay;
var BlendModes;
(function (BlendModes) {
    BlendModes[BlendModes["COMPOSITE"] = 0] = "COMPOSITE";
    BlendModes[BlendModes["MAXIMUM_INTENSITY_BLEND"] = 1] = "MAXIMUM_INTENSITY_BLEND";
    BlendModes[BlendModes["MINIMUM_INTENSITY_BLEND"] = 2] = "MINIMUM_INTENSITY_BLEND";
    BlendModes[BlendModes["AVERAGE_INTENSITY_BLEND"] = 3] = "AVERAGE_INTENSITY_BLEND";
})(BlendModes || (BlendModes = {}));
/* harmony default export */ const enums_BlendModes = (BlendModes);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/OrientationAxis.js
var OrientationAxis = __webpack_require__(45919);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/SharedArrayBufferModes.js
var SharedArrayBufferModes = __webpack_require__(38698);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/GeometryType.js
var GeometryType;
(function (GeometryType) {
    GeometryType["CONTOUR"] = "contour";
    GeometryType["SURFACE"] = "Surface";
})(GeometryType || (GeometryType = {}));
/* harmony default export */ const enums_GeometryType = (GeometryType);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ContourType.js
var ContourType = __webpack_require__(99842);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/VOILUTFunctionType.js
var VOILUTFunctionType = __webpack_require__(15381);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/DynamicOperatorType.js
var DynamicOperatorType;
(function (DynamicOperatorType) {
    DynamicOperatorType["SUM"] = "SUM";
    DynamicOperatorType["AVERAGE"] = "AVERAGE";
    DynamicOperatorType["SUBTRACT"] = "SUBTRACT";
})(DynamicOperatorType || (DynamicOperatorType = {}));
/* harmony default export */ const enums_DynamicOperatorType = (DynamicOperatorType);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/CalibrationTypes.js
var CalibrationTypes;
(function (CalibrationTypes) {
    CalibrationTypes["NOT_APPLICABLE"] = "";
    CalibrationTypes["ERMF"] = "ERMF";
    CalibrationTypes["USER"] = "User";
    CalibrationTypes["PROJECTION"] = "Proj";
    CalibrationTypes["REGION"] = "Region";
    CalibrationTypes["ERROR"] = "Error";
    CalibrationTypes["UNCALIBRATED"] = "Uncalibrated";
})(CalibrationTypes || (CalibrationTypes = {}));
/* harmony default export */ const enums_CalibrationTypes = (CalibrationTypes);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ViewportStatus.js
var ViewportStatus = __webpack_require__(17702);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ImageQualityStatus.js
var ImageQualityStatus = __webpack_require__(89426);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/VideoEnums.js
var VideoEnums = __webpack_require__(49465);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/MetadataModules.js
var MetadataModules = __webpack_require__(29354);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/index.js



















/***/ }),

/***/ 29870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (/* binding */ getEnabledElement),
/* harmony export */   b1: () => (/* binding */ getEnabledElementByIds),
/* harmony export */   yj: () => (/* binding */ getEnabledElementByViewportId),
/* harmony export */   zb: () => (/* binding */ getEnabledElements)
/* harmony export */ });
/* harmony import */ var _RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49184);

function getEnabledElement(element) {
    if (!element) {
        return;
    }
    const { viewportUid, renderingEngineUid } = element.dataset;
    return getEnabledElementByIds(viewportUid, renderingEngineUid);
}
function getEnabledElementByIds(viewportId, renderingEngineId) {
    if (!renderingEngineId || !viewportId) {
        return;
    }
    const renderingEngine = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Ay)(renderingEngineId);
    if (!renderingEngine || renderingEngine.hasBeenDestroyed) {
        return;
    }
    const viewport = renderingEngine.getViewport(viewportId);
    if (!viewport) {
        return;
    }
    const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
    return {
        viewport,
        renderingEngine,
        viewportId,
        renderingEngineId,
        FrameOfReferenceUID,
    };
}
function getEnabledElementByViewportId(viewportId) {
    const renderingEngines = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* .getRenderingEngines */ .qO)();
    for (let i = 0; i < renderingEngines.length; i++) {
        const renderingEngine = renderingEngines[i];
        const viewport = renderingEngine.getViewport(viewportId);
        if (viewport) {
            return getEnabledElementByIds(viewportId, renderingEngine.id);
        }
    }
}
function getEnabledElements() {
    const enabledElements = [];
    const renderingEngines = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* .getRenderingEngines */ .qO)();
    renderingEngines.forEach((renderingEngine) => {
        const viewports = renderingEngine.getViewports();
        viewports.forEach(({ element }) => {
            enabledElements.push(getEnabledElement(element));
        });
    });
    return enabledElements;
}


/***/ }),

/***/ 79220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cancelLoadAll: () => (/* binding */ cancelLoadAll),
/* harmony export */   cancelLoadImage: () => (/* binding */ cancelLoadImage),
/* harmony export */   cancelLoadImages: () => (/* binding */ cancelLoadImages),
/* harmony export */   createAndCacheDerivedImage: () => (/* binding */ createAndCacheDerivedImage),
/* harmony export */   createAndCacheDerivedImages: () => (/* binding */ createAndCacheDerivedImages),
/* harmony export */   createAndCacheDerivedSegmentationImage: () => (/* binding */ createAndCacheDerivedSegmentationImage),
/* harmony export */   createAndCacheDerivedSegmentationImages: () => (/* binding */ createAndCacheDerivedSegmentationImages),
/* harmony export */   createAndCacheLocalImage: () => (/* binding */ createAndCacheLocalImage),
/* harmony export */   loadAndCacheImage: () => (/* binding */ loadAndCacheImage),
/* harmony export */   loadAndCacheImages: () => (/* binding */ loadAndCacheImages),
/* harmony export */   loadImage: () => (/* binding */ loadImage),
/* harmony export */   registerImageLoader: () => (/* binding */ registerImageLoader),
/* harmony export */   registerUnknownImageLoader: () => (/* binding */ registerUnknownImageLoader),
/* harmony export */   unregisterAllImageLoaders: () => (/* binding */ unregisterAllImageLoaders)
/* harmony export */ });
/* harmony import */ var _cache_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25534);
/* harmony import */ var _cache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13320);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11731);
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51884);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35678);
/* harmony import */ var _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(775);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92136);







const imageLoaders = {};
let unknownImageLoader;
function loadImageFromImageLoader(imageId, options) {
    const colonIndex = imageId.indexOf(':');
    const scheme = imageId.substring(0, colonIndex);
    const loader = imageLoaders[scheme];
    if (loader === undefined || loader === null) {
        if (unknownImageLoader !== undefined) {
            return unknownImageLoader(imageId);
        }
        throw new Error('loadImageFromImageLoader: no image loader for imageId');
    }
    const imageLoadObject = loader(imageId, options);
    imageLoadObject.promise.then(function (image) {
        (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.triggerEvent)(_eventTarget__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.IMAGE_LOADED, { image });
    }, function (error) {
        const errorObject = {
            imageId,
            error,
        };
        (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.triggerEvent)(_eventTarget__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.IMAGE_LOAD_FAILED, errorObject);
    });
    return imageLoadObject;
}
function loadImageFromCacheOrVolume(imageId, options) {
    if (options.ignoreCache) {
        return loadImageFromImageLoader(imageId, options);
    }
    let imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
    if (imageLoadObject !== undefined) {
        return imageLoadObject;
    }
    const cachedVolumeInfo = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getVolumeContainingImageId(imageId);
    if (cachedVolumeInfo?.volume?.loadStatus?.loaded) {
        const { volume, imageIdIndex } = cachedVolumeInfo;
        if (volume instanceof _cache__WEBPACK_IMPORTED_MODULE_1__/* .ImageVolume */ .QV) {
            imageLoadObject = volume.convertToCornerstoneImage(imageId, imageIdIndex);
        }
        return imageLoadObject;
    }
    const cachedImage = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getCachedImageBasedOnImageURI(imageId);
    if (cachedImage) {
        imageLoadObject = cachedImage.imageLoadObject;
        return imageLoadObject;
    }
    imageLoadObject = loadImageFromImageLoader(imageId, options);
    return imageLoadObject;
}
function loadImage(imageId, options = { priority: 0, requestType: 'prefetch' }) {
    if (imageId === undefined) {
        throw new Error('loadImage: parameter imageId must not be undefined');
    }
    return loadImageFromCacheOrVolume(imageId, options).promise;
}
function loadAndCacheImage(imageId, options = { priority: 0, requestType: 'prefetch' }) {
    if (imageId === undefined) {
        throw new Error('loadAndCacheImage: parameter imageId must not be undefined');
    }
    const imageLoadObject = loadImageFromCacheOrVolume(imageId, options);
    if (!_cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId)) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(imageId, imageLoadObject).catch((err) => {
            console.warn(err);
        });
    }
    return imageLoadObject.promise;
}
function loadAndCacheImages(imageIds, options = { priority: 0, requestType: 'prefetch' }) {
    if (!imageIds || imageIds.length === 0) {
        throw new Error('loadAndCacheImages: parameter imageIds must be list of image Ids');
    }
    const allPromises = imageIds.map((imageId) => {
        return loadAndCacheImage(imageId, options);
    });
    return allPromises;
}
function createAndCacheDerivedImage(referencedImageId, options = {}, preventCache = false) {
    if (referencedImageId === undefined) {
        throw new Error('createAndCacheDerivedImage: parameter imageId must not be undefined');
    }
    if (options.imageId === undefined) {
        options.imageId = `derived:${(0,_utilities__WEBPACK_IMPORTED_MODULE_4__.uuidv4)()}`;
    }
    const { imageId, skipCreateBuffer, onCacheAdd } = options;
    const imagePlaneModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePlaneModule', referencedImageId);
    const length = imagePlaneModule.rows * imagePlaneModule.columns;
    const { TypedArrayConstructor } = (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.getBufferConfiguration)(options.targetBufferType, length);
    const imageScalarData = new TypedArrayConstructor(skipCreateBuffer ? 1 : length);
    const derivedImageId = imageId;
    ['imagePlaneModule', 'generalSeriesModule'].forEach((type) => {
        _utilities__WEBPACK_IMPORTED_MODULE_4__.genericMetadataProvider.add(derivedImageId, {
            type,
            metadata: ___WEBPACK_IMPORTED_MODULE_6__.metaData.get(type, referencedImageId),
        });
    });
    const imagePixelModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePixelModule', referencedImageId);
    _utilities__WEBPACK_IMPORTED_MODULE_4__.genericMetadataProvider.add(derivedImageId, {
        type: 'imagePixelModule',
        metadata: {
            ...imagePixelModule,
            bitsAllocated: 8,
            bitsStored: 8,
            highBit: 7,
            samplesPerPixel: 1,
            pixelRepresentation: 0,
        },
    });
    const localImage = createAndCacheLocalImage({ scalarData: imageScalarData, onCacheAdd, skipCreateBuffer }, imageId, true);
    const imageLoadObject = {
        promise: Promise.resolve(localImage),
    };
    if (!preventCache) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(derivedImageId, imageLoadObject);
    }
    return imageLoadObject.promise;
}
function createAndCacheDerivedImages(referencedImageIds, options = {}) {
    if (referencedImageIds?.length === 0) {
        throw new Error('createAndCacheDerivedImages: parameter imageIds must be list of image Ids');
    }
    const derivedImageIds = [];
    const allPromises = referencedImageIds.map((referencedImageId) => {
        const newOptions = {
            imageId: options.getDerivedImageId?.(referencedImageId) || `derived:${(0,_utilities__WEBPACK_IMPORTED_MODULE_4__.uuidv4)()}`,
            ...options,
        };
        derivedImageIds.push(newOptions.imageId);
        return createAndCacheDerivedImage(referencedImageId, newOptions);
    });
    return { imageIds: derivedImageIds, promises: allPromises };
}
function createAndCacheLocalImage(options, imageId, preventCache = false) {
    const imagePlaneModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePlaneModule', imageId);
    const length = imagePlaneModule.rows * imagePlaneModule.columns;
    const image = {
        imageId: imageId,
        intercept: 0,
        windowCenter: 0,
        windowWidth: 0,
        color: false,
        numComps: 1,
        slope: 1,
        minPixelValue: 0,
        maxPixelValue: 255,
        voiLUTFunction: undefined,
        rows: imagePlaneModule.rows,
        columns: imagePlaneModule.columns,
        getCanvas: undefined,
        height: imagePlaneModule.rows,
        width: imagePlaneModule.columns,
        rgba: undefined,
        columnPixelSpacing: imagePlaneModule.columnPixelSpacing,
        rowPixelSpacing: imagePlaneModule.rowPixelSpacing,
        invert: false,
    };
    if (options.scalarData) {
        const imageScalarData = options.scalarData;
        if (!(imageScalarData instanceof Uint8Array ||
            imageScalarData instanceof Float32Array ||
            imageScalarData instanceof Uint16Array ||
            imageScalarData instanceof Int16Array)) {
            throw new Error('To use createLocalVolume you should pass scalarData of type Uint8Array, Uint16Array, Int16Array or Float32Array');
        }
        image.sizeInBytes = imageScalarData.byteLength;
        image.getPixelData = () => imageScalarData;
    }
    else if (options.skipCreateBuffer !== true) {
        const { numBytes, TypedArrayConstructor } = (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.getBufferConfiguration)(options.targetBufferType, length);
        const imageScalarData = new TypedArrayConstructor(length);
        image.sizeInBytes = numBytes;
        image.getPixelData = () => imageScalarData;
    }
    options.onCacheAdd?.(image);
    const imageLoadObject = {
        promise: Promise.resolve(image),
    };
    if (!preventCache) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(image.imageId, imageLoadObject);
    }
    return image;
}
function cancelLoadImage(imageId) {
    const filterFunction = ({ additionalDetails }) => {
        if (additionalDetails.imageId) {
            return additionalDetails.imageId !== imageId;
        }
        return true;
    };
    _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.filterRequests(filterFunction);
    const imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
    if (imageLoadObject) {
        imageLoadObject.cancelFn();
    }
}
function cancelLoadImages(imageIds) {
    imageIds.forEach((imageId) => cancelLoadImage(imageId));
}
function cancelLoadAll() {
    const requestPool = _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.getRequestPool();
    Object.keys(requestPool).forEach((type) => {
        const requests = requestPool[type];
        Object.keys(requests).forEach((priority) => {
            const requestDetails = requests[priority].pop();
            const additionalDetails = requestDetails.additionalDetails;
            const { imageId, volumeId } = additionalDetails;
            let loadObject;
            if (imageId) {
                loadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
            }
            else if (volumeId) {
                loadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
            }
            if (loadObject) {
                loadObject.cancel();
            }
        });
        _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.clearRequestStack(type);
    });
}
function registerImageLoader(scheme, imageLoader) {
    imageLoaders[scheme] = imageLoader;
}
function registerUnknownImageLoader(imageLoader) {
    const oldImageLoader = unknownImageLoader;
    unknownImageLoader = imageLoader;
    return oldImageLoader;
}
function unregisterAllImageLoaders() {
    Object.keys(imageLoaders).forEach((imageLoader) => delete imageLoaders[imageLoader]);
    unknownImageLoader = undefined;
}
function createAndCacheDerivedSegmentationImages(referencedImageIds, options = {
    targetBufferType: 'Uint8Array',
}) {
    return createAndCacheDerivedImages(referencedImageIds, options);
}
function createAndCacheDerivedSegmentationImage(referencedImageId, options = {
    targetBufferType: 'Uint8Array',
}) {
    return createAndCacheDerivedImage(referencedImageId, options);
}


/***/ }),

/***/ 82041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createAndCacheDerivedSegmentationVolume: () => (/* binding */ createAndCacheDerivedSegmentationVolume),
/* harmony export */   createAndCacheDerivedVolume: () => (/* binding */ createAndCacheDerivedVolume),
/* harmony export */   createAndCacheVolume: () => (/* binding */ createAndCacheVolume),
/* harmony export */   createAndCacheVolumeFromImages: () => (/* binding */ createAndCacheVolumeFromImages),
/* harmony export */   createLocalSegmentationVolume: () => (/* binding */ createLocalSegmentationVolume),
/* harmony export */   createLocalVolume: () => (/* binding */ createLocalVolume),
/* harmony export */   getUnknownVolumeLoaderSchema: () => (/* binding */ getUnknownVolumeLoaderSchema),
/* harmony export */   getVolumeLoaderSchemes: () => (/* binding */ getVolumeLoaderSchemes),
/* harmony export */   loadVolume: () => (/* binding */ loadVolume),
/* harmony export */   registerUnknownVolumeLoader: () => (/* binding */ registerUnknownVolumeLoader),
/* harmony export */   registerVolumeLoader: () => (/* binding */ registerVolumeLoader)
/* harmony export */ });
/* harmony import */ var _kitware_vtk_js_Rendering_Profiles_Volume__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3622);
/* harmony import */ var _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51250);
/* harmony import */ var _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45128);
/* harmony import */ var _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77076);
/* harmony import */ var _cache_cache__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25534);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11731);
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(51884);
/* harmony import */ var _utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(13292);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(48463);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(35678);
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71702);
/* harmony import */ var _utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51631);












function addScalarDataToImageData(imageData, scalarData, dataArrayAttrs) {
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: `Pixels`,
        values: scalarData,
        ...dataArrayAttrs,
    });
    imageData.getPointData().setScalars(scalarArray);
}
function addScalarDataArraysToImageData(imageData, scalarDataArrays, dataArrayAttrs) {
    scalarDataArrays.forEach((scalarData, i) => {
        const vtkScalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
            name: `timePoint-${i}`,
            values: scalarData,
            ...dataArrayAttrs,
        });
        imageData.getPointData().addArray(vtkScalarArray);
    });
    imageData.getPointData().setActiveScalars('timePoint-0');
}
function createInternalVTKRepresentation(volume) {
    const { dimensions, metadata, spacing, direction, origin } = volume;
    const { PhotometricInterpretation } = metadata;
    let numComponents = 1;
    if (PhotometricInterpretation === 'RGB') {
        numComponents = 3;
    }
    const imageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    const dataArrayAttrs = { numberOfComponents: numComponents };
    imageData.setDimensions(dimensions);
    imageData.setSpacing(spacing);
    imageData.setDirection(direction);
    imageData.setOrigin(origin);
    if (volume.isDynamicVolume()) {
        const scalarDataArrays = (volume).getScalarDataArrays();
        addScalarDataArraysToImageData(imageData, scalarDataArrays, dataArrayAttrs);
    }
    else {
        const scalarData = volume.getScalarData();
        addScalarDataToImageData(imageData, scalarData, dataArrayAttrs);
    }
    return imageData;
}
const volumeLoaders = {};
let unknownVolumeLoader;
function loadVolumeFromVolumeLoader(volumeId, options) {
    const colonIndex = volumeId.indexOf(':');
    const scheme = volumeId.substring(0, colonIndex);
    let loader = volumeLoaders[scheme];
    if (loader === undefined || loader === null) {
        if (unknownVolumeLoader == null ||
            typeof unknownVolumeLoader !== 'function') {
            throw new Error(`No volume loader for scheme ${scheme} has been registered`);
        }
        loader = unknownVolumeLoader;
    }
    const volumeLoadObject = loader(volumeId, options);
    (0,_utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__.setupCacheOptimizationEventListener)(volumeId);
    volumeLoadObject.promise.then(function (volume) {
        (0,_utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A)(_eventTarget__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.VOLUME_LOADED, { volume });
    }, function (error) {
        const errorObject = {
            volumeId,
            error,
        };
        (0,_utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A)(_eventTarget__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.VOLUME_LOADED_FAILED, errorObject);
    });
    return volumeLoadObject;
}
function loadVolume(volumeId, options = { imageIds: [] }) {
    if (volumeId === undefined) {
        throw new Error('loadVolume: parameter volumeId must not be undefined');
    }
    let volumeLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
    if (volumeLoadObject !== undefined) {
        return volumeLoadObject.promise;
    }
    volumeLoadObject = loadVolumeFromVolumeLoader(volumeId, options);
    return volumeLoadObject.promise.then((volume) => {
        volume.imageData = createInternalVTKRepresentation(volume);
        return volume;
    });
}
async function createAndCacheVolume(volumeId, options) {
    if (volumeId === undefined) {
        throw new Error('createAndCacheVolume: parameter volumeId must not be undefined');
    }
    let volumeLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
    if (volumeLoadObject !== undefined) {
        return volumeLoadObject.promise;
    }
    volumeLoadObject = loadVolumeFromVolumeLoader(volumeId, options);
    volumeLoadObject.promise.then((volume) => {
        volume.imageData = createInternalVTKRepresentation(volume);
    });
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject).catch((err) => {
        throw err;
    });
    return volumeLoadObject.promise;
}
async function createAndCacheDerivedVolume(referencedVolumeId, options) {
    const referencedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(referencedVolumeId);
    if (!referencedVolume) {
        throw new Error(`Cannot created derived volume: Referenced volume with id ${referencedVolumeId} does not exist.`);
    }
    let { volumeId } = options;
    const { targetBuffer } = options;
    if (volumeId === undefined) {
        volumeId = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.uuidv4)();
    }
    const { metadata, dimensions, spacing, origin, direction } = referencedVolume;
    const scalarData = referencedVolume.getScalarData();
    const scalarLength = scalarData.length;
    const { volumeScalarData, numBytes } = generateVolumeScalarData(targetBuffer, scalarLength);
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: 'Pixels',
        numberOfComponents: 1,
        values: volumeScalarData,
    });
    const derivedImageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    derivedImageData.setDimensions(dimensions);
    derivedImageData.setSpacing(spacing);
    derivedImageData.setDirection(direction);
    derivedImageData.setOrigin(origin);
    derivedImageData.getPointData().setScalars(scalarArray);
    const derivedVolume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        volumeId,
        metadata: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default()(metadata),
        dimensions: [dimensions[0], dimensions[1], dimensions[2]],
        spacing,
        origin,
        direction,
        imageData: derivedImageData,
        scalarData: volumeScalarData,
        sizeInBytes: numBytes,
        imageIds: [],
        referencedVolumeId,
    });
    const volumeLoadObject = {
        promise: Promise.resolve(derivedVolume),
    };
    await _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return derivedVolume;
}
function createLocalVolume(options, volumeId, preventCache = false) {
    const { metadata, dimensions, spacing, origin, direction, targetBuffer } = options;
    let { scalarData } = options;
    const validDataTypes = [
        'Uint8Array',
        'Float32Array',
        'Uint16Array',
        'Int16Array',
    ];
    const scalarLength = dimensions[0] * dimensions[1] * dimensions[2];
    if (!scalarData || !validDataTypes.includes(scalarData.constructor.name)) {
        if (!targetBuffer?.type || !validDataTypes.includes(targetBuffer.type)) {
            throw new Error('createLocalVolume: parameter scalarData must be provided and must be either Uint8Array, Float32Array, Uint16Array or Int16Array');
        }
        ({ volumeScalarData: scalarData } = generateVolumeScalarData(targetBuffer, scalarLength));
    }
    if (volumeId === undefined) {
        volumeId = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.uuidv4)();
    }
    const cachedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(volumeId);
    if (cachedVolume) {
        return cachedVolume;
    }
    const numBytes = scalarData ? scalarData.buffer.byteLength : scalarLength * 4;
    const isCacheable = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.isCacheable(numBytes);
    if (!isCacheable) {
        throw new Error(_enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.CACHE_SIZE_EXCEEDED);
    }
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: 'Pixels',
        numberOfComponents: 1,
        values: scalarData,
    });
    const imageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    imageData.setDimensions(dimensions);
    imageData.setSpacing(spacing);
    imageData.setDirection(direction);
    imageData.setOrigin(origin);
    imageData.getPointData().setScalars(scalarArray);
    const derivedVolume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        volumeId,
        metadata: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default()(metadata),
        dimensions: [dimensions[0], dimensions[1], dimensions[2]],
        spacing,
        origin,
        direction,
        imageData: imageData,
        scalarData,
        sizeInBytes: numBytes,
        referencedImageIds: options.referencedImageIds || [],
        referencedVolumeId: options.referencedVolumeId,
        imageIds: options.imageIds || [],
    });
    if (preventCache) {
        return derivedVolume;
    }
    const volumeLoadObject = {
        promise: Promise.resolve(derivedVolume),
    };
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return derivedVolume;
}
async function createAndCacheVolumeFromImages(volumeId, imageIds, options = {}) {
    const { preventCache = false } = options;
    if (imageIds === undefined) {
        throw new Error('createAndCacheVolumeFromImages: parameter imageIds must not be undefined');
    }
    if (volumeId === undefined) {
        throw new Error('createAndCacheVolumeFromImages: parameter volumeId must not be undefined');
    }
    const cachedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(volumeId);
    if (cachedVolume) {
        return Promise.resolve(cachedVolume);
    }
    const volumeProps = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.generateVolumePropsFromImageIds)(imageIds, volumeId);
    const imagePromises = volumeProps.imageIds.map((imageId, imageIdIndex) => {
        const imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getImageLoadObject(imageId);
        return imageLoadObject.promise.then((image) => {
            const pixelData = image.getPixelData();
            const offset = imageIdIndex * image.rows * image.columns;
            volumeProps.scalarData.set(pixelData, offset);
        });
    });
    await Promise.all(imagePromises);
    const volume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        ...volumeProps,
        referencedImageIds: imageIds,
        ...options,
    });
    (0,_utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__.performCacheOptimizationForVolume)(volume);
    const volumeLoadObject = {
        promise: Promise.resolve(volume),
    };
    if (preventCache) {
        return volumeLoadObject.promise;
    }
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return volumeLoadObject.promise;
}
function registerVolumeLoader(scheme, volumeLoader) {
    volumeLoaders[scheme] = volumeLoader;
}
function getVolumeLoaderSchemes() {
    return Object.keys(volumeLoaders);
}
function registerUnknownVolumeLoader(volumeLoader) {
    const oldVolumeLoader = unknownVolumeLoader;
    unknownVolumeLoader = volumeLoader;
    return oldVolumeLoader;
}
function getUnknownVolumeLoaderSchema() {
    return unknownVolumeLoader.name;
}
async function createAndCacheDerivedSegmentationVolume(referencedVolumeId, options = {}) {
    return createAndCacheDerivedVolume(referencedVolumeId, {
        ...options,
        targetBuffer: {
            type: 'Uint8Array',
        },
    });
}
async function createLocalSegmentationVolume(options, volumeId, preventCache = false) {
    if (!options.scalarData) {
        options.scalarData = new Uint8Array(options.dimensions[0] * options.dimensions[1] * options.dimensions[2]);
    }
    return createLocalVolume(options, volumeId, preventCache);
}
function generateVolumeScalarData(targetBuffer, scalarLength) {
    const { useNorm16Texture } = (0,_init__WEBPACK_IMPORTED_MODULE_10__/* .getConfiguration */ .D0)().rendering;
    const { TypedArrayConstructor, numBytes } = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.getBufferConfiguration)(targetBuffer?.type, scalarLength, {
        use16BitTexture: useNorm16Texture,
        isVolumeBuffer: true,
    });
    const isCacheable = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.isCacheable(numBytes);
    if (!isCacheable) {
        throw new Error(_enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.CACHE_SIZE_EXCEEDED);
    }
    let volumeScalarData;
    if (targetBuffer?.sharedArrayBuffer ?? (0,_init__WEBPACK_IMPORTED_MODULE_10__/* .getShouldUseSharedArrayBuffer */ .TB)()) {
        switch (targetBuffer.type) {
            case 'Float32Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createFloat32SharedArray)(scalarLength);
                break;
            case 'Uint8Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint8SharedArray)(scalarLength);
                break;
            case 'Uint16Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint16SharedArray)(scalarLength);
                break;
            case 'Int16Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint16SharedArray)(scalarLength);
                break;
            default:
                throw new Error('generateVolumeScalarData: SharedArrayBuffer is not supported for the specified target buffer type');
        }
    }
    else {
        volumeScalarData = new TypedArrayConstructor(scalarLength);
    }
    return { volumeScalarData, numBytes };
}


/***/ }),

/***/ 55692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addProvider: () => (/* binding */ addProvider),
/* harmony export */   get: () => (/* binding */ getMetaData),
/* harmony export */   removeAllProviders: () => (/* binding */ removeAllProviders),
/* harmony export */   removeProvider: () => (/* binding */ removeProvider)
/* harmony export */ });
const providers = [];
function addProvider(provider, priority = 0) {
    let i;
    for (i = 0; i < providers.length; i++) {
        if (providers[i].priority <= priority) {
            break;
        }
    }
    providers.splice(i, 0, {
        priority,
        provider,
    });
}
function removeProvider(provider) {
    for (let i = 0; i < providers.length; i++) {
        if (providers[i].provider === provider) {
            providers.splice(i, 1);
            break;
        }
    }
}
function removeAllProviders() {
    while (providers.length > 0) {
        providers.pop();
    }
}
function getMetaData(type, ...queries) {
    for (let i = 0; i < providers.length; i++) {
        const result = providers[i].provider(type, ...queries);
        if (result !== undefined) {
            return result;
        }
    }
}



/***/ }),

/***/ 775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _requestPoolManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79927);
/* harmony import */ var _enums_RequestType__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15453);


const imageLoadPoolManager = new _requestPoolManager__WEBPACK_IMPORTED_MODULE_0__/* .RequestPoolManager */ .R('imageLoadPool');
imageLoadPoolManager.grabDelay = 0;
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Interaction, 1000);
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Thumbnail, 1000);
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Prefetch, 1000);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (imageLoadPoolManager);


/***/ }),

/***/ 79927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ RequestPoolManager)
/* harmony export */ });
/* harmony import */ var _enums_RequestType__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15453);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35678);


class RequestPoolManager {
    constructor(id) {
        this.numRequests = {
            interaction: 0,
            thumbnail: 0,
            prefetch: 0,
            compute: 0,
        };
        this.id = id ? id : (0,_utilities__WEBPACK_IMPORTED_MODULE_1__.uuidv4)();
        this.requestPool = {
            interaction: { 0: [] },
            thumbnail: { 0: [] },
            prefetch: { 0: [] },
            compute: { 0: [] },
        };
        this.grabDelay = 5;
        this.awake = false;
        this.numRequests = {
            interaction: 0,
            thumbnail: 0,
            prefetch: 0,
            compute: 0,
        };
        this.maxNumRequests = {
            interaction: 6,
            thumbnail: 6,
            prefetch: 5,
            compute: 1000,
        };
    }
    setMaxSimultaneousRequests(type, maxNumRequests) {
        this.maxNumRequests[type] = maxNumRequests;
    }
    getMaxSimultaneousRequests(type) {
        return this.maxNumRequests[type];
    }
    destroy() {
        if (this.timeoutHandle) {
            window.clearTimeout(this.timeoutHandle);
        }
    }
    addRequest(requestFn, type, additionalDetails, priority = 0) {
        const requestDetails = {
            requestFn,
            type,
            additionalDetails,
        };
        if (this.requestPool[type][priority] === undefined) {
            this.requestPool[type][priority] = [];
        }
        this.requestPool[type][priority].push(requestDetails);
        this.startGrabbing();
    }
    filterRequests(filterFunction) {
        Object.keys(this.requestPool).forEach((type) => {
            const requestType = this.requestPool[type];
            Object.keys(requestType).forEach((priority) => {
                requestType[priority] = requestType[priority].filter((requestDetails) => {
                    return filterFunction(requestDetails);
                });
            });
        });
    }
    clearRequestStack(type) {
        if (!this.requestPool[type]) {
            throw new Error(`No category for the type ${type} found`);
        }
        this.requestPool[type] = { 0: [] };
    }
    sendRequests(type) {
        const requestsToSend = this.maxNumRequests[type] - this.numRequests[type];
        let syncImageCount = 0;
        for (let i = 0; i < requestsToSend; i++) {
            const requestDetails = this.getNextRequest(type);
            if (requestDetails === null) {
                return false;
            }
            else if (requestDetails) {
                this.numRequests[type]++;
                this.awake = true;
                let requestResult;
                try {
                    requestResult = requestDetails.requestFn();
                }
                catch (e) {
                    console.warn('sendRequest failed', e);
                }
                if (requestResult?.finally) {
                    requestResult.finally(() => {
                        this.numRequests[type]--;
                        this.startAgain();
                    });
                }
                else {
                    this.numRequests[type]--;
                    syncImageCount++;
                }
            }
        }
        if (syncImageCount) {
            this.startAgain();
        }
        return true;
    }
    getNextRequest(type) {
        const interactionPriorities = this.getSortedPriorityGroups(type);
        for (const priority of interactionPriorities) {
            if (this.requestPool[type][priority].length) {
                return this.requestPool[type][priority].shift();
            }
        }
        return null;
    }
    startGrabbing() {
        const hasRemainingInteractionRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Interaction);
        const hasRemainingThumbnailRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Thumbnail);
        const hasRemainingPrefetchRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Prefetch);
        const hasRemainingComputeRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Compute);
        if (!hasRemainingInteractionRequests &&
            !hasRemainingThumbnailRequests &&
            !hasRemainingPrefetchRequests &&
            !hasRemainingComputeRequests) {
            this.awake = false;
        }
    }
    startAgain() {
        if (!this.awake) {
            return;
        }
        if (this.grabDelay !== undefined) {
            if (!this.timeoutHandle) {
                this.timeoutHandle = window.setTimeout(() => {
                    this.timeoutHandle = null;
                    this.startGrabbing();
                }, this.grabDelay);
            }
        }
        else {
            this.startGrabbing();
        }
    }
    getSortedPriorityGroups(type) {
        const priorities = Object.keys(this.requestPool[type])
            .map(Number)
            .filter((priority) => this.requestPool[type][priority].length)
            .sort((a, b) => a - b);
        return priorities;
    }
    getRequestPool() {
        return this.requestPool;
    }
}



/***/ }),

/***/ 13292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ triggerEvent)
/* harmony export */ });
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(51884);

function triggerEvent(el = _eventTarget__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A, type, detail = null) {
    if (!type) {
        throw new Error('Event type was not defined');
    }
    const event = new CustomEvent(type, {
        detail,
        cancelable: true,
    });
    return el.dispatchEvent(event);
}


/***/ }),

/***/ 61874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var comlink__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99178);
/* harmony import */ var _enums___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98362);
/* harmony import */ var _requestPool_requestPoolManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79927);



class CentralizedWorkerManager {
    constructor() {
        this.workerRegistry = {};
        this.workerPoolManager = new _requestPool_requestPoolManager__WEBPACK_IMPORTED_MODULE_2__/* .RequestPoolManager */ .R('webworker');
    }
    registerWorker(workerName, workerFn, options = {}) {
        const { maxWorkerInstances = 1, overwrite = false, autoTerminateOnIdle = {
            enabled: false,
            idleTimeThreshold: 3000,
        }, } = options;
        if (this.workerRegistry[workerName] && !overwrite) {
            console.warn(`Worker type '${workerName}' is already registered...`);
            return;
        }
        if (overwrite && this.workerRegistry[workerName]?.idleCheckIntervalId) {
            clearInterval(this.workerRegistry[workerName].idleCheckIntervalId);
        }
        const workerProperties = {
            workerFn: null,
            instances: [],
            loadCounters: [],
            lastActiveTime: [],
            nativeWorkers: [],
            autoTerminateOnIdle: autoTerminateOnIdle.enabled,
            idleCheckIntervalId: null,
            idleTimeThreshold: autoTerminateOnIdle.idleTimeThreshold,
        };
        workerProperties.loadCounters = Array(maxWorkerInstances).fill(0);
        workerProperties.lastActiveTime = Array(maxWorkerInstances).fill(null);
        for (let i = 0; i < maxWorkerInstances; i++) {
            const worker = workerFn();
            workerProperties.instances.push(comlink__WEBPACK_IMPORTED_MODULE_0__/* .wrap */ .LV(worker));
            workerProperties.nativeWorkers.push(worker);
            workerProperties.workerFn = workerFn;
        }
        this.workerRegistry[workerName] = workerProperties;
    }
    getNextWorkerAPI(workerName) {
        const workerProperties = this.workerRegistry[workerName];
        if (!workerProperties) {
            console.error(`Worker type '${workerName}' is not registered.`);
            return null;
        }
        const workerInstances = workerProperties.instances.filter((instance) => instance !== null);
        let minLoadIndex = 0;
        let minLoadValue = workerProperties.loadCounters[0] || 0;
        for (let i = 1; i < workerInstances.length; i++) {
            const currentLoadValue = workerProperties.loadCounters[i] || 0;
            if (currentLoadValue < minLoadValue) {
                minLoadIndex = i;
                minLoadValue = currentLoadValue;
            }
        }
        if (workerProperties.instances[minLoadIndex] === null) {
            const worker = workerProperties.workerFn();
            workerProperties.instances[minLoadIndex] = comlink__WEBPACK_IMPORTED_MODULE_0__/* .wrap */ .LV(worker);
            workerProperties.nativeWorkers[minLoadIndex] = worker;
        }
        workerProperties.loadCounters[minLoadIndex] += 1;
        return {
            api: workerProperties.instances[minLoadIndex],
            index: minLoadIndex,
        };
    }
    executeTask(workerName, methodName, args = {}, { requestType = _enums___WEBPACK_IMPORTED_MODULE_1__.RequestType.Compute, priority = 0, options = {}, callbacks = [], } = {}) {
        return new Promise((resolve, reject) => {
            const requestFn = async () => {
                const { api, index } = this.getNextWorkerAPI(workerName);
                if (!api) {
                    const error = new Error(`No available worker instance for '${workerName}'`);
                    console.error(error);
                    reject(error);
                    return;
                }
                try {
                    let finalCallbacks = [];
                    if (callbacks.length) {
                        finalCallbacks = callbacks.map((cb) => {
                            return comlink__WEBPACK_IMPORTED_MODULE_0__/* .proxy */ .BX(cb);
                        });
                    }
                    const workerProperties = this.workerRegistry[workerName];
                    workerProperties.processing = true;
                    const results = await api[methodName](args, ...finalCallbacks);
                    workerProperties.processing = false;
                    workerProperties.lastActiveTime[index] = Date.now();
                    if (workerProperties.autoTerminateOnIdle &&
                        !workerProperties.idleCheckIntervalId &&
                        workerProperties.idleTimeThreshold) {
                        workerProperties.idleCheckIntervalId = setInterval(() => {
                            this.terminateIdleWorkers(workerName, workerProperties.idleTimeThreshold);
                        }, workerProperties.idleTimeThreshold);
                    }
                    resolve(results);
                }
                catch (err) {
                    console.error(`Error executing method '${methodName}' on worker '${workerName}':`, err);
                    reject(err);
                }
                finally {
                    this.workerRegistry[workerName].loadCounters[index]--;
                }
            };
            this.workerPoolManager.addRequest(requestFn, requestType, options, priority);
        });
    }
    terminateIdleWorkers(workerName, idleTimeThreshold) {
        const workerProperties = this.workerRegistry[workerName];
        if (workerProperties.processing) {
            return;
        }
        const now = Date.now();
        workerProperties.instances.forEach((_, index) => {
            const lastActiveTime = workerProperties.lastActiveTime[index];
            const isWorkerActive = lastActiveTime !== null && workerProperties.loadCounters[index] > 0;
            const idleTime = now - lastActiveTime;
            if (!isWorkerActive && idleTime > idleTimeThreshold) {
                this.terminateWorkerInstance(workerName, index);
            }
        });
    }
    terminate(workerName) {
        const workerProperties = this.workerRegistry[workerName];
        if (!workerProperties) {
            console.error(`Worker type '${workerName}' is not registered.`);
            return;
        }
        workerProperties.instances.forEach((_, index) => {
            this.terminateWorkerInstance(workerName, index);
        });
    }
    terminateWorkerInstance(workerName, index) {
        const workerProperties = this.workerRegistry[workerName];
        const workerInstance = workerProperties.instances[index];
        if (workerInstance !== null) {
            workerInstance[comlink__WEBPACK_IMPORTED_MODULE_0__/* .releaseProxy */ .A2]();
            workerProperties.nativeWorkers[index].terminate();
            workerProperties.instances[index] = null;
            workerProperties.lastActiveTime[index] = null;
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CentralizedWorkerManager);


/***/ }),

/***/ 79697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ drawingSvg_draw)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/getSvgDrawingHelper.js


const VIEWPORT_ELEMENT = 'viewport-element';
function getSvgDrawingHelper(element) {
    const enabledElement = (0,esm.getEnabledElement)(element);
    const { viewportId, renderingEngineId } = enabledElement;
    const canvasHash = `${viewportId}:${renderingEngineId}`;
    const svgLayerElement = _getSvgLayer(element);
    Object.keys(store/* state */.wk.svgNodeCache[canvasHash]).forEach((cacheKey) => {
        store/* state */.wk.svgNodeCache[canvasHash][cacheKey].touched = false;
    });
    return {
        svgLayerElement: svgLayerElement,
        svgNodeCacheForCanvas: store/* state */.wk.svgNodeCache,
        getSvgNode: getSvgNode.bind(this, canvasHash),
        appendNode: appendNode.bind(this, svgLayerElement, canvasHash),
        setNodeTouched: setNodeTouched.bind(this, canvasHash),
        clearUntouched: clearUntouched.bind(this, svgLayerElement, canvasHash),
    };
}
function _getSvgLayer(element) {
    const viewportElement = `.${VIEWPORT_ELEMENT}`;
    const internalDivElement = element.querySelector(viewportElement);
    const svgLayer = internalDivElement.querySelector(':scope > .svg-layer');
    return svgLayer;
}
function getSvgNode(canvasHash, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    if (store/* state */.wk.svgNodeCache[canvasHash][cacheKey]) {
        return store/* state */.wk.svgNodeCache[canvasHash][cacheKey].domRef;
    }
}
function appendNode(svgLayerElement, canvasHash, svgNode, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return null;
    }
    store/* state */.wk.svgNodeCache[canvasHash][cacheKey] = {
        touched: true,
        domRef: svgNode,
    };
    svgLayerElement.appendChild(svgNode);
}
function setNodeTouched(canvasHash, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    if (store/* state */.wk.svgNodeCache[canvasHash][cacheKey]) {
        store/* state */.wk.svgNodeCache[canvasHash][cacheKey].touched = true;
    }
}
function clearUntouched(svgLayerElement, canvasHash) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    Object.keys(store/* state */.wk.svgNodeCache[canvasHash]).forEach((cacheKey) => {
        const cacheEntry = store/* state */.wk.svgNodeCache[canvasHash][cacheKey];
        if (!cacheEntry.touched && cacheEntry.domRef) {
            svgLayerElement.removeChild(cacheEntry.domRef);
            delete store/* state */.wk.svgNodeCache[canvasHash][cacheKey];
        }
    });
}
/* harmony default export */ const drawingSvg_getSvgDrawingHelper = (getSvgDrawingHelper);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/draw.js

function draw(element, fn) {
    const svgDrawingHelper = drawingSvg_getSvgDrawingHelper(element);
    fn(svgDrawingHelper);
    svgDrawingHelper.clearUntouched();
}
/* harmony default export */ const drawingSvg_draw = (draw);


/***/ }),

/***/ 12468:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ToolModes;
(function (ToolModes) {
    ToolModes["Active"] = "Active";
    ToolModes["Passive"] = "Passive";
    ToolModes["Enabled"] = "Enabled";
    ToolModes["Disabled"] = "Disabled";
})(ToolModes || (ToolModes = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToolModes);


/***/ }),

/***/ 39371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   segmentation: () => (/* reexport module object */ _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_9__),
/* harmony export */   utilities: () => (/* reexport module object */ _utilities__WEBPACK_IMPORTED_MODULE_5__)
/* harmony export */ });
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35373);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61738);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(55965);
/* harmony import */ var _synchronizers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42375);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49574);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74119);
/* harmony import */ var _cursors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32916);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(40969);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45238);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63421);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(81848);
/* harmony import */ var _tools_annotation_VideoRedactionTool__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65043);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(84901);
















/***/ }),

/***/ 35837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getState: () => (/* reexport safe */ _getState__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   style: () => (/* reexport safe */ _ToolStyle__WEBPACK_IMPORTED_MODULE_2__.A)
/* harmony export */ });
/* harmony import */ var _getState__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70692);
/* harmony import */ var _getFont__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(80456);
/* harmony import */ var _ToolStyle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31862);






/***/ }),

/***/ 45238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* reexport module object */ _config__WEBPACK_IMPORTED_MODULE_0__),
/* harmony export */   state: () => (/* reexport module object */ _annotationState__WEBPACK_IMPORTED_MODULE_3__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35837);
/* harmony import */ var _annotationLocking__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48428);
/* harmony import */ var _annotationSelection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42351);
/* harmony import */ var _annotationState__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38296);
/* harmony import */ var _annotationVisibility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21009);
/* harmony import */ var _FrameOfReferenceSpecificAnnotationManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22581);
/* harmony import */ var _AnnotationGroup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16122);










/***/ }),

/***/ 27630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ ToolGroupManager_createToolGroup)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/index.js + 3 modules
var enums = __webpack_require__(84901);
// EXTERNAL MODULE: ../../../node_modules/lodash.get/index.js
var lodash_get = __webpack_require__(51008);
var lodash_get_default = /*#__PURE__*/__webpack_require__.n(lodash_get);
// EXTERNAL MODULE: ../../../node_modules/lodash.clonedeep/index.js
var lodash_clonedeep = __webpack_require__(48463);
var lodash_clonedeep_default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/index.js + 5 modules
var cursors = __webpack_require__(32916);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/elementCursor.js
var elementCursor = __webpack_require__(40233);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/ToolGroupManager/ToolGroup.js








const { Active, Passive, Enabled, Disabled } = enums.ToolModes;
const PRIMARY_BINDINGS = [{ mouseButton: enums.MouseBindings.Primary }];
class ToolGroup {
    constructor(id) {
        this.viewportsInfo = [];
        this.toolOptions = {};
        this.currentActivePrimaryToolName = null;
        this.prevActivePrimaryToolName = null;
        this.restoreToolOptions = {};
        this._toolInstances = {};
        this.id = id;
    }
    getViewportIds() {
        return this.viewportsInfo.map(({ viewportId }) => viewportId);
    }
    getViewportsInfo() {
        return this.viewportsInfo.slice();
    }
    getToolInstance(toolInstanceName) {
        const toolInstance = this._toolInstances[toolInstanceName];
        if (!toolInstance) {
            console.warn(`'${toolInstanceName}' is not registered with this toolGroup (${this.id}).`);
            return;
        }
        return toolInstance;
    }
    getToolInstances() {
        return this._toolInstances;
    }
    hasTool(toolName) {
        return !!this._toolInstances[toolName];
    }
    addTool(toolName, configuration = {}) {
        const toolDefinition = store/* state */.wk.tools[toolName];
        const hasToolName = typeof toolName !== 'undefined' && toolName !== '';
        const localToolInstance = this.toolOptions[toolName];
        if (!hasToolName) {
            console.warn('Tool with configuration did not produce a toolName: ', configuration);
            return;
        }
        if (!toolDefinition) {
            console.warn(`'${toolName}' is not registered with the library. You need to use cornerstoneTools.addTool to register it.`);
            return;
        }
        if (localToolInstance) {
            console.warn(`'${toolName}' is already registered for ToolGroup ${this.id}.`);
            return;
        }
        const { toolClass: ToolClass } = toolDefinition;
        const toolProps = {
            name: toolName,
            toolGroupId: this.id,
            configuration,
        };
        const instantiatedTool = new ToolClass(toolProps);
        this._toolInstances[toolName] = instantiatedTool;
    }
    addToolInstance(toolName, parentClassName, configuration = {}) {
        let ToolClassToUse = store/* state */.wk.tools[toolName]
            ?.toolClass;
        if (!ToolClassToUse) {
            const ParentClass = store/* state */.wk.tools[parentClassName]
                .toolClass;
            class ToolInstance extends ParentClass {
            }
            ToolInstance.toolName = toolName;
            ToolClassToUse = ToolInstance;
            store/* state */.wk.tools[toolName] = {
                toolClass: ToolInstance,
            };
        }
        this.addTool(ToolClassToUse.toolName, configuration);
    }
    addViewport(viewportId, renderingEngineId) {
        if (typeof viewportId !== 'string') {
            throw new Error('viewportId must be defined and be a string');
        }
        const renderingEngines = (0,esm.getRenderingEngines)();
        if (!renderingEngineId && renderingEngines.length > 1) {
            throw new Error('You must specify a renderingEngineId when there are multiple rendering engines.');
        }
        const renderingEngineUIDToUse = renderingEngineId || renderingEngines[0].id;
        if (!this.viewportsInfo.some(({ viewportId: vpId }) => vpId === viewportId)) {
            this.viewportsInfo.push({
                viewportId,
                renderingEngineId: renderingEngineUIDToUse,
            });
        }
        const toolName = this.getActivePrimaryMouseButtonTool();
        const runtimeSettings = esm.Settings.getRuntimeSettings();
        if (runtimeSettings.get('useCursors')) {
            this.setViewportsCursorByToolName(toolName);
        }
        const eventDetail = {
            toolGroupId: this.id,
            viewportId,
            renderingEngineId: renderingEngineUIDToUse,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOLGROUP_VIEWPORT_ADDED, eventDetail);
    }
    removeViewports(renderingEngineId, viewportId) {
        const indices = [];
        this.viewportsInfo.forEach((vpInfo, index) => {
            let match = false;
            if (vpInfo.renderingEngineId === renderingEngineId) {
                match = true;
                if (viewportId && vpInfo.viewportId !== viewportId) {
                    match = false;
                }
            }
            if (match) {
                indices.push(index);
            }
        });
        if (indices.length) {
            for (let i = indices.length - 1; i >= 0; i--) {
                this.viewportsInfo.splice(indices[i], 1);
            }
        }
        const eventDetail = {
            toolGroupId: this.id,
            viewportId,
            renderingEngineId,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOLGROUP_VIEWPORT_REMOVED, eventDetail);
    }
    setActiveStrategy(toolName, strategyName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool configuration.`);
            return;
        }
        toolInstance.setActiveStrategy(strategyName);
    }
    setToolMode(toolName, mode, options = {}) {
        if (!toolName) {
            console.warn('setToolMode: toolName must be defined');
            return;
        }
        if (mode === enums.ToolModes.Active) {
            this.setToolActive(toolName, options || this.restoreToolOptions[toolName]);
            return;
        }
        if (mode === enums.ToolModes.Passive) {
            this.setToolPassive(toolName);
            return;
        }
        if (mode === enums.ToolModes.Enabled) {
            this.setToolEnabled(toolName);
            return;
        }
        if (mode === enums.ToolModes.Disabled) {
            this.setToolDisabled(toolName);
            return;
        }
        console.warn('setToolMode: mode must be defined');
    }
    setToolActive(toolName, toolBindingsOptions = {}) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        if (!toolInstance) {
            console.warn(`'${toolName}' instance ${toolInstance} is not registered with this toolGroup, can't set tool mode.`);
            return;
        }
        const prevBindings = this.toolOptions[toolName]
            ? this.toolOptions[toolName].bindings
            : [];
        const newBindings = toolBindingsOptions.bindings
            ? toolBindingsOptions.bindings
            : [];
        const bindingsToUse = [...prevBindings, ...newBindings].reduce((unique, binding) => {
            const TouchBinding = binding.numTouchPoints !== undefined;
            const MouseBinding = binding.mouseButton !== undefined;
            if (!unique.some((obj) => hasSameBinding(obj, binding)) &&
                (TouchBinding || MouseBinding)) {
                unique.push(binding);
            }
            return unique;
        }, []);
        const toolOptions = {
            bindings: bindingsToUse,
            mode: Active,
        };
        this.toolOptions[toolName] = toolOptions;
        this._toolInstances[toolName].mode = Active;
        const runtimeSettings = esm.Settings.getRuntimeSettings();
        const useCursor = runtimeSettings.get('useCursors');
        if (this._hasMousePrimaryButtonBinding(toolBindingsOptions) && useCursor) {
            this.setViewportsCursorByToolName(toolName);
        }
        else {
            const activeToolIdentifier = this.getActivePrimaryMouseButtonTool();
            if (!activeToolIdentifier && useCursor) {
                const cursor = cursors.MouseCursor.getDefinedCursor('default');
                this._setCursorForViewports(cursor);
            }
        }
        if (this._hasMousePrimaryButtonBinding(toolBindingsOptions)) {
            if (this.prevActivePrimaryToolName === null) {
                this.prevActivePrimaryToolName = toolName;
            }
            else {
                this.prevActivePrimaryToolName = this.currentActivePrimaryToolName;
            }
            this.currentActivePrimaryToolName = toolName;
        }
        if (typeof toolInstance.onSetToolActive === 'function') {
            toolInstance.onSetToolActive();
        }
        this._renderViewports();
        const eventDetail = {
            toolGroupId: this.id,
            toolName,
            toolBindingsOptions,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOL_ACTIVATED, eventDetail);
        this._triggerToolModeChangedEvent(toolName, Active, toolBindingsOptions);
    }
    setToolPassive(toolName, options) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const prevToolOptions = this.getToolOptions(toolName);
        const toolOptions = Object.assign({
            bindings: prevToolOptions ? prevToolOptions.bindings : [],
        }, prevToolOptions, {
            mode: Passive,
        });
        const matchBindings = Array.isArray(options?.removeAllBindings)
            ? options.removeAllBindings
            : this.getDefaultPrimaryBindings();
        toolOptions.bindings = toolOptions.bindings.filter((binding) => options?.removeAllBindings !== true &&
            !matchBindings.some((matchBinding) => hasSameBinding(binding, matchBinding)));
        let mode = Passive;
        if (toolOptions.bindings.length !== 0) {
            mode = Active;
            toolOptions.mode = mode;
        }
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = mode;
        if (typeof toolInstance.onSetToolPassive === 'function') {
            toolInstance.onSetToolPassive();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Passive);
    }
    setToolEnabled(toolName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const toolOptions = {
            bindings: [],
            mode: Enabled,
        };
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = Enabled;
        if (typeof toolInstance.onSetToolEnabled === 'function') {
            toolInstance.onSetToolEnabled();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Enabled);
    }
    setToolDisabled(toolName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const toolOptions = {
            bindings: [],
            mode: Disabled,
        };
        this.restoreToolOptions[toolName] = this.toolOptions[toolName];
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = Disabled;
        if (typeof toolInstance.onSetToolDisabled === 'function') {
            toolInstance.onSetToolDisabled();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Disabled);
    }
    getToolOptions(toolName) {
        const toolOptionsForTool = this.toolOptions[toolName];
        if (toolOptionsForTool === undefined) {
            return;
        }
        return toolOptionsForTool;
    }
    getActivePrimaryMouseButtonTool() {
        return Object.keys(this.toolOptions).find((toolName) => {
            const toolOptions = this.toolOptions[toolName];
            return (toolOptions.mode === Active &&
                this._hasMousePrimaryButtonBinding(toolOptions));
        });
    }
    setViewportsCursorByToolName(toolName, strategyName) {
        const cursor = this._getCursor(toolName, strategyName);
        this._setCursorForViewports(cursor);
    }
    _getCursor(toolName, strategyName) {
        let cursorName;
        let cursor;
        if (strategyName) {
            cursorName = `${toolName}.${strategyName}`;
            cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
            if (cursor) {
                return cursor;
            }
        }
        cursorName = `${toolName}`;
        cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
        if (cursor) {
            return cursor;
        }
        cursorName = toolName;
        cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
        if (cursor) {
            return cursor;
        }
        return cursors.MouseCursor.getDefinedCursor('default');
    }
    _setCursorForViewports(cursor) {
        this.viewportsInfo.forEach(({ renderingEngineId, viewportId }) => {
            const enabledElement = (0,esm.getEnabledElementByIds)(viewportId, renderingEngineId);
            if (!enabledElement) {
                return;
            }
            const { viewport } = enabledElement;
            (0,elementCursor.initElementCursor)(viewport.element, cursor);
        });
    }
    setToolConfiguration(toolName, configuration, overwrite) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not present, can't set tool configuration.`);
            return false;
        }
        let _configuration;
        if (overwrite) {
            _configuration = configuration;
        }
        else {
            _configuration = Object.assign(toolInstance.configuration, configuration);
        }
        toolInstance.configuration = _configuration;
        if (typeof toolInstance.onSetToolConfiguration === 'function') {
            toolInstance.onSetToolConfiguration();
        }
        this._renderViewports();
        return true;
    }
    getDefaultMousePrimary() {
        return enums.MouseBindings.Primary;
    }
    getDefaultPrimaryBindings() {
        return PRIMARY_BINDINGS;
    }
    getToolConfiguration(toolName, configurationPath) {
        if (this._toolInstances[toolName] === undefined) {
            console.warn(`Tool ${toolName} not present, can't set tool configuration.`);
            return;
        }
        const _configuration = lodash_get_default()(this._toolInstances[toolName].configuration, configurationPath) ||
            this._toolInstances[toolName].configuration;
        return lodash_clonedeep_default()(_configuration);
    }
    getPrevActivePrimaryToolName() {
        return this.prevActivePrimaryToolName;
    }
    clone(newToolGroupId, fnToolFilter = null) {
        let toolGroup = store/* ToolGroupManager.getToolGroup */.dU.getToolGroup(newToolGroupId);
        if (toolGroup) {
            console.warn(`ToolGroup ${newToolGroupId} already exists`);
            return toolGroup;
        }
        toolGroup = store/* ToolGroupManager.createToolGroup */.dU.createToolGroup(newToolGroupId);
        fnToolFilter = fnToolFilter ?? (() => true);
        Object.keys(this._toolInstances)
            .filter(fnToolFilter)
            .forEach((toolName) => {
            const sourceToolInstance = this._toolInstances[toolName];
            const sourceToolOptions = this.toolOptions[toolName];
            const sourceToolMode = sourceToolInstance.mode;
            toolGroup.addTool(toolName);
            toolGroup.setToolMode(toolName, sourceToolMode, {
                bindings: sourceToolOptions.bindings ?? [],
            });
        });
        return toolGroup;
    }
    _hasMousePrimaryButtonBinding(toolOptions) {
        const primaryBindings = this.getDefaultPrimaryBindings();
        return toolOptions?.bindings?.some((binding) => primaryBindings.some((primary) => hasSameBinding(binding, primary)));
    }
    _renderViewports() {
        this.viewportsInfo.forEach(({ renderingEngineId, viewportId }) => {
            (0,esm.getRenderingEngine)(renderingEngineId).renderViewport(viewportId);
        });
    }
    _triggerToolModeChangedEvent(toolName, mode, toolBindingsOptions) {
        const eventDetail = {
            toolGroupId: this.id,
            toolName,
            mode,
            toolBindingsOptions,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOL_MODE_CHANGED, eventDetail);
    }
}
function hasSameBinding(binding1, binding2) {
    if (binding1.mouseButton !== binding2.mouseButton) {
        return false;
    }
    if (binding1.numTouchPoints !== binding2.numTouchPoints) {
        return false;
    }
    return binding1.modifierKey === binding2.modifierKey;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/ToolGroupManager/createToolGroup.js


function createToolGroup(toolGroupId) {
    const toolGroupWithIdExists = store/* state */.wk.toolGroups.some((tg) => tg.id === toolGroupId);
    if (toolGroupWithIdExists) {
        console.warn(`'${toolGroupId}' already exists.`);
        return;
    }
    const toolGroup = new ToolGroup(toolGroupId);
    store/* state */.wk.toolGroups.push(toolGroup);
    return toolGroup;
}
/* harmony default export */ const ToolGroupManager_createToolGroup = (createToolGroup);


/***/ }),

/***/ 648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _destroyToolGroup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59755);


function destroy() {
    const toolGroups = [..._index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups];
    for (const toolGroup of toolGroups) {
        (0,_destroyToolGroup__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(toolGroup.id);
    }
    _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups = [];
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (destroy);


/***/ }),

/***/ 59755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63421);
/* harmony import */ var _utilities_segmentation_triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49521);



function destroyToolGroup(toolGroupId) {
    const toolGroupIndex = _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.findIndex((tg) => tg.id === toolGroupId);
    if (toolGroupIndex > -1) {
        _utilities_segmentation_triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_2__/* .segmentationRenderingEngine */ .px.removeToolGroup(toolGroupId);
        (0,_stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__.removeSegmentationsFromToolGroup)(toolGroupId);
        _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.splice(toolGroupIndex, 1);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (destroyToolGroup);


/***/ }),

/***/ 3193:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);

function getAllToolGroups() {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getAllToolGroups);


/***/ }),

/***/ 29697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);

function getToolGroup(toolGroupId) {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.find((s) => s.id === toolGroupId);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getToolGroup);


/***/ }),

/***/ 64109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84901);


const MODES = [_enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Active, _enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Passive, _enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Enabled];
function getToolGroupsWithToolName(toolName) {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.filter(({ toolOptions }) => {
        const toolGroupToolNames = Object.keys(toolOptions);
        for (let i = 0; i < toolGroupToolNames.length; i++) {
            if (toolName !== toolGroupToolNames[i]) {
                continue;
            }
            if (!toolOptions[toolName]) {
                continue;
            }
            if (MODES.includes(toolOptions[toolName].mode)) {
                return true;
            }
        }
        return false;
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getToolGroupsWithToolName);


/***/ }),

/***/ 50720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);
/* harmony import */ var _utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24592);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74119);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(96214);
/* harmony import */ var _utilities_throttle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(21090);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38296);
/* harmony import */ var _stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(48428);
/* harmony import */ var _stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(21009);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54177);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49574);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(61738);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(84901);
/* harmony import */ var _utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(90252);
/* harmony import */ var _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(21954);
/* harmony import */ var _utilities_drawing__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(10910);
/* harmony import */ var _cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(40233);
/* harmony import */ var _utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(23072);


















const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities;
class BidirectionalTool extends _base__WEBPACK_IMPORTED_MODULE_4__/* .AnnotationTool */ .EC {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            preventHandleOutsideImage: false,
            getTextLines: defaultGetTextLines,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.isPointNearTool = (element, annotation, canvasCoords, proximity) => {
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { data } = annotation;
            const { points } = data.handles;
            let canvasPoint1 = viewport.worldToCanvas(points[0]);
            let canvasPoint2 = viewport.worldToCanvas(points[1]);
            let line = {
                start: {
                    x: canvasPoint1[0],
                    y: canvasPoint1[1],
                },
                end: {
                    x: canvasPoint2[0],
                    y: canvasPoint2[1],
                },
            };
            let distanceToPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.distanceToPoint([line.start.x, line.start.y], [line.end.x, line.end.y], [canvasCoords[0], canvasCoords[1]]);
            if (distanceToPoint <= proximity) {
                return true;
            }
            canvasPoint1 = viewport.worldToCanvas(points[2]);
            canvasPoint2 = viewport.worldToCanvas(points[3]);
            line = {
                start: {
                    x: canvasPoint1[0],
                    y: canvasPoint1[1],
                },
                end: {
                    x: canvasPoint2[0],
                    y: canvasPoint2[1],
                },
            };
            distanceToPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.distanceToPoint([line.start.x, line.start.y], [line.end.x, line.end.y], [canvasCoords[0], canvasCoords[1]]);
            if (distanceToPoint <= proximity) {
                return true;
            }
            return false;
        };
        this.toolSelectedCallback = (evt, annotation) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            annotation.highlighted = true;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                movingTextBox: false,
            };
            this._activateModify(element);
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
            evt.preventDefault();
        };
        this.handleSelectedCallback = (evt, annotation, handle) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const data = annotation.data;
            annotation.highlighted = true;
            let movingTextBox = false;
            let handleIndex;
            if (handle.worldPosition) {
                movingTextBox = true;
            }
            else {
                handleIndex = data.handles.points.findIndex((p) => p === handle);
            }
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex,
                movingTextBox,
            };
            this._activateModify(element);
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            evt.preventDefault();
        };
        this._endCallback = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const { annotation, viewportIdsToRender, newAnnotation, hasMoved } = this.editData;
            const { data } = annotation;
            if (newAnnotation && !hasMoved) {
                return;
            }
            data.handles.activeHandleIndex = null;
            this._deactivateModify(element);
            this._deactivateDraw(element);
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.resetElementCursor)(element);
            const { renderingEngine } = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            if (this.editData.handleIndex !== undefined) {
                const { points } = data.handles;
                const firstLineSegmentLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.distance */ .eR.distance(points[0], points[1]);
                const secondLineSegmentLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.distance */ .eR.distance(points[2], points[3]);
                if (secondLineSegmentLength > firstLineSegmentLength) {
                    const longAxis = [[...points[2]], [...points[3]]];
                    const shortAxisPoint0 = [...points[0]];
                    const shortAxisPoint1 = [...points[1]];
                    const longAxisVector = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(longAxisVector, longAxis[1][0] - longAxis[0][0], longAxis[1][1] - longAxis[1][0]);
                    const counterClockWisePerpendicularToLongAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(counterClockWisePerpendicularToLongAxis, -longAxisVector[1], longAxisVector[0]);
                    const currentShortAxisVector = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(currentShortAxisVector, shortAxisPoint1[0] - shortAxisPoint0[0], shortAxisPoint1[1] - shortAxisPoint0[0]);
                    let shortAxis;
                    if (gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.dot */ .Zc.dot(currentShortAxisVector, counterClockWisePerpendicularToLongAxis) > 0) {
                        shortAxis = [shortAxisPoint0, shortAxisPoint1];
                    }
                    else {
                        shortAxis = [shortAxisPoint1, shortAxisPoint0];
                    }
                    data.handles.points = [
                        longAxis[0],
                        longAxis[1],
                        shortAxis[0],
                        shortAxis[1],
                    ];
                }
            }
            if (this.isHandleOutsideImage &&
                this.configuration.preventHandleOutsideImage) {
                (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.removeAnnotation)(annotation.annotationUID);
            }
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            if (newAnnotation) {
                (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationCompleted */ .dZ)(annotation);
            }
            this.editData = null;
            this.isDrawing = false;
        };
        this._dragDrawCallback = (evt) => {
            this.isDrawing = true;
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine, viewport } = enabledElement;
            const { worldToCanvas } = viewport;
            const { annotation, viewportIdsToRender, handleIndex } = this.editData;
            const { data } = annotation;
            const worldPos = currentPoints.world;
            data.handles.points[handleIndex] = [...worldPos];
            const canvasCoordPoints = data.handles.points.map(worldToCanvas);
            const canvasCoords = {
                longLineSegment: {
                    start: {
                        x: canvasCoordPoints[0][0],
                        y: canvasCoordPoints[0][1],
                    },
                    end: {
                        x: canvasCoordPoints[1][0],
                        y: canvasCoordPoints[1][1],
                    },
                },
                shortLineSegment: {
                    start: {
                        x: canvasCoordPoints[2][0],
                        y: canvasCoordPoints[2][1],
                    },
                    end: {
                        x: canvasCoordPoints[3][0],
                        y: canvasCoordPoints[3][1],
                    },
                },
            };
            const dist = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.distance */ .Zc.distance(canvasCoordPoints[0], canvasCoordPoints[1]);
            const shortAxisDistFromCenter = dist / 3;
            const dx = canvasCoords.longLineSegment.start.x - canvasCoords.longLineSegment.end.x;
            const dy = canvasCoords.longLineSegment.start.y - canvasCoords.longLineSegment.end.y;
            const length = Math.sqrt(dx * dx + dy * dy);
            const vectorX = dx / length;
            const vectorY = dy / length;
            const xMid = (canvasCoords.longLineSegment.start.x +
                canvasCoords.longLineSegment.end.x) /
                2;
            const yMid = (canvasCoords.longLineSegment.start.y +
                canvasCoords.longLineSegment.end.y) /
                2;
            const startX = xMid + shortAxisDistFromCenter * vectorY;
            const startY = yMid - shortAxisDistFromCenter * vectorX;
            const endX = xMid - shortAxisDistFromCenter * vectorY;
            const endY = yMid + shortAxisDistFromCenter * vectorX;
            data.handles.points[2] = viewport.canvasToWorld([startX, startY]);
            data.handles.points[3] = viewport.canvasToWorld([endX, endY]);
            annotation.invalidated = true;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            this.editData.hasMoved = true;
        };
        this._dragModifyCallback = (evt) => {
            this.isDrawing = true;
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            const { annotation, viewportIdsToRender, handleIndex, movingTextBox } = this.editData;
            const { data } = annotation;
            if (movingTextBox) {
                const { deltaPoints } = eventDetail;
                const worldPosDelta = deltaPoints.world;
                const { textBox } = data.handles;
                const { worldPosition } = textBox;
                worldPosition[0] += worldPosDelta[0];
                worldPosition[1] += worldPosDelta[1];
                worldPosition[2] += worldPosDelta[2];
                textBox.hasMoved = true;
            }
            else if (handleIndex === undefined) {
                const { deltaPoints } = eventDetail;
                const worldPosDelta = deltaPoints.world;
                const points = data.handles.points;
                points.forEach((point) => {
                    point[0] += worldPosDelta[0];
                    point[1] += worldPosDelta[1];
                    point[2] += worldPosDelta[2];
                });
                annotation.invalidated = true;
            }
            else {
                this._dragModifyHandle(evt);
                annotation.invalidated = true;
            }
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
        };
        this._dragModifyHandle = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { annotation, handleIndex: movingHandleIndex } = this.editData;
            const { data } = annotation;
            const worldPos = currentPoints.world;
            const canvasCoordHandlesCurrent = [
                viewport.worldToCanvas(data.handles.points[0]),
                viewport.worldToCanvas(data.handles.points[1]),
                viewport.worldToCanvas(data.handles.points[2]),
                viewport.worldToCanvas(data.handles.points[3]),
            ];
            const firstLineSegment = {
                start: {
                    x: canvasCoordHandlesCurrent[0][0],
                    y: canvasCoordHandlesCurrent[0][1],
                },
                end: {
                    x: canvasCoordHandlesCurrent[1][0],
                    y: canvasCoordHandlesCurrent[1][1],
                },
            };
            const secondLineSegment = {
                start: {
                    x: canvasCoordHandlesCurrent[2][0],
                    y: canvasCoordHandlesCurrent[2][1],
                },
                end: {
                    x: canvasCoordHandlesCurrent[3][0],
                    y: canvasCoordHandlesCurrent[3][1],
                },
            };
            const proposedPoint = [...worldPos];
            const proposedCanvasCoord = viewport.worldToCanvas(proposedPoint);
            if (movingHandleIndex === 0 || movingHandleIndex === 1) {
                const fixedHandleIndex = movingHandleIndex === 0 ? 1 : 0;
                const fixedHandleCanvasCoord = canvasCoordHandlesCurrent[fixedHandleIndex];
                const fixedHandleToProposedCoordVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), proposedCanvasCoord[0] - fixedHandleCanvasCoord[0], proposedCanvasCoord[1] - fixedHandleCanvasCoord[1]);
                const fixedHandleToOldCoordVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), canvasCoordHandlesCurrent[movingHandleIndex][0] -
                    fixedHandleCanvasCoord[0], canvasCoordHandlesCurrent[movingHandleIndex][1] -
                    fixedHandleCanvasCoord[1]);
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(fixedHandleToProposedCoordVec, fixedHandleToProposedCoordVec);
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(fixedHandleToOldCoordVec, fixedHandleToOldCoordVec);
                const proposedFirstLineSegment = {
                    start: {
                        x: fixedHandleCanvasCoord[0],
                        y: fixedHandleCanvasCoord[1],
                    },
                    end: {
                        x: proposedCanvasCoord[0],
                        y: proposedCanvasCoord[1],
                    },
                };
                if (this._movingLongAxisWouldPutItThroughShortAxis(proposedFirstLineSegment, secondLineSegment)) {
                    return;
                }
                const centerOfRotation = fixedHandleCanvasCoord;
                const angle = this._getSignedAngle(fixedHandleToOldCoordVec, fixedHandleToProposedCoordVec);
                let firstPointX = canvasCoordHandlesCurrent[2][0];
                let firstPointY = canvasCoordHandlesCurrent[2][1];
                let secondPointX = canvasCoordHandlesCurrent[3][0];
                let secondPointY = canvasCoordHandlesCurrent[3][1];
                firstPointX -= centerOfRotation[0];
                firstPointY -= centerOfRotation[1];
                secondPointX -= centerOfRotation[0];
                secondPointY -= centerOfRotation[1];
                const rotatedFirstPoint = firstPointX * Math.cos(angle) - firstPointY * Math.sin(angle);
                const rotatedFirstPointY = firstPointX * Math.sin(angle) + firstPointY * Math.cos(angle);
                const rotatedSecondPoint = secondPointX * Math.cos(angle) - secondPointY * Math.sin(angle);
                const rotatedSecondPointY = secondPointX * Math.sin(angle) + secondPointY * Math.cos(angle);
                firstPointX = rotatedFirstPoint + centerOfRotation[0];
                firstPointY = rotatedFirstPointY + centerOfRotation[1];
                secondPointX = rotatedSecondPoint + centerOfRotation[0];
                secondPointY = rotatedSecondPointY + centerOfRotation[1];
                const newFirstPoint = viewport.canvasToWorld([firstPointX, firstPointY]);
                const newSecondPoint = viewport.canvasToWorld([
                    secondPointX,
                    secondPointY,
                ]);
                data.handles.points[movingHandleIndex] = proposedPoint;
                data.handles.points[2] = newFirstPoint;
                data.handles.points[3] = newSecondPoint;
            }
            else {
                const translateHandleIndex = movingHandleIndex === 2 ? 3 : 2;
                const canvasCoordsCurrent = {
                    longLineSegment: {
                        start: firstLineSegment.start,
                        end: firstLineSegment.end,
                    },
                    shortLineSegment: {
                        start: secondLineSegment.start,
                        end: secondLineSegment.end,
                    },
                };
                const longLineSegmentVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.subtract */ .Zc.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [
                    canvasCoordsCurrent.longLineSegment.end.x,
                    canvasCoordsCurrent.longLineSegment.end.y,
                ], [
                    canvasCoordsCurrent.longLineSegment.start.x,
                    canvasCoordsCurrent.longLineSegment.start.y,
                ]);
                const longLineSegmentVecNormalized = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), longLineSegmentVec);
                const proposedToCurrentVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.subtract */ .Zc.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [proposedCanvasCoord[0], proposedCanvasCoord[1]], [
                    canvasCoordHandlesCurrent[movingHandleIndex][0],
                    canvasCoordHandlesCurrent[movingHandleIndex][1],
                ]);
                const movementLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.length */ .Zc.length(proposedToCurrentVec);
                const angle = this._getSignedAngle(longLineSegmentVecNormalized, proposedToCurrentVec);
                const movementAlongLineSegmentLength = Math.cos(angle) * movementLength;
                const newTranslatedPoint = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.scaleAndAdd */ .Zc.scaleAndAdd(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [
                    canvasCoordHandlesCurrent[translateHandleIndex][0],
                    canvasCoordHandlesCurrent[translateHandleIndex][1],
                ], longLineSegmentVecNormalized, movementAlongLineSegmentLength);
                if (this._movingLongAxisWouldPutItThroughShortAxis({
                    start: {
                        x: proposedCanvasCoord[0],
                        y: proposedCanvasCoord[1],
                    },
                    end: {
                        x: newTranslatedPoint[0],
                        y: newTranslatedPoint[1],
                    },
                }, {
                    start: {
                        x: canvasCoordsCurrent.longLineSegment.start.x,
                        y: canvasCoordsCurrent.longLineSegment.start.y,
                    },
                    end: {
                        x: canvasCoordsCurrent.longLineSegment.end.x,
                        y: canvasCoordsCurrent.longLineSegment.end.y,
                    },
                })) {
                    return;
                }
                const intersectionPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.intersectLine([proposedCanvasCoord[0], proposedCanvasCoord[1]], [newTranslatedPoint[0], newTranslatedPoint[1]], [firstLineSegment.start.x, firstLineSegment.start.y], [firstLineSegment.end.x, firstLineSegment.end.y]);
                if (!intersectionPoint) {
                    return;
                }
                data.handles.points[translateHandleIndex] = viewport.canvasToWorld(newTranslatedPoint);
                data.handles.points[movingHandleIndex] = proposedPoint;
            }
        };
        this.cancel = (element) => {
            if (this.isDrawing) {
                this.isDrawing = false;
                this._deactivateDraw(element);
                this._deactivateModify(element);
                (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.resetElementCursor)(element);
                const { annotation, viewportIdsToRender, newAnnotation } = this.editData;
                const { data } = annotation;
                annotation.highlighted = false;
                data.handles.activeHandleIndex = null;
                const { renderingEngine } = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
                (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
                if (newAnnotation) {
                    (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationCompleted */ .dZ)(annotation);
                }
                this.editData = null;
                return annotation.annotationUID;
            }
        };
        this._activateDraw = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = true;
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragDrawCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_MOVE, this._dragDrawCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragDrawCallback);
        };
        this._deactivateDraw = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = false;
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragDrawCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_MOVE, this._dragDrawCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragDrawCallback);
        };
        this._activateModify = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = true;
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragModifyCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragModifyCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
        };
        this._deactivateModify = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = false;
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragModifyCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragModifyCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = true;
            const { viewport } = enabledElement;
            const { element } = viewport;
            let annotations = (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.getAnnotations)(this.getToolName(), element);
            if (!annotations?.length) {
                return renderStatus;
            }
            annotations = this.filterInteractableAnnotationsForElement(element, annotations);
            if (!annotations?.length) {
                return renderStatus;
            }
            const targetId = this.getTargetId(viewport);
            const renderingEngine = viewport.getRenderingEngine();
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const { color, lineWidth, lineDash, shadow } = this.getAnnotationStyle({
                    annotation,
                    styleSpecifier,
                });
                if (!data.cachedStats[targetId] ||
                    data.cachedStats[targetId].unit == null) {
                    data.cachedStats[targetId] = {
                        length: null,
                        width: null,
                        unit: null,
                    };
                    this._calculateCachedStats(annotation, renderingEngine, enabledElement);
                }
                else if (annotation.invalidated) {
                    this._throttledCalculateCachedStats(annotation, renderingEngine, enabledElement);
                }
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                let activeHandleCanvasCoords;
                if (!(0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_8__.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_7__.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                const dataId1 = `${annotationUID}-line-1`;
                const dataId2 = `${annotationUID}-line-2`;
                const lineUID = '0';
                (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLine)(svgDrawingHelper, annotationUID, lineUID, canvasCoordinates[0], canvasCoordinates[1], {
                    color,
                    lineDash,
                    lineWidth,
                    shadow,
                }, dataId1);
                const secondLineUID = '1';
                (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLine)(svgDrawingHelper, annotationUID, secondLineUID, canvasCoordinates[2], canvasCoordinates[3], {
                    color,
                    lineDash,
                    lineWidth,
                    shadow,
                }, dataId2);
                renderStatus = true;
                const options = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
                if (!options.visibility) {
                    data.handles.textBox = {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    };
                    continue;
                }
                const textLines = this.configuration.getTextLines(data, targetId);
                if (!textLines || textLines.length === 0) {
                    continue;
                }
                let canvasTextBoxCoords;
                if (!data.handles.textBox.hasMoved) {
                    canvasTextBoxCoords = (0,_utilities_drawing__WEBPACK_IMPORTED_MODULE_15__.getTextBoxCoordsCanvas)(canvasCoordinates);
                    data.handles.textBox.worldPosition =
                        viewport.canvasToWorld(canvasTextBoxCoords);
                }
                const textBoxPosition = viewport.worldToCanvas(data.handles.textBox.worldPosition);
                const textBoxUID = '1';
                const boundingBox = (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLinkedTextBox)(svgDrawingHelper, annotationUID, textBoxUID, textLines, textBoxPosition, canvasCoordinates, {}, options);
                const { x: left, y: top, width, height } = boundingBox;
                data.handles.textBox.worldBoundingBox = {
                    topLeft: viewport.canvasToWorld([left, top]),
                    topRight: viewport.canvasToWorld([left + width, top]),
                    bottomLeft: viewport.canvasToWorld([left, top + height]),
                    bottomRight: viewport.canvasToWorld([left + width, top + height]),
                };
            }
            return renderStatus;
        };
        this._movingLongAxisWouldPutItThroughShortAxis = (firstLineSegment, secondLineSegment) => {
            const vectorInSecondLineDirection = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(vectorInSecondLineDirection, secondLineSegment.end.x - secondLineSegment.start.x, secondLineSegment.end.y - secondLineSegment.start.y);
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(vectorInSecondLineDirection, vectorInSecondLineDirection);
            const extendedSecondLineSegment = {
                start: {
                    x: secondLineSegment.start.x - vectorInSecondLineDirection[0] * 10,
                    y: secondLineSegment.start.y - vectorInSecondLineDirection[1] * 10,
                },
                end: {
                    x: secondLineSegment.end.x + vectorInSecondLineDirection[0] * 10,
                    y: secondLineSegment.end.y + vectorInSecondLineDirection[1] * 10,
                },
            };
            const proposedIntersectionPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.intersectLine([extendedSecondLineSegment.start.x, extendedSecondLineSegment.start.y], [extendedSecondLineSegment.end.x, extendedSecondLineSegment.end.y], [firstLineSegment.start.x, firstLineSegment.start.y], [firstLineSegment.end.x, firstLineSegment.end.y]);
            const wouldPutThroughShortAxis = !proposedIntersectionPoint;
            return wouldPutThroughShortAxis;
        };
        this._calculateCachedStats = (annotation, renderingEngine, enabledElement) => {
            const { data } = annotation;
            const { element } = enabledElement.viewport;
            const worldPos1 = data.handles.points[0];
            const worldPos2 = data.handles.points[1];
            const worldPos3 = data.handles.points[2];
            const worldPos4 = data.handles.points[3];
            const { cachedStats } = data;
            const targetIds = Object.keys(cachedStats);
            for (let i = 0; i < targetIds.length; i++) {
                const targetId = targetIds[i];
                const image = this.getTargetIdImage(targetId, renderingEngine);
                if (!image) {
                    continue;
                }
                const { imageData, dimensions } = image;
                const index1 = transformWorldToIndex(imageData, worldPos1);
                const index2 = transformWorldToIndex(imageData, worldPos2);
                const index3 = transformWorldToIndex(imageData, worldPos3);
                const index4 = transformWorldToIndex(imageData, worldPos4);
                const handles1 = [index1, index2];
                const handles2 = [index3, index4];
                const { scale: scale1, units: units1 } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, handles1);
                const { scale: scale2, units: units2 } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, handles2);
                const dist1 = this._calculateLength(worldPos1, worldPos2) / scale1;
                const dist2 = this._calculateLength(worldPos3, worldPos4) / scale2;
                const length = dist1 > dist2 ? dist1 : dist2;
                const width = dist1 > dist2 ? dist2 : dist1;
                const lengthUnit = dist1 > dist2 ? units1 : units2;
                const widthUnit = dist1 > dist2 ? units2 : units1;
                this._isInsideVolume(index1, index2, index3, index4, dimensions)
                    ? (this.isHandleOutsideImage = false)
                    : (this.isHandleOutsideImage = true);
                cachedStats[targetId] = {
                    length,
                    width,
                    unit: units1,
                    lengthUnit,
                    widthUnit,
                };
            }
            annotation.invalidated = false;
            (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationModified */ .XF)(annotation, element);
            return cachedStats;
        };
        this._isInsideVolume = (index1, index2, index3, index4, dimensions) => {
            return (_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index1, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index2, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index3, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index4, dimensions));
        };
        this._getSignedAngle = (vector1, vector2) => {
            return Math.atan2(vector1[0] * vector2[1] - vector1[1] * vector2[0], vector1[0] * vector2[0] + vector1[1] * vector2[1]);
        };
        this._throttledCalculateCachedStats = (0,_utilities_throttle__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A)(this._calculateCachedStats, 100, { trailing: true });
    }
    addNewAnnotation(evt) {
        const eventDetail = evt.detail;
        const { currentPoints, element } = eventDetail;
        const worldPos = currentPoints.world;
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
        const { viewport, renderingEngine } = enabledElement;
        this.isDrawing = true;
        const camera = viewport.getCamera();
        const { viewPlaneNormal, viewUp } = camera;
        const referencedImageId = this.getReferencedImageId(viewport, worldPos, viewPlaneNormal, viewUp);
        const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
        const annotation = {
            highlighted: true,
            invalidated: true,
            metadata: {
                toolName: this.getToolName(),
                viewPlaneNormal: [...viewPlaneNormal],
                viewUp: [...viewUp],
                FrameOfReferenceUID,
                referencedImageId,
                ...viewport.getViewReference({ points: [worldPos] }),
            },
            data: {
                handles: {
                    points: [
                        [...worldPos],
                        [...worldPos],
                        [...worldPos],
                        [...worldPos],
                    ],
                    textBox: {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    },
                    activeHandleIndex: null,
                },
                label: '',
                cachedStats: {},
            },
        };
        (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.addAnnotation)(annotation, element);
        const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
        this.editData = {
            annotation,
            viewportIdsToRender,
            handleIndex: 1,
            movingTextBox: false,
            newAnnotation: true,
            hasMoved: false,
        };
        this._activateDraw(element);
        (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
        evt.preventDefault();
        (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
        return annotation;
    }
    _calculateLength(pos1, pos2) {
        const dx = pos1[0] - pos2[0];
        const dy = pos1[1] - pos2[1];
        const dz = pos1[2] - pos2[2];
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
function defaultGetTextLines(data, targetId) {
    const { cachedStats, label } = data;
    const { length, width, unit, lengthUnit, widthUnit } = cachedStats[targetId];
    const textLines = [];
    if (label) {
        textLines.push(label);
    }
    if (length === undefined) {
        return textLines;
    }
    textLines.push(`L: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(length)} ${lengthUnit || unit}`, `W: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(width)} ${widthUnit || unit}`);
    return textLines;
}
BidirectionalTool.toolName = 'Bidirectional';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BidirectionalTool);


/***/ }),

/***/ 39244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24592);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74119);
/* harmony import */ var _utilities_math__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(73047);
/* harmony import */ var _utilities_planar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84797);
/* harmony import */ var _utilities_throttle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(21090);
/* harmony import */ var _utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(90252);
/* harmony import */ var _utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23072);
/* harmony import */ var _planarFreehandROITool_drawLoop__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(14695);
/* harmony import */ var _planarFreehandROITool_editLoopCommon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1344);
/* harmony import */ var _planarFreehandROITool_closedContourEditLoop__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(30911);
/* harmony import */ var _planarFreehandROITool_openContourEditLoop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(90511);
/* harmony import */ var _planarFreehandROITool_openContourEndEditLoop__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(72702);
/* harmony import */ var _planarFreehandROITool_renderMethods__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(11585);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(54177);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(49574);
/* harmony import */ var _utilities_drawing__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(10910);
/* harmony import */ var _utilities_math_polyline__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(56634);
/* harmony import */ var _utilities_pointInShapeCallback__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(75403);
/* harmony import */ var _utilities_viewport_isViewportPreScaled__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(97022);
/* harmony import */ var _utilities_getModalityUnit__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(73801);
/* harmony import */ var _utilities_math_basic__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(83112);
/* harmony import */ var _utilities_contours_calculatePerimeter__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(53891);
/* harmony import */ var _base_ContourSegmentationBaseTool__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(76840);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(84901);


























const { pointCanProjectOnLine } = _utilities_math__WEBPACK_IMPORTED_MODULE_4__.polyline;
const { EPSILON } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.CONSTANTS;
const PARALLEL_THRESHOLD = 1 - EPSILON;
class PlanarFreehandROITool extends _base_ContourSegmentationBaseTool__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .A {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            shadow: true,
            preventHandleOutsideImage: false,
            contourHoleAdditionModifierKey: _enums__WEBPACK_IMPORTED_MODULE_25__.KeyboardBindings.Shift,
            alwaysRenderOpenContourHandles: {
                enabled: false,
                radius: 2,
            },
            allowOpenContours: true,
            closeContourProximity: 10,
            checkCanvasEditFallbackProximity: 6,
            makeClockWise: true,
            subPixelResolution: 4,
            smoothing: {
                smoothOnAdd: false,
                smoothOnEdit: false,
                knotsRatioPercentageOnAdd: 40,
                knotsRatioPercentageOnEdit: 40,
            },
            interpolation: {
                enabled: false,
                onInterpolationComplete: null,
            },
            decimate: {
                enabled: false,
                epsilon: 0.1,
            },
            displayOnePointAsCrosshairs: false,
            calculateStats: true,
            getTextLines: defaultGetTextLines,
            statsCalculator: _utilities_math_basic__WEBPACK_IMPORTED_MODULE_22__.BasicStatsCalculator,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.isDrawing = false;
        this.isEditingClosed = false;
        this.isEditingOpen = false;
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            const annotation = this.createAnnotation(evt);
            this.addAnnotation(annotation, element);
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.activateDraw(evt, annotation, viewportIdsToRender);
            evt.preventDefault();
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this.handleSelectedCallback = (evt, annotation, handle) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.activateOpenContourEndEdit(evt, annotation, viewportIdsToRender, handle);
        };
        this.toolSelectedCallback = (evt, annotation) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            if (annotation.data.contour.closed) {
                this.activateClosedContourEdit(evt, annotation, viewportIdsToRender);
            }
            else {
                this.activateOpenContourEdit(evt, annotation, viewportIdsToRender);
            }
            evt.preventDefault();
        };
        this.isPointNearTool = (element, annotation, canvasCoords, proximity) => {
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { polyline: points } = annotation.data.contour;
            let previousPoint = viewport.worldToCanvas(points[0]);
            for (let i = 1; i < points.length; i++) {
                const p1 = previousPoint;
                const p2 = viewport.worldToCanvas(points[i]);
                const canProject = pointCanProjectOnLine(canvasCoords, p1, p2, proximity);
                if (canProject) {
                    return true;
                }
                previousPoint = p2;
            }
            if (!annotation.data.contour.closed) {
                return false;
            }
            const pStart = viewport.worldToCanvas(points[0]);
            const pEnd = viewport.worldToCanvas(points[points.length - 1]);
            return pointCanProjectOnLine(canvasCoords, pStart, pEnd, proximity);
        };
        this.cancel = (element) => {
            const isDrawing = this.isDrawing;
            const isEditingOpen = this.isEditingOpen;
            const isEditingClosed = this.isEditingClosed;
            if (isDrawing) {
                this.cancelDrawing(element);
            }
            else if (isEditingOpen) {
                this.cancelOpenContourEdit(element);
            }
            else if (isEditingClosed) {
                this.cancelClosedContourEdit(element);
            }
        };
        this._calculateCachedStats = (annotation, viewport, renderingEngine, enabledElement) => {
            const { data } = annotation;
            const { cachedStats } = data;
            const { polyline: points, closed } = data.contour;
            const targetIds = Object.keys(cachedStats);
            for (let i = 0; i < targetIds.length; i++) {
                const targetId = targetIds[i];
                const image = this.getTargetIdImage(targetId, renderingEngine);
                if (!image) {
                    continue;
                }
                const { imageData, metadata } = image;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                const canvasPoint = canvasCoordinates[0];
                const originalWorldPoint = viewport.canvasToWorld(canvasPoint);
                const deltaXPoint = viewport.canvasToWorld([
                    canvasPoint[0] + 1,
                    canvasPoint[1],
                ]);
                const deltaYPoint = viewport.canvasToWorld([
                    canvasPoint[0],
                    canvasPoint[1] + 1,
                ]);
                const deltaInX = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(originalWorldPoint, deltaXPoint);
                const deltaInY = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(originalWorldPoint, deltaYPoint);
                const worldPosIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[0]);
                worldPosIndex[0] = Math.floor(worldPosIndex[0]);
                worldPosIndex[1] = Math.floor(worldPosIndex[1]);
                worldPosIndex[2] = Math.floor(worldPosIndex[2]);
                let iMin = worldPosIndex[0];
                let iMax = worldPosIndex[0];
                let jMin = worldPosIndex[1];
                let jMax = worldPosIndex[1];
                let kMin = worldPosIndex[2];
                let kMax = worldPosIndex[2];
                for (let j = 1; j < points.length; j++) {
                    const worldPosIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[j]);
                    worldPosIndex[0] = Math.floor(worldPosIndex[0]);
                    worldPosIndex[1] = Math.floor(worldPosIndex[1]);
                    worldPosIndex[2] = Math.floor(worldPosIndex[2]);
                    iMin = Math.min(iMin, worldPosIndex[0]);
                    iMax = Math.max(iMax, worldPosIndex[0]);
                    jMin = Math.min(jMin, worldPosIndex[1]);
                    jMax = Math.max(jMax, worldPosIndex[1]);
                    kMin = Math.min(kMin, worldPosIndex[2]);
                    kMax = Math.max(kMax, worldPosIndex[2]);
                }
                const worldPosIndex2 = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[1]);
                worldPosIndex2[0] = Math.floor(worldPosIndex2[0]);
                worldPosIndex2[1] = Math.floor(worldPosIndex2[1]);
                worldPosIndex2[2] = Math.floor(worldPosIndex2[2]);
                const { scale, areaUnits } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, () => {
                    const polyline = data.contour.polyline;
                    const numPoints = polyline.length;
                    const projectedPolyline = new Array(numPoints);
                    for (let i = 0; i < numPoints; i++) {
                        projectedPolyline[i] = viewport.worldToCanvas(polyline[i]);
                    }
                    const { maxX: canvasMaxX, maxY: canvasMaxY, minX: canvasMinX, minY: canvasMinY, } = _utilities__WEBPACK_IMPORTED_MODULE_3__.math.polyline.getAABB(projectedPolyline);
                    const topLeftBBWorld = viewport.canvasToWorld([
                        canvasMinX,
                        canvasMinY,
                    ]);
                    const topLeftBBIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, topLeftBBWorld);
                    const bottomRightBBWorld = viewport.canvasToWorld([
                        canvasMaxX,
                        canvasMaxY,
                    ]);
                    const bottomRightBBIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, bottomRightBBWorld);
                    return [topLeftBBIndex, bottomRightBBIndex];
                });
                let area = _utilities_math__WEBPACK_IMPORTED_MODULE_4__.polyline.getArea(canvasCoordinates) / scale / scale;
                area *= deltaInX * deltaInY;
                const iDelta = 0.01 * (iMax - iMin);
                const jDelta = 0.01 * (jMax - jMin);
                const kDelta = 0.01 * (kMax - kMin);
                iMin = Math.floor(iMin - iDelta);
                iMax = Math.ceil(iMax + iDelta);
                jMin = Math.floor(jMin - jDelta);
                jMax = Math.ceil(jMax + jDelta);
                kMin = Math.floor(kMin - kDelta);
                kMax = Math.ceil(kMax + kDelta);
                const boundsIJK = [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ];
                const worldPosEnd = imageData.indexToWorld([iMax, jMax, kMax]);
                const canvasPosEnd = viewport.worldToCanvas(worldPosEnd);
                let curRow = 0;
                let intersections = [];
                let intersectionCounter = 0;
                const pointsInShape = (0,_utilities_pointInShapeCallback__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .A)(imageData, (pointLPS, pointIJK) => {
                    let result = true;
                    const point = viewport.worldToCanvas(pointLPS);
                    if (point[1] != curRow) {
                        intersectionCounter = 0;
                        curRow = point[1];
                        intersections = (0,_utilities_math_polyline__WEBPACK_IMPORTED_MODULE_18__.getLineSegmentIntersectionsCoordinates)(canvasCoordinates, point, [canvasPosEnd[0], point[1]]);
                        intersections.sort((function (index) {
                            return function (a, b) {
                                return a[index] === b[index]
                                    ? 0
                                    : a[index] < b[index]
                                        ? -1
                                        : 1;
                            };
                        })(0));
                    }
                    if (intersections.length && point[0] > intersections[0][0]) {
                        intersections.shift();
                        intersectionCounter++;
                    }
                    if (intersectionCounter % 2 === 0) {
                        result = false;
                    }
                    return result;
                }, this.configuration.statsCalculator.statsCallback, boundsIJK);
                const modalityUnitOptions = {
                    isPreScaled: (0,_utilities_viewport_isViewportPreScaled__WEBPACK_IMPORTED_MODULE_20__/* .isViewportPreScaled */ .u)(viewport, targetId),
                    isSuvScaled: this.isSuvScaled(viewport, targetId, annotation.metadata.referencedImageId),
                };
                const modalityUnit = (0,_utilities_getModalityUnit__WEBPACK_IMPORTED_MODULE_21__/* .getModalityUnit */ .c)(metadata.Modality, annotation.metadata.referencedImageId, modalityUnitOptions);
                const stats = this.configuration.statsCalculator.getStatistics();
                cachedStats[targetId] = {
                    Modality: metadata.Modality,
                    area,
                    perimeter: (0,_utilities_contours_calculatePerimeter__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .A)(canvasCoordinates, closed),
                    mean: stats.mean?.value,
                    max: stats.max?.value,
                    stdDev: stats.stdDev?.value,
                    statsArray: stats.array,
                    pointsInShape: pointsInShape,
                    areaUnit: areaUnits,
                    modalityUnit,
                };
            }
            (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_15__/* .triggerAnnotationModified */ .XF)(annotation, enabledElement.viewport.element, _enums__WEBPACK_IMPORTED_MODULE_25__.ChangeTypes.StatsUpdated);
            annotation.invalidated = false;
            return cachedStats;
        };
        this._renderStats = (annotation, viewport, enabledElement, svgDrawingHelper) => {
            const { data } = annotation;
            const targetId = this.getTargetId(viewport);
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            const options = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
            if (!options.visibility) {
                return;
            }
            const textLines = this.configuration.getTextLines(data, targetId);
            if (!textLines || textLines.length === 0) {
                return;
            }
            const canvasCoordinates = data.contour.polyline.map((p) => viewport.worldToCanvas(p));
            if (!data.handles.textBox.hasMoved) {
                const canvasTextBoxCoords = (0,_utilities_drawing__WEBPACK_IMPORTED_MODULE_17__.getTextBoxCoordsCanvas)(canvasCoordinates);
                data.handles.textBox.worldPosition =
                    viewport.canvasToWorld(canvasTextBoxCoords);
            }
            const textBoxPosition = viewport.worldToCanvas(data.handles.textBox.worldPosition);
            const textBoxUID = '1';
            const boundingBox = (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_16__.drawLinkedTextBox)(svgDrawingHelper, annotation.annotationUID ?? '', textBoxUID, textLines, textBoxPosition, canvasCoordinates, {}, options);
            const { x: left, y: top, width, height } = boundingBox;
            data.handles.textBox.worldBoundingBox = {
                topLeft: viewport.canvasToWorld([left, top]),
                topRight: viewport.canvasToWorld([left + width, top]),
                bottomLeft: viewport.canvasToWorld([left, top + height]),
                bottomRight: viewport.canvasToWorld([left + width, top + height]),
            };
        };
        (0,_planarFreehandROITool_drawLoop__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_editLoopCommon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_closedContourEditLoop__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_openContourEditLoop__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_openContourEndEditLoop__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_renderMethods__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .A)(this);
        this._throttledCalculateCachedStats = (0,_utilities_throttle__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(this._calculateCachedStats, 100, { trailing: true });
    }
    filterInteractableAnnotationsForElement(element, annotations) {
        if (!annotations || !annotations.length) {
            return;
        }
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        let annotationsToDisplay;
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
            const camera = viewport.getCamera();
            const { spacingInNormalDirection } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getTargetVolumeAndSpacingInNormalDir(viewport, camera);
            annotationsToDisplay = this.filterAnnotationsWithinSlice(annotations, camera, spacingInNormalDirection);
        }
        else {
            annotationsToDisplay = (0,_utilities_planar__WEBPACK_IMPORTED_MODULE_5__.filterAnnotationsForDisplay)(viewport, annotations);
        }
        return annotationsToDisplay;
    }
    filterAnnotationsWithinSlice(annotations, camera, spacingInNormalDirection) {
        const { viewPlaneNormal } = camera;
        const annotationsWithParallelNormals = annotations.filter((td) => {
            const annotationViewPlaneNormal = td.metadata.viewPlaneNormal;
            const isParallel = Math.abs(gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(viewPlaneNormal, annotationViewPlaneNormal)) >
                PARALLEL_THRESHOLD;
            return annotationViewPlaneNormal && isParallel;
        });
        if (!annotationsWithParallelNormals.length) {
            return [];
        }
        const halfSpacingInNormalDirection = spacingInNormalDirection / 2;
        const { focalPoint } = camera;
        const annotationsWithinSlice = [];
        for (const annotation of annotationsWithParallelNormals) {
            const data = annotation.data;
            const point = data.contour.polyline[0];
            if (!annotation.isVisible) {
                continue;
            }
            const dir = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
            gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.sub */ .eR.sub(dir, focalPoint, point);
            const dot = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(dir, viewPlaneNormal);
            if (Math.abs(dot) < halfSpacingInNormalDirection) {
                annotationsWithinSlice.push(annotation);
            }
        }
        return annotationsWithinSlice;
    }
    isContourSegmentationTool() {
        return false;
    }
    createAnnotation(evt) {
        const worldPos = evt.detail.currentPoints.world;
        const contourAnnotation = super.createAnnotation(evt);
        const onInterpolationComplete = (annotation) => {
            annotation.data.handles.points.length = 0;
        };
        const annotation = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(contourAnnotation, {
            data: {
                contour: {
                    polyline: [[...worldPos]],
                },
                label: '',
                cachedStats: {},
            },
            onInterpolationComplete,
        });
        return annotation;
    }
    getAnnotationStyle(context) {
        return super.getAnnotationStyle(context);
    }
    renderAnnotationInstance(renderContext) {
        const { enabledElement, targetId, svgDrawingHelper } = renderContext;
        const annotation = renderContext.annotation;
        let renderStatus = false;
        const { viewport, renderingEngine } = enabledElement;
        const isDrawing = this.isDrawing;
        const isEditingOpen = this.isEditingOpen;
        const isEditingClosed = this.isEditingClosed;
        if (!(isDrawing || isEditingOpen || isEditingClosed)) {
            if (this.configuration.displayOnePointAsCrosshairs &&
                annotation.data.contour.polyline.length === 1) {
                this.renderPointContourWithMarker(enabledElement, svgDrawingHelper, annotation);
            }
            else {
                this.renderContour(enabledElement, svgDrawingHelper, annotation);
            }
        }
        else {
            const activeAnnotationUID = this.commonData.annotation.annotationUID;
            if (annotation.annotationUID === activeAnnotationUID) {
                if (isDrawing) {
                    this.renderContourBeingDrawn(enabledElement, svgDrawingHelper, annotation);
                }
                else if (isEditingClosed) {
                    this.renderClosedContourBeingEdited(enabledElement, svgDrawingHelper, annotation);
                }
                else if (isEditingOpen) {
                    this.renderOpenContourBeingEdited(enabledElement, svgDrawingHelper, annotation);
                }
                else {
                    throw new Error(`Unknown ${this.getToolName()} annotation rendering state`);
                }
            }
            else {
                if (this.configuration.displayOnePointAsCrosshairs &&
                    annotation.data.contour.polyline.length === 1) {
                    this.renderPointContourWithMarker(enabledElement, svgDrawingHelper, annotation);
                }
                else {
                    this.renderContour(enabledElement, svgDrawingHelper, annotation);
                }
            }
            renderStatus = true;
        }
        if (!this.configuration.calculateStats) {
            return;
        }
        this._calculateStatsIfActive(annotation, targetId, viewport, renderingEngine, enabledElement);
        this._renderStats(annotation, viewport, enabledElement, svgDrawingHelper);
        return renderStatus;
    }
    _calculateStatsIfActive(annotation, targetId, viewport, renderingEngine, enabledElement) {
        const activeAnnotationUID = this.commonData?.annotation.annotationUID;
        if (annotation.annotationUID === activeAnnotationUID &&
            !this.commonData?.movingTextBox) {
            return;
        }
        if (!this.commonData?.movingTextBox) {
            const { data } = annotation;
            if (!data.cachedStats[targetId] ||
                data.cachedStats[targetId].areaUnit == null) {
                data.cachedStats[targetId] = {
                    Modality: null,
                    area: null,
                    max: null,
                    mean: null,
                    stdDev: null,
                    areaUnit: null,
                };
                this._calculateCachedStats(annotation, viewport, renderingEngine, enabledElement);
            }
            else if (annotation.invalidated) {
                this._throttledCalculateCachedStats(annotation, viewport, renderingEngine, enabledElement);
            }
        }
    }
}
function defaultGetTextLines(data, targetId) {
    const cachedVolumeStats = data.cachedStats[targetId];
    const { area, mean, stdDev, perimeter, max, isEmptyArea, areaUnit, modalityUnit, } = cachedVolumeStats || {};
    const textLines = [];
    if (area) {
        const areaLine = isEmptyArea
            ? `Area: Oblique not supported`
            : `Area: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(area)} ${areaUnit}`;
        textLines.push(areaLine);
    }
    if (mean) {
        textLines.push(`Mean: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(mean)} ${modalityUnit}`);
    }
    if (max) {
        textLines.push(`Max: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(max)} ${modalityUnit}`);
    }
    if (stdDev) {
        textLines.push(`Std Dev: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(stdDev)} ${modalityUnit}`);
    }
    if (perimeter) {
        textLines.push(`Perimeter: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(perimeter)} ${modalityUnit}`);
    }
    return textLines;
}
PlanarFreehandROITool.toolName = 'PlanarFreehandROI';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlanarFreehandROITool);


/***/ }),

/***/ 31163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63421);
/* harmony import */ var _stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23308);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30322);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52610);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(96214);
/* harmony import */ var _Surface__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57313);
/* harmony import */ var _Contour__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2884);
/* harmony import */ var _Labelmap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(94318);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(61738);
/* harmony import */ var _annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20070);













const planarContourToolName = _annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A.toolName;
class SegmentationDisplayTool extends _base__WEBPACK_IMPORTED_MODULE_6__/* .BaseTool */ .oS {
    constructor(toolProps = {}, defaultToolProps = {
        configuration: {},
    }) {
        super(toolProps, defaultToolProps);
        this.renderSegmentation = (toolGroupId) => {
            const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__.getToolGroup)(toolGroupId);
            if (!toolGroup) {
                return;
            }
            const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
            if (!toolGroupSegmentationRepresentations ||
                toolGroupSegmentationRepresentations.length === 0) {
                return;
            }
            const toolGroupViewports = toolGroup.viewportsInfo.map(({ renderingEngineId, viewportId }) => {
                const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElementByIds)(viewportId, renderingEngineId);
                if (enabledElement) {
                    return enabledElement.viewport;
                }
            });
            const segmentationRenderList = toolGroupSegmentationRepresentations.map((representation) => {
                const config = this._getMergedRepresentationsConfig(toolGroupId);
                const viewportsRenderList = [];
                const renderers = {
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Labelmap]: _Labelmap__WEBPACK_IMPORTED_MODULE_9__/* .labelmapDisplay */ .Zy,
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Contour]: _Contour__WEBPACK_IMPORTED_MODULE_8__/* .contourDisplay */ .T,
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Surface]: _Surface__WEBPACK_IMPORTED_MODULE_7__/* .surfaceDisplay */ .u,
                };
                if (representation.type === _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Contour) {
                    this.addPlanarFreeHandToolIfAbsent(toolGroupId);
                }
                const display = renderers[representation.type];
                for (const viewport of toolGroupViewports) {
                    const renderedViewport = display.render(viewport, representation, config);
                    viewportsRenderList.push(renderedViewport);
                }
                return viewportsRenderList;
            });
            Promise.allSettled(segmentationRenderList).then(() => {
                toolGroupViewports.forEach((viewport) => {
                    viewport.render();
                });
            });
        };
    }
    onSetToolEnabled() {
        const toolGroupId = this.toolGroupId;
        const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
        if (!toolGroupSegmentationRepresentations ||
            toolGroupSegmentationRepresentations.length === 0) {
            return;
        }
        toolGroupSegmentationRepresentations.forEach((segmentationRepresentation) => {
            (0,_stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__.setSegmentationVisibility)(toolGroupId, segmentationRepresentation.segmentationRepresentationUID, true);
        });
    }
    onSetToolDisabled() {
        const toolGroupId = this.toolGroupId;
        const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
        if (!toolGroupSegmentationRepresentations ||
            toolGroupSegmentationRepresentations.length === 0) {
            return;
        }
        toolGroupSegmentationRepresentations.forEach((segmentationRepresentation) => {
            (0,_stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__.setSegmentationVisibility)(toolGroupId, segmentationRepresentation.segmentationRepresentationUID, false);
        });
    }
    addPlanarFreeHandToolIfAbsent(toolGroupId) {
        if (!(planarContourToolName in _store__WEBPACK_IMPORTED_MODULE_10__/* .state */ .wk.tools)) {
            (0,_store__WEBPACK_IMPORTED_MODULE_10__/* .addTool */ .Gx)(_annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A);
        }
        const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__.getToolGroup)(toolGroupId);
        if (!toolGroup.hasTool(planarContourToolName)) {
            toolGroup.addTool(planarContourToolName);
            toolGroup.setToolPassive(planarContourToolName);
        }
    }
    _getMergedRepresentationsConfig(toolGroupId) {
        const toolGroupConfig = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__.config.getToolGroupSpecificConfig(toolGroupId);
        const globalConfig = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__.config.getGlobalConfig();
        const mergedConfig = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(globalConfig, toolGroupConfig);
        return mergedConfig;
    }
}
SegmentationDisplayTool.toolName = 'SegmentationDisplay';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SegmentationDisplayTool);


/***/ }),

/***/ 81848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  M$: () => (/* reexport */ AdvancedMagnifyTool/* default */.A),
  EC: () => (/* reexport */ base/* AnnotationTool */.EC),
  PlanarFreehandContourSegmentationTool: () => (/* reexport */ PlanarFreehandContourSegmentationTool/* default */.A),
  ex: () => (/* reexport */ PlanarFreehandROITool/* default */.A),
  mX: () => (/* reexport */ segmentation_RectangleROIStartEndThresholdTool),
  TR: () => (/* reexport */ segmentation_RectangleROIThresholdTool),
  t0: () => (/* reexport */ SegmentationDisplayTool/* default */.A)
});

// UNUSED EXPORTS: AngleTool, AnnotationDisplayTool, ArrowAnnotateTool, BaseTool, BidirectionalTool, BrushTool, CircleROIStartEndThresholdTool, CircleROITool, CircleScissorsTool, CobbAngleTool, CrosshairsTool, DragProbeTool, EllipticalROITool, EraserTool, KeyImageTool, LengthTool, LivewireContourSegmentationTool, LivewireContourTool, MIPJumpToClickTool, MagnifyTool, OrientationMarkerTool, OverlayGridTool, PaintFillTool, PanTool, PlanarRotateTool, ProbeTool, RectangleROITool, RectangleScissorsTool, ReferenceCursors, ReferenceLines, ReferenceLinesTool, ScaleOverlayTool, SculptorTool, SegmentSelectTool, SegmentationIntersectionTool, SphereScissorsTool, SplineContourSegmentationTool, SplineROITool, StackScrollMouseWheelTool, StackScrollTool, TrackballRotateTool, UltrasoundDirectionalTool, VolumeRotateMouseWheelTool, WindowLevelRegionTool, WindowLevelTool, ZoomTool

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/base/index.js
var base = __webpack_require__(96214);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/PanTool.js
var PanTool = __webpack_require__(25294);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/TrackballRotateTool.js
var TrackballRotateTool = __webpack_require__(15924);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/WindowLevelTool.js
var WindowLevelTool = __webpack_require__(455);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/WindowLevelRegionTool.js
var WindowLevelRegionTool = __webpack_require__(60747);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/StackScrollTool.js
var StackScrollTool = __webpack_require__(20132);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/PlanarRotateTool.js
var PlanarRotateTool = __webpack_require__(15354);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/StackScrollToolMouseWheelTool.js
var StackScrollToolMouseWheelTool = __webpack_require__(57008);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ZoomTool.js
var ZoomTool = __webpack_require__(20842);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/VolumeRotateMouseWheelTool.js
var VolumeRotateMouseWheelTool = __webpack_require__(94574);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/MIPJumpToClickTool.js
var MIPJumpToClickTool = __webpack_require__(57424);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/CrosshairsTool.js
var CrosshairsTool = __webpack_require__(91976);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/MagnifyTool.js
var MagnifyTool = __webpack_require__(93970);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/AdvancedMagnifyTool.js
var AdvancedMagnifyTool = __webpack_require__(73168);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ReferenceLinesTool.js
var ReferenceLinesTool = __webpack_require__(54541);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/OverlayGridTool.js
var OverlayGridTool = __webpack_require__(87841);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/SegmentationIntersectionTool.js
var SegmentationIntersectionTool = __webpack_require__(70494);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ReferenceCursors.js
var ReferenceCursors = __webpack_require__(1143);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ScaleOverlayTool.js
var ScaleOverlayTool = __webpack_require__(92807);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/SculptorTool.js
var SculptorTool = __webpack_require__(16151);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/BidirectionalTool.js
var BidirectionalTool = __webpack_require__(50720);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LengthTool.js
var LengthTool = __webpack_require__(72655);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/ProbeTool.js
var ProbeTool = __webpack_require__(30049);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/DragProbeTool.js
var DragProbeTool = __webpack_require__(28087);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/RectangleROITool.js
var RectangleROITool = __webpack_require__(19994);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/EllipticalROITool.js
var EllipticalROITool = __webpack_require__(19116);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/CircleROITool.js
var CircleROITool = __webpack_require__(42865);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/SplineROITool.js
var SplineROITool = __webpack_require__(42058);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/SplineContourSegmentationTool.js
var SplineContourSegmentationTool = __webpack_require__(67540);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/PlanarFreehandROITool.js
var PlanarFreehandROITool = __webpack_require__(39244);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/PlanarFreehandContourSegmentationTool.js
var PlanarFreehandContourSegmentationTool = __webpack_require__(20070);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LivewireContourTool.js
var LivewireContourTool = __webpack_require__(19904);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LivewireContourSegmentationTool.js
var LivewireContourSegmentationTool = __webpack_require__(88854);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/ArrowAnnotateTool.js
var ArrowAnnotateTool = __webpack_require__(65314);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/AngleTool.js
var AngleTool = __webpack_require__(1368);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/CobbAngleTool.js
var CobbAngleTool = __webpack_require__(40310);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/UltrasoundDirectionalTool.js
var UltrasoundDirectionalTool = __webpack_require__(95608);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/KeyImageTool.js
var KeyImageTool = __webpack_require__(72799);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/AnnotationEraserTool.js
var AnnotationEraserTool = __webpack_require__(7336);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/displayTools/SegmentationDisplayTool.js
var SegmentationDisplayTool = __webpack_require__(31163);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleScissorsTool.js
var RectangleScissorsTool = __webpack_require__(81502);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/CircleScissorsTool.js
var CircleScissorsTool = __webpack_require__(34229);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/SphereScissorsTool.js
var SphereScissorsTool = __webpack_require__(55108);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/index.js
var stateManagement = __webpack_require__(95778);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/annotationLocking.js
var annotationLocking = __webpack_require__(48428);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/index.js + 18 modules
var drawingSvg = __webpack_require__(49574);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js + 4 modules
var viewportFilters = __webpack_require__(90252);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/elementCursor.js
var elementCursor = __webpack_require__(40233);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForViewportIds.js
var triggerAnnotationRenderForViewportIds = __webpack_require__(23072);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/annotationVisibility.js
var annotationVisibility = __webpack_require__(21009);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/helpers/state.js
var state = __webpack_require__(54177);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleROIThresholdTool.js










class RectangleROIThresholdTool extends RectangleROITool/* default */.A {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            shadow: true,
            preventHandleOutsideImage: false,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const worldPos = currentPoints.world;
            const enabledElement = (0,esm.getEnabledElement)(element);
            const { viewport, renderingEngine } = enabledElement;
            this.isDrawing = true;
            const camera = viewport.getCamera();
            const { viewPlaneNormal, viewUp } = camera;
            const targetId = this.getTargetId(viewport);
            let referencedImageId, volumeId;
            if (viewport instanceof esm.StackViewport) {
                referencedImageId = targetId.split('imageId:')[1];
            }
            else {
                volumeId = esm.utilities.getVolumeId(targetId);
                const imageVolume = esm.cache.getVolume(volumeId);
                referencedImageId = esm.utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
            }
            const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
            const annotation = {
                highlighted: true,
                invalidated: true,
                metadata: {
                    viewPlaneNormal: [...viewPlaneNormal],
                    enabledElement,
                    viewUp: [...viewUp],
                    FrameOfReferenceUID,
                    referencedImageId,
                    toolName: this.getToolName(),
                    volumeId,
                },
                data: {
                    label: '',
                    handles: {
                        textBox: {
                            hasMoved: false,
                            worldPosition: null,
                            worldBoundingBox: null,
                        },
                        points: [
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                        ],
                        activeHandleIndex: null,
                    },
                    segmentationId: null,
                },
            };
            (0,stateManagement/* addAnnotation */.lC)(annotation, element);
            const viewportIdsToRender = (0,viewportFilters.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex: 3,
                newAnnotation: true,
                hasMoved: false,
            };
            this._activateDraw(element);
            (0,elementCursor.hideElementCursor)(element);
            evt.preventDefault();
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = false;
            const { viewport } = enabledElement;
            const { element } = viewport;
            let annotations = (0,stateManagement/* getAnnotations */.Rh)(this.getToolName(), element);
            if (!annotations?.length) {
                return renderStatus;
            }
            annotations = this.filterInteractableAnnotationsForElement(element, annotations);
            if (!annotations?.length) {
                return renderStatus;
            }
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const lineWidth = this.getStyle('lineWidth', styleSpecifier, annotation);
                const lineDash = this.getStyle('lineDash', styleSpecifier, annotation);
                const color = this.getStyle('color', styleSpecifier, annotation);
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                (0,state/* triggerAnnotationModified */.XF)(annotation, element);
                let activeHandleCanvasCoords;
                if (!(0,annotationVisibility.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,annotationLocking.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,drawingSvg.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                const rectangleUID = '0';
                (0,drawingSvg.drawRect)(svgDrawingHelper, annotationUID, rectangleUID, canvasCoordinates[0], canvasCoordinates[3], {
                    color,
                    lineDash,
                    lineWidth,
                });
                renderStatus = true;
            }
            return renderStatus;
        };
    }
}
RectangleROIThresholdTool.toolName = 'RectangleROIThreshold';
/* harmony default export */ const segmentation_RectangleROIThresholdTool = (RectangleROIThresholdTool);

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var gl_matrix_esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/throttle.js
var throttle = __webpack_require__(21090);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js + 1 modules
var utilities = __webpack_require__(74119);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleROIStartEndThresholdTool.js














const { transformWorldToIndex } = esm.utilities;
class RectangleROIStartEndThresholdTool extends RectangleROITool/* default */.A {
    constructor(toolProps = {}, defaultToolProps = {
        configuration: {
            numSlicesToPropagate: 10,
            computePointsInsideVolume: false,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const worldPos = currentPoints.world;
            const enabledElement = (0,esm.getEnabledElement)(element);
            const { viewport, renderingEngine } = enabledElement;
            this.isDrawing = true;
            const camera = viewport.getCamera();
            const { viewPlaneNormal, viewUp } = camera;
            let referencedImageId, imageVolume, volumeId;
            if (viewport instanceof esm.StackViewport) {
                throw new Error('Stack Viewport Not implemented');
            }
            else {
                const targetId = this.getTargetId(viewport);
                volumeId = esm.utilities.getVolumeId(targetId);
                imageVolume = esm.cache.getVolume(volumeId);
                referencedImageId = esm.utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
            }
            if (!referencedImageId) {
                throw new Error('This tool does not work on non-acquisition planes');
            }
            const startIndex = viewport.getCurrentImageIdIndex();
            const spacingInNormal = esm.utilities.getSpacingInNormalDirection(imageVolume, viewPlaneNormal);
            const endIndex = this._getEndSliceIndex(imageVolume, worldPos, spacingInNormal, viewPlaneNormal);
            const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
            const annotation = {
                highlighted: true,
                invalidated: true,
                metadata: {
                    viewPlaneNormal: [...viewPlaneNormal],
                    enabledElement,
                    viewUp: [...viewUp],
                    FrameOfReferenceUID,
                    referencedImageId,
                    toolName: this.getToolName(),
                    volumeId,
                    spacingInNormal,
                },
                data: {
                    label: '',
                    startSlice: startIndex,
                    endSlice: endIndex,
                    cachedStats: {
                        pointsInVolume: [],
                        projectionPoints: [],
                        projectionPointsImageIds: [referencedImageId],
                    },
                    handles: {
                        textBox: {
                            hasMoved: false,
                            worldPosition: null,
                            worldBoundingBox: null,
                        },
                        points: [
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                        ],
                        activeHandleIndex: null,
                    },
                    labelmapUID: null,
                },
            };
            this._computeProjectionPoints(annotation, imageVolume);
            (0,stateManagement/* addAnnotation */.lC)(annotation, element);
            const viewportIdsToRender = (0,viewportFilters.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex: 3,
                newAnnotation: true,
                hasMoved: false,
            };
            this._activateDraw(element);
            (0,elementCursor.hideElementCursor)(element);
            evt.preventDefault();
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this._endCallback = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const { annotation, viewportIdsToRender, newAnnotation, hasMoved } = this.editData;
            const { data } = annotation;
            if (newAnnotation && !hasMoved) {
                return;
            }
            data.handles.activeHandleIndex = null;
            this._deactivateModify(element);
            this._deactivateDraw(element);
            (0,elementCursor.resetElementCursor)(element);
            const enabledElement = (0,esm.getEnabledElement)(element);
            this.editData = null;
            this.isDrawing = false;
            if (this.isHandleOutsideImage &&
                this.configuration.preventHandleOutsideImage) {
                (0,stateManagement/* removeAnnotation */.O8)(annotation.annotationUID);
            }
            const targetId = this.getTargetId(enabledElement.viewport);
            const imageVolume = esm.cache.getVolume(targetId.split(/volumeId:|\?/)[1]);
            if (this.configuration.calculatePointsInsideVolume) {
                this._computePointsInsideVolume(annotation, imageVolume, enabledElement);
            }
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(enabledElement.renderingEngine, viewportIdsToRender);
            if (newAnnotation) {
                (0,state/* triggerAnnotationCompleted */.dZ)(annotation);
            }
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = false;
            const { viewport } = enabledElement;
            const annotations = (0,stateManagement/* getAnnotations */.Rh)(this.getToolName(), viewport.element);
            if (!annotations?.length) {
                return renderStatus;
            }
            const sliceIndex = viewport.getCurrentImageIdIndex();
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { startSlice, endSlice } = data;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const lineWidth = this.getStyle('lineWidth', styleSpecifier, annotation);
                const lineDash = this.getStyle('lineDash', styleSpecifier, annotation);
                const color = this.getStyle('color', styleSpecifier, annotation);
                if (sliceIndex < Math.min(startSlice, endSlice) ||
                    sliceIndex > Math.max(startSlice, endSlice)) {
                    continue;
                }
                if (annotation.invalidated) {
                    this._throttledCalculateCachedStats(annotation, enabledElement);
                }
                let firstOrLastSlice = false;
                if (sliceIndex === startSlice || sliceIndex === endSlice) {
                    firstOrLastSlice = true;
                }
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                let activeHandleCanvasCoords;
                if (!(0,annotationVisibility.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,annotationLocking.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null &&
                    firstOrLastSlice) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,drawingSvg.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                let lineDashToUse = lineDash;
                if (!firstOrLastSlice) {
                    lineDashToUse = 2;
                }
                const rectangleUID = '0';
                (0,drawingSvg.drawRect)(svgDrawingHelper, annotationUID, rectangleUID, canvasCoordinates[0], canvasCoordinates[3], {
                    color,
                    lineDash: lineDashToUse,
                    lineWidth,
                });
                renderStatus = true;
            }
            return renderStatus;
        };
        this._throttledCalculateCachedStats = (0,throttle/* default */.A)(this._calculateCachedStatsTool, 100, { trailing: true });
    }
    _computeProjectionPoints(annotation, imageVolume) {
        const { data, metadata } = annotation;
        const { viewPlaneNormal, spacingInNormal } = metadata;
        const { imageData } = imageVolume;
        const { startSlice, endSlice } = data;
        const { points } = data.handles;
        const startIJK = transformWorldToIndex(imageData, points[0]);
        if (startIJK[2] !== startSlice) {
            throw new Error('Start slice does not match');
        }
        const endIJK = gl_matrix_esm/* vec3.fromValues */.eR.fromValues(startIJK[0], startIJK[1], endSlice);
        const startWorld = gl_matrix_esm/* vec3.create */.eR.create();
        imageData.indexToWorldVec3(startIJK, startWorld);
        const endWorld = gl_matrix_esm/* vec3.create */.eR.create();
        imageData.indexToWorldVec3(endIJK, endWorld);
        const distance = gl_matrix_esm/* vec3.distance */.eR.distance(startWorld, endWorld);
        const newProjectionPoints = [];
        for (let dist = 0; dist < distance; dist += spacingInNormal) {
            newProjectionPoints.push(points.map((point) => {
                const newPoint = gl_matrix_esm/* vec3.create */.eR.create();
                gl_matrix_esm/* vec3.scaleAndAdd */.eR.scaleAndAdd(newPoint, point, viewPlaneNormal, dist);
                return Array.from(newPoint);
            }));
        }
        data.cachedStats.projectionPoints = newProjectionPoints;
        const projectionPointsImageIds = [];
        for (const RectanglePoints of newProjectionPoints) {
            const imageId = esm.utilities.getClosestImageId(imageVolume, RectanglePoints[0], viewPlaneNormal);
            projectionPointsImageIds.push(imageId);
        }
        data.cachedStats.projectionPointsImageIds = projectionPointsImageIds;
    }
    _computePointsInsideVolume(annotation, imageVolume, enabledElement) {
        const { data } = annotation;
        const projectionPoints = data.cachedStats.projectionPoints;
        const pointsInsideVolume = [[]];
        for (let i = 0; i < projectionPoints.length; i++) {
            if (!imageVolume) {
                continue;
            }
            const projectionPoint = projectionPoints[i][0];
            const worldPos1 = data.handles.points[0];
            const worldPos2 = data.handles.points[3];
            const { dimensions, imageData } = imageVolume;
            const worldPos1Index = transformWorldToIndex(imageData, worldPos1);
            const worldProjectionPointIndex = transformWorldToIndex(imageData, projectionPoint);
            worldPos1Index[0] = Math.floor(worldPos1Index[0]);
            worldPos1Index[1] = Math.floor(worldPos1Index[1]);
            worldPos1Index[2] = Math.floor(worldProjectionPointIndex[2]);
            const worldPos2Index = transformWorldToIndex(imageData, worldPos2);
            worldPos2Index[0] = Math.floor(worldPos2Index[0]);
            worldPos2Index[1] = Math.floor(worldPos2Index[1]);
            worldPos2Index[2] = Math.floor(worldProjectionPointIndex[2]);
            if (this._isInsideVolume(worldPos1Index, worldPos2Index, dimensions)) {
                this.isHandleOutsideImage = false;
                const iMin = Math.min(worldPos1Index[0], worldPos2Index[0]);
                const iMax = Math.max(worldPos1Index[0], worldPos2Index[0]);
                const jMin = Math.min(worldPos1Index[1], worldPos2Index[1]);
                const jMax = Math.max(worldPos1Index[1], worldPos2Index[1]);
                const kMin = Math.min(worldPos1Index[2], worldPos2Index[2]);
                const kMax = Math.max(worldPos1Index[2], worldPos2Index[2]);
                const boundsIJK = [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ];
                const pointsInShape = (0,utilities.pointInShapeCallback)(imageData, () => true, null, boundsIJK);
                pointsInsideVolume.push(pointsInShape);
            }
        }
        data.cachedStats.pointsInVolume = pointsInsideVolume;
    }
    _calculateCachedStatsTool(annotation, enabledElement) {
        const data = annotation.data;
        const { viewport } = enabledElement;
        const { cachedStats } = data;
        const targetId = this.getTargetId(viewport);
        const imageVolume = esm.cache.getVolume(targetId.split(/volumeId:|\?/)[1]);
        this._computeProjectionPoints(annotation, imageVolume);
        annotation.invalidated = false;
        (0,state/* triggerAnnotationModified */.XF)(annotation, viewport.element);
        return cachedStats;
    }
    _getEndSliceIndex(imageVolume, worldPos, spacingInNormal, viewPlaneNormal) {
        const numSlicesToPropagate = this.configuration.numSlicesToPropagate;
        const endPos = gl_matrix_esm/* vec3.create */.eR.create();
        gl_matrix_esm/* vec3.scaleAndAdd */.eR.scaleAndAdd(endPos, worldPos, viewPlaneNormal, numSlicesToPropagate * spacingInNormal);
        const halfSpacingInNormalDirection = spacingInNormal / 2;
        const { imageIds } = imageVolume;
        let imageIdIndex;
        for (let i = 0; i < imageIds.length; i++) {
            const imageId = imageIds[i];
            const { imagePositionPatient } = esm.metaData.get('imagePlaneModule', imageId);
            const dir = gl_matrix_esm/* vec3.create */.eR.create();
            gl_matrix_esm/* vec3.sub */.eR.sub(dir, endPos, imagePositionPatient);
            const dot = gl_matrix_esm/* vec3.dot */.eR.dot(dir, viewPlaneNormal);
            if (Math.abs(dot) < halfSpacingInNormalDirection) {
                imageIdIndex = i;
            }
        }
        return imageIdIndex;
    }
}
RectangleROIStartEndThresholdTool.toolName = 'RectangleROIStartEndThreshold';
/* harmony default export */ const segmentation_RectangleROIStartEndThresholdTool = (RectangleROIStartEndThresholdTool);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/CircleROIStartEndThresholdTool.js
var CircleROIStartEndThresholdTool = __webpack_require__(94932);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/BrushTool.js
var BrushTool = __webpack_require__(53712);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/PaintFillTool.js
var PaintFillTool = __webpack_require__(70817);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/OrientationMarkerTool.js
var OrientationMarkerTool = __webpack_require__(36129);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/SegmentSelectTool.js
var SegmentSelectTool = __webpack_require__(34041);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/index.js






















































/***/ }),

/***/ 7259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addContourSegmentationAnnotation: () => (/* reexport safe */ _addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_2__.V),
/* harmony export */   areSameSegment: () => (/* reexport safe */ _areSameSegment__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   isContourSegmentationAnnotation: () => (/* reexport safe */ _isContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_1__.A),
/* harmony export */   removeContourSegmentationAnnotation: () => (/* reexport safe */ _removeContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_3__.M)
/* harmony export */ });
/* harmony import */ var _areSameSegment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3030);
/* harmony import */ var _isContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84354);
/* harmony import */ var _addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32415);
/* harmony import */ var _removeContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78170);






/***/ }),

/***/ 74119:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  annotationFrameRange: () => (/* reexport */ annotationFrameRange/* default */.A),
  annotationHydration: () => (/* reexport */ annotationHydration/* annotationHydration */.i),
  boundingBox: () => (/* reexport */ boundingBox),
  calibrateImageSpacing: () => (/* reexport */ calibrateImageSpacing/* default */.A),
  cine: () => (/* reexport */ cine),
  clip: () => (/* reexport */ clip/* default */.Ay),
  contourSegmentation: () => (/* reexport */ contourSegmentation),
  contours: () => (/* reexport */ contours),
  debounce: () => (/* reexport */ debounce/* default */.A),
  drawing: () => (/* reexport */ drawing),
  dynamicVolume: () => (/* reexport */ dynamicVolume),
  getAnnotationNearPoint: () => (/* reexport */ getAnnotationNearPoint/* getAnnotationNearPoint */.S),
  getAnnotationNearPointOnEnabledElement: () => (/* reexport */ getAnnotationNearPoint/* getAnnotationNearPointOnEnabledElement */.s),
  getCalibratedAspect: () => (/* reexport */ getCalibratedUnits/* getCalibratedAspect */.CQ),
  getCalibratedLengthUnitsAndScale: () => (/* reexport */ getCalibratedUnits/* getCalibratedLengthUnitsAndScale */.Op),
  getCalibratedProbeUnitsAndValue: () => (/* reexport */ getCalibratedUnits/* getCalibratedProbeUnitsAndValue */.Xw),
  getClosestImageIdForStackViewport: () => (/* reexport */ annotationHydration/* getClosestImageIdForStackViewport */.x),
  getSphereBoundsInfo: () => (/* reexport */ getSphereBoundsInfo/* getSphereBoundsInfo */.R),
  getViewportForAnnotation: () => (/* reexport */ getViewportForAnnotation/* default */.A),
  isObject: () => (/* reexport */ isObject/* default */.A),
  jumpToSlice: () => (/* reexport */ jumpToSlice/* default */.A),
  math: () => (/* reexport */ math),
  orientation: () => (/* reexport */ orientation_namespaceObject),
  planar: () => (/* reexport */ planar),
  planarFreehandROITool: () => (/* reexport */ planarFreehandROITool),
  pointInShapeCallback: () => (/* reexport */ pointInShapeCallback/* default */.A),
  pointInSurroundingSphereCallback: () => (/* reexport */ pointInSurroundingSphereCallback/* default */.A),
  pointToString: () => (/* reexport */ pointToString/* pointToString */.l),
  polyDataUtils: () => (/* reexport */ utils),
  rectangleROITool: () => (/* reexport */ rectangleROITool),
  roundNumber: () => (/* binding */ roundNumber),
  scroll: () => (/* reexport */ utilities_scroll/* default */.A),
  segmentation: () => (/* reexport */ segmentation),
  stackContextPrefetch: () => (/* reexport */ stackPrefetch/* stackContextPrefetch */.N),
  stackPrefetch: () => (/* reexport */ stackPrefetch/* stackPrefetch */.S),
  throttle: () => (/* reexport */ throttle/* default */.A),
  touch: () => (/* reexport */ touch),
  triggerAnnotationRender: () => (/* reexport */ triggerAnnotationRender/* default */.Ay),
  triggerAnnotationRenderForToolGroupIds: () => (/* reexport */ triggerAnnotationRenderForToolGroupIds/* default */.A),
  triggerAnnotationRenderForViewportIds: () => (/* reexport */ triggerAnnotationRenderForViewportIds/* default */.A),
  triggerEvent: () => (/* reexport */ esm.triggerEvent),
  viewport: () => (/* reexport */ viewport),
  viewportFilters: () => (/* reexport */ viewportFilters),
  voi: () => (/* reexport */ voi)
});

// NAMESPACE OBJECT: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/index.js
var orientation_namespaceObject = {};
__webpack_require__.r(orientation_namespaceObject);
__webpack_require__.d(orientation_namespaceObject, {
  getOrientationStringLPS: () => (getOrientationStringLPS/* default */.A),
  invertOrientationStringLPS: () => (invertOrientationStringLPS/* default */.A)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getAnnotationNearPoint.js
var getAnnotationNearPoint = __webpack_require__(66429);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/debounce.js
var debounce = __webpack_require__(64857);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/throttle.js
var throttle = __webpack_require__(21090);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/isObject.js
var isObject = __webpack_require__(11857);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/clip.js
var clip = __webpack_require__(88484);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/calibrateImageSpacing.js
var calibrateImageSpacing = __webpack_require__(17167);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getCalibratedUnits.js
var getCalibratedUnits = __webpack_require__(24592);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForViewportIds.js
var triggerAnnotationRenderForViewportIds = __webpack_require__(23072);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForToolGroupIds.js
var triggerAnnotationRenderForToolGroupIds = __webpack_require__(27819);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRender.js
var triggerAnnotationRender = __webpack_require__(6805);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewport/jumpToSlice.js
var jumpToSlice = __webpack_require__(11666);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInShapeCallback.js
var pointInShapeCallback = __webpack_require__(75403);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getSphereBoundsInfo.js
var getSphereBoundsInfo = __webpack_require__(96760);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/scroll.js
var utilities_scroll = __webpack_require__(21783);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointToString.js
var pointToString = __webpack_require__(60438);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/annotationFrameRange.js
var annotationFrameRange = __webpack_require__(41209);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInSurroundingSphereCallback.js
var pointInSurroundingSphereCallback = __webpack_require__(5093);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getViewportForAnnotation.js
var getViewportForAnnotation = __webpack_require__(39490);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/annotationHydration.js
var annotationHydration = __webpack_require__(25781);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js + 9 modules
var contours = __webpack_require__(75908);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/index.js
var segmentation = __webpack_require__(10351);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/index.js + 1 modules
var drawing = __webpack_require__(10910);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/planar/index.js
var planar = __webpack_require__(84797);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js + 4 modules
var viewportFilters = __webpack_require__(90252);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/getOrientationStringLPS.js
var getOrientationStringLPS = __webpack_require__(80393);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/invertOrientationStringLPS.js
var invertOrientationStringLPS = __webpack_require__(39365);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/index.js




// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/index.js + 3 modules
var cine = __webpack_require__(60001);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/boundingBox/index.js
var boundingBox = __webpack_require__(15306);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/planarFreehandROITool/index.js
var planarFreehandROITool = __webpack_require__(44074);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/rectangleROITool/index.js
var rectangleROITool = __webpack_require__(15874);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/index.js + 2 modules
var stackPrefetch = __webpack_require__(90387);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewport/index.js
var viewport = __webpack_require__(31555);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/touch/index.js
var touch = __webpack_require__(54868);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/index.js + 2 modules
var dynamicVolume = __webpack_require__(16390);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/polyData/utils.js
var utils = __webpack_require__(46514);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/index.js + 4 modules
var voi = __webpack_require__(14149);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contourSegmentation/index.js
var contourSegmentation = __webpack_require__(7259);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js






































const roundNumber = esm.utilities.roundNumber;




/***/ }),

/***/ 73047:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BasicStatsCalculator: () => (/* reexport module object */ _basic__WEBPACK_IMPORTED_MODULE_1__),
/* harmony export */   aabb: () => (/* reexport module object */ _aabb__WEBPACK_IMPORTED_MODULE_0__),
/* harmony export */   ellipse: () => (/* reexport module object */ _ellipse__WEBPACK_IMPORTED_MODULE_2__),
/* harmony export */   lineSegment: () => (/* reexport module object */ _line__WEBPACK_IMPORTED_MODULE_3__),
/* harmony export */   point: () => (/* reexport module object */ _point__WEBPACK_IMPORTED_MODULE_4__),
/* harmony export */   polyline: () => (/* reexport module object */ _polyline__WEBPACK_IMPORTED_MODULE_5__),
/* harmony export */   rectangle: () => (/* reexport module object */ _rectangle__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   vec2: () => (/* reexport module object */ _vec2__WEBPACK_IMPORTED_MODULE_7__)
/* harmony export */ });
/* harmony import */ var _aabb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27924);
/* harmony import */ var _basic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83112);
/* harmony import */ var _ellipse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2264);
/* harmony import */ var _line__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21954);
/* harmony import */ var _point__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14846);
/* harmony import */ var _polyline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(56634);
/* harmony import */ var _rectangle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23345);
/* harmony import */ var _vec2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(73100);











/***/ }),

/***/ 10351:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   contourAndFindLargestBidirectional: () => (/* reexport safe */ _contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_12__.A),
/* harmony export */   createBidirectionalToolData: () => (/* reexport safe */ _createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_13__.A),
/* harmony export */   createImageIdReferenceMap: () => (/* reexport safe */ _createImageIdReferenceMap__WEBPACK_IMPORTED_MODULE_11__.c),
/* harmony export */   createLabelmapVolumeForViewport: () => (/* reexport safe */ _createLabelmapVolumeForViewport__WEBPACK_IMPORTED_MODULE_5__.A),
/* harmony export */   createMergedLabelmapForIndex: () => (/* reexport safe */ _createMergedLabelmapForIndex__WEBPACK_IMPORTED_MODULE_2__.A),
/* harmony export */   floodFill: () => (/* reexport safe */ _floodFill__WEBPACK_IMPORTED_MODULE_7__.A),
/* harmony export */   getBrushSizeForToolGroup: () => (/* reexport safe */ _brushSizeForToolGroup__WEBPACK_IMPORTED_MODULE_8__.A),
/* harmony export */   getBrushThresholdForToolGroup: () => (/* reexport safe */ _brushThresholdForToolGroup__WEBPACK_IMPORTED_MODULE_9__.Q),
/* harmony export */   getBrushToolInstances: () => (/* reexport safe */ _utilities__WEBPACK_IMPORTED_MODULE_20__.n7),
/* harmony export */   getDefaultRepresentationConfig: () => (/* reexport safe */ _getDefaultRepresentationConfig__WEBPACK_IMPORTED_MODULE_4__.A),
/* harmony export */   getHoveredContourSegmentationAnnotation: () => (/* reexport safe */ _getHoveredContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_19__.L),
/* harmony export */   getSegmentAtLabelmapBorder: () => (/* reexport safe */ _getSegmentAtLabelmapBorder__WEBPACK_IMPORTED_MODULE_18__.F),
/* harmony export */   getSegmentAtWorldPoint: () => (/* reexport safe */ _getSegmentAtWorldPoint__WEBPACK_IMPORTED_MODULE_17__.Z5),
/* harmony export */   getUniqueSegmentIndices: () => (/* reexport safe */ _getUniqueSegmentIndices__WEBPACK_IMPORTED_MODULE_16__.OX),
/* harmony export */   invalidateBrushCursor: () => (/* reexport safe */ _invalidateBrushCursor__WEBPACK_IMPORTED_MODULE_15__.E),
/* harmony export */   isValidRepresentationConfig: () => (/* reexport safe */ _isValidRepresentationConfig__WEBPACK_IMPORTED_MODULE_3__.A),
/* harmony export */   rectangleROIThresholdVolumeByRange: () => (/* reexport safe */ _rectangleROIThresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_1__.A),
/* harmony export */   segmentContourAction: () => (/* reexport safe */ _segmentContourAction__WEBPACK_IMPORTED_MODULE_14__.A),
/* harmony export */   setBrushSizeForToolGroup: () => (/* reexport safe */ _brushSizeForToolGroup__WEBPACK_IMPORTED_MODULE_8__.M),
/* harmony export */   setBrushThresholdForToolGroup: () => (/* reexport safe */ _brushThresholdForToolGroup__WEBPACK_IMPORTED_MODULE_9__.K),
/* harmony export */   thresholdSegmentationByRange: () => (/* reexport safe */ _thresholdSegmentationByRange__WEBPACK_IMPORTED_MODULE_10__.A),
/* harmony export */   thresholdVolumeByRange: () => (/* reexport safe */ _thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   triggerSegmentationRender: () => (/* reexport safe */ _triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_6__.h6)
/* harmony export */ });
/* harmony import */ var _thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32854);
/* harmony import */ var _rectangleROIThresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71411);
/* harmony import */ var _createMergedLabelmapForIndex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86398);
/* harmony import */ var _isValidRepresentationConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19434);
/* harmony import */ var _getDefaultRepresentationConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50969);
/* harmony import */ var _createLabelmapVolumeForViewport__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5092);
/* harmony import */ var _triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49521);
/* harmony import */ var _floodFill__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27650);
/* harmony import */ var _brushSizeForToolGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87590);
/* harmony import */ var _brushThresholdForToolGroup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7300);
/* harmony import */ var _thresholdSegmentationByRange__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(92922);
/* harmony import */ var _createImageIdReferenceMap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(82914);
/* harmony import */ var _contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(41196);
/* harmony import */ var _createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(96610);
/* harmony import */ var _segmentContourAction__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(10032);
/* harmony import */ var _invalidateBrushCursor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(15818);
/* harmony import */ var _getUniqueSegmentIndices__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(94510);
/* harmony import */ var _getSegmentAtWorldPoint__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2465);
/* harmony import */ var _getSegmentAtLabelmapBorder__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(54117);
/* harmony import */ var _getHoveredContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4863);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(77071);
























/***/ }),

/***/ 64690:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Colorbar: () => (/* reexport safe */ _Colorbar__WEBPACK_IMPORTED_MODULE_1__.P),
/* harmony export */   Enums: () => (/* reexport module object */ _enums__WEBPACK_IMPORTED_MODULE_0__),
/* harmony export */   ViewportColorbar: () => (/* reexport safe */ _ViewportColorbar__WEBPACK_IMPORTED_MODULE_2__.b)
/* harmony export */ });
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(73231);
/* harmony import */ var _Colorbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50112);
/* harmony import */ var _ViewportColorbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(81034);






/***/ }),

/***/ 51250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (/* binding */ vtkImageData$1)
/* harmony export */ });
/* unused harmony exports extend, newInstance */
/* harmony import */ var _macros2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50906);
/* harmony import */ var _Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68680);
/* harmony import */ var _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52662);
/* harmony import */ var _DataSet_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(32090);
/* harmony import */ var _StructuredData_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89780);
/* harmony import */ var _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13422);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(44753);








const {
  vtkErrorMacro
} = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m;

// ----------------------------------------------------------------------------
// vtkImageData methods
// ----------------------------------------------------------------------------

function vtkImageData(publicAPI, model) {
  // Set our className
  model.classHierarchy.push('vtkImageData');
  publicAPI.setExtent = function () {
    if (model.deleted) {
      vtkErrorMacro('instance deleted - cannot call any method');
      return false;
    }
    for (var _len = arguments.length, inExtent = new Array(_len), _key = 0; _key < _len; _key++) {
      inExtent[_key] = arguments[_key];
    }
    const extentArray = inExtent.length === 1 ? inExtent[0] : inExtent;
    if (extentArray.length !== 6) {
      return false;
    }
    const changeDetected = model.extent.some((item, index) => item !== extentArray[index]);
    if (changeDetected) {
      model.extent = extentArray.slice();
      model.dataDescription = _StructuredData_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"].getDataDescriptionFromExtent */ .A.getDataDescriptionFromExtent(model.extent);
      publicAPI.modified();
    }
    return changeDetected;
  };
  publicAPI.setDimensions = function () {
    let i;
    let j;
    let k;
    if (model.deleted) {
      vtkErrorMacro('instance deleted - cannot call any method');
      return;
    }
    if (arguments.length === 1) {
      const array = arguments.length <= 0 ? undefined : arguments[0];
      i = array[0];
      j = array[1];
      k = array[2];
    } else if (arguments.length === 3) {
      i = arguments.length <= 0 ? undefined : arguments[0];
      j = arguments.length <= 1 ? undefined : arguments[1];
      k = arguments.length <= 2 ? undefined : arguments[2];
    } else {
      vtkErrorMacro('Bad dimension specification');
      return;
    }
    publicAPI.setExtent(0, i - 1, 0, j - 1, 0, k - 1);
  };
  publicAPI.getDimensions = () => [model.extent[1] - model.extent[0] + 1, model.extent[3] - model.extent[2] + 1, model.extent[5] - model.extent[4] + 1];
  publicAPI.getNumberOfCells = () => {
    const dims = publicAPI.getDimensions();
    let nCells = 1;
    for (let i = 0; i < 3; i++) {
      if (dims[i] === 0) {
        return 0;
      }
      if (dims[i] > 1) {
        nCells *= dims[i] - 1;
      }
    }
    return nCells;
  };
  publicAPI.getNumberOfPoints = () => {
    const dims = publicAPI.getDimensions();
    return dims[0] * dims[1] * dims[2];
  };
  publicAPI.getPoint = index => {
    const dims = publicAPI.getDimensions();
    if (dims[0] === 0 || dims[1] === 0 || dims[2] === 0) {
      vtkErrorMacro('Requesting a point from an empty image.');
      return null;
    }
    const ijk = new Float64Array(3);
    switch (model.dataDescription) {
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.EMPTY:
        return null;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.SINGLE_POINT:
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.X_LINE:
        ijk[0] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.Y_LINE:
        ijk[1] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.Z_LINE:
        ijk[2] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XY_PLANE:
        ijk[0] = index % dims[0];
        ijk[1] = index / dims[0];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.YZ_PLANE:
        ijk[1] = index % dims[1];
        ijk[2] = index / dims[1];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XZ_PLANE:
        ijk[0] = index % dims[0];
        ijk[2] = index / dims[0];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XYZ_GRID:
        ijk[0] = index % dims[0];
        ijk[1] = index / dims[0] % dims[1];
        ijk[2] = index / (dims[0] * dims[1]);
        break;
      default:
        vtkErrorMacro('Invalid dataDescription');
        break;
    }
    const coords = [0, 0, 0];
    publicAPI.indexToWorld(ijk, coords);
    return coords;
  };

  // vtkCell *GetCell(vtkIdType cellId) VTK_OVERRIDE;
  // void GetCell(vtkIdType cellId, vtkGenericCell *cell) VTK_OVERRIDE;
  // void GetCellBounds(vtkIdType cellId, double bounds[6]) VTK_OVERRIDE;
  // virtual vtkIdType FindPoint(double x, double y, double z)
  // {
  //   return this->vtkDataSet::FindPoint(x, y, z);
  // }
  // vtkIdType FindPoint(double x[3]) VTK_OVERRIDE;
  // vtkIdType FindCell(
  //   double x[3], vtkCell *cell, vtkIdType cellId, double tol2,
  //   int& subId, double pcoords[3], double *weights) VTK_OVERRIDE;
  // vtkIdType FindCell(
  //   double x[3], vtkCell *cell, vtkGenericCell *gencell,
  //   vtkIdType cellId, double tol2, int& subId,
  //   double pcoords[3], double *weights) VTK_OVERRIDE;
  // vtkCell *FindAndGetCell(double x[3], vtkCell *cell, vtkIdType cellId,
  //                                 double tol2, int& subId, double pcoords[3],
  //                                 double *weights) VTK_OVERRIDE;
  // int GetCellType(vtkIdType cellId) VTK_OVERRIDE;
  // void GetCellPoints(vtkIdType cellId, vtkIdList *ptIds) VTK_OVERRIDE
  //   {vtkStructuredData::GetCellPoints(cellId,ptIds,this->DataDescription,
  //                                     this->GetDimensions());}
  // void GetPointCells(vtkIdType ptId, vtkIdList *cellIds) VTK_OVERRIDE
  //   {vtkStructuredData::GetPointCells(ptId,cellIds,this->GetDimensions());}
  // void ComputeBounds() VTK_OVERRIDE;
  // int GetMaxCellSize() VTK_OVERRIDE {return 8;}; //voxel is the largest

  publicAPI.getBounds = () => publicAPI.extentToBounds(publicAPI.getSpatialExtent());
  publicAPI.extentToBounds = ex => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(ex, model.indexToWorld);
  publicAPI.getSpatialExtent = () => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].inflate */ .Ay.inflate([...model.extent], 0.5);

  // Internal, shouldn't need to call this manually.
  publicAPI.computeTransforms = () => {
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.fromTranslation */ .pB.fromTranslation(model.indexToWorld, model.origin);
    model.indexToWorld[0] = model.direction[0];
    model.indexToWorld[1] = model.direction[1];
    model.indexToWorld[2] = model.direction[2];
    model.indexToWorld[4] = model.direction[3];
    model.indexToWorld[5] = model.direction[4];
    model.indexToWorld[6] = model.direction[5];
    model.indexToWorld[8] = model.direction[6];
    model.indexToWorld[9] = model.direction[7];
    model.indexToWorld[10] = model.direction[8];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.scale */ .pB.scale(model.indexToWorld, model.indexToWorld, model.spacing);
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.invert */ .pB.invert(model.worldToIndex, model.indexToWorld);
  };
  publicAPI.indexToWorld = function (ain) {
    let aout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .vec3.transformMat4 */ .eR.transformMat4(aout, ain, model.indexToWorld);
    return aout;
  };
  publicAPI.indexToWorldVec3 = publicAPI.indexToWorld;
  publicAPI.worldToIndex = function (ain) {
    let aout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .vec3.transformMat4 */ .eR.transformMat4(aout, ain, model.worldToIndex);
    return aout;
  };
  publicAPI.worldToIndexVec3 = publicAPI.worldToIndex;
  publicAPI.indexToWorldBounds = function (bin) {
    let bout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    return _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(bin, model.indexToWorld, bout);
  };
  publicAPI.worldToIndexBounds = function (bin) {
    let bout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    return _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(bin, model.worldToIndex, bout);
  };

  // Make sure the transform is correct
  publicAPI.onModified(publicAPI.computeTransforms);
  publicAPI.computeTransforms();
  publicAPI.getCenter = () => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getCenter */ .Ay.getCenter(publicAPI.getBounds());
  publicAPI.computeHistogram = function (worldBounds) {
    let voxelFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    const bounds = [0, 0, 0, 0, 0, 0];
    publicAPI.worldToIndexBounds(worldBounds, bounds);
    const point1 = [0, 0, 0];
    const point2 = [0, 0, 0];
    _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].computeCornerPoints */ .Ay.computeCornerPoints(bounds, point1, point2);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.b)(point1, point1);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.b)(point2, point2);
    const dimensions = publicAPI.getDimensions();
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.c)(point1, [0, 0, 0], [dimensions[0] - 1, dimensions[1] - 1, dimensions[2] - 1], point1);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.c)(point2, [0, 0, 0], [dimensions[0] - 1, dimensions[1] - 1, dimensions[2] - 1], point2);
    const yStride = dimensions[0];
    const zStride = dimensions[0] * dimensions[1];
    const pixels = publicAPI.getPointData().getScalars().getData();
    let maximum = -Infinity;
    let minimum = Infinity;
    let sumOfSquares = 0;
    let isum = 0;
    let inum = 0;
    for (let z = point1[2]; z <= point2[2]; z++) {
      for (let y = point1[1]; y <= point2[1]; y++) {
        let index = point1[0] + y * yStride + z * zStride;
        for (let x = point1[0]; x <= point2[0]; x++) {
          if (!voxelFunc || voxelFunc([x, y, z], bounds)) {
            const pixel = pixels[index];
            if (pixel > maximum) maximum = pixel;
            if (pixel < minimum) minimum = pixel;
            sumOfSquares += pixel * pixel;
            isum += pixel;
            inum += 1;
          }
          ++index;
        }
      }
    }
    const average = inum > 0 ? isum / inum : 0;
    const variance = inum ? Math.abs(sumOfSquares / inum - average * average) : 0;
    const sigma = Math.sqrt(variance);
    return {
      minimum,
      maximum,
      average,
      variance,
      sigma,
      count: inum
    };
  };

  // TODO: use the unimplemented `vtkDataSetAttributes` for scalar length, that is currently also a TODO (GetNumberOfComponents).
  // Scalar data could be tuples for color information?
  publicAPI.computeIncrements = function (extent) {
    let numberOfComponents = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    const increments = [];
    let incr = numberOfComponents;

    // Calculate array increment offsets
    // similar to c++ vtkImageData::ComputeIncrements
    for (let idx = 0; idx < 3; ++idx) {
      increments[idx] = incr;
      incr *= extent[idx * 2 + 1] - extent[idx * 2] + 1;
    }
    return increments;
  };

  /**
   * @param {Number[]} index the localized `[i,j,k]` pixel array position. Float values will be rounded.
   * @return {Number} the corresponding flattened index in the scalar array
   */
  publicAPI.computeOffsetIndex = _ref => {
    let [i, j, k] = _ref;
    const extent = publicAPI.getExtent();
    const numberOfComponents = publicAPI.getPointData().getScalars().getNumberOfComponents();
    const increments = publicAPI.computeIncrements(extent, numberOfComponents);
    // Use the array increments to find the pixel index
    // similar to c++ vtkImageData::GetArrayPointer
    // Math.floor to catch "practically 0" e^-15 scenarios.
    return Math.floor((Math.round(i) - extent[0]) * increments[0] + (Math.round(j) - extent[2]) * increments[1] + (Math.round(k) - extent[4]) * increments[2]);
  };

  /**
   * @param {Number[]} xyz the [x,y,z] Array in world coordinates
   * @return {Number|NaN} the corresponding pixel's index in the scalar array
   */
  publicAPI.getOffsetIndexFromWorld = xyz => {
    const extent = publicAPI.getExtent();
    const index = publicAPI.worldToIndex(xyz);

    // Confirm indexed i,j,k coords are within the bounds of the volume
    for (let idx = 0; idx < 3; ++idx) {
      if (index[idx] < extent[idx * 2] || index[idx] > extent[idx * 2 + 1]) {
        vtkErrorMacro(`GetScalarPointer: Pixel ${index} is not in memory. Current extent = ${extent}`);
        return NaN;
      }
    }

    // Assumed the index here is within 0 <-> scalarData.length, but doesn't hurt to check upstream
    return publicAPI.computeOffsetIndex(index);
  };
  /**
   * @param {Number[]} xyz the [x,y,z] Array in world coordinates
   * @param {Number?} comp the scalar component index for multi-component scalars
   * @return {Number|NaN} the corresponding pixel's scalar value
   */
  publicAPI.getScalarValueFromWorld = function (xyz) {
    let comp = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    const numberOfComponents = publicAPI.getPointData().getScalars().getNumberOfComponents();
    if (comp < 0 || comp >= numberOfComponents) {
      vtkErrorMacro(`GetScalarPointer: Scalar Component ${comp} is not within bounds. Current Scalar numberOfComponents: ${numberOfComponents}`);
      return NaN;
    }
    const offsetIndex = publicAPI.getOffsetIndexFromWorld(xyz);
    if (Number.isNaN(offsetIndex)) {
      // VTK Error Macro will have been tripped already, no need to do it again,
      return offsetIndex;
    }
    return publicAPI.getPointData().getScalars().getComponent(offsetIndex, comp);
  };
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {
  direction: null,
  // a mat3
  indexToWorld: null,
  // a mat4
  worldToIndex: null,
  // a mat4
  spacing: [1.0, 1.0, 1.0],
  origin: [0.0, 0.0, 0.0],
  extent: [0, -1, 0, -1, 0, -1],
  dataDescription: _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.EMPTY
};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);

  // Inheritance
  _DataSet_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"].extend */ .Ay.extend(publicAPI, model, initialValues);
  if (!model.direction) {
    model.direction = gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat3.identity */ .w0.identity(new Float64Array(9));
  } else if (Array.isArray(model.direction)) {
    model.direction = new Float64Array(model.direction.slice(0, 9));
  }
  model.indexToWorld = new Float64Array(16);
  model.worldToIndex = new Float64Array(16);

  // Set/Get methods
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.get(publicAPI, model, ['indexToWorld', 'worldToIndex']);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGetArray(publicAPI, model, ['origin', 'spacing'], 3);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGetArray(publicAPI, model, ['direction'], 9);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.getArray(publicAPI, model, ['extent'], 6);

  // Object specific methods
  vtkImageData(publicAPI, model);
}

// ----------------------------------------------------------------------------

const newInstance = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.newInstance(extend, 'vtkImageData');

// ----------------------------------------------------------------------------

var vtkImageData$1 = {
  newInstance,
  extend
};




/***/ }),

/***/ 51008:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** `Object#toString` result references. */
var funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    symbolTag = '[object Symbol]';

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/,
    reLeadingDot = /^\./,
    rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof __webpack_require__.g == 'object' && __webpack_require__.g && __webpack_require__.g.Object === Object && __webpack_require__.g;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Checks if `value` is a host object in IE < 9.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
 */
function isHostObject(value) {
  // Many host objects are `Object` objects that can coerce to strings
  // despite having improperly defined `toString` methods.
  var result = false;
  if (value != null && typeof value.toString != 'function') {
    try {
      result = !!(value + '');
    } catch (e) {}
  }
  return result;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype,
    funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/** Built-in value references. */
var Symbol = root.Symbol,
    splice = arrayProto.splice;

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map'),
    nativeCreate = getNative(Object, 'create');

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  return this.has(key) && delete this.__data__[key];
}

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? data[key] !== undefined : hasOwnProperty.call(data, key);
}

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
}

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  return getMapData(this, key)['delete'](key);
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  getMapData(this, key).set(key, value);
  return this;
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */
function baseGet(object, path) {
  path = isKey(path, object) ? [path] : castPath(path);

  var index = 0,
      length = path.length;

  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return (index && index == length) ? object : undefined;
}

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = (isFunction(value) || isHostObject(value)) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value) {
  return isArray(value) ? value : stringToPath(value);
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoize(function(string) {
  string = toString(string);

  var result = [];
  if (reLeadingDot.test(string)) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, string) {
    result.push(quote ? string.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to process.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result);
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Assign cache to `_.memoize`.
memoize.Cache = MapCache;

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 8-9 which returns 'object' for typed array and other constructors.
  var tag = isObject(value) ? objectToString.call(value) : '';
  return tag == funcTag || tag == genTag;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */
function get(object, path, defaultValue) {
  var result = object == null ? undefined : baseGet(object, path);
  return result === undefined ? defaultValue : result;
}

module.exports = get;


/***/ }),

/***/ 99178:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A2: () => (/* binding */ releaseProxy),
/* harmony export */   BX: () => (/* binding */ proxy),
/* harmony export */   LV: () => (/* binding */ wrap),
/* harmony export */   p: () => (/* binding */ expose)
/* harmony export */ });
/* unused harmony exports createEndpoint, finalizer, proxyMarker, transfer, transferHandlers, windowEndpoint */
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const proxyMarker = Symbol("Comlink.proxy");
const createEndpoint = Symbol("Comlink.endpoint");
const releaseProxy = Symbol("Comlink.releaseProxy");
const finalizer = Symbol("Comlink.finalizer");
const throwMarker = Symbol("Comlink.thrown");
const isObject = (val) => (typeof val === "object" && val !== null) || typeof val === "function";
/**
 * Internal transfer handle to handle objects marked to proxy.
 */
const proxyTransferHandler = {
    canHandle: (val) => isObject(val) && val[proxyMarker],
    serialize(obj) {
        const { port1, port2 } = new MessageChannel();
        expose(obj, port1);
        return [port2, [port2]];
    },
    deserialize(port) {
        port.start();
        return wrap(port);
    },
};
/**
 * Internal transfer handler to handle thrown exceptions.
 */
const throwTransferHandler = {
    canHandle: (value) => isObject(value) && throwMarker in value,
    serialize({ value }) {
        let serialized;
        if (value instanceof Error) {
            serialized = {
                isError: true,
                value: {
                    message: value.message,
                    name: value.name,
                    stack: value.stack,
                },
            };
        }
        else {
            serialized = { isError: false, value };
        }
        return [serialized, []];
    },
    deserialize(serialized) {
        if (serialized.isError) {
            throw Object.assign(new Error(serialized.value.message), serialized.value);
        }
        throw serialized.value;
    },
};
/**
 * Allows customizing the serialization of certain values.
 */
const transferHandlers = new Map([
    ["proxy", proxyTransferHandler],
    ["throw", throwTransferHandler],
]);
function isAllowedOrigin(allowedOrigins, origin) {
    for (const allowedOrigin of allowedOrigins) {
        if (origin === allowedOrigin || allowedOrigin === "*") {
            return true;
        }
        if (allowedOrigin instanceof RegExp && allowedOrigin.test(origin)) {
            return true;
        }
    }
    return false;
}
function expose(obj, ep = globalThis, allowedOrigins = ["*"]) {
    ep.addEventListener("message", function callback(ev) {
        if (!ev || !ev.data) {
            return;
        }
        if (!isAllowedOrigin(allowedOrigins, ev.origin)) {
            console.warn(`Invalid origin '${ev.origin}' for comlink proxy`);
            return;
        }
        const { id, type, path } = Object.assign({ path: [] }, ev.data);
        const argumentList = (ev.data.argumentList || []).map(fromWireValue);
        let returnValue;
        try {
            const parent = path.slice(0, -1).reduce((obj, prop) => obj[prop], obj);
            const rawValue = path.reduce((obj, prop) => obj[prop], obj);
            switch (type) {
                case "GET" /* MessageType.GET */:
                    {
                        returnValue = rawValue;
                    }
                    break;
                case "SET" /* MessageType.SET */:
                    {
                        parent[path.slice(-1)[0]] = fromWireValue(ev.data.value);
                        returnValue = true;
                    }
                    break;
                case "APPLY" /* MessageType.APPLY */:
                    {
                        returnValue = rawValue.apply(parent, argumentList);
                    }
                    break;
                case "CONSTRUCT" /* MessageType.CONSTRUCT */:
                    {
                        const value = new rawValue(...argumentList);
                        returnValue = proxy(value);
                    }
                    break;
                case "ENDPOINT" /* MessageType.ENDPOINT */:
                    {
                        const { port1, port2 } = new MessageChannel();
                        expose(obj, port2);
                        returnValue = transfer(port1, [port1]);
                    }
                    break;
                case "RELEASE" /* MessageType.RELEASE */:
                    {
                        returnValue = undefined;
                    }
                    break;
                default:
                    return;
            }
        }
        catch (value) {
            returnValue = { value, [throwMarker]: 0 };
        }
        Promise.resolve(returnValue)
            .catch((value) => {
            return { value, [throwMarker]: 0 };
        })
            .then((returnValue) => {
            const [wireValue, transferables] = toWireValue(returnValue);
            ep.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
            if (type === "RELEASE" /* MessageType.RELEASE */) {
                // detach and deactive after sending release response above.
                ep.removeEventListener("message", callback);
                closeEndPoint(ep);
                if (finalizer in obj && typeof obj[finalizer] === "function") {
                    obj[finalizer]();
                }
            }
        })
            .catch((error) => {
            // Send Serialization Error To Caller
            const [wireValue, transferables] = toWireValue({
                value: new TypeError("Unserializable return value"),
                [throwMarker]: 0,
            });
            ep.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
        });
    });
    if (ep.start) {
        ep.start();
    }
}
function isMessagePort(endpoint) {
    return endpoint.constructor.name === "MessagePort";
}
function closeEndPoint(endpoint) {
    if (isMessagePort(endpoint))
        endpoint.close();
}
function wrap(ep, target) {
    return createProxy(ep, [], target);
}
function throwIfProxyReleased(isReleased) {
    if (isReleased) {
        throw new Error("Proxy has been released and is not useable");
    }
}
function releaseEndpoint(ep) {
    return requestResponseMessage(ep, {
        type: "RELEASE" /* MessageType.RELEASE */,
    }).then(() => {
        closeEndPoint(ep);
    });
}
const proxyCounter = new WeakMap();
const proxyFinalizers = "FinalizationRegistry" in globalThis &&
    new FinalizationRegistry((ep) => {
        const newCount = (proxyCounter.get(ep) || 0) - 1;
        proxyCounter.set(ep, newCount);
        if (newCount === 0) {
            releaseEndpoint(ep);
        }
    });
function registerProxy(proxy, ep) {
    const newCount = (proxyCounter.get(ep) || 0) + 1;
    proxyCounter.set(ep, newCount);
    if (proxyFinalizers) {
        proxyFinalizers.register(proxy, ep, proxy);
    }
}
function unregisterProxy(proxy) {
    if (proxyFinalizers) {
        proxyFinalizers.unregister(proxy);
    }
}
function createProxy(ep, path = [], target = function () { }) {
    let isProxyReleased = false;
    const proxy = new Proxy(target, {
        get(_target, prop) {
            throwIfProxyReleased(isProxyReleased);
            if (prop === releaseProxy) {
                return () => {
                    unregisterProxy(proxy);
                    releaseEndpoint(ep);
                    isProxyReleased = true;
                };
            }
            if (prop === "then") {
                if (path.length === 0) {
                    return { then: () => proxy };
                }
                const r = requestResponseMessage(ep, {
                    type: "GET" /* MessageType.GET */,
                    path: path.map((p) => p.toString()),
                }).then(fromWireValue);
                return r.then.bind(r);
            }
            return createProxy(ep, [...path, prop]);
        },
        set(_target, prop, rawValue) {
            throwIfProxyReleased(isProxyReleased);
            // FIXME: ES6 Proxy Handler `set` methods are supposed to return a
            // boolean. To show good will, we return true asynchronously ¯\_(ツ)_/¯
            const [value, transferables] = toWireValue(rawValue);
            return requestResponseMessage(ep, {
                type: "SET" /* MessageType.SET */,
                path: [...path, prop].map((p) => p.toString()),
                value,
            }, transferables).then(fromWireValue);
        },
        apply(_target, _thisArg, rawArgumentList) {
            throwIfProxyReleased(isProxyReleased);
            const last = path[path.length - 1];
            if (last === createEndpoint) {
                return requestResponseMessage(ep, {
                    type: "ENDPOINT" /* MessageType.ENDPOINT */,
                }).then(fromWireValue);
            }
            // We just pretend that `bind()` didn’t happen.
            if (last === "bind") {
                return createProxy(ep, path.slice(0, -1));
            }
            const [argumentList, transferables] = processArguments(rawArgumentList);
            return requestResponseMessage(ep, {
                type: "APPLY" /* MessageType.APPLY */,
                path: path.map((p) => p.toString()),
                argumentList,
            }, transferables).then(fromWireValue);
        },
        construct(_target, rawArgumentList) {
            throwIfProxyReleased(isProxyReleased);
            const [argumentList, transferables] = processArguments(rawArgumentList);
            return requestResponseMessage(ep, {
                type: "CONSTRUCT" /* MessageType.CONSTRUCT */,
                path: path.map((p) => p.toString()),
                argumentList,
            }, transferables).then(fromWireValue);
        },
    });
    registerProxy(proxy, ep);
    return proxy;
}
function myFlat(arr) {
    return Array.prototype.concat.apply([], arr);
}
function processArguments(argumentList) {
    const processed = argumentList.map(toWireValue);
    return [processed.map((v) => v[0]), myFlat(processed.map((v) => v[1]))];
}
const transferCache = new WeakMap();
function transfer(obj, transfers) {
    transferCache.set(obj, transfers);
    return obj;
}
function proxy(obj) {
    return Object.assign(obj, { [proxyMarker]: true });
}
function windowEndpoint(w, context = globalThis, targetOrigin = "*") {
    return {
        postMessage: (msg, transferables) => w.postMessage(msg, targetOrigin, transferables),
        addEventListener: context.addEventListener.bind(context),
        removeEventListener: context.removeEventListener.bind(context),
    };
}
function toWireValue(value) {
    for (const [name, handler] of transferHandlers) {
        if (handler.canHandle(value)) {
            const [serializedValue, transferables] = handler.serialize(value);
            return [
                {
                    type: "HANDLER" /* WireValueType.HANDLER */,
                    name,
                    value: serializedValue,
                },
                transferables,
            ];
        }
    }
    return [
        {
            type: "RAW" /* WireValueType.RAW */,
            value,
        },
        transferCache.get(value) || [],
    ];
}
function fromWireValue(value) {
    switch (value.type) {
        case "HANDLER" /* WireValueType.HANDLER */:
            return transferHandlers.get(value.name).deserialize(value.value);
        case "RAW" /* WireValueType.RAW */:
            return value.value;
    }
}
function requestResponseMessage(ep, msg, transfers) {
    return new Promise((resolve) => {
        const id = generateUUID();
        ep.addEventListener("message", function l(ev) {
            if (!ev.data || !ev.data.id || ev.data.id !== id) {
                return;
            }
            ep.removeEventListener("message", l);
            resolve(ev.data);
        });
        if (ep.start) {
            ep.start();
        }
        ep.postMessage(Object.assign({ id }, msg), transfers);
    });
}
function generateUUID() {
    return new Array(4)
        .fill(0)
        .map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16))
        .join("-");
}


//# sourceMappingURL=comlink.mjs.map


/***/ }),

/***/ 1201:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ bisector)
/* harmony export */ });
/* harmony import */ var _ascending_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89370);
/* harmony import */ var _descending_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43768);



function bisector(f) {
  let compare1, compare2, delta;

  // If an accessor is specified, promote it to a comparator. In this case we
  // can test whether the search value is (self-) comparable. We can’t do this
  // for a comparator (except for specific, known comparators) because we can’t
  // tell if the comparator is symmetric, and an asymmetric comparator can’t be
  // used to test whether a single value is comparable.
  if (f.length !== 2) {
    compare1 = _ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A;
    compare2 = (d, x) => (0,_ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(f(d), x);
    delta = (d, x) => f(d) - x;
  } else {
    compare1 = f === _ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A || f === _descending_js__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A ? f : zero;
    compare2 = f;
    delta = f;
  }

  function left(a, x, lo = 0, hi = a.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = (lo + hi) >>> 1;
        if (compare2(a[mid], x) < 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }

  function right(a, x, lo = 0, hi = a.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = (lo + hi) >>> 1;
        if (compare2(a[mid], x) <= 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }

  function center(a, x, lo = 0, hi = a.length) {
    const i = left(a, x, lo, hi - 1);
    return i > lo && delta(a[i - 1], x) > -delta(a[i], x) ? i - 1 : i;
  }

  return {left, center, right};
}

function zero() {
  return 0;
}


/***/ })

}]);