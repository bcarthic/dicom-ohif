"use strict";
(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([[914],{

/***/ 52454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _AnnotationDisplayTool__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28062);
/* harmony import */ var _stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48428);
/* harmony import */ var _stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21009);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38296);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(54177);







class AnnotationTool extends _AnnotationDisplayTool__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A {
    constructor(toolProps, defaultToolProps) {
        super(toolProps, defaultToolProps);
        this.mouseMoveCallback = (evt, filteredAnnotations) => {
            if (!filteredAnnotations) {
                return false;
            }
            const { element, currentPoints } = evt.detail;
            const canvasCoords = currentPoints.canvas;
            let annotationsNeedToBeRedrawn = false;
            for (const annotation of filteredAnnotations) {
                if ((0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__.isAnnotationLocked)(annotation) ||
                    !(0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__.isAnnotationVisible)(annotation.annotationUID)) {
                    continue;
                }
                const { data } = annotation;
                const activateHandleIndex = data.handles
                    ? data.handles.activeHandleIndex
                    : undefined;
                const near = this._imagePointNearToolOrHandle(element, annotation, canvasCoords, 6);
                const nearToolAndNotMarkedActive = near && !annotation.highlighted;
                const notNearToolAndMarkedActive = !near && annotation.highlighted;
                if (nearToolAndNotMarkedActive || notNearToolAndMarkedActive) {
                    annotation.highlighted = !annotation.highlighted;
                    annotationsNeedToBeRedrawn = true;
                }
                else if (data.handles &&
                    data.handles.activeHandleIndex !== activateHandleIndex) {
                    annotationsNeedToBeRedrawn = true;
                }
            }
            return annotationsNeedToBeRedrawn;
        };
        if (toolProps.configuration?.getTextLines) {
            this.configuration.getTextLines = toolProps.configuration.getTextLines;
        }
        if (toolProps.configuration?.statsCalculator) {
            this.configuration.statsCalculator =
                toolProps.configuration.statsCalculator;
        }
    }
    static createAnnotation(...annotationBaseData) {
        let annotation = {
            annotationUID: null,
            highlighted: true,
            invalidated: true,
            metadata: {
                toolName: this.toolName,
            },
            data: {
                text: '',
                handles: {
                    points: new Array(),
                    textBox: {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    },
                },
                label: '',
            },
        };
        for (const baseData of annotationBaseData) {
            annotation = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(annotation, baseData);
        }
        return annotation;
    }
    static createAnnotationForViewport(viewport, ...annotationBaseData) {
        return this.createAnnotation({ metadata: viewport.getViewReference() }, ...annotationBaseData);
    }
    static createAndAddAnnotation(viewport, ...annotationBaseData) {
        const annotation = this.createAnnotationForViewport(viewport, ...annotationBaseData);
        (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_5__.addAnnotation)(annotation, viewport.element);
        (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_6__/* .triggerAnnotationModified */ .XF)(annotation, viewport.element);
    }
    getHandleNearImagePoint(element, annotation, canvasCoords, proximity) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const { data } = annotation;
        const { isCanvasAnnotation } = data;
        const { points, textBox } = data.handles;
        if (textBox) {
            const { worldBoundingBox } = textBox;
            if (worldBoundingBox) {
                const canvasBoundingBox = {
                    topLeft: viewport.worldToCanvas(worldBoundingBox.topLeft),
                    topRight: viewport.worldToCanvas(worldBoundingBox.topRight),
                    bottomLeft: viewport.worldToCanvas(worldBoundingBox.bottomLeft),
                    bottomRight: viewport.worldToCanvas(worldBoundingBox.bottomRight),
                };
                if (canvasCoords[0] >= canvasBoundingBox.topLeft[0] &&
                    canvasCoords[0] <= canvasBoundingBox.bottomRight[0] &&
                    canvasCoords[1] >= canvasBoundingBox.topLeft[1] &&
                    canvasCoords[1] <= canvasBoundingBox.bottomRight[1]) {
                    data.handles.activeHandleIndex = null;
                    return textBox;
                }
            }
        }
        for (let i = 0; i < points?.length; i++) {
            const point = points[i];
            const annotationCanvasCoordinate = isCanvasAnnotation
                ? point.slice(0, 2)
                : viewport.worldToCanvas(point);
            const near = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec2.distance */ .Zc.distance(canvasCoords, annotationCanvasCoordinate) < proximity;
            if (near === true) {
                data.handles.activeHandleIndex = i;
                return point;
            }
        }
        data.handles.activeHandleIndex = null;
    }
    getLinkedTextBoxStyle(specifications, annotation) {
        return {
            visibility: this.getStyle('textBoxVisibility', specifications, annotation),
            fontFamily: this.getStyle('textBoxFontFamily', specifications, annotation),
            fontSize: this.getStyle('textBoxFontSize', specifications, annotation),
            color: this.getStyle('textBoxColor', specifications, annotation),
            shadow: this.getStyle('textBoxShadow', specifications, annotation),
            background: this.getStyle('textBoxBackground', specifications, annotation),
            lineWidth: this.getStyle('textBoxLinkLineWidth', specifications, annotation),
            lineDash: this.getStyle('textBoxLinkLineDash', specifications, annotation),
        };
    }
    isSuvScaled(viewport, targetId, imageId) {
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
            const volumeId = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getVolumeId(targetId);
            const volume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
            return volume?.scaling?.PT !== undefined;
        }
        const scalingModule = imageId && _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.metaData.get('scalingModule', imageId);
        return typeof scalingModule?.suvbw === 'number';
    }
    getAnnotationStyle(context) {
        const { annotation, styleSpecifier } = context;
        const getStyle = (property) => this.getStyle(property, styleSpecifier, annotation);
        const { annotationUID } = annotation;
        const visibility = (0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__.isAnnotationVisible)(annotationUID);
        const locked = (0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__.isAnnotationLocked)(annotation);
        const lineWidth = getStyle('lineWidth');
        const lineDash = getStyle('lineDash');
        const color = getStyle('color');
        const shadow = getStyle('shadow');
        const textboxStyle = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
        return {
            visibility,
            locked,
            color,
            lineWidth,
            lineDash,
            lineOpacity: 1,
            fillColor: color,
            fillOpacity: 0,
            shadow,
            textbox: textboxStyle,
        };
    }
    _imagePointNearToolOrHandle(element, annotation, canvasCoords, proximity) {
        const handleNearImagePoint = this.getHandleNearImagePoint(element, annotation, canvasCoords, proximity);
        if (handleNearImagePoint) {
            return true;
        }
        const toolNewImagePoint = this.isPointNearTool(element, annotation, canvasCoords, proximity, 'mouse');
        if (toolNewImagePoint) {
            return true;
        }
    }
}
AnnotationTool.toolName = 'AnnotationTool';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AnnotationTool);


/***/ }),

/***/ 44350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   J: () => (/* binding */ isValidLabelmapConfig)
/* harmony export */ });
const defaultLabelmapConfig = {
    renderOutline: true,
    outlineWidthActive: 3,
    outlineWidthInactive: 2,
    activeSegmentOutlineWidthDelta: 0,
    renderFill: true,
    renderFillInactive: true,
    fillAlpha: 0.7,
    fillAlphaInactive: 0.65,
    outlineOpacity: 1,
    outlineOpacityInactive: 0.85,
};
function getDefaultLabelmapConfig() {
    return defaultLabelmapConfig;
}
function isValidLabelmapConfig(config) {
    return (config &&
        typeof config.renderOutline === 'boolean' &&
        typeof config.outlineWidthActive === 'number' &&
        typeof config.outlineWidthInactive === 'number' &&
        typeof config.activeSegmentOutlineWidthDelta === 'number' &&
        typeof config.renderFill === 'boolean' &&
        typeof config.renderFillInactive === 'boolean' &&
        typeof config.fillAlpha === 'number' &&
        typeof config.fillAlphaInactive === 'number' &&
        typeof config.outlineOpacity === 'number' &&
        typeof config.outlineOpacityInactive === 'number');
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getDefaultLabelmapConfig);



/***/ }),

/***/ 41209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ AnnotationFrameRange)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28117);


class AnnotationFrameRange {
    static { this.frameRangeExtractor = /(\/frames\/|[&?]frameNumber=)([^/&?]*)/i; }
    static imageIdToFrames(imageId) {
        const match = imageId.match(this.frameRangeExtractor);
        if (!match || !match[2]) {
            return null;
        }
        const range = match[2].split('-').map((it) => Number(it));
        if (range.length === 1) {
            return range[0];
        }
        return range;
    }
    static framesToString(range) {
        if (Array.isArray(range)) {
            return `${range[0]}-${range[1]}`;
        }
        return String(range);
    }
    static framesToImageId(imageId, range) {
        const match = imageId.match(this.frameRangeExtractor);
        if (!match || !match[2]) {
            return null;
        }
        const newRangeString = this.framesToString(range);
        return imageId.replace(this.frameRangeExtractor, `${match[1]}${newRangeString}`);
    }
    static setFrameRange(annotation, range, eventBase) {
        const { referencedImageId } = annotation.metadata;
        annotation.metadata.referencedImageId = this.framesToImageId(referencedImageId, range);
        const eventDetail = {
            ...eventBase,
            annotation,
        };
        (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.triggerEvent)(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _enums_Events__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.ANNOTATION_MODIFIED, eventDetail);
    }
    static getFrameRange(annotation) {
        return this.imageIdToFrames(annotation.metadata.referencedImageId);
    }
}


/***/ }),

/***/ 25781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ annotationHydration),
/* harmony export */   x: () => (/* binding */ getClosestImageIdForStackViewport)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95778);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44753);



function annotationHydration(viewport, toolName, worldPoints, options) {
    const viewReference = viewport.getViewReference();
    const { viewPlaneNormal, FrameOfReferenceUID } = viewReference;
    const annotation = {
        annotationUID: options?.annotationUID || _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.uuidv4(),
        data: {
            handles: {
                points: worldPoints,
            },
        },
        highlighted: false,
        autoGenerated: false,
        invalidated: false,
        isLocked: false,
        isVisible: true,
        metadata: {
            toolName,
            viewPlaneNormal,
            FrameOfReferenceUID,
            referencedImageId: getReferencedImageId(viewport, worldPoints[0], viewPlaneNormal),
            ...options,
        },
    };
    (0,_stateManagement__WEBPACK_IMPORTED_MODULE_1__/* .addAnnotation */ .lC)(annotation, viewport.element);
    return annotation;
}
function getReferencedImageId(viewport, worldPos, viewPlaneNormal) {
    let referencedImageId;
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        referencedImageId = getClosestImageIdForStackViewport(viewport, worldPos, viewPlaneNormal);
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
        const targetId = getTargetId(viewport);
        const volumeId = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getVolumeId(targetId);
        const imageVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        referencedImageId = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
    }
    else {
        throw new Error('getReferencedImageId: viewport must be a StackViewport or BaseVolumeViewport');
    }
    return referencedImageId;
}
function getTargetId(viewport) {
    const targetId = viewport.getReferenceId?.();
    if (targetId) {
        return targetId;
    }
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
        return `volumeId:${getTargetVolumeId(viewport)}`;
    }
    throw new Error('getTargetId: viewport must have a getTargetId method');
}
function getTargetVolumeId(viewport) {
    const actorEntries = viewport.getActors();
    if (!actorEntries) {
        return;
    }
    return actorEntries.find((actorEntry) => actorEntry.actor.getClassName() === 'vtkVolume')?.uid;
}
function getClosestImageIdForStackViewport(viewport, worldPos, viewPlaneNormal) {
    const imageIds = viewport.getImageIds();
    if (!imageIds || !imageIds.length) {
        return;
    }
    const distanceImagePairs = imageIds.map((imageId) => {
        const { imagePositionPatient } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.metaData.get('imagePlaneModule', imageId);
        const distance = calculateDistanceToImage(worldPos, imagePositionPatient, viewPlaneNormal);
        return { imageId, distance };
    });
    distanceImagePairs.sort((a, b) => a.distance - b.distance);
    return distanceImagePairs[0].imageId;
}
function calculateDistanceToImage(worldPos, ImagePositionPatient, viewPlaneNormal) {
    const dir = gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.sub */ .eR.sub(dir, worldPos, ImagePositionPatient);
    const dot = gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.dot */ .eR.dot(dir, viewPlaneNormal);
    return Math.abs(dot);
}



/***/ }),

/***/ 42290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function extend2DBoundingBoxInViewAxis(boundsIJK, numSlicesToProject) {
    const sliceNormalIndex = boundsIJK.findIndex(([min, max]) => min === max);
    if (sliceNormalIndex === -1) {
        throw new Error('3D bounding boxes not supported in an oblique plane');
    }
    boundsIJK[sliceNormalIndex][0] -= numSlicesToProject;
    boundsIJK[sliceNormalIndex][1] += numSlicesToProject;
    return boundsIJK;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extend2DBoundingBoxInViewAxis);


/***/ }),

/***/ 14471:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ getBoundingBoxAroundShapeWorld),
/* harmony export */   g: () => (/* binding */ getBoundingBoxAroundShapeIJK)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { EPSILON } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.CONSTANTS;
function calculateBoundingBox(points, dimensions, isWorld = false) {
    let xMin = Infinity;
    let xMax = isWorld ? -Infinity : 0;
    let yMin = Infinity;
    let yMax = isWorld ? -Infinity : 0;
    let zMin = Infinity;
    let zMax = isWorld ? -Infinity : 0;
    const is3D = points[0]?.length === 3;
    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        xMin = Math.min(p[0], xMin);
        xMax = Math.max(p[0], xMax);
        yMin = Math.min(p[1], yMin);
        yMax = Math.max(p[1], yMax);
        if (is3D) {
            zMin = Math.min(p[2] ?? zMin, zMin);
            zMax = Math.max(p[2] ?? zMax, zMax);
        }
    }
    if (dimensions) {
        xMin = Math.max(isWorld ? dimensions[0] + EPSILON : 0, xMin);
        xMax = Math.min(isWorld ? dimensions[0] - EPSILON : dimensions[0] - 1, xMax);
        yMin = Math.max(isWorld ? dimensions[1] + EPSILON : 0, yMin);
        yMax = Math.min(isWorld ? dimensions[1] - EPSILON : dimensions[1] - 1, yMax);
        if (is3D && dimensions.length === 3) {
            zMin = Math.max(isWorld ? dimensions[2] + EPSILON : 0, zMin);
            zMax = Math.min(isWorld ? dimensions[2] - EPSILON : dimensions[2] - 1, zMax);
        }
    }
    else if (!isWorld) {
        xMin = Math.max(0, xMin);
        xMax = Math.min(Infinity, xMax);
        yMin = Math.max(0, yMin);
        yMax = Math.min(Infinity, yMax);
        if (is3D) {
            zMin = Math.max(0, zMin);
            zMax = Math.min(Infinity, zMax);
        }
    }
    return is3D
        ? [
            [xMin, xMax],
            [yMin, yMax],
            [zMin, zMax],
        ]
        : [[xMin, xMax], [yMin, yMax], null];
}
function getBoundingBoxAroundShapeIJK(points, dimensions) {
    return calculateBoundingBox(points, dimensions, false);
}
function getBoundingBoxAroundShapeWorld(points, clipBounds) {
    return calculateBoundingBox(points, clipBounds, true);
}


/***/ }),

/***/ 15306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   extend2DBoundingBoxInViewAxis: () => (/* reexport safe */ _extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   getBoundingBoxAroundShape: () => (/* reexport safe */ _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__.g),
/* harmony export */   getBoundingBoxAroundShapeIJK: () => (/* reexport safe */ _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__.g),
/* harmony export */   getBoundingBoxAroundShapeWorld: () => (/* reexport safe */ _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__.C)
/* harmony export */ });
/* harmony import */ var _extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42290);
/* harmony import */ var _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14471);





/***/ }),

/***/ 17167:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ calibrateImageSpacing)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { calibratedPixelSpacingMetadataProvider } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function calibrateImageSpacing(imageId, renderingEngine, calibrationOrScale) {
    if (typeof calibrationOrScale === 'number') {
        calibrationOrScale = {
            type: _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.Enums.CalibrationTypes.USER,
            scale: calibrationOrScale,
        };
    }
    calibratedPixelSpacingMetadataProvider.add(imageId, calibrationOrScale);
    const viewports = renderingEngine.getStackViewports();
    viewports.forEach((viewport) => {
        const imageIds = viewport.getImageIds();
        if (imageIds.includes(imageId)) {
            viewport.calibrateSpacing(imageId);
        }
    });
}


/***/ }),

/***/ 60001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Events: () => (/* reexport */ events),
  addToolState: () => (/* reexport */ addToolState),
  getToolState: () => (/* reexport */ getToolState),
  playClip: () => (/* reexport */ playClip),
  stopClip: () => (/* reexport */ stopClip)
});

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/events.js
var Events;
(function (Events) {
    Events["CLIP_STOPPED"] = "CORNERSTONE_CINE_TOOL_STOPPED";
    Events["CLIP_STARTED"] = "CORNERSTONE_CINE_TOOL_STARTED";
})(Events || (Events = {}));
/* harmony default export */ const events = (Events);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/state.js

const state = {};
function addToolState(element, data) {
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    const { viewportId } = enabledElement;
    state[viewportId] = data;
}
function getToolState(element) {
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    const { viewportId } = enabledElement;
    return state[viewportId];
}
function getToolStateByViewportId(viewportId) {
    return state[viewportId];
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/scroll.js
var utilities_scroll = __webpack_require__(21783);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/playClip.js





const { ViewportStatus } = dist_esm.Enums;
const { triggerEvent } = dist_esm.utilities;
const debounced = true;
const dynamicVolumesPlayingMap = new Map();
function playClip(element, playClipOptions) {
    let playClipTimeouts;
    let playClipIsTimeVarying;
    if (element === undefined) {
        throw new Error('playClip: element must not be undefined');
    }
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    if (!enabledElement) {
        throw new Error('playClip: element must be a valid Cornerstone enabled element');
    }
    if (!playClipOptions) {
        playClipOptions = {};
    }
    playClipOptions.dynamicCineEnabled =
        playClipOptions.dynamicCineEnabled ?? true;
    const { viewport } = enabledElement;
    const volume = _getVolumeFromViewport(viewport);
    const playClipContext = _createCinePlayContext(viewport, playClipOptions);
    let playClipData = getToolState(element);
    const isDynamicCinePlaying = playClipOptions.dynamicCineEnabled && volume?.isDynamicVolume();
    if (isDynamicCinePlaying) {
        _stopDynamicVolumeCine(element);
    }
    if (!playClipData) {
        playClipData = {
            intervalId: undefined,
            framesPerSecond: 30,
            lastFrameTimeStamp: undefined,
            ignoreFrameTimeVector: false,
            usingFrameTimeVector: false,
            frameTimeVector: playClipOptions.frameTimeVector ?? undefined,
            speed: playClipOptions.frameTimeVectorSpeedMultiplier ?? 1,
            reverse: playClipOptions.reverse ?? false,
            loop: playClipOptions.loop ?? true,
        };
        addToolState(element, playClipData);
    }
    else {
        _stopClip(element, {
            stopDynamicCine: !isDynamicCinePlaying,
            viewportId: viewport.id,
        });
    }
    playClipData.dynamicCineEnabled = playClipOptions.dynamicCineEnabled;
    if (playClipOptions.framesPerSecond < 0 ||
        playClipOptions.framesPerSecond > 0) {
        playClipData.framesPerSecond = Number(playClipOptions.framesPerSecond);
        playClipData.reverse = playClipData.framesPerSecond < 0;
        playClipData.ignoreFrameTimeVector = true;
    }
    if (playClipData.ignoreFrameTimeVector !== true &&
        playClipData.frameTimeVector &&
        playClipData.frameTimeVector.length === playClipContext.numScrollSteps &&
        playClipContext.frameTimeVectorEnabled) {
        const { timeouts, isTimeVarying } = _getPlayClipTimeouts(playClipData.frameTimeVector, playClipData.speed);
        playClipTimeouts = timeouts;
        playClipIsTimeVarying = isTimeVarying;
    }
    const playClipAction = () => {
        const { numScrollSteps, currentStepIndex } = playClipContext;
        let newStepIndex = currentStepIndex + (playClipData.reverse ? -1 : 1);
        const newStepIndexOutOfRange = newStepIndex < 0 || newStepIndex >= numScrollSteps;
        if (!playClipData.loop && newStepIndexOutOfRange) {
            _stopClip(element, {
                stopDynamicCine: !isDynamicCinePlaying,
                viewportId: viewport.id,
            });
            const eventDetail = { element };
            triggerEvent(element, events.CLIP_STOPPED, eventDetail);
            return;
        }
        if (newStepIndex >= numScrollSteps) {
            newStepIndex = 0;
        }
        else if (newStepIndex < 0) {
            newStepIndex = numScrollSteps - 1;
        }
        const delta = newStepIndex - currentStepIndex;
        if (delta) {
            playClipContext.scroll(delta);
        }
    };
    if (isDynamicCinePlaying) {
        dynamicVolumesPlayingMap.set(volume.volumeId, element);
    }
    if (playClipTimeouts &&
        playClipTimeouts.length > 0 &&
        playClipIsTimeVarying) {
        playClipData.usingFrameTimeVector = true;
        playClipData.intervalId = window.setTimeout(function playClipTimeoutHandler() {
            playClipData.intervalId = window.setTimeout(playClipTimeoutHandler, playClipTimeouts[playClipContext.currentStepIndex]);
            playClipAction();
        }, 0);
    }
    else {
        playClipData.usingFrameTimeVector = false;
        playClipData.intervalId = window.setInterval(playClipAction, 1000 / Math.abs(playClipData.framesPerSecond));
    }
    const eventDetail = {
        element,
    };
    triggerEvent(element, events.CLIP_STARTED, eventDetail);
}
function stopClip(element, options = {}) {
    _stopClip(element, {
        stopDynamicCine: true,
        ...options,
    });
}
function _stopClip(element, options = { stopDynamicCine: true, viewportId: undefined }) {
    const { stopDynamicCine, viewportId } = options;
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    let toolState;
    if (!enabledElement) {
        if (viewportId) {
            toolState = getToolStateByViewportId(viewportId);
        }
        else {
            return;
        }
    }
    else {
        const { viewport } = enabledElement;
        toolState = getToolState(viewport.element);
    }
    if (toolState) {
        _stopClipWithData(toolState);
    }
    if (stopDynamicCine &&
        enabledElement?.viewport instanceof dist_esm.BaseVolumeViewport) {
        _stopDynamicVolumeCine(element);
    }
}
function _stopDynamicVolumeCine(element) {
    const { viewport } = (0,dist_esm.getEnabledElement)(element);
    const volume = _getVolumeFromViewport(viewport);
    if (volume?.isDynamicVolume()) {
        const dynamicCineElement = dynamicVolumesPlayingMap.get(volume.volumeId);
        dynamicVolumesPlayingMap.delete(volume.volumeId);
        if (dynamicCineElement && dynamicCineElement !== element) {
            stopClip(dynamicCineElement);
        }
    }
}
function _getPlayClipTimeouts(vector, speed) {
    let i;
    let sample;
    let delay;
    let sum = 0;
    const limit = vector.length;
    const timeouts = [];
    let isTimeVarying = false;
    if (typeof speed !== 'number' || speed <= 0) {
        speed = 1;
    }
    for (i = 1; i < limit; i++) {
        delay = (Number(vector[i]) / speed) | 0;
        timeouts.push(delay);
        if (i === 1) {
            sample = delay;
        }
        else if (delay !== sample) {
            isTimeVarying = true;
        }
        sum += delay;
    }
    if (timeouts.length > 0) {
        if (isTimeVarying) {
            delay = (sum / timeouts.length) | 0;
        }
        else {
            delay = timeouts[0];
        }
        timeouts.push(delay);
    }
    return { timeouts, isTimeVarying };
}
function _stopClipWithData(playClipData) {
    const id = playClipData.intervalId;
    if (typeof id !== 'undefined') {
        playClipData.intervalId = undefined;
        if (playClipData.usingFrameTimeVector) {
            clearTimeout(id);
        }
        else {
            clearInterval(id);
        }
    }
}
function _getVolumesFromViewport(viewport) {
    return viewport
        .getActors()
        .map((actor) => dist_esm.cache.getVolume(actor.uid))
        .filter((volume) => !!volume);
}
function _getVolumeFromViewport(viewport) {
    const volumes = _getVolumesFromViewport(viewport);
    const dynamicVolume = volumes.find((volume) => volume.isDynamicVolume());
    return dynamicVolume ?? volumes[0];
}
function _createStackViewportCinePlayContext(viewport, waitForRendered) {
    const imageIds = viewport.getImageIds();
    return {
        get numScrollSteps() {
            return imageIds.length;
        },
        get currentStepIndex() {
            return viewport.getTargetImageIdIndex();
        },
        get frameTimeVectorEnabled() {
            return true;
        },
        waitForRenderedCount: 0,
        scroll(delta) {
            if (this.waitForRenderedCount <= waitForRendered &&
                viewport.viewportStatus !== ViewportStatus.RENDERED) {
                this.waitForRenderedCount++;
                return;
            }
            this.waitForRenderedCount = 0;
            (0,utilities_scroll/* default */.A)(viewport, { delta, debounceLoading: debounced });
        },
    };
}
function _createVolumeViewportCinePlayContext(viewport, volume) {
    const { volumeId } = volume;
    const cachedScrollInfo = {
        viewPlaneNormal: esm/* vec3.create */.eR.create(),
        scrollInfo: null,
    };
    const getScrollInfo = () => {
        const camera = viewport.getCamera();
        const updateCache = !cachedScrollInfo.scrollInfo ||
            !esm/* vec3.equals */.eR.equals(camera.viewPlaneNormal, cachedScrollInfo.viewPlaneNormal);
        if (updateCache) {
            const scrollInfo = dist_esm.utilities.getVolumeViewportScrollInfo(viewport, volumeId);
            cachedScrollInfo.viewPlaneNormal = camera.viewPlaneNormal;
            cachedScrollInfo.scrollInfo = scrollInfo;
        }
        return cachedScrollInfo.scrollInfo;
    };
    return {
        get numScrollSteps() {
            return getScrollInfo().numScrollSteps;
        },
        get currentStepIndex() {
            return getScrollInfo().currentStepIndex;
        },
        get frameTimeVectorEnabled() {
            const camera = viewport.getCamera();
            const volumeViewPlaneNormal = volume.direction
                .slice(6, 9)
                .map((x) => -x);
            const dot = esm/* vec3.dot */.eR.dot(volumeViewPlaneNormal, camera.viewPlaneNormal);
            return esm/* glMatrix.equals */.Fd.equals(dot, 1);
        },
        scroll(delta) {
            getScrollInfo().currentStepIndex += delta;
            (0,utilities_scroll/* default */.A)(viewport, { delta });
        },
    };
}
function _createDynamicVolumeViewportCinePlayContext(volume) {
    return {
        get numScrollSteps() {
            return volume.numTimePoints;
        },
        get currentStepIndex() {
            return volume.timePointIndex;
        },
        get frameTimeVectorEnabled() {
            return false;
        },
        scroll(delta) {
            volume.timePointIndex += delta;
        },
    };
}
function _createCinePlayContext(viewport, playClipOptions) {
    if (viewport instanceof dist_esm.StackViewport) {
        return _createStackViewportCinePlayContext(viewport, playClipOptions.waitForRendered ?? 30);
    }
    if (viewport instanceof dist_esm.VolumeViewport) {
        const volume = _getVolumeFromViewport(viewport);
        if (playClipOptions.dynamicCineEnabled && volume?.isDynamicVolume()) {
            return _createDynamicVolumeViewportCinePlayContext(volume);
        }
        return _createVolumeViewportCinePlayContext(viewport, volume);
    }
    throw new Error('Unknown viewport type');
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/index.js






/***/ }),

/***/ 88484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports clip, clipToBox */
function clip(val, low, high) {
    return Math.min(Math.max(low, val), high);
}
function clipToBox(point, box) {
    point.x = clip(point.x, 0, box.width);
    point.y = clip(point.y, 0, box.height);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clip);


/***/ }),

/***/ 32415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ addContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30322);

function addContourSegmentationAnnotation(annotation) {
    if (annotation.parentAnnotationUID) {
        return;
    }
    if (!annotation.data.segmentation) {
        throw new Error('addContourSegmentationAnnotation: annotation does not have a segmentation data');
    }
    const { segmentationId, segmentIndex } = annotation.data.segmentation;
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_0__.getSegmentation)(segmentationId);
    if (!segmentation.representationData.CONTOUR) {
        segmentation.representationData.CONTOUR = { annotationUIDsMap: new Map() };
    }
    const { annotationUIDsMap } = segmentation.representationData.CONTOUR;
    let annotationsUIDsSet = annotationUIDsMap.get(segmentIndex);
    if (!annotationsUIDsSet) {
        annotationsUIDsSet = new Set();
        annotationUIDsMap.set(segmentIndex, annotationsUIDsSet);
    }
    annotationUIDsMap.set(segmentIndex, annotationsUIDsSet.add(annotation.annotationUID));
}


/***/ }),

/***/ 3030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ areSameSegment)
/* harmony export */ });
function areSameSegment(firstAnnotation, secondAnnotation) {
    const { segmentation: firstSegmentation } = firstAnnotation.data;
    const { segmentation: secondSegmentation } = secondAnnotation.data;
    return (firstSegmentation.segmentationId === secondSegmentation.segmentationId &&
        firstSegmentation.segmentIndex === secondSegmentation.segmentIndex);
}


/***/ }),

/***/ 84354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ isContourSegmentationAnnotation)
/* harmony export */ });
function isContourSegmentationAnnotation(annotation) {
    return !!annotation.data?.segmentation;
}


/***/ }),

/***/ 78170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ removeContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63421);

function removeContourSegmentationAnnotation(annotation) {
    if (!annotation.data.segmentation) {
        throw new Error('removeContourSegmentationAnnotation: annotation does not have a segmentation data');
    }
    const { segmentationId, segmentIndex } = annotation.data.segmentation;
    const segmentation = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_0__.state.getSegmentation(segmentationId);
    const { annotationUIDsMap } = segmentation?.representationData.CONTOUR || {};
    const annotationsUIDsSet = annotationUIDsMap?.get(segmentIndex);
    if (!annotationsUIDsSet) {
        return;
    }
    annotationsUIDsSet.delete(annotation.annotationUID);
    if (!annotationsUIDsSet.size) {
        annotationUIDsMap.delete(segmentIndex);
    }
}


/***/ }),

/***/ 53891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function calculatePerimeter(polyline, closed) {
    let perimeter = 0;
    for (let i = 0; i < polyline.length - 1; i++) {
        const point1 = polyline[i];
        const point2 = polyline[i + 1];
        perimeter += Math.sqrt(Math.pow(point2[0] - point1[0], 2) + Math.pow(point2[1] - point1[1], 2));
    }
    if (closed) {
        const firstPoint = polyline[0];
        const lastPoint = polyline[polyline.length - 1];
        perimeter += Math.sqrt(Math.pow(lastPoint[0] - firstPoint[0], 2) +
            Math.pow(lastPoint[1] - firstPoint[1], 2));
    }
    return perimeter;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (calculatePerimeter);


/***/ }),

/***/ 84045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ findHandlePolylineIndex)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);


const { isEqual } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function findHandlePolylineIndex(annotation, handleIndex) {
    const { polyline } = annotation.data.contour;
    const { points } = annotation.data.handles;
    const { length } = points;
    if (handleIndex === length) {
        return polyline.length;
    }
    if (handleIndex < 0) {
        handleIndex = (handleIndex + length) % length;
    }
    if (handleIndex === 0) {
        return 0;
    }
    const handle = points[handleIndex];
    const index = polyline.findIndex((point) => isEqual(handle, point));
    if (index !== -1) {
        return index;
    }
    let closestDistance = Infinity;
    return polyline.reduce((closestIndex, point, testIndex) => {
        const distance = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.squaredDistance */ .eR.squaredDistance(point, handle);
        if (distance < closestDistance) {
            closestDistance = distance;
            return testIndex;
        }
        return closestIndex;
    }, -1);
}


/***/ }),

/***/ 75908:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  AnnotationToPointData: () => (/* reexport */ contours_AnnotationToPointData),
  acceptAutogeneratedInterpolations: () => (/* reexport */ acceptAutogeneratedInterpolations),
  areCoplanarContours: () => (/* reexport */ areCoplanarContours),
  calculatePerimeter: () => (/* reexport */ calculatePerimeter/* default */.A),
  contourFinder: () => (/* reexport */ contourFinder),
  detectContourHoles: () => (/* reexport */ detectContourHoles),
  findHandlePolylineIndex: () => (/* reexport */ findHandlePolylineIndex/* default */.A),
  generateContourSetsFromLabelmap: () => (/* reexport */ generateContourSetsFromLabelmap),
  getContourHolesDataCanvas: () => (/* reexport */ getContourHolesDataCanvas),
  getContourHolesDataWorld: () => (/* reexport */ getContourHolesDataWorld),
  getDeduplicatedVTKPolyDataPoints: () => (/* reexport */ getDeduplicatedVTKPolyDataPoints),
  interpolation: () => (/* reexport */ interpolation),
  updateContourPolyline: () => (/* reexport */ updateContourPolyline/* default */.A)
});

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/areCoplanarContours.js

function areCoplanarContours(firstAnnotation, secondAnnotation) {
    const { viewPlaneNormal: firstViewPlaneNormal } = firstAnnotation.metadata;
    const { viewPlaneNormal: secondViewPlaneNormal } = secondAnnotation.metadata;
    const dot = esm/* vec3.dot */.eR.dot(firstViewPlaneNormal, secondViewPlaneNormal);
    const parallelPlanes = esm/* glMatrix.equals */.Fd.equals(1, Math.abs(dot));
    if (!parallelPlanes) {
        return false;
    }
    const { polyline: firstPolyline } = firstAnnotation.data.contour;
    const { polyline: secondPolyline } = secondAnnotation.data.contour;
    const firstDistance = esm/* vec3.dot */.eR.dot(firstViewPlaneNormal, firstPolyline[0]);
    const secondDistance = esm/* vec3.dot */.eR.dot(firstViewPlaneNormal, secondPolyline[0]);
    return esm/* glMatrix.equals */.Fd.equals(firstDistance, secondDistance);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/contourFinder.js
function findNextLink(line, lines, contourPoints) {
    let index = -1;
    lines.forEach((cell, i) => {
        if (index >= 0) {
            return;
        }
        if (cell.a == line.b) {
            index = i;
        }
    });
    if (index >= 0) {
        const nextLine = lines[index];
        lines.splice(index, 1);
        contourPoints.push(nextLine.b);
        if (contourPoints[0] == nextLine.b) {
            return {
                remainingLines: lines,
                contourPoints,
                type: 'CLOSED_PLANAR',
            };
        }
        return findNextLink(nextLine, lines, contourPoints);
    }
    return {
        remainingLines: lines,
        contourPoints,
        type: 'OPEN_PLANAR',
    };
}
function findContours(lines) {
    if (lines.length == 0) {
        return [];
    }
    const contourPoints = [];
    const firstCell = lines.shift();
    contourPoints.push(firstCell.a);
    contourPoints.push(firstCell.b);
    const result = findNextLink(firstCell, lines, contourPoints);
    if (result.remainingLines.length == 0) {
        return [
            {
                type: result.type,
                contourPoints: result.contourPoints,
            },
        ];
    }
    else {
        const extraContours = findContours(result.remainingLines);
        extraContours.push({
            type: result.type,
            contourPoints: result.contourPoints,
        });
        return extraContours;
    }
}
function findContoursFromReducedSet(lines) {
    return findContours(lines);
}
/* harmony default export */ const contourFinder = ({
    findContours,
    findContoursFromReducedSet,
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getDeduplicatedVTKPolyDataPoints.js
function getDeduplicatedVTKPolyDataPoints(polyData, bypass = false) {
    const points = polyData.getPoints();
    const lines = polyData.getLines();
    const pointsArray = new Array(points.getNumberOfPoints())
        .fill(0)
        .map((_, i) => points.getPoint(i).slice());
    const linesArray = new Array(lines.getNumberOfCells()).fill(0).map((_, i) => {
        const cell = lines.getCell(i * 3).slice();
        return { a: cell[0], b: cell[1] };
    });
    if (bypass) {
        return { points: pointsArray, lines: linesArray };
    }
    const newPoints = [];
    for (const [i, pt] of pointsArray.entries()) {
        const index = newPoints.findIndex((point) => point[0] === pt[0] && point[1] === pt[1] && point[2] === pt[2]);
        if (index >= 0) {
            linesArray.map((line) => {
                if (line.a === i) {
                    line.a = index;
                }
                if (line.b === i) {
                    line.b = index;
                }
                return line;
            });
        }
        else {
            const newIndex = newPoints.length;
            newPoints.push(pt);
            linesArray.map((line) => {
                if (line.a === i) {
                    line.a = newIndex;
                }
                if (line.b === i) {
                    line.b = newIndex;
                }
                return line;
            });
        }
    }
    const newLines = linesArray.filter((line) => line.a !== line.b);
    return { points: newPoints, lines: newLines };
}
/* harmony default export */ const contours_getDeduplicatedVTKPolyDataPoints = ({ getDeduplicatedVTKPolyDataPoints });

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/detectContourHoles.js
const getIsPointInsidePolygon = (point, vertices) => {
    const x = point[0];
    const y = point[1];
    let inside = false;
    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
        const xi = vertices[i][0], yi = vertices[i][1];
        const xj = vertices[j][0], yj = vertices[j][1];
        const intersect = yi > y != yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
        if (intersect) {
            inside = !inside;
        }
    }
    return inside;
};
function checkEnclosed(outerContour, innerContour, points) {
    const vertices = [];
    outerContour.contourPoints.forEach((point) => {
        vertices.push([points[point][0], points[point][1]]);
    });
    let pointsNotEnclosed = 0;
    innerContour.contourPoints.forEach((point) => {
        const result = getIsPointInsidePolygon([points[point][0], points[point][1]], vertices);
        if (!result) {
            pointsNotEnclosed++;
        }
    });
    return pointsNotEnclosed === 0;
}
function processContourHoles(contours, points, useXOR = true) {
    const retContours = contours.filter((contour) => contour.type !== 'CLOSED_PLANAR');
    const closedContours = contours.filter((contour) => contour.type === 'CLOSED_PLANAR');
    const contourWithHoles = [];
    let contourWithoutHoles = [];
    closedContours.forEach((contour, index) => {
        const holes = [];
        closedContours.forEach((hContour, hIndex) => {
            if (index != hIndex) {
                if (checkEnclosed(contour, hContour, points)) {
                    holes.push(hIndex);
                }
            }
        });
        if (holes.length > 0) {
            contourWithHoles.push({
                contour,
                holes,
            });
        }
        else {
            contourWithoutHoles.push(index);
        }
    });
    if (useXOR) {
        contourWithHoles.forEach((contourHoleSet) => {
            contourHoleSet.contour.type = 'CLOSEDPLANAR_XOR';
            retContours.push(contourHoleSet.contour);
            contourHoleSet.holes.forEach((holeIndex) => {
                closedContours[holeIndex].type = 'CLOSEDPLANAR_XOR';
                retContours.push(closedContours[holeIndex]);
                contourWithoutHoles = contourWithoutHoles.filter((contourIndex) => {
                    return contourIndex !== holeIndex;
                });
            });
        });
        contourWithoutHoles.forEach((contourIndex) => {
            retContours.push(closedContours[contourIndex]);
        });
    }
    else {
    }
    return retContours;
}
/* harmony default export */ const detectContourHoles = ({ processContourHoles });

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Filters/General/ImageMarchingSquares.js
var ImageMarchingSquares = __webpack_require__(52754);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/Core/DataArray.js
var DataArray = __webpack_require__(45128);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/DataModel/ImageData.js
var ImageData = __webpack_require__(51250);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/SegmentationRepresentations.js
var SegmentationRepresentations = __webpack_require__(83946);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/generateContourSetsFromLabelmap.js







const { Labelmap } = SegmentationRepresentations/* default */.A;
function generateContourSetsFromLabelmap({ segmentations }) {
    const { representationData, segments = [0, 1] } = segmentations;
    const { volumeId: segVolumeId } = representationData[Labelmap];
    const vol = dist_esm.cache.getVolume(segVolumeId);
    if (!vol) {
        console.warn(`No volume found for ${segVolumeId}`);
        return;
    }
    const numSlices = vol.dimensions[2];
    const segData = vol.imageData.getPointData().getScalars().getData();
    const pixelsPerSlice = vol.dimensions[0] * vol.dimensions[1];
    for (let z = 0; z < numSlices; z++) {
        for (let y = 0; y < vol.dimensions[1]; y++) {
            const index = y * vol.dimensions[0] + z * pixelsPerSlice;
            segData[index] = 0;
            segData[index + vol.dimensions[0] - 1] = 0;
        }
    }
    const ContourSets = [];
    const { FrameOfReferenceUID } = vol.metadata;
    const numSegments = segments.length;
    for (let segIndex = 0; segIndex < numSegments; segIndex++) {
        const segment = segments[segIndex];
        if (!segment) {
            continue;
        }
        const sliceContours = [];
        const scalars = DataArray/* default.newInstance */.Ay.newInstance({
            name: 'Scalars',
            numberOfComponents: 1,
            size: pixelsPerSlice * numSlices,
            dataType: 'Uint8Array',
        });
        const { containedSegmentIndices } = segment;
        for (let sliceIndex = 0; sliceIndex < numSlices; sliceIndex++) {
            if (isSliceEmptyForSegment(sliceIndex, segData, pixelsPerSlice, segIndex)) {
                continue;
            }
            const frameStart = sliceIndex * pixelsPerSlice;
            try {
                for (let i = 0; i < pixelsPerSlice; i++) {
                    const value = segData[i + frameStart];
                    if (value === segIndex || containedSegmentIndices?.has(value)) {
                        scalars.setValue(i + frameStart, 1);
                    }
                    else {
                        scalars.setValue(i, 0);
                    }
                }
                const mSquares = ImageMarchingSquares/* default.newInstance */.Ay.newInstance({
                    slice: sliceIndex,
                });
                const imageDataCopy = ImageData/* default.newInstance */.Ay.newInstance();
                imageDataCopy.shallowCopy(vol.imageData);
                imageDataCopy.getPointData().setScalars(scalars);
                mSquares.setInputData(imageDataCopy);
                const cValues = [1];
                mSquares.setContourValues(cValues);
                mSquares.setMergePoints(false);
                const msOutput = mSquares.getOutputData();
                const reducedSet = getDeduplicatedVTKPolyDataPoints(msOutput);
                if (reducedSet.points?.length) {
                    const contours = findContoursFromReducedSet(reducedSet.lines);
                    sliceContours.push({
                        contours,
                        polyData: reducedSet,
                        FrameNumber: sliceIndex + 1,
                        sliceIndex,
                        FrameOfReferenceUID,
                    });
                }
            }
            catch (e) {
                console.warn(sliceIndex);
                console.warn(e);
            }
        }
        const metadata = {
            FrameOfReferenceUID,
        };
        const ContourSet = {
            label: segment.label,
            color: segment.color,
            metadata,
            sliceContours,
        };
        ContourSets.push(ContourSet);
    }
    return ContourSets;
}
function isSliceEmptyForSegment(sliceIndex, segData, pixelsPerSlice, segIndex) {
    const startIdx = sliceIndex * pixelsPerSlice;
    const endIdx = startIdx + pixelsPerSlice;
    for (let i = startIdx; i < endIdx; i++) {
        if (segData[i] === segIndex) {
            return false;
        }
    }
    return true;
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/RectangleROIStartEndThreshold.js
var RectangleROIStartEndThreshold = __webpack_require__(69405);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/AnnotationToPointData.js

function validateAnnotation(annotation) {
    if (!annotation?.data) {
        throw new Error('Tool data is empty');
    }
    if (!annotation.metadata || annotation.metadata.referenceImageId) {
        throw new Error('Tool data is not associated with any imageId');
    }
}
class AnnotationToPointData {
    constructor() {
    }
    static { this.TOOL_NAMES = {}; }
    static convert(annotation, index, metadataProvider) {
        validateAnnotation(annotation);
        const { toolName } = annotation.metadata;
        const toolClass = AnnotationToPointData.TOOL_NAMES[toolName];
        if (!toolClass) {
            throw new Error(`Unknown tool type: ${toolName}, cannot convert to RTSSReport`);
        }
        const ContourSequence = toolClass.getContourSequence(annotation, metadataProvider);
        const color = [
            Math.floor(Math.random() * 255),
            Math.floor(Math.random() * 255),
            Math.floor(Math.random() * 255),
        ];
        return {
            ReferencedROINumber: index + 1,
            ROIDisplayColor: color,
            ContourSequence,
        };
    }
    static register(toolClass) {
        AnnotationToPointData.TOOL_NAMES[toolClass.toolName] = toolClass;
    }
}
AnnotationToPointData.register(RectangleROIStartEndThreshold/* default */.A);
/* harmony default export */ const contours_AnnotationToPointData = (AnnotationToPointData);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/index.js
var stateManagement = __webpack_require__(95778);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getContourHolesDataWorld.js

function getContourHolesDataWorld(annotation) {
    const childAnnotationUIDs = annotation.childAnnotationUIDs ?? [];
    return childAnnotationUIDs.map((uid) => (0,stateManagement/* getAnnotation */.gw)(uid).data.contour.polyline);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getContourHolesDataCanvas.js

function getContourHolesDataCanvas(annotation, viewport) {
    const worldHoleContours = getContourHolesDataWorld(annotation);
    const canvasHoleContours = [];
    worldHoleContours.forEach((worldHoleContour) => {
        const numPoints = worldHoleContour.length;
        const canvasHoleContour = new Array(numPoints);
        for (let i = 0; i < numPoints; i++) {
            canvasHoleContour[i] = viewport.worldToCanvas(worldHoleContour[i]);
        }
        canvasHoleContours.push(canvasHoleContour);
    });
    return canvasHoleContours;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/updateContourPolyline.js
var updateContourPolyline = __webpack_require__(89111);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/InterpolationManager/InterpolationManager.js
var InterpolationManager = __webpack_require__(33836);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/interpolation/acceptAutogeneratedInterpolations.js

function acceptAutogeneratedInterpolations(annotationGroupSelector, selector) {
    InterpolationManager/* default */.A.acceptAutoGenerated(annotationGroupSelector, selector);
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/interpolation/index.js
var interpolation = __webpack_require__(69115);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/findHandlePolylineIndex.js
var findHandlePolylineIndex = __webpack_require__(84045);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/calculatePerimeter.js
var calculatePerimeter = __webpack_require__(53891);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js
















/***/ }),

/***/ 69115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterpolationManager: () => (/* reexport safe */ _segmentation_InterpolationManager_InterpolationManager__WEBPACK_IMPORTED_MODULE_0__.A)
/* harmony export */ });
/* harmony import */ var _segmentation_InterpolationManager_InterpolationManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33836);




/***/ }),

/***/ 89111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ updateContourPolyline)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _math__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(73047);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95778);



function updateContourPolyline(annotation, polylineData, transforms, options) {
    const { canvasToWorld, worldToCanvas } = transforms;
    const { data } = annotation;
    const { targetWindingDirection } = polylineData;
    let { points: polyline } = polylineData;
    if (options?.decimate?.enabled) {
        polyline = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.decimate(polylineData.points, options?.decimate?.epsilon);
    }
    let { closed } = polylineData;
    const numPoints = polyline.length;
    const polylineWorldPoints = new Array(numPoints);
    const currentPolylineWindingDirection = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.getWindingDirection(polyline);
    const parentAnnotation = (0,_stateManagement__WEBPACK_IMPORTED_MODULE_2__/* .getParentAnnotation */ .Ay)(annotation);
    if (closed === undefined) {
        let currentClosedState = false;
        if (polyline.length > 3) {
            const lastToFirstDist = _math__WEBPACK_IMPORTED_MODULE_1__.point.distanceToPointSquared(polyline[0], polyline[numPoints - 1]);
            currentClosedState = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(0, lastToFirstDist);
        }
        closed = currentClosedState;
    }
    let windingDirection = parentAnnotation
        ? parentAnnotation.data.contour.windingDirection * -1
        : targetWindingDirection;
    if (windingDirection === undefined) {
        windingDirection = currentPolylineWindingDirection;
    }
    if (windingDirection !== currentPolylineWindingDirection) {
        polyline.reverse();
    }
    const handlePoints = data.handles.points.map((p) => worldToCanvas(p));
    if (handlePoints.length > 2) {
        const currentHandlesWindingDirection = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.getWindingDirection(handlePoints);
        if (currentHandlesWindingDirection !== windingDirection) {
            data.handles.points.reverse();
        }
    }
    for (let i = 0; i < numPoints; i++) {
        polylineWorldPoints[i] = canvasToWorld(polyline[i]);
    }
    data.contour.polyline = polylineWorldPoints;
    data.contour.closed = closed;
    data.contour.windingDirection = windingDirection;
    (0,_stateManagement__WEBPACK_IMPORTED_MODULE_2__/* .invalidateAnnotation */ .zH)(annotation);
}


/***/ }),

/***/ 64857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _isObject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11857);

function debounce(func, wait, options) {
    let lastArgs, lastThis, maxWait, result, timerId, lastCallTime;
    let lastInvokeTime = 0;
    let leading = false;
    let maxing = false;
    let trailing = true;
    const useRAF = !wait && wait !== 0 && typeof window.requestAnimationFrame === 'function';
    if (typeof func !== 'function') {
        throw new TypeError('Expected a function');
    }
    wait = Number(wait) || 0;
    if ((0,_isObject__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(options)) {
        leading = Boolean(options.leading);
        maxing = 'maxWait' in options;
        maxWait = maxing ? Math.max(Number(options.maxWait) || 0, wait) : maxWait;
        trailing = 'trailing' in options ? Boolean(options.trailing) : trailing;
    }
    function invokeFunc(time) {
        const args = lastArgs;
        const thisArg = lastThis;
        lastArgs = lastThis = undefined;
        lastInvokeTime = time;
        result = func.apply(thisArg, args);
        return result;
    }
    function startTimer(pendingFunc, wait) {
        if (useRAF) {
            return window.requestAnimationFrame(pendingFunc);
        }
        return setTimeout(pendingFunc, wait);
    }
    function cancelTimer(id) {
        if (useRAF) {
            return window.cancelAnimationFrame(id);
        }
        clearTimeout(id);
    }
    function leadingEdge(time) {
        lastInvokeTime = time;
        timerId = startTimer(timerExpired, wait);
        return leading ? invokeFunc(time) : result;
    }
    function remainingWait(time) {
        const timeSinceLastCall = time - lastCallTime;
        const timeSinceLastInvoke = time - lastInvokeTime;
        const timeWaiting = wait - timeSinceLastCall;
        return maxing
            ? Math.min(timeWaiting, maxWait - timeSinceLastInvoke)
            : timeWaiting;
    }
    function shouldInvoke(time) {
        const timeSinceLastCall = time - lastCallTime;
        const timeSinceLastInvoke = time - lastInvokeTime;
        return (lastCallTime === undefined ||
            timeSinceLastCall >= wait ||
            timeSinceLastCall < 0 ||
            (maxing && timeSinceLastInvoke >= maxWait));
    }
    function timerExpired() {
        const time = Date.now();
        if (shouldInvoke(time)) {
            return trailingEdge(time);
        }
        timerId = startTimer(timerExpired, remainingWait(time));
    }
    function trailingEdge(time) {
        timerId = undefined;
        if (trailing && lastArgs) {
            return invokeFunc(time);
        }
        lastArgs = lastThis = undefined;
        return result;
    }
    function cancel() {
        if (timerId !== undefined) {
            cancelTimer(timerId);
        }
        lastInvokeTime = 0;
        lastArgs = lastCallTime = lastThis = timerId = undefined;
    }
    function flush() {
        return timerId === undefined ? result : trailingEdge(Date.now());
    }
    function pending() {
        return timerId !== undefined;
    }
    function debounced(...args) {
        const time = Date.now();
        const isInvoking = shouldInvoke(time);
        lastArgs = args;
        lastThis = this;
        lastCallTime = time;
        if (isInvoking) {
            if (timerId === undefined) {
                return leadingEdge(lastCallTime);
            }
            if (maxing) {
                timerId = startTimer(timerExpired, wait);
                return invokeFunc(lastCallTime);
            }
        }
        if (timerId === undefined) {
            timerId = startTimer(timerExpired, wait);
        }
        return result;
    }
    debounced.cancel = cancel;
    debounced.flush = flush;
    debounced.pending = pending;
    return debounced;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (debounce);


/***/ }),

/***/ 10910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  getTextBoxCoordsCanvas: () => (/* reexport */ getTextBoxCoordsCanvas)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/getTextBoxCoordsCanvas.js
function getTextBoxCoordsCanvas(annotationCanvasPoints) {
    const corners = _determineCorners(annotationCanvasPoints);
    const centerY = (corners.top[1] + corners.bottom[1]) / 2;
    const textBoxCanvas = [corners.right[0], centerY];
    return textBoxCanvas;
}
function _determineCorners(canvasPoints) {
    const handlesLeftToRight = [canvasPoints[0], canvasPoints[1]].sort(_compareX);
    const handlesTopToBottom = [canvasPoints[0], canvasPoints[1]].sort(_compareY);
    const right = handlesLeftToRight[handlesLeftToRight.length - 1];
    const top = handlesTopToBottom[0];
    const bottom = handlesTopToBottom[handlesTopToBottom.length - 1];
    return {
        top,
        bottom,
        right,
    };
    function _compareX(a, b) {
        return a[0] < b[0] ? -1 : 1;
    }
    function _compareY(a, b) {
        return a[1] < b[1] ? -1 : 1;
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/index.js




/***/ }),

/***/ 16390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  generateImageFromTimeData: () => (/* reexport */ dynamicVolume_generateImageFromTimeData),
  getDataInTime: () => (/* reexport */ dynamicVolume_getDataInTime)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/utilities.js
var utilities = __webpack_require__(77071);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInShapeCallback.js
var pointInShapeCallback = __webpack_require__(75403);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/getDataInTime.js



function getDataInTime(dynamicVolume, options) {
    let dataInTime;
    const frames = options.frameNumbers || [
        ...Array(dynamicVolume.numTimePoints).keys(),
    ];
    if (!options.maskVolumeId && !options.imageCoordinate) {
        throw new Error('You should provide either maskVolumeId or imageCoordinate');
    }
    if (options.maskVolumeId && options.imageCoordinate) {
        throw new Error('You can only use one of maskVolumeId or imageCoordinate');
    }
    if (options.maskVolumeId) {
        const segmentationVolume = esm.cache.getVolume(options.maskVolumeId);
        const [dataInTime, ijkCoords] = _getTimePointDataMask(frames, dynamicVolume, segmentationVolume);
        return [dataInTime, ijkCoords];
    }
    if (options.imageCoordinate) {
        const dataInTime = _getTimePointDataCoordinate(frames, options.imageCoordinate, dynamicVolume);
        return dataInTime;
    }
    return dataInTime;
}
function _getTimePointDataCoordinate(frames, coordinate, volume) {
    const { dimensions, imageData } = volume;
    const index = imageData.worldToIndex(coordinate);
    index[0] = Math.floor(index[0]);
    index[1] = Math.floor(index[1]);
    index[2] = Math.floor(index[2]);
    if (!esm.utilities.indexWithinDimensions(index, dimensions)) {
        throw new Error('outside bounds');
    }
    const yMultiple = dimensions[0];
    const zMultiple = dimensions[0] * dimensions[1];
    const allScalarData = volume.getScalarDataArrays();
    const value = [];
    frames.forEach((frame) => {
        const activeScalarData = allScalarData[frame];
        const scalarIndex = index[2] * zMultiple + index[1] * yMultiple + index[0];
        value.push(activeScalarData[scalarIndex]);
    });
    return value;
}
function _getTimePointDataMask(frames, dynamicVolume, segmentationVolume) {
    const { imageData: maskImageData } = segmentationVolume;
    const segScalarData = segmentationVolume.getScalarData();
    const len = segScalarData.length;
    const nonZeroVoxelIndices = [];
    nonZeroVoxelIndices.length = len;
    const ijkCoords = [];
    const dimensions = segmentationVolume.dimensions;
    let actualLen = 0;
    for (let i = 0, len = segScalarData.length; i < len; i++) {
        if (segScalarData[i] !== 0) {
            ijkCoords.push([
                i % dimensions[0],
                Math.floor((i / dimensions[0]) % dimensions[1]),
                Math.floor(i / (dimensions[0] * dimensions[1])),
            ]);
            nonZeroVoxelIndices[actualLen++] = i;
        }
    }
    nonZeroVoxelIndices.length = actualLen;
    const dynamicVolumeScalarDataArray = dynamicVolume.getScalarDataArrays();
    const values = [];
    const isSameVolume = dynamicVolumeScalarDataArray[0].length === len &&
        JSON.stringify(dynamicVolume.spacing) ===
            JSON.stringify(segmentationVolume.spacing);
    if (isSameVolume) {
        for (let i = 0; i < nonZeroVoxelIndices.length; i++) {
            const indexValues = [];
            frames.forEach((frame) => {
                const activeScalarData = dynamicVolumeScalarDataArray[frame];
                indexValues.push(activeScalarData[nonZeroVoxelIndices[i]]);
            });
            values.push(indexValues);
        }
        return [values, ijkCoords];
    }
    const callback = ({ pointLPS: segPointLPS, value: segValue, pointIJK: segPointIJK, }) => {
        if (segValue === 0) {
            return;
        }
        const overlapIJKMinMax = (0,utilities/* getVoxelOverlap */.Q5)(dynamicVolume.imageData, dynamicVolume.dimensions, dynamicVolume.spacing, segPointLPS);
        let count = 0;
        const perFrameSum = new Map();
        frames.forEach((frame) => perFrameSum.set(frame, 0));
        const averageCallback = ({ index }) => {
            for (let i = 0; i < frames.length; i++) {
                const value = dynamicVolumeScalarDataArray[i][index];
                const frame = frames[i];
                perFrameSum.set(frame, perFrameSum.get(frame) + value);
            }
            count++;
        };
        (0,pointInShapeCallback/* default */.A)(dynamicVolume.imageData, () => true, averageCallback, overlapIJKMinMax);
        const averageValues = [];
        perFrameSum.forEach((sum) => {
            averageValues.push(sum / count);
        });
        ijkCoords.push(segPointIJK);
        values.push(averageValues);
    };
    (0,pointInShapeCallback/* default */.A)(maskImageData, () => true, callback);
    return [values, ijkCoords];
}
/* harmony default export */ const dynamicVolume_getDataInTime = (getDataInTime);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/generateImageFromTimeData.js

function generateImageFromTimeData(dynamicVolume, operation, frameNumbers) {
    const frames = frameNumbers || [...Array(dynamicVolume.numTimePoints).keys()];
    const numFrames = frames.length;
    if (frames.length <= 1) {
        throw new Error('Please provide two or more time points');
    }
    const typedArrays = dynamicVolume.getScalarDataArrays();
    const arrayLength = typedArrays[0].length;
    const finalArray = new Float32Array(arrayLength);
    if (operation === esm.Enums.DynamicOperatorType.SUM) {
        for (let i = 0; i < numFrames; i++) {
            const currentArray = typedArrays[frames[i]];
            for (let j = 0; j < arrayLength; j++) {
                finalArray[j] += currentArray[j];
            }
        }
        return finalArray;
    }
    if (operation === esm.Enums.DynamicOperatorType.SUBTRACT) {
        if (frames.length > 2) {
            throw new Error('Please provide only 2 time points for subtraction.');
        }
        for (let j = 0; j < arrayLength; j++) {
            finalArray[j] += typedArrays[frames[0]][j] - typedArrays[frames[1]][j];
        }
        return finalArray;
    }
    if (operation === esm.Enums.DynamicOperatorType.AVERAGE) {
        for (let i = 0; i < numFrames; i++) {
            const currentArray = typedArrays[frames[i]];
            for (let j = 0; j < arrayLength; j++) {
                finalArray[j] += currentArray[j];
            }
        }
        for (let k = 0; k < arrayLength; k++) {
            finalArray[k] = finalArray[k] / numFrames;
        }
        return finalArray;
    }
}
/* harmony default export */ const dynamicVolume_generateImageFromTimeData = (generateImageFromTimeData);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/index.js






/***/ }),

/***/ 66429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   S: () => (/* binding */ getAnnotationNearPoint),
/* harmony export */   s: () => (/* binding */ getAnnotationNearPointOnEnabledElement)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38296);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52610);



function getAnnotationNearPoint(element, canvasPoint, proximity = 5) {
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
    if (!enabledElement) {
        throw new Error('getAnnotationNearPoint: enabledElement not found');
    }
    return getAnnotationNearPointOnEnabledElement(enabledElement, canvasPoint, proximity);
}
function getAnnotationNearPointOnEnabledElement(enabledElement, point, proximity) {
    const { renderingEngineId, viewportId } = enabledElement;
    const toolGroup = _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__.getToolGroupForViewport(viewportId, renderingEngineId);
    if (!toolGroup) {
        return null;
    }
    const { _toolInstances: tools } = toolGroup;
    for (const name in tools) {
        const found = findAnnotationNearPointByTool(tools[name], enabledElement, point, proximity);
        if (found) {
            return found;
        }
    }
    return null;
}
function findAnnotationNearPointByTool(tool, enabledElement, point, proximity) {
    const { viewport } = enabledElement;
    const annotations = (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_1__.getAnnotations)(tool.constructor.toolName, viewport?.element);
    const currentId = viewport?.getCurrentImageId?.();
    if (annotations?.length) {
        const { element } = enabledElement.viewport;
        for (const annotation of annotations) {
            const referencedImageId = annotation.metadata?.referencedImageId;
            if ((currentId && referencedImageId && currentId !== referencedImageId) ||
                !tool.isPointNearTool) {
                continue;
            }
            if (tool.isPointNearTool(element, annotation, point, proximity, '') ||
                tool.getHandleNearImagePoint(element, annotation, point, proximity)) {
                return annotation;
            }
        }
    }
    return null;
}



/***/ }),

/***/ 24592:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CQ: () => (/* binding */ getCalibratedAspect),
/* harmony export */   Op: () => (/* binding */ getCalibratedLengthUnitsAndScale),
/* harmony export */   Xw: () => (/* binding */ getCalibratedProbeUnitsAndValue)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { CalibrationTypes } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.Enums;
const PIXEL_UNITS = 'px';
const SUPPORTED_REGION_DATA_TYPES = [
    1,
];
const SUPPORTED_LENGTH_VARIANT = [
    '3,3',
];
const SUPPORTED_PROBE_VARIANT = [
    '4,3',
];
const UNIT_MAPPING = {
    3: 'cm',
    4: 'seconds',
};
const EPS = 1e-3;
const SQUARE = '\xb2';
const getCalibratedLengthUnitsAndScale = (image, handles) => {
    const { calibration, hasPixelSpacing } = image;
    let units = hasPixelSpacing ? 'mm' : PIXEL_UNITS;
    let areaUnits = units + SQUARE;
    let scale = 1;
    let calibrationType = '';
    if (!calibration ||
        (!calibration.type && !calibration.sequenceOfUltrasoundRegions)) {
        return { units, areaUnits, scale };
    }
    if (calibration.type === CalibrationTypes.UNCALIBRATED) {
        return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
    }
    if (calibration.sequenceOfUltrasoundRegions) {
        let imageIndex1, imageIndex2;
        if (Array.isArray(handles) && handles.length === 2) {
            [imageIndex1, imageIndex2] = handles;
        }
        else if (typeof handles === 'function') {
            const points = handles();
            imageIndex1 = points[0];
            imageIndex2 = points[1];
        }
        let regions = calibration.sequenceOfUltrasoundRegions.filter((region) => imageIndex1[0] >= region.regionLocationMinX0 &&
            imageIndex1[0] <= region.regionLocationMaxX1 &&
            imageIndex1[1] >= region.regionLocationMinY0 &&
            imageIndex1[1] <= region.regionLocationMaxY1 &&
            imageIndex2[0] >= region.regionLocationMinX0 &&
            imageIndex2[0] <= region.regionLocationMaxX1 &&
            imageIndex2[1] >= region.regionLocationMinY0 &&
            imageIndex2[1] <= region.regionLocationMaxY1);
        if (!regions?.length) {
            return { units, areaUnits, scale };
        }
        regions = regions.filter((region) => SUPPORTED_REGION_DATA_TYPES.includes(region.regionDataType) &&
            SUPPORTED_LENGTH_VARIANT.includes(`${region.physicalUnitsXDirection},${region.physicalUnitsYDirection}`));
        if (!regions.length) {
            return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
        }
        const region = regions[0];
        const physicalDeltaX = Math.abs(region.physicalDeltaX);
        const physicalDeltaY = Math.abs(region.physicalDeltaY);
        const isSamePhysicalDelta = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(physicalDeltaX, physicalDeltaY, EPS);
        if (isSamePhysicalDelta) {
            scale = 1 / (physicalDeltaX * 10);
            calibrationType = 'US Region';
            units = 'mm';
            areaUnits = 'mm' + SQUARE;
        }
        else {
            return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
        }
    }
    else if (calibration.scale) {
        scale = calibration.scale;
    }
    const types = [
        CalibrationTypes.ERMF,
        CalibrationTypes.USER,
        CalibrationTypes.ERROR,
        CalibrationTypes.PROJECTION,
    ];
    if (types.includes(calibration?.type)) {
        calibrationType = calibration.type;
    }
    return {
        units: units + (calibrationType ? ` ${calibrationType}` : ''),
        areaUnits: areaUnits + (calibrationType ? ` ${calibrationType}` : ''),
        scale,
    };
};
const getCalibratedProbeUnitsAndValue = (image, handles) => {
    const [imageIndex] = handles;
    const { calibration } = image;
    let units = ['raw'];
    let values = [null];
    let calibrationType = '';
    if (!calibration ||
        (!calibration.type && !calibration.sequenceOfUltrasoundRegions)) {
        return { units, values };
    }
    if (calibration.sequenceOfUltrasoundRegions) {
        const supportedRegionsMetadata = calibration.sequenceOfUltrasoundRegions.filter((region) => SUPPORTED_REGION_DATA_TYPES.includes(region.regionDataType) &&
            SUPPORTED_PROBE_VARIANT.includes(`${region.physicalUnitsXDirection},${region.physicalUnitsYDirection}`));
        if (!supportedRegionsMetadata?.length) {
            return { units, values };
        }
        const region = supportedRegionsMetadata.find((region) => imageIndex[0] >= region.regionLocationMinX0 &&
            imageIndex[0] <= region.regionLocationMaxX1 &&
            imageIndex[1] >= region.regionLocationMinY0 &&
            imageIndex[1] <= region.regionLocationMaxY1);
        if (!region) {
            return { units, values };
        }
        const { referencePixelX0 = 0, referencePixelY0 = 0 } = region;
        const { physicalDeltaX, physicalDeltaY } = region;
        const yValue = (imageIndex[1] - region.regionLocationMinY0 - referencePixelY0) *
            physicalDeltaY;
        const xValue = (imageIndex[0] - region.regionLocationMinX0 - referencePixelX0) *
            physicalDeltaX;
        calibrationType = 'US Region';
        values = [xValue, yValue];
        units = [
            UNIT_MAPPING[region.physicalUnitsXDirection],
            UNIT_MAPPING[region.physicalUnitsYDirection],
        ];
    }
    return {
        units,
        values,
        calibrationType,
    };
};
const getCalibratedAspect = (image) => image.calibration?.aspect || 1;



/***/ }),

/***/ 96760:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ getSphereBoundsInfo)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _boundingBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15306);



const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function getSphereBoundsInfo(circlePoints, imageData, viewport) {
    const [bottom, top] = circlePoints;
    const centerWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues((bottom[0] + top[0]) / 2, (bottom[1] + top[1]) / 2, (bottom[2] + top[2]) / 2);
    const radiusWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(bottom, top) / 2;
    if (!viewport) {
        throw new Error('viewport is required in order to calculate the sphere bounds');
    }
    const { boundsIJK, topLeftWorld, bottomRightWorld } = _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld);
    return {
        boundsIJK,
        centerWorld: centerWorld,
        radiusWorld,
        topLeftWorld: topLeftWorld,
        bottomRightWorld: bottomRightWorld,
    };
}
function _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld) {
    const [bottom, top] = circlePoints;
    const dimensions = imageData.getDimensions();
    const camera = viewport.getCamera();
    const viewUp = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewUp[0], camera.viewUp[1], camera.viewUp[2]);
    const viewPlaneNormal = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewPlaneNormal[0], camera.viewPlaneNormal[1], camera.viewPlaneNormal[2]);
    const viewRight = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.cross */ .eR.cross(viewRight, viewUp, viewPlaneNormal);
    const topLeftWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    const bottomRightWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, top, viewPlaneNormal, radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottom, viewPlaneNormal, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, topLeftWorld, viewRight, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottomRightWorld, viewRight, radiusWorld);
    const topLeftIJK = transformWorldToIndex(imageData, topLeftWorld);
    const bottomRightIJK = transformWorldToIndex(imageData, bottomRightWorld);
    const pointsIJK = circlePoints.map((p) => transformWorldToIndex(imageData, p));
    const boundsIJK = (0,_boundingBox__WEBPACK_IMPORTED_MODULE_2__.getBoundingBoxAroundShapeIJK)([topLeftIJK, bottomRightIJK, ...pointsIJK], dimensions);
    return { boundsIJK, topLeftWorld, bottomRightWorld };
}



/***/ }),

/***/ 39490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ getViewportForAnnotation)
/* harmony export */ });
/* harmony import */ var _getViewportsForAnnotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65903);

function getViewportForAnnotation(annotation) {
    const viewports = (0,_getViewportsForAnnotation__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(annotation);
    return viewports.length ? viewports[0] : undefined;
}


/***/ }),

/***/ 11857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function isObject(value) {
    const type = typeof value;
    return value !== null && (type === 'object' || type === 'function');
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isObject);


/***/ }),

/***/ 27924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint),
  distanceToPointSquared: () => (/* reexport */ distanceToPointSquared),
  intersectAABB: () => (/* reexport */ intersectAABB)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/intersectAABB.js
function intersectAABB(aabb1, aabb2) {
    return (aabb1.minX <= aabb2.maxX &&
        aabb1.maxX >= aabb2.minX &&
        aabb1.minY <= aabb2.maxY &&
        aabb1.maxY >= aabb2.minY);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/distanceToPointSquared.js
function distanceToPointSquared(aabb, point) {
    const aabbWidth = aabb.maxX - aabb.minX;
    const aabbHeight = aabb.maxY - aabb.minY;
    const aabbSize = [aabbWidth, aabbHeight];
    const aabbCenter = [
        aabb.minX + aabbWidth / 2,
        aabb.minY + aabbHeight / 2,
    ];
    const translatedPoint = [
        Math.abs(point[0] - aabbCenter[0]),
        Math.abs(point[1] - aabbCenter[1]),
    ];
    const dx = translatedPoint[0] - aabbSize[0] * 0.5;
    const dy = translatedPoint[1] - aabbSize[1] * 0.5;
    if (dx > 0 && dy > 0) {
        return dx * dx + dy * dy;
    }
    const dist = Math.max(dx, 0) + Math.max(dy, 0);
    return dist * dist;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/distanceToPoint.js

function distanceToPoint(aabb, point) {
    return Math.sqrt(distanceToPointSquared(aabb, point));
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/index.js





/***/ }),

/***/ 83112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BasicStatsCalculator: () => (/* reexport */ BasicStatsCalculator),
  Calculator: () => (/* reexport */ basic_Calculator)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/Calculator.js
class Calculator {
}
/* harmony default export */ const basic_Calculator = (Calculator);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/BasicStatsCalculator.js


const { PointsManager } = esm.utilities;
class BasicStatsCalculator extends basic_Calculator {
    static { this.max = [-Infinity]; }
    static { this.min = [Infinity]; }
    static { this.sum = [0]; }
    static { this.count = 0; }
    static { this.runMean = [0]; }
    static { this.m2 = [0]; }
    static { this.pointsInShape = PointsManager.create3(1024); }
    static statsInit(options) {
        if (options.noPointsCollection) {
            BasicStatsCalculator.pointsInShape = null;
        }
    }
    static { this.statsCallback = ({ value: newValue, pointLPS = null }) => {
        if (Array.isArray(newValue) &&
            newValue.length > 1 &&
            this.max.length === 1) {
            this.max.push(this.max[0], this.max[0]);
            this.min.push(this.min[0], this.min[0]);
            this.sum.push(this.sum[0], this.sum[0]);
            this.runMean.push(0, 0);
            this.m2.push(this.m2[0], this.m2[0]);
        }
        this.pointsInShape?.push(pointLPS);
        const newArray = Array.isArray(newValue) ? newValue : [newValue];
        this.count += 1;
        this.max.map((it, idx) => {
            const value = newArray[idx];
            const delta = value - this.runMean[idx];
            this.sum[idx] += value;
            this.runMean[idx] += delta / this.count;
            const delta2 = value - this.runMean[idx];
            this.m2[idx] += delta * delta2;
            this.min[idx] = Math.min(this.min[idx], value);
            this.max[idx] = Math.max(it, value);
        });
    }; }
    static { this.getStatistics = (options) => {
        const mean = this.sum.map((sum) => sum / this.count);
        const stdDev = this.m2.map((squaredDiffSum) => Math.sqrt(squaredDiffSum / this.count));
        const unit = options?.unit || null;
        const named = {
            max: {
                name: 'max',
                label: 'Max Pixel',
                value: singleArrayAsNumber(this.max),
                unit,
            },
            min: {
                name: 'min',
                label: 'Min Pixel',
                value: singleArrayAsNumber(this.min),
                unit,
            },
            mean: {
                name: 'mean',
                label: 'Mean Pixel',
                value: singleArrayAsNumber(mean),
                unit,
            },
            stdDev: {
                name: 'stdDev',
                label: 'Standard Deviation',
                value: singleArrayAsNumber(stdDev),
                unit,
            },
            count: {
                name: 'count',
                label: 'Pixel Count',
                value: this.count,
                unit: null,
            },
            pointsInShape: this.pointsInShape,
            array: [],
        };
        named.array.push(named.max, named.mean, named.stdDev, named.stdDev, named.count);
        this.max = [-Infinity];
        this.min = [Infinity];
        this.sum = [0];
        this.m2 = [0];
        this.runMean = [0];
        this.count = 0;
        this.pointsInShape = PointsManager.create3(1024);
        return named;
    }; }
}
function singleArrayAsNumber(val) {
    return val.length === 1 ? val[0] : val;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/index.js





/***/ }),

/***/ 2264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  getCanvasEllipseCorners: () => (/* reexport */ getCanvasEllipseCorners),
  pointInEllipse: () => (/* reexport */ pointInEllipse),
  precalculatePointInEllipse: () => (/* reexport */ precalculatePointInEllipse)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/pointInEllipse.js
function pointInEllipse(ellipse, pointLPS, inverts = {}) {
    if (!inverts.precalculated) {
        precalculatePointInEllipse(ellipse, inverts);
    }
    return inverts.precalculated(pointLPS);
}
const precalculatePointInEllipse = (ellipse, inverts = {}) => {
    const { xRadius, yRadius, zRadius } = ellipse;
    if (inverts.invXRadiusSq === undefined ||
        inverts.invYRadiusSq === undefined ||
        inverts.invZRadiusSq === undefined) {
        inverts.invXRadiusSq = xRadius !== 0 ? 1 / xRadius ** 2 : 0;
        inverts.invYRadiusSq = yRadius !== 0 ? 1 / yRadius ** 2 : 0;
        inverts.invZRadiusSq = zRadius !== 0 ? 1 / zRadius ** 2 : 0;
    }
    const { invXRadiusSq, invYRadiusSq, invZRadiusSq } = inverts;
    const { center } = ellipse;
    const [centerL, centerP, centerS] = center;
    inverts.precalculated = (pointLPS) => {
        const dx = pointLPS[0] - centerL;
        let inside = dx * dx * invXRadiusSq;
        if (inside > 1) {
            return false;
        }
        const dy = pointLPS[1] - centerP;
        inside += dy * dy * invYRadiusSq;
        if (inside > 1) {
            return false;
        }
        const dz = pointLPS[2] - centerS;
        inside += dz * dz * invZRadiusSq;
        return inside <= 1;
    };
    return inverts;
};


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/getCanvasEllipseCorners.js
function getCanvasEllipseCorners(ellipseCanvasPoints) {
    const [bottom, top, left, right] = ellipseCanvasPoints;
    const topLeft = [left[0], top[1]];
    const bottomRight = [right[0], bottom[1]];
    return [topLeft, bottomRight];
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/index.js





/***/ }),

/***/ 21954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint),
  distanceToPointSquared: () => (/* reexport */ distanceToPointSquared),
  distanceToPointSquaredInfo: () => (/* reexport */ distanceToPointSquaredInfo),
  intersectLine: () => (/* reexport */ intersectLine),
  isPointOnLineSegment: () => (/* reexport */ isPointOnLineSegment)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPointSquaredInfo.js

function distanceToPointSquaredInfo(lineStart, lineEnd, point) {
    let closestPoint;
    const distanceSquared = math.point.distanceToPointSquared(lineStart, lineEnd);
    if (lineStart[0] === lineEnd[0] && lineStart[1] === lineEnd[1]) {
        closestPoint = lineStart;
    }
    if (!closestPoint) {
        const dotProduct = ((point[0] - lineStart[0]) * (lineEnd[0] - lineStart[0]) +
            (point[1] - lineStart[1]) * (lineEnd[1] - lineStart[1])) /
            distanceSquared;
        if (dotProduct < 0) {
            closestPoint = lineStart;
        }
        else if (dotProduct > 1) {
            closestPoint = lineEnd;
        }
        else {
            closestPoint = [
                lineStart[0] + dotProduct * (lineEnd[0] - lineStart[0]),
                lineStart[1] + dotProduct * (lineEnd[1] - lineStart[1]),
            ];
        }
    }
    return {
        point: [...closestPoint],
        distanceSquared: math.point.distanceToPointSquared(point, closestPoint),
    };
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPointSquared.js

function distanceToPointSquared(lineStart, lineEnd, point) {
    return distanceToPointSquaredInfo(lineStart, lineEnd, point).distanceSquared;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPoint.js

function distanceToPoint(lineStart, lineEnd, point) {
    if (lineStart.length !== 2 || lineEnd.length !== 2 || point.length !== 2) {
        throw Error('lineStart, lineEnd, and point should have 2 elements of [x, y]');
    }
    return Math.sqrt(distanceToPointSquared(lineStart, lineEnd, point));
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/intersectLine.js
function sign(x) {
    return typeof x === 'number'
        ? x
            ? x < 0
                ? -1
                : 1
            : x === x
                ? 0
                : NaN
        : NaN;
}
function intersectLine(line1Start, line1End, line2Start, line2End) {
    const [x1, y1] = line1Start;
    const [x2, y2] = line1End;
    const [x3, y3] = line2Start;
    const [x4, y4] = line2End;
    const a1 = y2 - y1;
    const b1 = x1 - x2;
    const c1 = x2 * y1 - x1 * y2;
    const r3 = a1 * x3 + b1 * y3 + c1;
    const r4 = a1 * x4 + b1 * y4 + c1;
    if (r3 !== 0 && r4 !== 0 && sign(r3) === sign(r4)) {
        return;
    }
    const a2 = y4 - y3;
    const b2 = x3 - x4;
    const c2 = x4 * y3 - x3 * y4;
    const r1 = a2 * x1 + b2 * y1 + c2;
    const r2 = a2 * x2 + b2 * y2 + c2;
    if (r1 !== 0 && r2 !== 0 && sign(r1) === sign(r2)) {
        return;
    }
    const denom = a1 * b2 - a2 * b1;
    let num;
    num = b1 * c2 - b2 * c1;
    const x = num / denom;
    num = a2 * c1 - a1 * c2;
    const y = num / denom;
    const intersectionPoint = [x, y];
    return intersectionPoint;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/isPointOnLineSegment.js
const ORIENTATION_TOLERANCE = 1e-2;
function isPointOnLineSegment(lineStart, lineEnd, point) {
    const minX = lineStart[0] <= lineEnd[0] ? lineStart[0] : lineEnd[0];
    const maxX = lineStart[0] >= lineEnd[0] ? lineStart[0] : lineEnd[0];
    const minY = lineStart[1] <= lineEnd[1] ? lineStart[1] : lineEnd[1];
    const maxY = lineStart[1] >= lineEnd[1] ? lineStart[1] : lineEnd[1];
    const aabbContainsPoint = point[0] >= minX - ORIENTATION_TOLERANCE &&
        point[0] <= maxX + ORIENTATION_TOLERANCE &&
        point[1] >= minY - ORIENTATION_TOLERANCE &&
        point[1] <= maxY + ORIENTATION_TOLERANCE;
    if (!aabbContainsPoint) {
        return false;
    }
    const orientation = (lineEnd[1] - lineStart[1]) * (point[0] - lineEnd[0]) -
        (lineEnd[0] - lineStart[0]) * (point[1] - lineEnd[1]);
    const absOrientation = orientation >= 0 ? orientation : -orientation;
    return absOrientation <= ORIENTATION_TOLERANCE;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js








/***/ }),

/***/ 38566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ distanceToPoint)
/* harmony export */ });
/* harmony import */ var _distanceToPointSquared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14257);

function distanceToPoint(p1, p2) {
    return Math.sqrt((0,_distanceToPointSquared__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(p1, p2));
}


/***/ }),

/***/ 14257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ distanceToPointSquared)
/* harmony export */ });
function distanceToPointSquared(p1, p2) {
    if (p1.length !== p2.length) {
        throw Error('Both points should have the same dimensionality');
    }
    const [x1, y1, z1 = 0] = p1;
    const [x2, y2, z2 = 0] = p2;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    return dx * dx + dy * dy + dz * dz;
}


/***/ }),

/***/ 49131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ mirror)
/* harmony export */ });
function mirror(mirrorPoint, staticPoint) {
    const [x1, y1] = mirrorPoint;
    const [x2, y2] = staticPoint;
    const newX = 2 * x2 - x1;
    const newY = 2 * y2 - y1;
    return [newX, newY];
}


/***/ }),

/***/ 56634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  addCanvasPointsToArray: () => (/* reexport */ polyline_addCanvasPointsToArray),
  containsPoint: () => (/* reexport */ containsPoint),
  containsPoints: () => (/* reexport */ containsPoints),
  decimate: () => (/* reexport */ decimate),
  getAABB: () => (/* reexport */ getAABB/* default */.A),
  getArea: () => (/* reexport */ getArea),
  getClosestLineSegmentIntersection: () => (/* reexport */ getClosestLineSegmentIntersection),
  getFirstLineSegmentIntersectionIndexes: () => (/* reexport */ getFirstLineSegmentIntersectionIndexes),
  getLineSegmentIntersectionsCoordinates: () => (/* reexport */ getLineSegmentIntersectionsCoordinates),
  getLineSegmentIntersectionsIndexes: () => (/* reexport */ getLineSegmentIntersectionsIndexes),
  getNormal2: () => (/* reexport */ getNormal2),
  getNormal3: () => (/* reexport */ getNormal3),
  getSignedArea: () => (/* reexport */ getSignedArea),
  getSubPixelSpacingAndXYDirections: () => (/* reexport */ polyline_getSubPixelSpacingAndXYDirections),
  getWindingDirection: () => (/* reexport */ getWindingDirection),
  intersectPolyline: () => (/* reexport */ intersectPolyline),
  isClosed: () => (/* reexport */ isClosed),
  isPointInsidePolyline3D: () => (/* reexport */ isPointInsidePolyline3D),
  mergePolylines: () => (/* reexport */ mergePolylines),
  pointCanProjectOnLine: () => (/* reexport */ polyline_pointCanProjectOnLine),
  pointsAreWithinCloseContourProximity: () => (/* reexport */ polyline_pointsAreWithinCloseContourProximity),
  projectTo2D: () => (/* reexport */ projectTo2D),
  subtractPolylines: () => (/* reexport */ subtractPolylines)
});

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/isClosed.js


function isClosed(polyline) {
    if (polyline.length < 3) {
        return false;
    }
    const numPolylinePoints = polyline.length;
    const firstPoint = polyline[0];
    const lastPoint = polyline[numPolylinePoints - 1];
    const distFirstToLastPoints = math.point.distanceToPointSquared(firstPoint, lastPoint);
    return esm/* glMatrix.equals */.Fd.equals(0, distFirstToLastPoints);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/containsPoint.js

function containsPoint(polyline, point, options = {
    closed: undefined,
}) {
    if (polyline.length < 3) {
        return false;
    }
    const numPolylinePoints = polyline.length;
    let numIntersections = 0;
    const { closed, holes } = options;
    if (holes?.length) {
        for (const hole of holes) {
            if (containsPoint(hole, point)) {
                return false;
            }
        }
    }
    const shouldClose = !(closed === undefined ? isClosed(polyline) : closed);
    const maxSegmentIndex = polyline.length - (shouldClose ? 1 : 2);
    for (let i = 0; i <= maxSegmentIndex; i++) {
        const p1 = polyline[i];
        const p2Index = i === numPolylinePoints - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const maxX = p1[0] >= p2[0] ? p1[0] : p2[0];
        const maxY = p1[1] >= p2[1] ? p1[1] : p2[1];
        const minY = p1[1] <= p2[1] ? p1[1] : p2[1];
        const mayIntersectLineSegment = point[0] <= maxX && point[1] >= minY && point[1] < maxY;
        if (mayIntersectLineSegment) {
            const isVerticalLine = p1[0] === p2[0];
            let intersects = isVerticalLine;
            if (!intersects) {
                const xIntersection = ((point[1] - p1[1]) * (p2[0] - p1[0])) / (p2[1] - p1[1]) + p1[0];
                intersects = point[0] <= xIntersection;
            }
            numIntersections += intersects ? 1 : 0;
        }
    }
    return !!(numIntersections % 2);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/containsPoints.js

function containsPoints(polyline, points) {
    for (let i = 0, numPoint = points.length; i < numPoint; i++) {
        if (!containsPoint(polyline, points[i])) {
            return false;
        }
    }
    return true;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getAABB.js
var getAABB = __webpack_require__(86970);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getArea.js
function getArea(points) {
    const n = points.length;
    let area = 0.0;
    let j = n - 1;
    for (let i = 0; i < n; i++) {
        area += (points[j][0] + points[i][0]) * (points[j][1] - points[i][1]);
        j = i;
    }
    return Math.abs(area / 2.0);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getSignedArea.js
function getSignedArea(polyline) {
    if (polyline.length < 3) {
        return 0;
    }
    const refPoint = polyline[0];
    let area = 0;
    for (let i = 0, len = polyline.length; i < len; i++) {
        const p1 = polyline[i];
        const p2Index = i === len - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const aX = p1[0] - refPoint[0];
        const aY = p1[1] - refPoint[1];
        const bX = p2[0] - refPoint[0];
        const bY = p2[1] - refPoint[1];
        area += aX * bY - aY * bX;
    }
    area *= 0.5;
    return area;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getWindingDirection.js

function getWindingDirection(polyline) {
    const signedArea = getSignedArea(polyline);
    return signedArea >= 0 ? 1 : -1;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getNormal3.js

function _getAreaVector(polyline) {
    const vecArea = esm/* vec3.create */.eR.create();
    const refPoint = polyline[0];
    for (let i = 0, len = polyline.length; i < len; i++) {
        const p1 = polyline[i];
        const p2Index = i === len - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const aX = p1[0] - refPoint[0];
        const aY = p1[1] - refPoint[1];
        const aZ = p1[2] - refPoint[2];
        const bX = p2[0] - refPoint[0];
        const bY = p2[1] - refPoint[1];
        const bZ = p2[2] - refPoint[2];
        vecArea[0] += aY * bZ - aZ * bY;
        vecArea[1] += aZ * bX - aX * bZ;
        vecArea[2] += aX * bY - aY * bX;
    }
    esm/* vec3.scale */.eR.scale(vecArea, vecArea, 0.5);
    return vecArea;
}
function getNormal3(polyline) {
    const vecArea = _getAreaVector(polyline);
    return esm/* vec3.normalize */.eR.normalize(vecArea, vecArea);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getNormal2.js

function getNormal2(polyline) {
    const area = getSignedArea(polyline);
    return [0, 0, area / Math.abs(area)];
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/point/index.js
var point = __webpack_require__(14846);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/areLineSegmentsIntersecting.js
function areLineSegmentsIntersecting(p1, q1, p2, q2) {
    let result = false;
    const line1MinX = p1[0] < q1[0] ? p1[0] : q1[0];
    const line1MinY = p1[1] < q1[1] ? p1[1] : q1[1];
    const line1MaxX = p1[0] > q1[0] ? p1[0] : q1[0];
    const line1MaxY = p1[1] > q1[1] ? p1[1] : q1[1];
    const line2MinX = p2[0] < q2[0] ? p2[0] : q2[0];
    const line2MinY = p2[1] < q2[1] ? p2[1] : q2[1];
    const line2MaxX = p2[0] > q2[0] ? p2[0] : q2[0];
    const line2MaxY = p2[1] > q2[1] ? p2[1] : q2[1];
    if (line1MinX > line2MaxX ||
        line1MaxX < line2MinX ||
        line1MinY > line2MaxY ||
        line1MaxY < line2MinY) {
        return false;
    }
    const orient = [
        orientation(p1, q1, p2),
        orientation(p1, q1, q2),
        orientation(p2, q2, p1),
        orientation(p2, q2, q1),
    ];
    if (orient[0] !== orient[1] && orient[2] !== orient[3]) {
        return true;
    }
    if (orient[0] === 0 && onSegment(p1, p2, q1)) {
        result = true;
    }
    else if (orient[1] === 0 && onSegment(p1, q2, q1)) {
        result = true;
    }
    else if (orient[2] === 0 && onSegment(p2, p1, q2)) {
        result = true;
    }
    else if (orient[3] === 0 && onSegment(p2, q1, q2)) {
        result = true;
    }
    return result;
}
function orientation(p, q, r) {
    const orientationValue = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1]);
    if (orientationValue === 0) {
        return 0;
    }
    return orientationValue > 0 ? 1 : 2;
}
function onSegment(p, q, r) {
    if (q[0] <= Math.max(p[0], r[0]) &&
        q[0] >= Math.min(p[0], r[0]) &&
        q[1] <= Math.max(p[1], r[1]) &&
        q[1] >= Math.min(p[1], r[1])) {
        return true;
    }
    return false;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLineSegmentIntersectionsIndexes.js

function getLineSegmentIntersectionsIndexes(polyline, p1, q1, closed = true) {
    const intersections = [];
    const numPoints = polyline.length;
    const maxI = numPoints - (closed ? 1 : 2);
    for (let i = 0; i <= maxI; i++) {
        const p2 = polyline[i];
        const j = i === numPoints - 1 ? 0 : i + 1;
        const q2 = polyline[j];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            intersections.push([i, j]);
        }
    }
    return intersections;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js + 5 modules
var line = __webpack_require__(21954);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLinesIntersection.js

const PARALLEL_LINES_TOLERANCE = 1e-2;
function getLinesIntersection(p1, q1, p2, q2) {
    const diffQ1P1 = [q1[0] - p1[0], q1[1] - p1[1]];
    const diffQ2P2 = [q2[0] - p2[0], q2[1] - p2[1]];
    const denominator = diffQ2P2[1] * diffQ1P1[0] - diffQ2P2[0] * diffQ1P1[1];
    const absDenominator = denominator >= 0 ? denominator : -denominator;
    if (absDenominator < PARALLEL_LINES_TOLERANCE) {
        const line1AABB = [
            p1[0] < q1[0] ? p1[0] : q1[0],
            p1[0] > q1[0] ? p1[0] : q1[0],
            p1[1] < q1[1] ? p1[1] : q1[1],
            p1[1] > q1[1] ? p1[1] : q1[1],
        ];
        const line2AABB = [
            p2[0] < q2[0] ? p2[0] : q2[0],
            p2[0] > q2[0] ? p2[0] : q2[0],
            p2[1] < q2[1] ? p2[1] : q2[1],
            p2[1] > q2[1] ? p2[1] : q2[1],
        ];
        const aabbIntersects = line1AABB[0] <= line2AABB[1] &&
            line1AABB[1] >= line2AABB[0] &&
            line1AABB[2] <= line2AABB[3] &&
            line1AABB[3] >= line2AABB[2];
        if (!aabbIntersects) {
            return;
        }
        const overlap = line.isPointOnLineSegment(p1, q1, p2) ||
            line.isPointOnLineSegment(p1, q1, q2) ||
            line.isPointOnLineSegment(p2, q2, p1);
        if (!overlap) {
            return;
        }
        const minX = line1AABB[0] > line2AABB[0] ? line1AABB[0] : line2AABB[0];
        const maxX = line1AABB[1] < line2AABB[1] ? line1AABB[1] : line2AABB[1];
        const minY = line1AABB[2] > line2AABB[2] ? line1AABB[2] : line2AABB[2];
        const maxY = line1AABB[3] < line2AABB[3] ? line1AABB[3] : line2AABB[3];
        const midX = (minX + maxX) * 0.5;
        const midY = (minY + maxY) * 0.5;
        return [midX, midY];
    }
    let a = p1[1] - p2[1];
    let b = p1[0] - p2[0];
    const numerator1 = diffQ2P2[0] * a - diffQ2P2[1] * b;
    const numerator2 = diffQ1P1[0] * a - diffQ1P1[1] * b;
    a = numerator1 / denominator;
    b = numerator2 / denominator;
    const resultX = p1[0] + a * diffQ1P1[0];
    const resultY = p1[1] + a * diffQ1P1[1];
    return [resultX, resultY];
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/combinePolyline.js






var PolylinePointType;
(function (PolylinePointType) {
    PolylinePointType[PolylinePointType["Vertex"] = 0] = "Vertex";
    PolylinePointType[PolylinePointType["Intersection"] = 1] = "Intersection";
})(PolylinePointType || (PolylinePointType = {}));
var PolylinePointPosition;
(function (PolylinePointPosition) {
    PolylinePointPosition[PolylinePointPosition["Outside"] = -1] = "Outside";
    PolylinePointPosition[PolylinePointPosition["Edge"] = 0] = "Edge";
    PolylinePointPosition[PolylinePointPosition["Inside"] = 1] = "Inside";
})(PolylinePointPosition || (PolylinePointPosition = {}));
var PolylinePointDirection;
(function (PolylinePointDirection) {
    PolylinePointDirection[PolylinePointDirection["Exiting"] = -1] = "Exiting";
    PolylinePointDirection[PolylinePointDirection["Unknown"] = 0] = "Unknown";
    PolylinePointDirection[PolylinePointDirection["Entering"] = 1] = "Entering";
})(PolylinePointDirection || (PolylinePointDirection = {}));
function ensuresNextPointers(polylinePoints) {
    for (let i = 0, len = polylinePoints.length; i < len; i++) {
        const currentPoint = polylinePoints[i];
        if (!currentPoint.next) {
            currentPoint.next = polylinePoints[i === len - 1 ? 0 : i + 1];
        }
    }
}
function getSourceAndTargetPointsList(targetPolyline, sourcePolyline) {
    const targetPolylinePoints = [];
    const sourcePolylinePoints = [];
    const sourceIntersectionsCache = new Map();
    const isFirstPointInside = containsPoint(sourcePolyline, targetPolyline[0]);
    let intersectionPointDirection = isFirstPointInside
        ? PolylinePointDirection.Exiting
        : PolylinePointDirection.Entering;
    for (let i = 0, len = targetPolyline.length; i < len; i++) {
        const p1 = targetPolyline[i];
        const pointInside = containsPoint(sourcePolyline, p1);
        const vertexPoint = {
            type: PolylinePointType.Vertex,
            coordinates: p1,
            position: pointInside
                ? PolylinePointPosition.Inside
                : PolylinePointPosition.Outside,
            visited: false,
            next: null,
        };
        targetPolylinePoints.push(vertexPoint);
        const q1 = targetPolyline[i === len - 1 ? 0 : i + 1];
        const intersectionsInfo = getLineSegmentIntersectionsIndexes(sourcePolyline, p1, q1).map((intersectedLineSegment) => {
            const sourceLineSegmentId = intersectedLineSegment[0];
            const p2 = sourcePolyline[intersectedLineSegment[0]];
            const q2 = sourcePolyline[intersectedLineSegment[1]];
            const intersectionCoordinate = getLinesIntersection(p1, q1, p2, q2);
            const targetStartPointDistSquared = point.distanceToPointSquared(p1, intersectionCoordinate);
            return {
                sourceLineSegmentId,
                coordinate: intersectionCoordinate,
                targetStartPointDistSquared,
            };
        });
        intersectionsInfo.sort((left, right) => left.targetStartPointDistSquared - right.targetStartPointDistSquared);
        intersectionsInfo.forEach((intersectionInfo) => {
            const { sourceLineSegmentId, coordinate: intersectionCoordinate } = intersectionInfo;
            const targetEdgePoint = {
                type: PolylinePointType.Intersection,
                coordinates: intersectionCoordinate,
                position: PolylinePointPosition.Edge,
                direction: intersectionPointDirection,
                visited: false,
                next: null,
            };
            const sourceEdgePoint = {
                ...targetEdgePoint,
                direction: PolylinePointDirection.Unknown,
                cloned: true,
            };
            if (intersectionPointDirection === PolylinePointDirection.Entering) {
                targetEdgePoint.next = sourceEdgePoint;
            }
            else {
                sourceEdgePoint.next = targetEdgePoint;
            }
            let sourceIntersectionPoints = sourceIntersectionsCache.get(sourceLineSegmentId);
            if (!sourceIntersectionPoints) {
                sourceIntersectionPoints = [];
                sourceIntersectionsCache.set(sourceLineSegmentId, sourceIntersectionPoints);
            }
            targetPolylinePoints.push(targetEdgePoint);
            sourceIntersectionPoints.push(sourceEdgePoint);
            intersectionPointDirection *= -1;
        });
    }
    for (let i = 0, len = sourcePolyline.length; i < len; i++) {
        const lineSegmentId = i;
        const p1 = sourcePolyline[i];
        const vertexPoint = {
            type: PolylinePointType.Vertex,
            coordinates: p1,
            visited: false,
            next: null,
        };
        sourcePolylinePoints.push(vertexPoint);
        const sourceIntersectionPoints = sourceIntersectionsCache.get(lineSegmentId);
        if (!sourceIntersectionPoints?.length) {
            continue;
        }
        sourceIntersectionPoints
            .map((intersectionPoint) => ({
            intersectionPoint,
            lineSegStartDistSquared: point.distanceToPointSquared(p1, intersectionPoint.coordinates),
        }))
            .sort((left, right) => left.lineSegStartDistSquared - right.lineSegStartDistSquared)
            .map(({ intersectionPoint }) => intersectionPoint)
            .forEach((intersectionPoint) => sourcePolylinePoints.push(intersectionPoint));
    }
    ensuresNextPointers(targetPolylinePoints);
    ensuresNextPointers(sourcePolylinePoints);
    return { targetPolylinePoints, sourcePolylinePoints };
}
function getUnvisitedOutsidePoint(polylinePoints) {
    for (let i = 0, len = polylinePoints.length; i < len; i++) {
        const point = polylinePoints[i];
        if (!point.visited && point.position === PolylinePointPosition.Outside) {
            return point;
        }
    }
}
function mergePolylines(targetPolyline, sourcePolyline) {
    const targetNormal = getNormal2(targetPolyline);
    const sourceNormal = getNormal2(sourcePolyline);
    const dotNormals = esm/* vec3.dot */.eR.dot(sourceNormal, targetNormal);
    if (!esm/* glMatrix.equals */.Fd.equals(1, dotNormals)) {
        sourcePolyline = sourcePolyline.slice().reverse();
    }
    const { targetPolylinePoints } = getSourceAndTargetPointsList(targetPolyline, sourcePolyline);
    const startPoint = getUnvisitedOutsidePoint(targetPolylinePoints);
    if (!startPoint) {
        return targetPolyline.slice();
    }
    const mergedPolyline = [startPoint.coordinates];
    let currentPoint = startPoint.next;
    while (currentPoint !== startPoint) {
        if (currentPoint.type === PolylinePointType.Intersection &&
            currentPoint.cloned) {
            currentPoint = currentPoint.next;
            continue;
        }
        mergedPolyline.push(currentPoint.coordinates);
        currentPoint = currentPoint.next;
    }
    return mergedPolyline;
}
function subtractPolylines(targetPolyline, sourcePolyline) {
    const targetNormal = getNormal2(targetPolyline);
    const sourceNormal = getNormal2(sourcePolyline);
    const dotNormals = esm/* vec3.dot */.eR.dot(sourceNormal, targetNormal);
    if (!esm/* glMatrix.equals */.Fd.equals(-1, dotNormals)) {
        sourcePolyline = sourcePolyline.slice().reverse();
    }
    const { targetPolylinePoints } = getSourceAndTargetPointsList(targetPolyline, sourcePolyline);
    let startPoint = null;
    const subtractedPolylines = [];
    while ((startPoint = getUnvisitedOutsidePoint(targetPolylinePoints))) {
        const subtractedPolyline = [startPoint.coordinates];
        let currentPoint = startPoint.next;
        startPoint.visited = true;
        while (currentPoint !== startPoint) {
            currentPoint.visited = true;
            if (currentPoint.type === PolylinePointType.Intersection &&
                currentPoint.cloned) {
                currentPoint = currentPoint.next;
                continue;
            }
            subtractedPolyline.push(currentPoint.coordinates);
            currentPoint = currentPoint.next;
        }
        subtractedPolylines.push(subtractedPolyline);
    }
    return subtractedPolylines;
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getFirstLineSegmentIntersectionIndexes.js

function getFirstLineSegmentIntersectionIndexes(points, p1, q1, closed = true) {
    let initialI;
    let j;
    if (closed) {
        j = points.length - 1;
        initialI = 0;
    }
    else {
        j = 0;
        initialI = 1;
    }
    for (let i = initialI; i < points.length; i++) {
        const p2 = points[j];
        const q2 = points[i];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            return [j, i];
        }
        j = i;
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/intersectPolyline.js

function intersectPolyline(sourcePolyline, targetPolyline) {
    for (let i = 0, sourceLen = sourcePolyline.length; i < sourceLen; i++) {
        const sourceP1 = sourcePolyline[i];
        const sourceP2Index = i === sourceLen - 1 ? 0 : i + 1;
        const sourceP2 = sourcePolyline[sourceP2Index];
        const intersectionPointIndexes = getFirstLineSegmentIntersectionIndexes(targetPolyline, sourceP1, sourceP2);
        if (intersectionPointIndexes?.length === 2) {
            return true;
        }
    }
    return false;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/decimate.js

const DEFAULT_EPSILON = 0.1;
function decimate(polyline, epsilon = DEFAULT_EPSILON) {
    const numPoints = polyline.length;
    if (numPoints < 3) {
        return polyline;
    }
    const epsilonSquared = epsilon * epsilon;
    const partitionQueue = [[0, numPoints - 1]];
    const polylinePointFlags = new Array(numPoints).fill(false);
    let numDecimatedPoints = 2;
    polylinePointFlags[0] = true;
    polylinePointFlags[numPoints - 1] = true;
    while (partitionQueue.length) {
        const [startIndex, endIndex] = partitionQueue.pop();
        if (endIndex - startIndex === 1) {
            continue;
        }
        const startPoint = polyline[startIndex];
        const endPoint = polyline[endIndex];
        let maxDistSquared = -Infinity;
        let maxDistIndex = -1;
        for (let i = startIndex + 1; i < endIndex; i++) {
            const currentPoint = polyline[i];
            const distSquared = line.distanceToPointSquared(startPoint, endPoint, currentPoint);
            if (distSquared > maxDistSquared) {
                maxDistSquared = distSquared;
                maxDistIndex = i;
            }
        }
        if (maxDistSquared < epsilonSquared) {
            continue;
        }
        polylinePointFlags[maxDistIndex] = true;
        numDecimatedPoints++;
        partitionQueue.push([maxDistIndex, endIndex]);
        partitionQueue.push([startIndex, maxDistIndex]);
    }
    const decimatedPolyline = new Array(numDecimatedPoints);
    for (let srcIndex = 0, dstIndex = 0; srcIndex < numPoints; srcIndex++) {
        if (polylinePointFlags[srcIndex]) {
            decimatedPolyline[dstIndex++] = polyline[srcIndex];
        }
    }
    return decimatedPolyline;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLineSegmentIntersectionsCoordinates.js


function getLineSegmentIntersectionsCoordinates(points, p1, q1, closed = true) {
    const result = [];
    const polylineIndexes = getLineSegmentIntersectionsIndexes(points, p1, q1, closed);
    for (let i = 0; i < polylineIndexes.length; i++) {
        const p2 = points[polylineIndexes[i][0]];
        const q2 = points[polylineIndexes[i][1]];
        const intersection = getLinesIntersection(p1, q1, p2, q2);
        result.push(intersection);
    }
    return result;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getClosestLineSegmentIntersection.js


function getClosestLineSegmentIntersection(points, p1, q1, closed = true) {
    let initialQ2Index;
    let p2Index;
    if (closed) {
        p2Index = points.length - 1;
        initialQ2Index = 0;
    }
    else {
        p2Index = 0;
        initialQ2Index = 1;
    }
    const intersections = [];
    for (let q2Index = initialQ2Index; q2Index < points.length; q2Index++) {
        const p2 = points[p2Index];
        const q2 = points[q2Index];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            intersections.push([p2Index, q2Index]);
        }
        p2Index = q2Index;
    }
    if (intersections.length === 0) {
        return;
    }
    const distances = [];
    intersections.forEach((intersection) => {
        const intersectionPoints = [
            points[intersection[0]],
            points[intersection[1]],
        ];
        const midpoint = [
            (intersectionPoints[0][0] + intersectionPoints[1][0]) / 2,
            (intersectionPoints[0][1] + intersectionPoints[1][1]) / 2,
        ];
        distances.push(esm/* vec2.distance */.Zc.distance(midpoint, p1));
    });
    const minDistance = Math.min(...distances);
    const indexOfMinDistance = distances.indexOf(minDistance);
    return {
        segment: intersections[indexOfMinDistance],
        distance: minDistance,
    };
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getSubPixelSpacingAndXYDirections.js


const EPSILON = 1e-3;
const getSubPixelSpacingAndXYDirections = (viewport, subPixelResolution) => {
    let spacing;
    let xDir;
    let yDir;
    if (viewport instanceof dist_esm.StackViewport) {
        const imageData = viewport.getImageData();
        xDir = imageData.direction.slice(0, 3);
        yDir = imageData.direction.slice(3, 6);
        spacing = imageData.spacing;
    }
    else {
        const imageData = viewport.getImageData();
        const { direction, spacing: volumeSpacing } = imageData;
        const { viewPlaneNormal, viewUp } = viewport.getCamera();
        const iVector = direction.slice(0, 3);
        const jVector = direction.slice(3, 6);
        const kVector = direction.slice(6, 9);
        const viewRight = esm/* vec3.create */.eR.create();
        esm/* vec3.cross */.eR.cross(viewRight, viewUp, viewPlaneNormal);
        const absViewRightDotI = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, iVector));
        const absViewRightDotJ = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, jVector));
        const absViewRightDotK = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, kVector));
        let xSpacing;
        if (Math.abs(1 - absViewRightDotI) < EPSILON) {
            xSpacing = volumeSpacing[0];
            xDir = iVector;
        }
        else if (Math.abs(1 - absViewRightDotJ) < EPSILON) {
            xSpacing = volumeSpacing[1];
            xDir = jVector;
        }
        else if (Math.abs(1 - absViewRightDotK) < EPSILON) {
            xSpacing = volumeSpacing[2];
            xDir = kVector;
        }
        else {
            throw new Error('No support yet for oblique plane planar contours');
        }
        const absViewUpDotI = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, iVector));
        const absViewUpDotJ = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, jVector));
        const absViewUpDotK = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, kVector));
        let ySpacing;
        if (Math.abs(1 - absViewUpDotI) < EPSILON) {
            ySpacing = volumeSpacing[0];
            yDir = iVector;
        }
        else if (Math.abs(1 - absViewUpDotJ) < EPSILON) {
            ySpacing = volumeSpacing[1];
            yDir = jVector;
        }
        else if (Math.abs(1 - absViewUpDotK) < EPSILON) {
            ySpacing = volumeSpacing[2];
            yDir = kVector;
        }
        else {
            throw new Error('No support yet for oblique plane planar contours');
        }
        spacing = [xSpacing, ySpacing];
    }
    const subPixelSpacing = [
        spacing[0] / subPixelResolution,
        spacing[1] / subPixelResolution,
    ];
    return { spacing: subPixelSpacing, xDir, yDir };
};
/* harmony default export */ const polyline_getSubPixelSpacingAndXYDirections = (getSubPixelSpacingAndXYDirections);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/pointsAreWithinCloseContourProximity.js

const pointsAreWithinCloseContourProximity = (p1, p2, closeContourProximity) => {
    return esm/* vec2.dist */.Zc.dist(p1, p2) < closeContourProximity;
};
/* harmony default export */ const polyline_pointsAreWithinCloseContourProximity = (pointsAreWithinCloseContourProximity);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/addCanvasPointsToArray.js


const addCanvasPointsToArray = (element, canvasPoints, newCanvasPoint, commonData) => {
    const { xDir, yDir, spacing } = commonData;
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    const { viewport } = enabledElement;
    if (!canvasPoints.length) {
        canvasPoints.push(newCanvasPoint);
        console.log('>>>>> !canvasPoints. :: RETURN');
        return 1;
    }
    const lastWorldPos = viewport.canvasToWorld(canvasPoints[canvasPoints.length - 1]);
    const newWorldPos = viewport.canvasToWorld(newCanvasPoint);
    const worldPosDiff = esm/* vec3.create */.eR.create();
    esm/* vec3.subtract */.eR.subtract(worldPosDiff, newWorldPos, lastWorldPos);
    const xDist = Math.abs(esm/* vec3.dot */.eR.dot(worldPosDiff, xDir));
    const yDist = Math.abs(esm/* vec3.dot */.eR.dot(worldPosDiff, yDir));
    const numPointsToAdd = Math.max(Math.floor(xDist / spacing[0]), Math.floor(yDist / spacing[0]));
    if (numPointsToAdd > 1) {
        const lastCanvasPoint = canvasPoints[canvasPoints.length - 1];
        const canvasDist = esm/* vec2.dist */.Zc.dist(lastCanvasPoint, newCanvasPoint);
        const canvasDir = esm/* vec2.create */.Zc.create();
        esm/* vec2.subtract */.Zc.subtract(canvasDir, newCanvasPoint, lastCanvasPoint);
        esm/* vec2.set */.Zc.set(canvasDir, canvasDir[0] / canvasDist, canvasDir[1] / canvasDist);
        const distPerPoint = canvasDist / numPointsToAdd;
        for (let i = 1; i <= numPointsToAdd; i++) {
            canvasPoints.push([
                lastCanvasPoint[0] + distPerPoint * canvasDir[0] * i,
                lastCanvasPoint[1] + distPerPoint * canvasDir[1] * i,
            ]);
        }
    }
    else {
        canvasPoints.push(newCanvasPoint);
    }
    return numPointsToAdd;
};
/* harmony default export */ const polyline_addCanvasPointsToArray = (addCanvasPointsToArray);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/pointCanProjectOnLine.js

const pointCanProjectOnLine = (p, p1, p2, proximity) => {
    const p1p = [p[0] - p1[0], p[1] - p1[1]];
    const p1p2 = [p2[0] - p1[0], p2[1] - p1[1]];
    const dot = p1p[0] * p1p2[0] + p1p[1] * p1p2[1];
    if (dot < 0) {
        return false;
    }
    const p1p2Mag = Math.sqrt(p1p2[0] * p1p2[0] + p1p2[1] * p1p2[1]);
    if (p1p2Mag === 0) {
        return false;
    }
    const projectionVectorMag = dot / p1p2Mag;
    const p1p2UnitVector = [p1p2[0] / p1p2Mag, p1p2[1] / p1p2Mag];
    const projectionVector = [
        p1p2UnitVector[0] * projectionVectorMag,
        p1p2UnitVector[1] * projectionVectorMag,
    ];
    const projectionPoint = [
        p1[0] + projectionVector[0],
        p1[1] + projectionVector[1],
    ];
    const distance = esm/* vec2.distance */.Zc.distance(p, projectionPoint);
    if (distance > proximity) {
        return false;
    }
    if (esm/* vec2.distance */.Zc.distance(p1, projectionPoint) > esm/* vec2.distance */.Zc.distance(p1, p2)) {
        return false;
    }
    return true;
};
/* harmony default export */ const polyline_pointCanProjectOnLine = (pointCanProjectOnLine);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/projectTo2D.js

const epsilon = 1e-6;
function projectTo2D(polyline) {
    let sharedDimensionIndex;
    const testPoints = dist_esm.utilities.getRandomSampleFromArray(polyline, 50);
    for (let i = 0; i < 3; i++) {
        if (testPoints.every((point, index, array) => Math.abs(point[i] - array[0][i]) < epsilon)) {
            sharedDimensionIndex = i;
            break;
        }
    }
    if (sharedDimensionIndex === undefined) {
        throw new Error('Cannot find a shared dimension index for polyline, probably oblique plane');
    }
    const points2D = [];
    const firstDim = (sharedDimensionIndex + 1) % 3;
    const secondDim = (sharedDimensionIndex + 2) % 3;
    for (let i = 0; i < polyline.length; i++) {
        points2D.push([polyline[i][firstDim], polyline[i][secondDim]]);
    }
    return {
        sharedDimensionIndex,
        projectedPolyline: points2D,
    };
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/isPointInsidePolyline3D.js


function isPointInsidePolyline3D(point, polyline, options = {}) {
    const { sharedDimensionIndex, projectedPolyline } = projectTo2D(polyline);
    const { holes } = options;
    const projectedHoles = [];
    if (holes) {
        for (let i = 0; i < holes.length; i++) {
            const hole = holes[i];
            const hole2D = [];
            for (let j = 0; j < hole.length; j++) {
                hole2D.push([
                    hole[j][(sharedDimensionIndex + 1) % 3],
                    hole[j][(sharedDimensionIndex + 2) % 3],
                ]);
            }
            projectedHoles.push(hole2D);
        }
    }
    const point2D = [
        point[(sharedDimensionIndex + 1) % 3],
        point[(sharedDimensionIndex + 2) % 3],
    ];
    return containsPoint(projectedPolyline, point2D, { holes: projectedHoles });
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/index.js

























/***/ }),

/***/ 23345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js + 5 modules
var line = __webpack_require__(21954);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/rectangle/distanceToPoint.js

function rectToLineSegments(left, top, width, height) {
    const topLineStart = [left, top];
    const topLineEnd = [left + width, top];
    const rightLineStart = [left + width, top];
    const rightLineEnd = [left + width, top + height];
    const bottomLineStart = [left + width, top + height];
    const bottomLineEnd = [left, top + height];
    const leftLineStart = [left, top + height];
    const leftLineEnd = [left, top];
    const lineSegments = {
        top: [topLineStart, topLineEnd],
        right: [rightLineStart, rightLineEnd],
        bottom: [bottomLineStart, bottomLineEnd],
        left: [leftLineStart, leftLineEnd],
    };
    return lineSegments;
}
function distanceToPoint(rect, point) {
    if (rect.length !== 4 || point.length !== 2) {
        throw Error('rectangle:[left, top, width, height] or point: [x,y] not defined correctly');
    }
    const [left, top, width, height] = rect;
    let minDistance = 655535;
    const lineSegments = rectToLineSegments(left, top, width, height);
    Object.keys(lineSegments).forEach((segment) => {
        const [lineStart, lineEnd] = lineSegments[segment];
        const distance = line.distanceToPoint(lineStart, lineEnd, point);
        if (distance < minDistance) {
            minDistance = distance;
        }
    });
    return minDistance;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/rectangle/index.js




/***/ }),

/***/ 19096:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  d: () => (/* reexport */ pointInSphere)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/sphere/pointInSphere.js
function pointInSphere(sphere, pointLPS) {
    const { center, radius } = sphere;
    const radius2 = sphere.radius2 || radius * radius;
    return ((pointLPS[0] - center[0]) * (pointLPS[0] - center[0]) +
        (pointLPS[1] - center[1]) * (pointLPS[1] - center[1]) +
        (pointLPS[2] - center[2]) * (pointLPS[2] - center[2]) <=
        radius2);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/sphere/index.js




/***/ }),

/***/ 73100:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   findClosestPoint: () => (/* reexport safe */ _findClosestPoint__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   liangBarksyClip: () => (/* reexport safe */ _liangBarksyClip__WEBPACK_IMPORTED_MODULE_1__.A)
/* harmony export */ });
/* harmony import */ var _findClosestPoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87658);
/* harmony import */ var _liangBarksyClip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86981);





/***/ }),

/***/ 86981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ clip)
/* harmony export */ });
const EPSILON = 1e-6;
const INSIDE = 1;
const OUTSIDE = 0;
function clipT(num, denom, c) {
    const [tE, tL] = c;
    if (Math.abs(denom) < EPSILON) {
        return num < 0;
    }
    const t = num / denom;
    if (denom > 0) {
        if (t > tL) {
            return 0;
        }
        if (t > tE) {
            c[0] = t;
        }
    }
    else {
        if (t < tE) {
            return 0;
        }
        if (t < tL) {
            c[1] = t;
        }
    }
    return 1;
}
function clip(a, b, box, da, db) {
    const [x1, y1] = a;
    const [x2, y2] = b;
    const dx = x2 - x1;
    const dy = y2 - y1;
    if (da === undefined || db === undefined) {
        da = a;
        db = b;
    }
    else {
        da[0] = a[0];
        da[1] = a[1];
        db[0] = b[0];
        db[1] = b[1];
    }
    if (Math.abs(dx) < EPSILON &&
        Math.abs(dy) < EPSILON &&
        x1 >= box[0] &&
        x1 <= box[2] &&
        y1 >= box[1] &&
        y1 <= box[3]) {
        return INSIDE;
    }
    const c = [0, 1];
    if (clipT(box[0] - x1, dx, c) &&
        clipT(x1 - box[2], -dx, c) &&
        clipT(box[1] - y1, dy, c) &&
        clipT(y1 - box[3], -dy, c)) {
        const [tE, tL] = c;
        if (tL < 1) {
            db[0] = x1 + tL * dx;
            db[1] = y1 + tL * dy;
        }
        if (tE > 0) {
            da[0] += tE * dx;
            da[1] += tE * dy;
        }
        return INSIDE;
    }
    return OUTSIDE;
}


/***/ }),

/***/ 80393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ getOrientationStringLPS)
/* harmony export */ });
function getOrientationStringLPS(vector) {
    let orientation = '';
    const orientationX = vector[0] < 0 ? 'R' : 'L';
    const orientationY = vector[1] < 0 ? 'A' : 'P';
    const orientationZ = vector[2] < 0 ? 'F' : 'H';
    const abs = [Math.abs(vector[0]), Math.abs(vector[1]), Math.abs(vector[2])];
    const MIN = 0.0001;
    for (let i = 0; i < 3; i++) {
        if (abs[0] > MIN && abs[0] > abs[1] && abs[0] > abs[2]) {
            orientation += orientationX;
            abs[0] = 0;
        }
        else if (abs[1] > MIN && abs[1] > abs[0] && abs[1] > abs[2]) {
            orientation += orientationY;
            abs[1] = 0;
        }
        else if (abs[2] > MIN && abs[2] > abs[0] && abs[2] > abs[1]) {
            orientation += orientationZ;
            abs[2] = 0;
        }
        else if (abs[0] > MIN && abs[1] > MIN && abs[0] === abs[1]) {
            orientation += orientationX + orientationY;
            abs[0] = 0;
            abs[1] = 0;
        }
        else if (abs[0] > MIN && abs[2] > MIN && abs[0] === abs[2]) {
            orientation += orientationX + orientationZ;
            abs[0] = 0;
            abs[2] = 0;
        }
        else if (abs[1] > MIN && abs[2] > MIN && abs[1] === abs[2]) {
            orientation += orientationY + orientationZ;
            abs[1] = 0;
            abs[2] = 0;
        }
        else {
            break;
        }
    }
    return orientation;
}


/***/ }),

/***/ 39365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ invertOrientationStringLPS)
/* harmony export */ });
function invertOrientationStringLPS(orientationString) {
    let inverted = orientationString.replace('H', 'f');
    inverted = inverted.replace('F', 'h');
    inverted = inverted.replace('R', 'l');
    inverted = inverted.replace('L', 'r');
    inverted = inverted.replace('A', 'p');
    inverted = inverted.replace('P', 'a');
    inverted = inverted.toUpperCase();
    return inverted;
}


/***/ }),

/***/ 84797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   filterAnnotationsForDisplay: () => (/* reexport safe */ _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__.A),
/* harmony export */   filterAnnotationsWithinSlice: () => (/* reexport safe */ _filterAnnotationsWithinSlice__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   getPointInLineOfSightWithCriteria: () => (/* reexport safe */ _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__.A),
/* harmony export */   getWorldWidthAndHeightFromCorners: () => (/* reexport safe */ _getWorldWidthAndHeightFromCorners__WEBPACK_IMPORTED_MODULE_1__.A),
/* harmony export */   isPlaneIntersectingAABB: () => (/* reexport safe */ _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__.Y)
/* harmony export */ });
/* harmony import */ var _filterAnnotationsWithinSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17926);
/* harmony import */ var _getWorldWidthAndHeightFromCorners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(78609);
/* harmony import */ var _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65826);
/* harmony import */ var _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3895);
/* harmony import */ var _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99706);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    filterAnnotationsWithinSlice: _filterAnnotationsWithinSlice__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A,
    getWorldWidthAndHeightFromCorners: _getWorldWidthAndHeightFromCorners__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A,
    filterAnnotationsForDisplay: _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A,
    getPointInLineOfSightWithCriteria: _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A,
    isPlaneIntersectingAABB: _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__/* .isPlaneIntersectingAABB */ .Y,
});



/***/ }),

/***/ 44074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   smoothAnnotation: () => (/* reexport safe */ _smoothAnnotation__WEBPACK_IMPORTED_MODULE_0__.A)
/* harmony export */ });
/* harmony import */ var _smoothAnnotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14659);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    smoothAnnotation: _smoothAnnotation__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A,
});



/***/ }),

/***/ 75403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ pointInShapeCallback)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);

function pointInShapeCallback(imageData, pointInShapeFn, callback, boundsIJK) {
    let iMin, iMax, jMin, jMax, kMin, kMax;
    let scalarData;
    const { numComps } = imageData;
    if (imageData.getScalarData) {
        scalarData = imageData.getScalarData();
    }
    else {
        scalarData = imageData
            .getPointData()
            .getScalars()
            .getData();
    }
    const dimensions = imageData.getDimensions();
    if (!boundsIJK) {
        iMin = 0;
        iMax = dimensions[0];
        jMin = 0;
        jMax = dimensions[1];
        kMin = 0;
        kMax = dimensions[2];
    }
    else {
        [[iMin, iMax], [jMin, jMax], [kMin, kMax]] = boundsIJK;
    }
    const start = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(iMin, jMin, kMin);
    const direction = imageData.getDirection();
    const rowCosines = direction.slice(0, 3);
    const columnCosines = direction.slice(3, 6);
    const scanAxisNormal = direction.slice(6, 9);
    const spacing = imageData.getSpacing();
    const [rowSpacing, columnSpacing, scanAxisSpacing] = spacing;
    const worldPosStart = imageData.indexToWorld(start);
    const rowStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(rowCosines[0] * rowSpacing, rowCosines[1] * rowSpacing, rowCosines[2] * rowSpacing);
    const columnStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(columnCosines[0] * columnSpacing, columnCosines[1] * columnSpacing, columnCosines[2] * columnSpacing);
    const scanAxisStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(scanAxisNormal[0] * scanAxisSpacing, scanAxisNormal[1] * scanAxisSpacing, scanAxisNormal[2] * scanAxisSpacing);
    const xMultiple = numComps ||
        scalarData.length / dimensions[2] / dimensions[1] / dimensions[0];
    const yMultiple = dimensions[0] * xMultiple;
    const zMultiple = dimensions[1] * yMultiple;
    const pointsInShape = [];
    const currentPos = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(worldPosStart);
    for (let k = kMin; k <= kMax; k++) {
        const startPosJ = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(currentPos);
        for (let j = jMin; j <= jMax; j++) {
            const startPosI = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(currentPos);
            for (let i = iMin; i <= iMax; i++) {
                const pointIJK = [i, j, k];
                if (pointInShapeFn(currentPos, pointIJK)) {
                    const index = k * zMultiple + j * yMultiple + i * xMultiple;
                    let value;
                    if (xMultiple > 2) {
                        value = [
                            scalarData[index],
                            scalarData[index + 1],
                            scalarData[index + 2],
                        ];
                    }
                    else {
                        value = scalarData[index];
                    }
                    pointsInShape.push({
                        value,
                        index,
                        pointIJK,
                        pointLPS: currentPos.slice(),
                    });
                    if (callback) {
                        callback({ value, index, pointIJK, pointLPS: currentPos });
                    }
                }
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, rowStep);
            }
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.copy */ .eR.copy(currentPos, startPosI);
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, columnStep);
        }
        gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.copy */ .eR.copy(currentPos, startPosJ);
        gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, scanAxisStep);
    }
    return pointsInShape;
}


/***/ }),

/***/ 5093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ pointInSurroundingSphereCallback)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _math_sphere__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19096);
/* harmony import */ var _pointInShapeCallback__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75403);
/* harmony import */ var _boundingBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15306);





const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function pointInSurroundingSphereCallback(imageData, circlePoints, callback, viewport) {
    const { boundsIJK, centerWorld, radiusWorld } = _getBounds(circlePoints, imageData, viewport);
    const sphereObj = {
        center: centerWorld,
        radius: radiusWorld,
    };
    (0,_pointInShapeCallback__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(imageData, (pointLPS) => (0,_math_sphere__WEBPACK_IMPORTED_MODULE_2__/* .pointInSphere */ .d)(sphereObj, pointLPS), callback, boundsIJK);
}
function _getBounds(circlePoints, imageData, viewport) {
    const [bottom, top] = circlePoints;
    const centerWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues((bottom[0] + top[0]) / 2, (bottom[1] + top[1]) / 2, (bottom[2] + top[2]) / 2);
    const radiusWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(bottom, top) / 2;
    let boundsIJK;
    if (!viewport) {
        const centerIJK = transformWorldToIndex(imageData, centerWorld);
        const spacings = imageData.getSpacing();
        const minSpacing = Math.min(...spacings);
        const maxRadiusIJK = Math.ceil(radiusWorld / minSpacing);
        boundsIJK = [
            [centerIJK[0] - maxRadiusIJK, centerIJK[0] + maxRadiusIJK],
            [centerIJK[1] - maxRadiusIJK, centerIJK[1] + maxRadiusIJK],
            [centerIJK[2] - maxRadiusIJK, centerIJK[2] + maxRadiusIJK],
        ];
        return {
            boundsIJK,
            centerWorld: centerWorld,
            radiusWorld,
        };
    }
    boundsIJK = _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld);
    return {
        boundsIJK,
        centerWorld: centerWorld,
        radiusWorld,
    };
}
function _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld) {
    const [bottom, top] = circlePoints;
    const dimensions = imageData.getDimensions();
    const camera = viewport.getCamera();
    const viewUp = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewUp[0], camera.viewUp[1], camera.viewUp[2]);
    const viewPlaneNormal = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewPlaneNormal[0], camera.viewPlaneNormal[1], camera.viewPlaneNormal[2]);
    const viewRight = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.cross */ .eR.cross(viewRight, viewUp, viewPlaneNormal);
    const topLeftWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    const bottomRightWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, top, viewPlaneNormal, radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottom, viewPlaneNormal, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, topLeftWorld, viewRight, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottomRightWorld, viewRight, radiusWorld);
    const sphereCornersIJK = [
        transformWorldToIndex(imageData, topLeftWorld),
        (transformWorldToIndex(imageData, bottomRightWorld)),
    ];
    const boundsIJK = (0,_boundingBox__WEBPACK_IMPORTED_MODULE_4__.getBoundingBoxAroundShape)(sphereCornersIJK, dimensions);
    return boundsIJK;
}


/***/ }),

/***/ 60438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ pointToString)
/* harmony export */ });
function pointToString(point, decimals = 5) {
    return (parseFloat(point[0]).toFixed(decimals) +
        ',' +
        parseFloat(point[1]).toFixed(decimals) +
        ',' +
        parseFloat(point[2]).toFixed(decimals) +
        ',');
}


/***/ }),

/***/ 46514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPoint: () => (/* binding */ getPoint),
/* harmony export */   getPolyDataPointIndexes: () => (/* binding */ getPolyDataPointIndexes),
/* harmony export */   getPolyDataPoints: () => (/* binding */ getPolyDataPoints)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);

function getPoint(points, idx) {
    const idx3 = idx * 3;
    if (idx3 < points.length) {
        return gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(points[idx3], points[idx3 + 1], points[idx3 + 2]);
    }
}
function getPolyDataPointIndexes(polyData) {
    const linesData = polyData.getLines().getData();
    let idx = 0;
    const lineSegments = new Map();
    while (idx < linesData.length) {
        const segmentSize = linesData[idx++];
        const segment = [];
        for (let i = 0; i < segmentSize; i++) {
            segment.push(linesData[idx + i]);
        }
        lineSegments.set(segment[0], segment);
        idx += segmentSize;
    }
    const contours = [];
    const findStartingPoint = (map) => {
        for (const [key, value] of map.entries()) {
            if (value !== undefined) {
                return key;
            }
        }
        return -1;
    };
    let startPoint = findStartingPoint(lineSegments);
    while (startPoint !== -1) {
        const contour = [startPoint];
        while (lineSegments.has(startPoint)) {
            const nextPoint = lineSegments.get(startPoint)[1];
            if (lineSegments.has(nextPoint)) {
                contour.push(nextPoint);
            }
            lineSegments.delete(startPoint);
            startPoint = nextPoint;
        }
        contours.push(contour);
        startPoint = findStartingPoint(lineSegments);
    }
    return contours.length ? contours : undefined;
}
function getPolyDataPoints(polyData) {
    const contoursIndexes = getPolyDataPointIndexes(polyData);
    if (!contoursIndexes) {
        return;
    }
    const rawPointsData = polyData.getPoints().getData();
    return contoursIndexes.map((contourIndexes) => contourIndexes.map((index) => getPoint(rawPointsData, index)));
}


/***/ }),

/***/ 89786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14471);
/* harmony import */ var _boundingBox_extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42290);



function getBoundsIJKFromRectangleAnnotations(annotations, referenceVolume, options = {}) {
    const AllBoundsIJK = [];
    annotations.forEach((annotation) => {
        const { data } = annotation;
        const { points } = data.handles;
        const { imageData, dimensions } = referenceVolume;
        let pointsToUse = points;
        if (data.cachedStats?.projectionPoints) {
            const { projectionPoints } = data.cachedStats;
            pointsToUse = [].concat(...projectionPoints);
        }
        const rectangleCornersIJK = pointsToUse.map((world) => _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, world));
        let boundsIJK = (0,_boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__/* .getBoundingBoxAroundShapeIJK */ .g)(rectangleCornersIJK, dimensions);
        if (options.numSlicesToProject && !data.cachedStats?.projectionPoints) {
            boundsIJK = (0,_boundingBox_extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A)(boundsIJK, options.numSlicesToProject);
        }
        AllBoundsIJK.push(boundsIJK);
    });
    if (AllBoundsIJK.length === 1) {
        return AllBoundsIJK[0];
    }
    const boundsIJK = AllBoundsIJK.reduce((accumulator, currentValue) => {
        return {
            iMin: Math.min(accumulator.iMin, currentValue.iMin),
            jMin: Math.min(accumulator.jMin, currentValue.jMin),
            kMin: Math.min(accumulator.kMin, currentValue.kMin),
            iMax: Math.max(accumulator.iMax, currentValue.iMax),
            jMax: Math.max(accumulator.jMax, currentValue.jMax),
            kMax: Math.max(accumulator.kMax, currentValue.kMax),
        };
    }, {
        iMin: Infinity,
        jMin: Infinity,
        kMin: Infinity,
        iMax: -Infinity,
        jMax: -Infinity,
        kMax: -Infinity,
    });
    return boundsIJK;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getBoundsIJKFromRectangleAnnotations);


/***/ }),

/***/ 15874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getBoundsIJKFromRectangleAnnotations: () => (/* reexport safe */ _getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   isAxisAlignedRectangle: () => (/* reexport safe */ _isAxisAlignedRectangle__WEBPACK_IMPORTED_MODULE_1__.l)
/* harmony export */ });
/* harmony import */ var _getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89786);
/* harmony import */ var _isAxisAlignedRectangle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81952);





/***/ }),

/***/ 81952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ isAxisAlignedRectangle)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);


const { isEqual } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities;
const iAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(1, 0, 0);
const jAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(0, 1, 0);
const kAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(0, 0, 1);
const axisList = [iAxis, jAxis, kAxis];
function isAxisAlignedRectangle(rectangleCornersIJK) {
    const rectangleVec1 = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.subtract */ .eR.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.create */ .eR.create(), rectangleCornersIJK[0], rectangleCornersIJK[1]);
    const rectangleVec2 = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.subtract */ .eR.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.create */ .eR.create(), rectangleCornersIJK[0], rectangleCornersIJK[2]);
    const anglesVec1 = calculateAnglesWithAxes(rectangleVec1, axisList);
    const anglesVec2 = calculateAnglesWithAxes(rectangleVec2, axisList);
    const isAligned = [...anglesVec1, ...anglesVec2].every((angle) => isEqual(angle, 0) ||
        isEqual(angle, 90) ||
        isEqual(angle, 180) ||
        isEqual(angle, 270));
    return isAligned;
}
function calculateAnglesWithAxes(vec, axes) {
    return axes.map((axis) => (gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.angle */ .eR.angle(vec, axis) * 180) / Math.PI);
}



/***/ }),

/***/ 21783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ scroll)
/* harmony export */ });
/* unused harmony export scrollVolume */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function scroll(viewport, options) {
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(viewport.element);
    if (!enabledElement) {
        throw new Error('Scroll::Viewport is not enabled (it might be disabled)');
    }
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport &&
        viewport.getImageIds().length === 0) {
        throw new Error('Scroll::Stack Viewport has no images');
    }
    const { type: viewportType } = viewport;
    const { volumeId, delta, scrollSlabs } = options;
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        viewport.scroll(delta, options.debounceLoading, options.loop);
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
        scrollVolume(viewport, volumeId, delta, scrollSlabs);
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VideoViewport) {
        viewport.scroll(delta);
    }
    else {
        throw new Error(`Not implemented for Viewport Type: ${viewportType}`);
    }
}
function scrollVolume(viewport, volumeId, delta, scrollSlabs = false) {
    const useSlabThickness = scrollSlabs;
    const { numScrollSteps, currentStepIndex, sliceRangeInfo } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getVolumeViewportScrollInfo(viewport, volumeId, useSlabThickness);
    if (!sliceRangeInfo) {
        return;
    }
    const { sliceRange, spacingInNormalDirection, camera } = sliceRangeInfo;
    const { focalPoint, viewPlaneNormal, position } = camera;
    const { newFocalPoint, newPosition } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.snapFocalPointToSlice(focalPoint, position, sliceRange, viewPlaneNormal, spacingInNormalDirection, delta);
    viewport.setCamera({
        focalPoint: newFocalPoint,
        position: newPosition,
    });
    viewport.render();
    const desiredStepIndex = currentStepIndex + delta;
    const VolumeScrollEventDetail = {
        volumeId,
        viewport,
        delta,
        desiredStepIndex,
        currentStepIndex,
        numScrollSteps,
        currentImageId: viewport.getCurrentImageId(),
    };
    if ((desiredStepIndex > numScrollSteps || desiredStepIndex < 0) &&
        viewport.getCurrentImageId()) {
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.triggerEvent(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.EVENTS.VOLUME_SCROLL_OUT_OF_BOUNDS, VolumeScrollEventDetail);
    }
    else {
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.triggerEvent(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.EVENTS.VOLUME_VIEWPORT_SCROLL, VolumeScrollEventDetail);
    }
}


/***/ }),

/***/ 33836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ InterpolationManager)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45238);
/* harmony import */ var _contours_interpolation_getInterpolationDataCollection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23237);
/* harmony import */ var _contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7727);
/* harmony import */ var _deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20629);
/* harmony import */ var _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42111);
/* harmony import */ var _getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(39490);
/* harmony import */ var _contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32415);








const { uuidv4 } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
const ChangeTypesForInterpolation = [
    _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.HandlesUpdated,
    _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.InterpolationUpdated,
];
class InterpolationManager {
    static { this.toolNames = []; }
    static addTool(toolName) {
        if (!this.toolNames.includes(toolName)) {
            this.toolNames.push(toolName);
        }
    }
    static acceptAutoGenerated(annotationGroupSelector, selector = {}) {
        const { toolNames, segmentationId, segmentIndex, sliceIndex } = selector;
        for (const toolName of toolNames || InterpolationManager.toolNames) {
            const annotations = _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_1__.state.getAnnotations(toolName, annotationGroupSelector);
            if (!annotations?.length) {
                continue;
            }
            for (const annotation of annotations) {
                const { interpolationUID, data, autoGenerated, metadata } = annotation;
                if (interpolationUID) {
                    annotation.interpolationCompleted = true;
                }
                if (!autoGenerated) {
                    continue;
                }
                if (segmentIndex && segmentIndex !== data.segmentation.segmentIndex) {
                    continue;
                }
                if (sliceIndex !== undefined &&
                    metadata &&
                    sliceIndex !== metadata.sliceIndex) {
                    continue;
                }
                if (segmentationId &&
                    segmentationId !== data.segmentation.segmentationId) {
                    continue;
                }
                (0,_contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__/* .addContourSegmentationAnnotation */ .V)(annotation);
                annotation.autoGenerated = false;
            }
        }
    }
    static { this.handleAnnotationCompleted = (evt) => {
        const annotation = evt.detail.annotation;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName, originalToolName } = annotation.metadata;
        if (!this.toolNames.includes(toolName) &&
            !this.toolNames.includes(originalToolName)) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn('Unable to find viewport for', annotation);
            return;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
        };
        const hasInterpolationUID = !!annotation.interpolationUID;
        annotation.autoGenerated = false;
        if (hasInterpolationUID) {
            (0,_deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)(viewportData);
            (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
            return;
        }
        const filterData = [
            {
                key: 'segmentIndex',
                value: annotation.data.segmentation.segmentIndex,
                parentKey: (annotation) => annotation.data.segmentation,
            },
            {
                key: 'viewPlaneNormal',
                value: annotation.metadata.viewPlaneNormal,
                parentKey: (annotation) => annotation.metadata,
            },
            {
                key: 'viewUp',
                value: annotation.metadata.viewUp,
                parentKey: (annotation) => annotation.metadata,
            },
        ];
        let interpolationAnnotations = (0,_contours_interpolation_getInterpolationDataCollection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A)(viewportData, filterData);
        const { sliceIndex } = annotation.metadata;
        const skipUIDs = new Set();
        interpolationAnnotations.forEach((interpolationAnnotation) => {
            if (interpolationAnnotation.interpolationCompleted ||
                interpolationAnnotation.metadata.sliceIndex === sliceIndex) {
                const { interpolationUID } = interpolationAnnotation;
                skipUIDs.add(interpolationUID);
            }
        });
        interpolationAnnotations = interpolationAnnotations.filter((interpolationAnnotation) => !skipUIDs.has(interpolationAnnotation.interpolationUID));
        annotation.interpolationUID =
            interpolationAnnotations[0]?.interpolationUID || uuidv4();
        viewportData.interpolationUID = annotation.interpolationUID;
        (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
    }; }
    static { this.handleAnnotationUpdate = (evt) => {
        const annotation = evt.detail.annotation;
        const { changeType = _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.HandlesUpdated } = evt.detail;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName, originalToolName } = annotation.metadata;
        if ((!this.toolNames.includes(toolName) &&
            !this.toolNames.includes(originalToolName)) ||
            !ChangeTypesForInterpolation.includes(changeType)) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn('Unable to find matching viewport for annotation interpolation', annotation);
            return;
        }
        if (annotation.autoGenerated) {
            (0,_contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__/* .addContourSegmentationAnnotation */ .V)(annotation);
            annotation.autoGenerated = false;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
            isInterpolationUpdate: changeType === _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.InterpolationUpdated,
        };
        (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
    }; }
    static { this.handleAnnotationDelete = (evt) => {
        const annotation = evt.detail.annotation;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName } = annotation.metadata;
        if (!this.toolNames.includes(toolName) || annotation.autoGenerated) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn("No viewport, can't delete interpolated results", annotation);
            return;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
        };
        annotation.autoGenerated = false;
        (0,_deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)(viewportData);
    }; }
}
function getSliceData(viewport) {
    const sliceData = {
        numberOfSlices: viewport.getNumberOfSlices(),
        imageIndex: viewport.getCurrentImageIdIndex(),
    };
    return sliceData;
}


/***/ }),

/***/ 87590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ getBrushSizeForToolGroup),
/* harmony export */   M: () => (/* binding */ setBrushSizeForToolGroup)
/* harmony export */ });
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function setBrushSizeForToolGroup(toolGroupId, brushSize, toolName) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId, toolName);
    brushBasedToolInstances.forEach((tool) => {
        tool.configuration.brushSize = brushSize;
        tool.invalidateBrushCursor();
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    const viewportsInfoArray = Object.keys(viewportsInfo).map((key) => viewportsInfo[key]);
    if (!viewportsInfoArray.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfoArray[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__.getRenderingEngine)(renderingEngineId);
    (0,_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(renderingEngine, viewportIds);
}
function getBrushSizeForToolGroup(toolGroupId, toolName) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId, toolName);
    const brushToolInstance = brushBasedToolInstances[0];
    if (!brushToolInstance) {
        return;
    }
    return brushToolInstance.configuration.brushSize;
}


/***/ }),

/***/ 7300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   K: () => (/* binding */ setBrushThresholdForToolGroup),
/* harmony export */   Q: () => (/* binding */ getBrushThresholdForToolGroup)
/* harmony export */ });
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function setBrushThresholdForToolGroup(toolGroupId, threshold, otherArgs = { isDynamic: false }) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId);
    const configuration = {
        ...otherArgs,
        ...(threshold !== undefined && { threshold }),
    };
    brushBasedToolInstances.forEach((tool) => {
        tool.configuration.strategySpecificConfiguration.THRESHOLD = {
            ...tool.configuration.strategySpecificConfiguration.THRESHOLD,
            ...configuration,
        };
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    if (!viewportsInfo.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfo[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__.getRenderingEngine)(renderingEngineId);
    (0,_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(renderingEngine, viewportIds);
}
function getBrushThresholdForToolGroup(toolGroupId) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId);
    const brushToolInstance = brushBasedToolInstances[0];
    if (!brushToolInstance) {
        return;
    }
    return brushToolInstance.configuration.strategySpecificConfiguration.THRESHOLD
        .threshold;
}


/***/ }),

/***/ 41196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ contourAndFindLargestBidirectional)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js + 9 modules
var utilities_contours = __webpack_require__(75908);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/SegmentationRepresentations.js
var SegmentationRepresentations = __webpack_require__(83946);
// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/isLineInSegment.js


function isLineInSegment(point1, point2, isInSegment) {
    const ijk1 = isInSegment.toIJK(point1);
    const ijk2 = isInSegment.toIJK(point2);
    const testPoint = esm/* vec3.create */.eR.create();
    const { testIJK } = isInSegment;
    const delta = esm/* vec3.sub */.eR.sub(esm/* vec3.create */.eR.create(), ijk1, ijk2);
    const testSize = Math.round(Math.max(...delta.map(Math.abs)));
    if (testSize < 2) {
        return true;
    }
    const unitDelta = esm/* vec3.scale */.eR.scale(esm/* vec3.create */.eR.create(), delta, 1 / testSize);
    for (let i = 1; i < testSize; i++) {
        esm/* vec3.scaleAndAdd */.eR.scaleAndAdd(testPoint, ijk2, unitDelta, i);
        if (!testIJK(testPoint)) {
            return false;
        }
    }
    return true;
}
function createIsInSegment(segVolumeId, segmentIndex, containedSegmentIndices) {
    const vol = dist_esm.cache.getVolume(segVolumeId);
    if (!vol) {
        console.warn(`No volume found for ${segVolumeId}`);
        return;
    }
    const segData = vol.imageData.getPointData().getScalars().getData();
    const width = vol.dimensions[0];
    const pixelsPerSlice = width * vol.dimensions[1];
    return {
        testCenter: (point1, point2) => {
            const point = esm/* vec3.add */.eR.add(esm/* vec3.create */.eR.create(), point1, point2).map((it) => it / 2);
            const ijk = vol.imageData.worldToIndex(point).map(Math.round);
            const [i, j, k] = ijk;
            const index = i + j * width + k * pixelsPerSlice;
            const value = segData[index];
            return value === segmentIndex || containedSegmentIndices?.has(value);
        },
        toIJK: (point) => vol.imageData.worldToIndex(point),
        testIJK: (ijk) => {
            const [i, j, k] = ijk;
            const index = Math.round(i) + Math.round(j) * width + Math.round(k) * pixelsPerSlice;
            const value = segData[index];
            return value === segmentIndex || containedSegmentIndices?.has(value);
        },
    };
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/findLargestBidirectional.js


const EPSILON = 1e-2;
function findLargestBidirectional(contours, segVolumeId, segment) {
    const { sliceContours } = contours;
    const { segmentIndex, containedSegmentIndices } = segment;
    let maxBidirectional;
    const isInSegment = createIsInSegment(segVolumeId, segmentIndex, containedSegmentIndices);
    for (const sliceContour of sliceContours) {
        const bidirectional = createBidirectionalForSlice(sliceContour, isInSegment, maxBidirectional);
        if (!bidirectional) {
            continue;
        }
        maxBidirectional = bidirectional;
    }
    if (maxBidirectional) {
        Object.assign(maxBidirectional, segment);
    }
    return maxBidirectional;
}
function createBidirectionalForSlice(sliceContour, isInSegment, currentMax = { maxMajor: 0, maxMinor: 0 }) {
    const { points } = sliceContour.polyData;
    const { maxMinor: currentMaxMinor, maxMajor: currentMaxMajor } = currentMax;
    let maxMajor = currentMaxMajor * currentMaxMajor;
    let maxMinor = currentMaxMinor * currentMaxMinor;
    let maxMajorPoints;
    for (let index1 = 0; index1 < points.length; index1++) {
        for (let index2 = index1 + 1; index2 < points.length; index2++) {
            const point1 = points[index1];
            const point2 = points[index2];
            const distance2 = esm/* vec3.sqrDist */.eR.sqrDist(point1, point2);
            if (distance2 < maxMajor) {
                continue;
            }
            if (distance2 - EPSILON < maxMajor + EPSILON && maxMajorPoints) {
                continue;
            }
            if (!isInSegment.testCenter(point1, point2)) {
                continue;
            }
            if (!isLineInSegment(point1, point2, isInSegment)) {
                continue;
            }
            maxMajor = distance2 - EPSILON;
            maxMajorPoints = [index1, index2];
            maxMinor = 0;
        }
    }
    if (!maxMajorPoints) {
        return;
    }
    maxMajor = Math.sqrt(maxMajor + EPSILON);
    const handle0 = points[maxMajorPoints[0]];
    const handle1 = points[maxMajorPoints[1]];
    const unitMajor = esm/* vec3.sub */.eR.sub(esm/* vec3.create */.eR.create(), handle0, handle1);
    esm/* vec3.scale */.eR.scale(unitMajor, unitMajor, 1 / maxMajor);
    let maxMinorPoints;
    for (let index1 = 0; index1 < points.length; index1++) {
        for (let index2 = index1 + 1; index2 < points.length; index2++) {
            const point1 = points[index1];
            const point2 = points[index2];
            const distance2 = esm/* vec3.sqrDist */.eR.sqrDist(point1, point2);
            if (distance2 <= maxMinor) {
                continue;
            }
            const delta = esm/* vec3.sub */.eR.sub(esm/* vec3.create */.eR.create(), point1, point2);
            const dot = Math.abs(esm/* vec3.dot */.eR.dot(delta, unitMajor)) / Math.sqrt(distance2);
            if (dot > EPSILON) {
                continue;
            }
            if (!isInSegment.testCenter(point1, point2)) {
                continue;
            }
            if (!isLineInSegment(point1, point2, isInSegment)) {
                continue;
            }
            maxMinor = distance2;
            maxMinorPoints = [index1, index2];
        }
    }
    if (!maxMinorPoints) {
        return;
    }
    maxMinor = Math.sqrt(maxMinor);
    const handle2 = points[maxMinorPoints[0]];
    const handle3 = points[maxMinorPoints[1]];
    const bidirectional = {
        majorAxis: [handle0, handle1],
        minorAxis: [handle2, handle3],
        maxMajor,
        maxMinor,
        ...sliceContour,
    };
    return bidirectional;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/contourAndFindLargestBidirectional.js



const { Labelmap } = SegmentationRepresentations/* default */.A;
function contourAndFindLargestBidirectional(segmentation) {
    const contours = (0,utilities_contours.generateContourSetsFromLabelmap)({
        segmentations: segmentation,
    });
    if (!contours?.length || !contours[0].sliceContours.length) {
        return;
    }
    const { representationData, segments = [
        null,
        { label: 'Unspecified', color: null, containedSegmentIndices: null },
    ], } = segmentation;
    const { volumeId: segVolumeId } = representationData[Labelmap];
    const segmentIndex = segments.findIndex((it) => !!it);
    if (segmentIndex === -1) {
        return;
    }
    segments[segmentIndex].segmentIndex = segmentIndex;
    return findLargestBidirectional(contours[0], segVolumeId, segments[segmentIndex]);
}


/***/ }),

/***/ 96610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ createBidirectionalToolData)
/* harmony export */ });
function createBidirectionalToolData(bidirectionalData, viewport) {
    const { majorAxis, minorAxis, label = '', sliceIndex } = bidirectionalData;
    const [major0, major1] = majorAxis;
    const [minor0, minor1] = minorAxis;
    const points = [major0, major1, minor0, minor1];
    const bidirectionalToolData = {
        highlighted: true,
        invalidated: true,
        metadata: {
            toolName: 'Bidirectional',
            ...viewport.getViewReference({ sliceIndex }),
        },
        data: {
            handles: {
                points,
                textBox: {
                    hasMoved: false,
                    worldPosition: [0, 0, 0],
                    worldBoundingBox: {
                        topLeft: [0, 0, 0],
                        topRight: [0, 0, 0],
                        bottomLeft: [0, 0, 0],
                        bottomRight: [0, 0, 0],
                    },
                },
                activeHandleIndex: null,
            },
            label,
            cachedStats: {},
        },
        isLocked: false,
        isVisible: true,
    };
    return bidirectionalToolData;
}


/***/ }),

/***/ 82914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ createImageIdReferenceMap)
/* harmony export */ });
function createImageIdReferenceMap(imageIdsArray, segmentationImageIds) {
    const imageIdReferenceMap = new Map(imageIdsArray.map((imageId, index) => {
        return [imageId, segmentationImageIds[index]];
    }));
    return imageIdReferenceMap;
}



/***/ }),

/***/ 5092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ createLabelmapVolumeForViewport)
/* harmony export */ });
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(48463);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);


async function createLabelmapVolumeForViewport(input) {
    const { viewportId, renderingEngineId, options } = input;
    let { segmentationId } = input;
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElementByIds)(viewportId, renderingEngineId);
    if (!enabledElement) {
        throw new Error('element disabled');
    }
    const { viewport } = enabledElement;
    if (!(viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.VolumeViewport)) {
        throw new Error('Segmentation only supports VolumeViewport');
    }
    const { uid } = viewport.getDefaultActor();
    if (segmentationId === undefined) {
        segmentationId = `${uid}-based-segmentation-${options?.volumeId ?? _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.uuidv4().slice(0, 8)}`;
    }
    if (options) {
        const properties = lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0___default()(options);
        await _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.volumeLoader.createLocalVolume(properties, segmentationId);
    }
    else {
        const { uid: volumeId } = viewport.getDefaultActor();
        await _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.volumeLoader.createAndCacheDerivedSegmentationVolume(volumeId, {
            volumeId: segmentationId,
        });
    }
    return segmentationId;
}


/***/ }),

/***/ 86398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function createMergedLabelmapForIndex(labelmaps, segmentIndex = 1, volumeId = 'mergedLabelmap') {
    labelmaps.forEach(({ direction, dimensions, origin, spacing }) => {
        if (!_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(dimensions, labelmaps[0].dimensions) ||
            !_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(direction, labelmaps[0].direction) ||
            !_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(spacing, labelmaps[0].spacing) ||
            !_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(origin, labelmaps[0].origin)) {
            throw new Error('labelmaps must have the same size and shape');
        }
    });
    const labelmap = labelmaps[0];
    const arrayType = labelmap.getScalarData().constructor;
    const outputData = new arrayType(labelmap.getScalarData().length);
    labelmaps.forEach((labelmap) => {
        const scalarData = labelmap.getScalarData();
        for (let i = 0; i < scalarData.length; i++) {
            if (scalarData[i] === segmentIndex) {
                outputData[i] = segmentIndex;
            }
        }
    });
    const options = {
        scalarData: outputData,
        metadata: labelmap.metadata,
        spacing: labelmap.spacing,
        origin: labelmap.origin,
        direction: labelmap.direction,
        dimensions: labelmap.dimensions,
    };
    const preventCache = true;
    const mergedVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.volumeLoader.createLocalVolume(options, volumeId, preventCache);
    return mergedVolume;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createMergedLabelmapForIndex);


/***/ }),

/***/ 27650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function floodFill(getter, seed, options = {}) {
    const onFlood = options.onFlood;
    const onBoundary = options.onBoundary;
    const equals = options.equals;
    const diagonals = options.diagonals || false;
    const startNode = get(seed);
    const permutations = prunedPermutations();
    const stack = [];
    const flooded = [];
    const visits = new Set();
    const bounds = new Map();
    stack.push({ currentArgs: seed });
    while (stack.length > 0) {
        flood(stack.pop());
    }
    return {
        flooded,
        boundaries: boundaries(),
    };
    function flood(job) {
        const getArgs = job.currentArgs;
        const prevArgs = job.previousArgs;
        if (visited(getArgs)) {
            return;
        }
        markAsVisited(getArgs);
        if (member(getArgs)) {
            markAsFlooded(getArgs);
            pushAdjacent(getArgs);
        }
        else {
            markAsBoundary(prevArgs);
        }
    }
    function visited(key) {
        const [x, y, z = 0] = key;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        return visits.has(iKey);
    }
    function markAsVisited(key) {
        const [x, y, z = 0] = key;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        visits.add(iKey);
    }
    function member(getArgs) {
        const node = get(getArgs);
        return equals ? equals(node, startNode) : node === startNode;
    }
    function markAsFlooded(getArgs) {
        flooded.push(getArgs);
        if (onFlood) {
            onFlood(...getArgs);
        }
    }
    function markAsBoundary(prevArgs) {
        const [x, y, z = 0] = prevArgs;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        bounds.set(iKey, prevArgs);
        if (onBoundary) {
            onBoundary(...prevArgs);
        }
    }
    function pushAdjacent(getArgs) {
        for (let i = 0; i < permutations.length; i += 1) {
            const perm = permutations[i];
            const nextArgs = getArgs.slice(0);
            for (let j = 0; j < getArgs.length; j += 1) {
                nextArgs[j] += perm[j];
            }
            stack.push({
                currentArgs: nextArgs,
                previousArgs: getArgs,
            });
        }
    }
    function get(getArgs) {
        return getter(...getArgs);
    }
    function prunedPermutations() {
        const permutations = permute(seed.length);
        return permutations.filter(function (perm) {
            const count = countNonZeroes(perm);
            return count !== 0 && (count === 1 || diagonals);
        });
    }
    function permute(length) {
        const perms = [];
        const permutation = function (string) {
            return string.split('').map(function (c) {
                return parseInt(c, 10) - 1;
            });
        };
        for (let i = 0; i < Math.pow(3, length); i += 1) {
            const string = lpad(i.toString(3), '0', length);
            perms.push(permutation(string));
        }
        return perms;
    }
    function boundaries() {
        const array = Array.from(bounds.values());
        array.reverse();
        return array;
    }
}
function defaultEquals(a, b) {
    return a === b;
}
function countNonZeroes(array) {
    let count = 0;
    for (let i = 0; i < array.length; i += 1) {
        if (array[i] !== 0) {
            count += 1;
        }
    }
    return count;
}
function lpad(string, character, length) {
    const array = new Array(length + 1);
    const pad = array.join(character);
    return (pad + string).slice(-length);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (floodFill);


/***/ }),

/***/ 50969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ getDefaultRepresentationConfig)
/* harmony export */ });
/* harmony import */ var _tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44350);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);


function getDefaultRepresentationConfig(segmentation) {
    const { type: representationType } = segmentation;
    switch (representationType) {
        case _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Labelmap:
            return (0,_tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)();
        default:
            throw new Error(`Unknown representation type: ${representationType}`);
    }
}


/***/ }),

/***/ 4863:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ getHoveredContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95778);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30322);


function getHoveredContourSegmentationAnnotation(segmentationId) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentation)(segmentationId);
    const { annotationUIDsMap } = segmentation.representationData.CONTOUR;
    for (const [segmentIndex, annotationUIDs] of annotationUIDsMap.entries()) {
        const highlightedAnnotationUID = Array.from(annotationUIDs).find((annotationUID) => (0,_stateManagement__WEBPACK_IMPORTED_MODULE_0__/* .getAnnotation */ .gw)(annotationUID).highlighted);
        if (highlightedAnnotationUID) {
            return segmentIndex;
        }
    }
    return undefined;
}


/***/ }),

/***/ 54117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ getSegmentAtLabelmapBorder)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30322);
/* harmony import */ var _tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16124);



function getSegmentAtLabelmapBorder(segmentationId, worldPoint, { viewport, searchRadius }) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentation)(segmentationId);
    const labelmapData = segmentation.representationData.LABELMAP;
    if ((0,_tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_2__/* .isVolumeSegmentation */ .r)(labelmapData)) {
        const { volumeId } = labelmapData;
        const segmentationVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        if (!segmentationVolume) {
            return;
        }
        const imageData = segmentationVolume.imageData;
        const segmentIndex = imageData.getScalarValueFromWorld(worldPoint);
        const canvasPoint = viewport.worldToCanvas(worldPoint);
        const onEdge = isSegmentOnEdgeCanvas(canvasPoint, segmentIndex, viewport, imageData, searchRadius);
        return onEdge ? segmentIndex : undefined;
    }
    const { imageIdReferenceMap } = labelmapData;
    const currentImageId = viewport.getCurrentImageId();
    const segmentationImageId = imageIdReferenceMap.get(currentImageId);
    const image = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getImage(segmentationImageId);
    if (!image) {
        return;
    }
    const segmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentationIdRepresentations)(segmentation.segmentationId);
    const { segmentationRepresentationUID } = segmentationRepresentations[0];
    const segmentationActor = viewport.getActor(segmentationRepresentationUID);
    const imageData = segmentationActor?.actor.getMapper().getInputData();
    const indexIJK = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, worldPoint);
    const dimensions = imageData.getDimensions();
    const voxelManager = (imageData.voxelManager ||
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.VoxelManager.createVolumeVoxelManager(dimensions, imageData.getPointData().getScalars().getData()));
    const segmentIndex = voxelManager.getAtIJKPoint(indexIJK);
    const onEdge = isSegmentOnEdgeIJK(indexIJK, dimensions, voxelManager, segmentIndex);
    return onEdge ? segmentIndex : undefined;
}
function isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius = 1) {
    const neighborRange = Array.from({ length: 2 * searchRadius + 1 }, (_, i) => i - searchRadius);
    for (const deltaI of neighborRange) {
        for (const deltaJ of neighborRange) {
            for (const deltaK of neighborRange) {
                if (deltaI === 0 && deltaJ === 0 && deltaK === 0) {
                    continue;
                }
                const neighborIndex = getNeighborIndex(deltaI, deltaJ, deltaK);
                if (neighborIndex !== undefined && segmentIndex !== neighborIndex) {
                    return true;
                }
            }
        }
    }
    return false;
}
function isSegmentOnEdgeIJK(indexIJK, dimensions, voxelManager, segmentIndex, searchRadius) {
    const getNeighborIndex = (deltaI, deltaJ, deltaK) => {
        const neighborIJK = [
            indexIJK[0] + deltaI,
            indexIJK[1] + deltaJ,
            indexIJK[2] + deltaK,
        ];
        return voxelManager.getAtIJK(...neighborIJK);
    };
    return isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius);
}
function isSegmentOnEdgeCanvas(canvasPoint, segmentIndex, viewport, imageData, searchRadius) {
    const getNeighborIndex = (deltaI, deltaJ) => {
        const neighborCanvas = [canvasPoint[0] + deltaI, canvasPoint[1] + deltaJ];
        const worldPoint = viewport.canvasToWorld(neighborCanvas);
        return imageData.getScalarValueFromWorld(worldPoint);
    };
    return isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius);
}


/***/ }),

/***/ 2465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z5: () => (/* binding */ getSegmentAtWorldPoint)
/* harmony export */ });
/* unused harmony exports getSegmentAtWorldForLabelmap, getSegmentAtWorldForContour */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84901);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(30322);
/* harmony import */ var _tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16124);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(95778);
/* harmony import */ var _math_polyline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(56634);






function getSegmentAtWorldPoint(segmentationId, worldPoint, options = {}) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__.getSegmentation)(segmentationId);
    const representationData = segmentation.representationData;
    const desiredRepresentation = options?.representationType ?? Object.keys(representationData)[0];
    if (!desiredRepresentation) {
        throw new Error(`Segmentation ${segmentationId} does not have any representations`);
    }
    switch (desiredRepresentation) {
        case _enums__WEBPACK_IMPORTED_MODULE_1__.SegmentationRepresentations.Labelmap:
            return getSegmentAtWorldForLabelmap(segmentation, worldPoint, options);
        case _enums__WEBPACK_IMPORTED_MODULE_1__.SegmentationRepresentations.Contour:
            return getSegmentAtWorldForContour(segmentation, worldPoint, options);
        default:
            return;
    }
}
function getSegmentAtWorldForLabelmap(segmentation, worldPoint, { viewport }) {
    const labelmapData = segmentation.representationData.LABELMAP;
    if ((0,_tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_3__/* .isVolumeSegmentation */ .r)(labelmapData)) {
        const { volumeId } = labelmapData;
        const segmentationVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        if (!segmentationVolume) {
            return;
        }
        const segmentIndex = segmentationVolume.imageData.getScalarValueFromWorld(worldPoint);
        return segmentIndex;
    }
    const { imageIdReferenceMap } = labelmapData;
    const currentImageId = viewport.getCurrentImageId();
    const segmentationImageId = imageIdReferenceMap.get(currentImageId);
    const image = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getImage(segmentationImageId);
    if (!image) {
        return;
    }
    const segmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__.getSegmentationIdRepresentations)(segmentation.segmentationId);
    const { segmentationRepresentationUID } = segmentationRepresentations[0];
    const segmentationActor = viewport.getActor(segmentationRepresentationUID);
    const imageData = segmentationActor?.actor.getMapper().getInputData();
    const indexIJK = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, worldPoint);
    const dimensions = imageData.getDimensions();
    const voxelManager = (imageData.voxelManager ||
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.VoxelManager.createVolumeVoxelManager(dimensions, imageData.getPointData().getScalars().getData()));
    const segmentIndex = voxelManager.getAtIJKPoint(indexIJK);
    return segmentIndex;
}
function getSegmentAtWorldForContour(segmentation, worldPoint, { viewport }) {
    const contourData = segmentation.representationData.CONTOUR;
    const segmentIndices = Array.from(contourData.annotationUIDsMap.keys());
    const { viewPlaneNormal } = viewport.getCamera();
    for (const segmentIndex of segmentIndices) {
        const annotationsSet = contourData.annotationUIDsMap.get(segmentIndex);
        if (!annotationsSet) {
            continue;
        }
        for (const annotationUID of annotationsSet) {
            const annotation = (0,_stateManagement__WEBPACK_IMPORTED_MODULE_4__/* .getAnnotation */ .gw)(annotationUID);
            if (!annotation) {
                continue;
            }
            const { polyline } = annotation.data.contour;
            if (!_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(viewPlaneNormal, annotation.metadata.viewPlaneNormal)) {
                continue;
            }
            if ((0,_math_polyline__WEBPACK_IMPORTED_MODULE_5__.isPointInsidePolyline3D)(worldPoint, polyline)) {
                return Number(segmentIndex);
            }
        }
    }
}


/***/ }),

/***/ 15818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ invalidateBrushCursor)
/* harmony export */ });
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function invalidateBrushCursor(toolGroupId) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId);
    brushBasedToolInstances.forEach((tool) => {
        tool.invalidateBrushCursor();
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    const viewportsInfoArray = Object.keys(viewportsInfo).map((key) => viewportsInfo[key]);
    if (!viewportsInfoArray.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfoArray[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__.getRenderingEngine)(renderingEngineId);
    (0,_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(renderingEngine, viewportIds);
}


/***/ }),

/***/ 19434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ isValidRepresentationConfig)
/* harmony export */ });
/* harmony import */ var _tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44350);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);


function isValidRepresentationConfig(representationType, config) {
    switch (representationType) {
        case _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Labelmap:
            return (0,_tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__/* .isValidLabelmapConfig */ .J)(config);
        default:
            throw new Error(`Unknown representation type: ${representationType}`);
    }
}


/***/ }),

/***/ 71411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(45238);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81848);
/* harmony import */ var _thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32854);
/* harmony import */ var _rectangleROITool_getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89786);




function rectangleROIThresholdVolumeByRange(annotationUIDs, segmentationVolume, thresholdVolumeInformation, options) {
    const annotations = annotationUIDs.map((annotationUID) => {
        return _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_0__.state.getAnnotation(annotationUID);
    });
    _validateAnnotations(annotations);
    let boundsIJK;
    for (let i = 0; i < thresholdVolumeInformation.length; i++) {
        const volumeSize = thresholdVolumeInformation[i].volume.getScalarData().length;
        if (volumeSize === segmentationVolume.getScalarData().length || i === 0) {
            boundsIJK = (0,_rectangleROITool_getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(annotations, thresholdVolumeInformation[i].volume, options);
        }
    }
    const outputSegmentationVolume = (0,_thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A)(segmentationVolume, thresholdVolumeInformation, { ...options, boundsIJK });
    outputSegmentationVolume.modified();
    return outputSegmentationVolume;
}
function _validateAnnotations(annotations) {
    const validToolNames = [
        _tools__WEBPACK_IMPORTED_MODULE_1__/* .RectangleROIThresholdTool */ .TR.toolName,
        _tools__WEBPACK_IMPORTED_MODULE_1__/* .RectangleROIStartEndThresholdTool */ .mX.toolName,
    ];
    for (const annotation of annotations) {
        const name = annotation.metadata.toolName;
        if (!validToolNames.includes(name)) {
            throw new Error('rectangleROIThresholdVolumeByRange only supports RectangleROIThreshold and RectangleROIStartEndThreshold annotations');
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rectangleROIThresholdVolumeByRange);


/***/ }),

/***/ 10032:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ segmentContourAction)
/* harmony export */ });
/* unused harmony export defaultGetSegment */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63421);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45238);
/* harmony import */ var _viewport__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(31555);
/* harmony import */ var _contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41196);
/* harmony import */ var _createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(96610);
/* harmony import */ var _tools_annotation_BidirectionalTool__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(50720);







function segmentContourAction(element, configuration) {
    const { data: configurationData } = configuration;
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
    const segment = (configurationData.getSegment || defaultGetSegment)(enabledElement, configurationData);
    if (!segment) {
        return;
    }
    const FrameOfReferenceUID = enabledElement.viewport.getFrameOfReferenceUID();
    const segmentationsList = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__.state.getSegmentations();
    const { segmentIndex, segmentationId } = segment;
    const bidirectionals = _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__.state.getAnnotations(this.toolName || _tools_annotation_BidirectionalTool__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A.toolName, FrameOfReferenceUID);
    let hasExistingActiveSegment = false;
    const existingLargestBidirectionals = bidirectionals.filter((existingBidirectionalItem) => {
        const { segment } = existingBidirectionalItem.data;
        if (!segment) {
            return;
        }
        if (segment.segmentationId === segmentationId &&
            segment.segmentIndex === segmentIndex) {
            hasExistingActiveSegment = true;
            existingBidirectionalItem.data.segment = segment;
        }
        return !!segment;
    });
    if (!hasExistingActiveSegment) {
        existingLargestBidirectionals.push({
            data: { segment },
        });
    }
    let newBidirectional;
    existingLargestBidirectionals.forEach((existingLargestBidirectional) => {
        const segments = [];
        const { segment: updateSegment } = existingLargestBidirectional.data;
        const { segmentIndex, segmentationId } = updateSegment;
        segments[segmentIndex] = updateSegment;
        _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__.state.removeAnnotation(existingLargestBidirectional.annotationUID);
        const bidirectionalData = (0,_contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)({
            ...segmentationsList.find((segmentation) => segmentation.segmentationId === segmentationId),
            segments,
        });
        if (!bidirectionalData) {
            return;
        }
        const bidirectionalToolData = (0,_createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A)(bidirectionalData, enabledElement.viewport);
        bidirectionalToolData.annotationUID =
            existingLargestBidirectional.annotationUID;
        bidirectionalToolData.data.segment = updateSegment;
        const annotationUID = _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__.state.addAnnotation(bidirectionalToolData, FrameOfReferenceUID);
        if (updateSegment.segmentIndex === segment.segmentIndex &&
            updateSegment.segmentationId === segment.segmentationId) {
            newBidirectional = bidirectionalData;
            const { style } = segment;
            if (style) {
                _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__.config.style.setAnnotationStyles(annotationUID, style);
            }
        }
    });
    if (newBidirectional) {
        const { sliceIndex } = newBidirectional;
        const imageIds = enabledElement.viewport.getImageIds();
        (0,_viewport__WEBPACK_IMPORTED_MODULE_3__.jumpToSlice)(element, {
            imageIndex: imageIds.length - 1 - sliceIndex,
        });
        enabledElement.viewport.render();
    }
    else {
        console.warn('No bidirectional found');
    }
    return newBidirectional;
}
function defaultGetSegment(enabledElement, configuration) {
    const segmentationsList = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__.state.getSegmentations();
    if (!segmentationsList.length) {
        return;
    }
    const segmentationId = configuration.segmentationId || segmentationsList[0].segmentationId;
    const segmentIndex = configuration.segmentIndex ??
        _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__.segmentIndex.getActiveSegmentIndex(segmentationId);
    if (!segmentIndex) {
        return;
    }
    const segmentData = configuration.segmentData?.get(segmentIndex);
    return {
        label: `Segment ${segmentIndex}`,
        segmentIndex,
        segmentationId,
        ...segmentData,
    };
}


/***/ }),

/***/ 92922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74119);
/* harmony import */ var _stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87682);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77071);



function thresholdSegmentationByRange(segmentationVolume, segmentationIndex, thresholdVolumeInformation, overlapType) {
    const scalarData = segmentationVolume.getScalarData();
    const { baseVolumeIdx, volumeInfoList } = (0,_utilities__WEBPACK_IMPORTED_MODULE_2__/* .processVolumes */ .zf)(segmentationVolume, thresholdVolumeInformation);
    volumeInfoList.forEach((volumeInfo) => {
        const { volumeSize } = volumeInfo;
        if (volumeSize === scalarData.length) {
            _handleSameSizeVolume(scalarData, segmentationIndex, volumeInfo);
        }
        else {
            _handleDifferentSizeVolume(scalarData, segmentationIndex, volumeInfo, volumeInfoList, baseVolumeIdx, overlapType);
        }
    });
    (0,_stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__.triggerSegmentationDataModified)(segmentationVolume.volumeId);
    return segmentationVolume;
}
function _handleDifferentSizeVolume(scalarData, segmentationIndex, volumeInfo, volumeInfoList, baseVolumeIdx, overlapType) {
    const { imageData, lower, upper, dimensions } = volumeInfo;
    let total, overlaps, range;
    for (let i = 0; i < scalarData.length; i++) {
        if (scalarData[i] === segmentationIndex) {
            const overlapBounds = (0,_utilities__WEBPACK_IMPORTED_MODULE_2__/* .getVoxelOverlap */ .Q5)(imageData, dimensions, volumeInfoList[baseVolumeIdx].spacing, volumeInfoList[baseVolumeIdx].imageData.getPoint(i));
            const callbackOverlap = ({ value }) => {
                total = total + 1;
                if (value >= range.lower && value <= range.upper) {
                    overlaps = overlaps + 1;
                }
            };
            total = 0;
            overlaps = 0;
            range = { lower, upper };
            let overlapTest = false;
            (0,_utilities__WEBPACK_IMPORTED_MODULE_0__.pointInShapeCallback)(imageData, () => true, callbackOverlap, overlapBounds);
            overlapTest = overlapType === 0 ? overlaps > 0 : overlaps === total;
            scalarData[i] = overlapTest ? segmentationIndex : 0;
        }
    }
    return { total, range, overlaps };
}
function _handleSameSizeVolume(scalarData, segmentationIndex, volumeInfo) {
    const { referenceValues, lower, upper } = volumeInfo;
    for (let i = 0; i < scalarData.length; i++) {
        if (scalarData[i] === segmentationIndex) {
            const value = referenceValues[i];
            scalarData[i] = value >= lower && value <= upper ? segmentationIndex : 0;
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (thresholdSegmentationByRange);


/***/ }),

/***/ 32854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74119);
/* harmony import */ var _stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87682);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77071);



function thresholdVolumeByRange(segmentationVolume, thresholdVolumeInformation, options) {
    const { imageData: segmentationImageData } = segmentationVolume;
    const scalarData = segmentationVolume.getScalarData();
    const { overwrite, boundsIJK } = options;
    const overlapType = options?.overlapType || 0;
    if (overwrite) {
        for (let i = 0; i < scalarData.length; i++) {
            scalarData[i] = 0;
        }
    }
    const { baseVolumeIdx, volumeInfoList } = (0,_utilities__WEBPACK_IMPORTED_MODULE_2__/* .processVolumes */ .zf)(segmentationVolume, thresholdVolumeInformation);
    let overlaps, total, range;
    const testOverlapRange = (volumeInfo, voxelSpacing, voxelCenter) => {
        const callbackOverlap = ({ value }) => {
            total = total + 1;
            if (value >= range.lower && value <= range.upper) {
                overlaps = overlaps + 1;
            }
        };
        const { imageData, dimensions, lower, upper } = volumeInfo;
        const overlapBounds = (0,_utilities__WEBPACK_IMPORTED_MODULE_2__/* .getVoxelOverlap */ .Q5)(imageData, dimensions, voxelSpacing, voxelCenter);
        total = 0;
        overlaps = 0;
        range = { lower, upper };
        let overlapTest = false;
        (0,_utilities__WEBPACK_IMPORTED_MODULE_0__.pointInShapeCallback)(imageData, () => true, callbackOverlap, overlapBounds);
        if (overlapType === 0) {
            overlapTest = overlaps > 0;
        }
        else if (overlapType == 1) {
            overlapTest = overlaps === total;
        }
        return overlapTest;
    };
    const testRange = (volumeInfo, pointIJK) => {
        const { imageData, referenceValues, lower, upper } = volumeInfo;
        const offset = imageData.computeOffsetIndex(pointIJK);
        const value = referenceValues[offset];
        if (value <= lower || value >= upper) {
            return false;
        }
        else {
            return true;
        }
    };
    const callback = ({ index, pointIJK, pointLPS }) => {
        let insert = volumeInfoList.length > 0;
        for (let i = 0; i < volumeInfoList.length; i++) {
            if (volumeInfoList[i].volumeSize === scalarData.length) {
                insert = testRange(volumeInfoList[i], pointIJK);
            }
            else {
                insert = testOverlapRange(volumeInfoList[i], volumeInfoList[baseVolumeIdx].spacing, pointLPS);
            }
            if (!insert) {
                break;
            }
        }
        if (insert) {
            scalarData[index] = options.segmentIndex || 1;
        }
    };
    (0,_utilities__WEBPACK_IMPORTED_MODULE_0__.pointInShapeCallback)(segmentationImageData, () => true, callback, boundsIJK);
    (0,_stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__.triggerSegmentationDataModified)(segmentationVolume.volumeId);
    return segmentationVolume;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (thresholdVolumeByRange);


/***/ }),

/***/ 77071:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Q5: () => (/* binding */ getVoxelOverlap),
/* harmony export */   n7: () => (/* binding */ getBrushToolInstances),
/* harmony export */   zf: () => (/* binding */ processVolumes)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52610);
/* harmony import */ var _tools_segmentation_BrushTool__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53712);
/* harmony import */ var _boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14471);




function getBrushToolInstances(toolGroupId, toolName) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_1__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    if (toolName && toolInstances[toolName]) {
        return [toolInstances[toolName]];
    }
    const brushBasedToolInstances = Object.values(toolInstances).filter((toolInstance) => toolInstance instanceof _tools_segmentation_BrushTool__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
    return brushBasedToolInstances;
}
const equalsCheck = (a, b) => {
    return JSON.stringify(a) === JSON.stringify(b);
};
function getVoxelOverlap(imageData, dimensions, voxelSpacing, voxelCenter) {
    const voxelCornersWorld = [];
    for (let i = 0; i < 2; i++) {
        for (let j = 0; j < 2; j++) {
            for (let k = 0; k < 2; k++) {
                const point = [...voxelCenter];
                point[0] = point[0] + ((i * 2 - 1) * voxelSpacing[0]) / 2;
                point[1] = point[1] + ((j * 2 - 1) * voxelSpacing[1]) / 2;
                point[2] = point[2] + ((k * 2 - 1) * voxelSpacing[2]) / 2;
                voxelCornersWorld.push(point);
            }
        }
    }
    const voxelCornersIJK = voxelCornersWorld.map((world) => _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, world));
    const overlapBounds = (0,_boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_3__/* .getBoundingBoxAroundShapeIJK */ .g)(voxelCornersIJK, dimensions);
    return overlapBounds;
}
function processVolumes(segmentationVolume, thresholdVolumeInformation) {
    const { spacing: segmentationSpacing } = segmentationVolume;
    const scalarData = segmentationVolume.getScalarData();
    const volumeInfoList = [];
    let baseVolumeIdx = 0;
    for (let i = 0; i < thresholdVolumeInformation.length; i++) {
        const { imageData, spacing, dimensions } = thresholdVolumeInformation[i].volume;
        const volumeSize = thresholdVolumeInformation[i].volume.getScalarData().length;
        if (volumeSize === scalarData.length &&
            equalsCheck(spacing, segmentationSpacing)) {
            baseVolumeIdx = i;
        }
        const referenceValues = imageData.getPointData().getScalars().getData();
        const lower = thresholdVolumeInformation[i].lower;
        const upper = thresholdVolumeInformation[i].upper;
        volumeInfoList.push({
            imageData,
            referenceValues,
            lower,
            upper,
            spacing,
            dimensions,
            volumeSize,
        });
    }
    return {
        volumeInfoList,
        baseVolumeIdx,
    };
}


/***/ }),

/***/ 90387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  N: () => (/* reexport */ stackPrefetch_stackContextPrefetch),
  S: () => (/* reexport */ stackPrefetch_stackPrefetch)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/state.js
var state = __webpack_require__(54957);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackPrefetchUtils.js
var stackPrefetchUtils = __webpack_require__(48506);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackPrefetch.js



let configuration = {
    maxImagesToPrefetch: Infinity,
    preserveExistingPool: true,
};
let resetPrefetchTimeout;
const resetPrefetchDelay = 10;
function prefetch(element) {
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (!stackPrefetchData) {
        return;
    }
    const stackPrefetch = stackPrefetchData || {};
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack?.imageIds?.length) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const { currentImageIdIndex } = stack;
    stackPrefetch.enabled &&= stackPrefetch.indicesToRequest?.length;
    if (stackPrefetch.enabled === false) {
        return;
    }
    function removeFromList(imageIdIndex) {
        const index = stackPrefetch.indicesToRequest.indexOf(imageIdIndex);
        if (index > -1) {
            stackPrefetch.indicesToRequest.splice(index, 1);
        }
    }
    stackPrefetchData.indicesToRequest.sort((a, b) => a - b);
    const indicesToRequestCopy = stackPrefetch.indicesToRequest.slice();
    indicesToRequestCopy.forEach(function (imageIdIndex) {
        const imageId = stack.imageIds[imageIdIndex];
        if (!imageId) {
            return;
        }
        const distance = Math.abs(currentImageIdIndex - imageIdIndex);
        const imageCached = distance < 6
            ? esm.cache.getImageLoadObject(imageId)
            : esm.cache.isLoaded(imageId);
        if (imageCached) {
            removeFromList(imageIdIndex);
        }
    });
    if (!stackPrefetch.indicesToRequest.length) {
        return;
    }
    if (!configuration.preserveExistingPool) {
        esm.imageLoadPoolManager.clearRequestStack(stackPrefetchUtils/* requestType */.y9);
    }
    const nearest = (0,stackPrefetchUtils/* nearestIndex */.zo)(stackPrefetch.indicesToRequest, stack.currentImageIdIndex);
    let imageId;
    let nextImageIdIndex;
    const preventCache = false;
    function doneCallback(image) {
        console.log('prefetch done: %s', image.imageId);
        const imageIdIndex = stack.imageIds.indexOf(image.imageId);
        removeFromList(imageIdIndex);
    }
    let lowerIndex = nearest.low;
    let higherIndex = nearest.high;
    const imageIdsToPrefetch = [];
    while (lowerIndex >= 0 ||
        higherIndex < stackPrefetch.indicesToRequest.length) {
        const currentIndex = stack.currentImageIdIndex;
        const shouldSkipLower = currentIndex - stackPrefetch.indicesToRequest[lowerIndex] >
            configuration.maxImagesToPrefetch;
        const shouldSkipHigher = stackPrefetch.indicesToRequest[higherIndex] - currentIndex >
            configuration.maxImagesToPrefetch;
        const shouldLoadLower = !shouldSkipLower && lowerIndex >= 0;
        const shouldLoadHigher = !shouldSkipHigher && higherIndex < stackPrefetch.indicesToRequest.length;
        if (!shouldLoadHigher && !shouldLoadLower) {
            break;
        }
        if (shouldLoadLower) {
            nextImageIdIndex = stackPrefetch.indicesToRequest[lowerIndex--];
            imageId = stack.imageIds[nextImageIdIndex];
            imageIdsToPrefetch.push(imageId);
        }
        if (shouldLoadHigher) {
            nextImageIdIndex = stackPrefetch.indicesToRequest[higherIndex++];
            imageId = stack.imageIds[nextImageIdIndex];
            imageIdsToPrefetch.push(imageId);
        }
    }
    const requestFn = (imageId, options) => esm.imageLoader.loadAndCacheImage(imageId, options);
    const { useNorm16Texture, preferSizeOverAccuracy } = (0,esm.getConfiguration)().rendering;
    const useNativeDataType = useNorm16Texture || preferSizeOverAccuracy;
    imageIdsToPrefetch.forEach((imageId) => {
        const options = {
            targetBuffer: {
                type: useNativeDataType ? undefined : 'Float32Array',
            },
            preScale: {
                enabled: true,
            },
            useNativeDataType,
            requestType: stackPrefetchUtils/* requestType */.y9,
        };
        esm.imageLoadPoolManager.addRequest(requestFn.bind(null, imageId, options), stackPrefetchUtils/* requestType */.y9, {
            imageId,
        }, stackPrefetchUtils/* priority */.Lr);
    });
}
function onImageUpdated(e) {
    clearTimeout(resetPrefetchTimeout);
    resetPrefetchTimeout = setTimeout(function () {
        const element = e.target;
        try {
            prefetch(element);
        }
        catch (error) {
            return;
        }
    }, resetPrefetchDelay);
}
function enable(element) {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const stackPrefetchData = {
        indicesToRequest: (0,stackPrefetchUtils/* range */.y1)(0, stack.imageIds.length - 1),
        enabled: true,
        direction: 1,
    };
    const indexOfCurrentImage = stackPrefetchData.indicesToRequest.indexOf(stack.currentImageIdIndex);
    stackPrefetchData.indicesToRequest.splice(indexOfCurrentImage, 1);
    (0,state/* addToolState */.P)(element, stackPrefetchData);
    prefetch(element);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    element.addEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    esm.eventTarget.addEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
}
function disable(element) {
    clearTimeout(resetPrefetchTimeout);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (stackPrefetchData && stackPrefetchData.indicesToRequest.length) {
        stackPrefetchData.enabled = false;
        esm.imageLoadPoolManager.clearRequestStack(stackPrefetchUtils/* requestType */.y9);
    }
}
function getConfiguration() {
    return configuration;
}
function setConfiguration(config) {
    configuration = config;
}
const stackPrefetch = { enable, disable, getConfiguration, setConfiguration };
/* harmony default export */ const stackPrefetch_stackPrefetch = (stackPrefetch);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js + 1 modules
var utilities = __webpack_require__(74119);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackContextPrefetch.js




let stackContextPrefetch_configuration = {
    maxImagesToPrefetch: Infinity,
    minBefore: 2,
    maxAfter: 2,
    directionExtraImages: 10,
    preserveExistingPool: false,
};
let stackContextPrefetch_resetPrefetchTimeout;
const stackContextPrefetch_resetPrefetchDelay = 5;
const stackContextPrefetch_enable = (element) => {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    updateToolState(element);
    stackContextPrefetch_prefetch(element);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    element.addEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    esm.eventTarget.addEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
};
function stackContextPrefetch_prefetch(element) {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack?.imageIds?.length) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (!stackPrefetchData) {
        return;
    }
    const stackPrefetch = stackPrefetchData || {};
    stackPrefetch.enabled &&= stackPrefetch.indicesToRequest?.length;
    if (stackPrefetch.enabled === false) {
        return;
    }
    function removeFromList(imageIdIndex) {
        const index = stackPrefetch.indicesToRequest.indexOf(imageIdIndex);
        if (index > -1) {
            stackPrefetch.indicesToRequest.splice(index, 1);
        }
    }
    const indicesToRequestCopy = stackPrefetch.indicesToRequest.slice();
    const { currentImageIdIndex } = stack;
    indicesToRequestCopy.forEach((imageIdIndex) => {
        const imageId = stack.imageIds[imageIdIndex];
        if (!imageId) {
            return;
        }
        const distance = Math.abs(currentImageIdIndex - imageIdIndex);
        const imageCached = distance < 6
            ? esm.cache.getImageLoadObject(imageId)
            : esm.cache.isLoaded(imageId);
        if (imageCached) {
            removeFromList(imageIdIndex);
        }
    });
    if (!stackPrefetch.indicesToRequest.length) {
        return;
    }
    if (!stackContextPrefetch_configuration.preserveExistingPool) {
        esm.imageLoadPoolManager.filterRequests((0,stackPrefetchUtils/* clearFromImageIds */.Pg)(stack));
    }
    function doneCallback(imageId) {
        const imageIdIndex = stack.imageIds.indexOf(imageId);
        removeFromList(imageIdIndex);
        const image = esm.cache.getCachedImageBasedOnImageURI(imageId);
        const { stats } = stackPrefetch;
        const decodeTimeInMS = image?.image?.decodeTimeInMS || 0;
        if (decodeTimeInMS) {
            stats.imageIds.set(imageId, decodeTimeInMS);
            stats.decodeTimeInMS += decodeTimeInMS;
            const loadTimeInMS = image?.image?.loadTimeInMS || 0;
            stats.loadTimeInMS += loadTimeInMS;
        }
        if (!stackPrefetch.indicesToRequest.length) {
            if (image?.sizeInBytes) {
                const { sizeInBytes } = image;
                const usage = esm.cache.getMaxCacheSize() / 4 / sizeInBytes;
                if (!stackPrefetch.cacheFill) {
                    stats.initialTime = Date.now() - stats.start;
                    stats.initialSize = stats.imageIds.size;
                    updateToolState(element, usage);
                    stackContextPrefetch_prefetch(element);
                }
                else if (stats.imageIds.size) {
                    stats.fillTime = Date.now() - stats.start;
                    const { size } = stats.imageIds;
                    stats.fillSize = size;
                    console.log('Done cache fill', stats.fillTime, 'ms', size, 'items', 'average total time', (0,utilities.roundNumber)(stats.fillTime / size), 'ms', 'average load', (0,utilities.roundNumber)(stats.loadTimeInMS / size), 'ms', 'average decode', (0,utilities.roundNumber)(stats.decodeTimeInMS / size), 'ms');
                }
            }
        }
    }
    const requestFn = (imageId, options) => esm.imageLoader.loadAndCacheImage(imageId, options)
        .then(() => doneCallback(imageId));
    const { useNorm16Texture, preferSizeOverAccuracy } = (0,esm.getConfiguration)().rendering;
    const useNativeDataType = useNorm16Texture || preferSizeOverAccuracy;
    indicesToRequestCopy.forEach((imageIdIndex) => {
        const imageId = stack.imageIds[imageIdIndex];
        const options = {
            targetBuffer: {
                type: useNativeDataType ? undefined : 'Float32Array',
            },
            preScale: {
                enabled: true,
            },
            useNativeDataType,
            requestType: stackPrefetchUtils/* requestType */.y9,
        };
        esm.imageLoadPoolManager.addRequest(requestFn.bind(null, imageId, options), stackPrefetchUtils/* requestType */.y9, {
            imageId,
        }, stackPrefetchUtils/* priority */.Lr);
    });
}
function stackContextPrefetch_onImageUpdated(e) {
    clearTimeout(stackContextPrefetch_resetPrefetchTimeout);
    stackContextPrefetch_resetPrefetchTimeout = setTimeout(function () {
        const element = e.target;
        try {
            updateToolState(element);
            stackContextPrefetch_prefetch(element);
        }
        catch (error) {
            return;
        }
    }, stackContextPrefetch_resetPrefetchDelay);
}
const signum = (x) => (x < 0 ? -1 : 1);
const updateToolState = (element, usage) => {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const { currentImageIdIndex } = stack;
    let { maxAfter = 2, minBefore = 2 } = stackContextPrefetch_configuration;
    const { directionExtraImages = 10 } = stackContextPrefetch_configuration;
    const stackPrefetchData = (0,state/* getToolState */.k)(element) || {
        indicesToRequest: [],
        currentImageIdIndex,
        stackCount: 0,
        enabled: true,
        direction: 1,
        stats: {
            start: Date.now(),
            imageIds: new Map(),
            decodeTimeInMS: 0,
            loadTimeInMS: 0,
            totalBytes: 0,
        },
    };
    const delta = currentImageIdIndex - stackPrefetchData.currentImageIdIndex;
    stackPrefetchData.direction = signum(delta);
    stackPrefetchData.currentImageIdIndex = currentImageIdIndex;
    stackPrefetchData.enabled = true;
    if (stackPrefetchData.stackCount < 100) {
        stackPrefetchData.stackCount += directionExtraImages;
    }
    if (Math.abs(delta) > maxAfter || !delta) {
        stackPrefetchData.stackCount = 0;
        if (usage) {
            const positionFraction = currentImageIdIndex / stack.imageIds.length;
            minBefore = Math.ceil(usage * positionFraction);
            maxAfter = Math.ceil(usage * (1 - positionFraction));
            stackPrefetchData.cacheFill = true;
        }
        else {
            stackPrefetchData.cacheFill = false;
        }
    }
    else if (delta < 0) {
        minBefore += stackPrefetchData.stackCount;
        maxAfter = 0;
    }
    else {
        maxAfter += stackPrefetchData.stackCount;
        minBefore = 0;
    }
    const minIndex = Math.max(0, currentImageIdIndex - minBefore);
    const maxIndex = Math.min(stack.imageIds.length - 1, currentImageIdIndex + maxAfter);
    const indicesToRequest = [];
    for (let i = currentImageIdIndex + 1; i <= maxIndex; i++) {
        indicesToRequest.push(i);
    }
    for (let i = currentImageIdIndex - 1; i >= minIndex; i--) {
        indicesToRequest.push(i);
    }
    stackPrefetchData.indicesToRequest = indicesToRequest;
    (0,state/* addToolState */.P)(element, stackPrefetchData);
};
function stackContextPrefetch_disable(element) {
    clearTimeout(stackContextPrefetch_resetPrefetchTimeout);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (stackPrefetchData && stackPrefetchData.data.length) {
        stackPrefetchData.enabled = false;
    }
}
function stackContextPrefetch_getConfiguration() {
    return stackContextPrefetch_configuration;
}
function stackContextPrefetch_setConfiguration(config) {
    stackContextPrefetch_configuration = config;
}
const stackContextPrefetch = {
    enable: stackContextPrefetch_enable,
    disable: stackContextPrefetch_disable,
    getConfiguration: stackContextPrefetch_getConfiguration,
    setConfiguration: stackContextPrefetch_setConfiguration,
};
/* harmony default export */ const stackPrefetch_stackContextPrefetch = (stackContextPrefetch);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/index.js





/***/ }),

/***/ 21090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _debounce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64857);
/* harmony import */ var _isObject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11857);


function throttle(func, wait, options) {
    let leading = true;
    let trailing = true;
    if (typeof func !== 'function') {
        throw new TypeError('Expected a function');
    }
    if ((0,_isObject__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(options)) {
        leading = 'leading' in options ? Boolean(options.leading) : leading;
        trailing = 'trailing' in options ? Boolean(options.trailing) : trailing;
    }
    return (0,_debounce__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(func, wait, {
        leading,
        trailing,
        maxWait: wait,
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (throttle);


/***/ }),

/***/ 54868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   copyPoints: () => (/* binding */ copyPoints),
/* harmony export */   copyPointsList: () => (/* binding */ copyPointsList),
/* harmony export */   getDeltaDistance: () => (/* binding */ getDeltaDistance),
/* harmony export */   getDeltaDistanceBetweenIPoints: () => (/* binding */ getDeltaDistanceBetweenIPoints),
/* harmony export */   getDeltaPoints: () => (/* binding */ getDeltaPoints),
/* harmony export */   getDeltaRotation: () => (/* binding */ getDeltaRotation),
/* harmony export */   getMeanPoints: () => (/* binding */ getMeanPoints),
/* harmony export */   getMeanTouchPoints: () => (/* binding */ getMeanTouchPoints)
/* harmony export */ });
function getDeltaPoints(currentPoints, lastPoints) {
    const curr = getMeanPoints(currentPoints);
    const last = getMeanPoints(lastPoints);
    return {
        page: _subtractPoints2D(curr.page, last.page),
        client: _subtractPoints2D(curr.client, last.client),
        canvas: _subtractPoints2D(curr.canvas, last.canvas),
        world: _subtractPoints3D(curr.world, last.world),
    };
}
function getDeltaDistance(currentPoints, lastPoints) {
    const curr = getMeanPoints(currentPoints);
    const last = getMeanPoints(lastPoints);
    return {
        page: _getDistance2D(curr.page, last.page),
        client: _getDistance2D(curr.client, last.client),
        canvas: _getDistance2D(curr.canvas, last.canvas),
        world: _getDistance3D(curr.world, last.world),
    };
}
function getDeltaRotation(currentPoints, lastPoints) {
}
function getDeltaDistanceBetweenIPoints(currentPoints, lastPoints) {
    const currentDistance = _getMeanDistanceBetweenAllIPoints(currentPoints);
    const lastDistance = _getMeanDistanceBetweenAllIPoints(lastPoints);
    const deltaDistance = {
        page: currentDistance.page - lastDistance.page,
        client: currentDistance.client - lastDistance.client,
        canvas: currentDistance.canvas - lastDistance.canvas,
        world: currentDistance.world - lastDistance.world,
    };
    return deltaDistance;
}
function copyPointsList(points) {
    return JSON.parse(JSON.stringify(points));
}
function copyPoints(points) {
    return JSON.parse(JSON.stringify(points));
}
function getMeanPoints(points) {
    return points.reduce((prev, curr) => {
        return {
            page: [
                prev.page[0] + curr.page[0] / points.length,
                prev.page[1] + curr.page[1] / points.length,
            ],
            client: [
                prev.client[0] + curr.client[0] / points.length,
                prev.client[1] + curr.client[1] / points.length,
            ],
            canvas: [
                prev.canvas[0] + curr.canvas[0] / points.length,
                prev.canvas[1] + curr.canvas[1] / points.length,
            ],
            world: [
                prev.world[0] + curr.world[0] / points.length,
                prev.world[1] + curr.world[1] / points.length,
                prev.world[2] + curr.world[2] / points.length,
            ],
        };
    }, {
        page: [0, 0],
        client: [0, 0],
        canvas: [0, 0],
        world: [0, 0, 0],
    });
}
function getMeanTouchPoints(points) {
    return points.reduce((prev, curr) => {
        return {
            page: [
                prev.page[0] + curr.page[0] / points.length,
                prev.page[1] + curr.page[1] / points.length,
            ],
            client: [
                prev.client[0] + curr.client[0] / points.length,
                prev.client[1] + curr.client[1] / points.length,
            ],
            canvas: [
                prev.canvas[0] + curr.canvas[0] / points.length,
                prev.canvas[1] + curr.canvas[1] / points.length,
            ],
            world: [
                prev.world[0] + curr.world[0] / points.length,
                prev.world[1] + curr.world[1] / points.length,
                prev.world[2] + curr.world[2] / points.length,
            ],
            touch: {
                identifier: null,
                radiusX: prev.touch.radiusX + curr.touch.radiusX / points.length,
                radiusY: prev.touch.radiusY + curr.touch.radiusY / points.length,
                force: prev.touch.force + curr.touch.force / points.length,
                rotationAngle: prev.touch.rotationAngle + curr.touch.rotationAngle / points.length,
            },
        };
    }, {
        page: [0, 0],
        client: [0, 0],
        canvas: [0, 0],
        world: [0, 0, 0],
        touch: {
            identifier: null,
            radiusX: 0,
            radiusY: 0,
            force: 0,
            rotationAngle: 0,
        },
    });
}
function _subtractPoints2D(point0, point1) {
    return [point0[0] - point1[0], point0[1] - point1[1]];
}
function _subtractPoints3D(point0, point1) {
    return [point0[0] - point1[0], point0[1] - point1[1], point0[2] - point1[2]];
}
function _getMeanDistanceBetweenAllIPoints(points) {
    const pairedDistance = [];
    for (let i = 0; i < points.length; i++) {
        for (let j = 0; j < points.length; j++) {
            if (i < j) {
                pairedDistance.push({
                    page: _getDistance2D(points[i].page, points[j].page),
                    client: _getDistance2D(points[i].client, points[j].client),
                    canvas: _getDistance2D(points[i].canvas, points[j].canvas),
                    world: _getDistance3D(points[i].world, points[j].world),
                });
            }
        }
    }
    return pairedDistance.reduce((prev, curr) => {
        return {
            page: prev.page + curr.page / pairedDistance.length,
            client: prev.client + curr.client / pairedDistance.length,
            canvas: prev.canvas + curr.canvas / pairedDistance.length,
            world: prev.world + curr.world / pairedDistance.length,
        };
    }, {
        page: 0,
        client: 0,
        canvas: 0,
        world: 0,
    });
}
function _getDistance2D(point0, point1) {
    return Math.sqrt(Math.pow(point0[0] - point1[0], 2) + Math.pow(point0[1] - point1[1], 2));
}
function _getDistance3D(point0, point1) {
    return Math.sqrt(Math.pow(point0[0] - point1[0], 2) +
        Math.pow(point0[1] - point1[1], 2) +
        Math.pow(point0[2] - point1[2], 2));
}



/***/ }),

/***/ 27819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export triggerAnnotationRenderForToolGroupIds */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _triggerAnnotationRender__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6805);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52610);



function triggerAnnotationRenderForToolGroupIds(toolGroupIds) {
    toolGroupIds.forEach((toolGroupId) => {
        const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__.getToolGroup)(toolGroupId);
        if (!toolGroup) {
            console.warn(`ToolGroup not available for ${toolGroupId}`);
            return;
        }
        const viewportsInfo = toolGroup.getViewportsInfo();
        viewportsInfo.forEach((viewportInfo) => {
            const { renderingEngineId, viewportId } = viewportInfo;
            const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getRenderingEngine)(renderingEngineId);
            if (!renderingEngine) {
                console.warn(`RenderingEngine not available for ${renderingEngineId}`);
                return;
            }
            const viewport = renderingEngine.getViewport(viewportId);
            (0,_triggerAnnotationRender__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Ay)(viewport.element);
        });
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (triggerAnnotationRenderForToolGroupIds);


/***/ }),

/***/ 31555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isViewportPreScaled: () => (/* reexport safe */ _isViewportPreScaled__WEBPACK_IMPORTED_MODULE_0__.u),
/* harmony export */   jumpToSlice: () => (/* reexport safe */ _jumpToSlice__WEBPACK_IMPORTED_MODULE_1__.A),
/* harmony export */   jumpToWorld: () => (/* reexport safe */ _jumpToWorld__WEBPACK_IMPORTED_MODULE_2__.A)
/* harmony export */ });
/* harmony import */ var _isViewportPreScaled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97022);
/* harmony import */ var _jumpToSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11666);
/* harmony import */ var _jumpToWorld__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88240);






/***/ }),

/***/ 97022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ isViewportPreScaled)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function isViewportPreScaled(viewport, targetId) {
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
        const targetIdTokens = targetId.split('volumeId:');
        const volumeId = targetIdTokens.length > 1
            ? targetIdTokens[1].split('?')[0]
            : targetIdTokens[0];
        const volume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        return !!volume?.scaling && Object.keys(volume.scaling).length > 0;
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        const { preScale } = viewport.getImageData() || {};
        return !!preScale?.scaled;
    }
    else {
        return false;
    }
}



/***/ }),

/***/ 11666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _clip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(88484);
/* harmony import */ var _scroll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(21783);



async function jumpToSlice(element, options = {}) {
    const { imageIndex, debounceLoading, volumeId } = options;
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
    if (!enabledElement) {
        throw new Error('Element has been disabled');
    }
    const { viewport } = enabledElement;
    const { imageIndex: currentImageIndex, numberOfSlices } = _getImageSliceData(viewport, debounceLoading);
    const imageIndexToJump = _getImageIndexToJump(numberOfSlices, imageIndex);
    const delta = imageIndexToJump - currentImageIndex;
    (0,_scroll__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A)(viewport, { delta, debounceLoading, volumeId });
}
function _getImageSliceData(viewport, debounceLoading) {
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        return {
            numberOfSlices: viewport.getImageIds().length,
            imageIndex: debounceLoading
                ? viewport.getTargetImageIdIndex()
                : viewport.getCurrentImageIdIndex(),
        };
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
        return _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getImageSliceDataForVolumeViewport(viewport);
    }
    else {
        throw new Error('Unsupported viewport type');
    }
}
function _getImageIndexToJump(numberOfSlices, imageIndex) {
    const lastSliceIndex = numberOfSlices - 1;
    return (0,_clip__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Ay)(imageIndex, 0, lastSliceIndex);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (jumpToSlice);


/***/ }),

/***/ 88240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ jumpToWorld)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);


function jumpToWorld(viewport, jumpWorld) {
    if (!(viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport)) {
        return;
    }
    const { focalPoint } = viewport.getCamera();
    const delta = [0, 0, 0];
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.sub */ .eR.sub(delta, jumpWorld, focalPoint);
    _applyShift(viewport, delta);
    return true;
}
function _applyShift(viewport, delta) {
    const camera = viewport.getCamera();
    const normal = camera.viewPlaneNormal;
    const dotProd = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(delta, normal);
    const projectedDelta = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(normal[0], normal[1], normal[2]);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scale */ .eR.scale(projectedDelta, projectedDelta, dotProd);
    if (Math.abs(projectedDelta[0]) > 1e-3 ||
        Math.abs(projectedDelta[1]) > 1e-3 ||
        Math.abs(projectedDelta[2]) > 1e-3) {
        const newFocalPoint = [0, 0, 0];
        const newPosition = [0, 0, 0];
        gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.add */ .eR.add(newFocalPoint, camera.focalPoint, projectedDelta);
        gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.add */ .eR.add(newPosition, camera.position, projectedDelta);
        viewport.setCamera({
            focalPoint: newFocalPoint,
            position: newPosition,
        });
        viewport.render();
    }
}


/***/ }),

/***/ 90252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  filterViewportsWithFrameOfReferenceUID: () => (/* reexport */ filterViewportsWithFrameOfReferenceUID),
  filterViewportsWithParallelNormals: () => (/* reexport */ viewportFilters_filterViewportsWithParallelNormals),
  filterViewportsWithToolEnabled: () => (/* reexport */ filterViewportsWithToolEnabled),
  getViewportIdsWithToolToRender: () => (/* reexport */ getViewportIdsWithToolToRender)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithFrameOfReferenceUID.js
function filterViewportsWithFrameOfReferenceUID(viewports, FrameOfReferenceUID) {
    const numViewports = viewports.length;
    const viewportsWithFrameOfReferenceUID = [];
    for (let vp = 0; vp < numViewports; vp++) {
        const viewport = viewports[vp];
        if (viewport.getFrameOfReferenceUID() === FrameOfReferenceUID) {
            viewportsWithFrameOfReferenceUID.push(viewport);
        }
    }
    return viewportsWithFrameOfReferenceUID;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/index.js + 3 modules
var enums = __webpack_require__(84901);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithToolEnabled.js


const { Active, Passive, Enabled } = enums.ToolModes;
function filterViewportsWithToolEnabled(viewports, toolName) {
    const numViewports = viewports.length;
    const viewportsWithToolEnabled = [];
    for (let vp = 0; vp < numViewports; vp++) {
        const viewport = viewports[vp];
        const toolGroup = store/* ToolGroupManager.getToolGroupForViewport */.dU.getToolGroupForViewport(viewport.id, viewport.renderingEngineId);
        if (!toolGroup) {
            continue;
        }
        const hasTool = _toolGroupHasActiveEnabledOrPassiveTool(toolGroup, toolName);
        if (hasTool) {
            viewportsWithToolEnabled.push(viewport);
        }
    }
    return viewportsWithToolEnabled;
}
function _toolGroupHasActiveEnabledOrPassiveTool(toolGroup, toolName) {
    const { toolOptions } = toolGroup;
    const tool = toolOptions[toolName];
    if (!tool) {
        return false;
    }
    const toolMode = tool.mode;
    return toolMode === Active || toolMode === Passive || toolMode === Enabled;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var gl_matrix_esm = __webpack_require__(44753);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithParallelNormals.js

function filterViewportsWithParallelNormals(viewports, camera, EPS = 0.999) {
    return viewports.filter((viewport) => {
        const vpCamera = viewport.getCamera();
        const isParallel = Math.abs(gl_matrix_esm/* vec3.dot */.eR.dot(vpCamera.viewPlaneNormal, camera.viewPlaneNormal)) >
            EPS;
        return isParallel;
    });
}
/* harmony default export */ const viewportFilters_filterViewportsWithParallelNormals = (filterViewportsWithParallelNormals);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/getViewportIdsWithToolToRender.js




function getViewportIdsWithToolToRender(element, toolName, requireParallelNormals = true) {
    const enabledElement = (0,esm.getEnabledElement)(element);
    const { renderingEngine, FrameOfReferenceUID } = enabledElement;
    let viewports = renderingEngine.getViewports();
    viewports = filterViewportsWithFrameOfReferenceUID(viewports, FrameOfReferenceUID);
    viewports = filterViewportsWithToolEnabled(viewports, toolName);
    const viewport = renderingEngine.getViewport(enabledElement.viewportId);
    if (requireParallelNormals) {
        viewports = viewportFilters_filterViewportsWithParallelNormals(viewports, viewport.getCamera());
    }
    const viewportIds = viewports.map((vp) => vp.id);
    return viewportIds;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js







/***/ }),

/***/ 50112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ Colorbar)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24284);
/* harmony import */ var _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50614);
/* harmony import */ var _ColorbarCanvas__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25605);
/* harmony import */ var _ColorbarTicks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4856);
/* harmony import */ var _common_isRangeTextPositionValid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57457);
/* harmony import */ var _widgets_Widget__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38461);








const DEFAULTS = {
    MULTIPLIER: 1,
    RANGE_TEXT_POSITION: _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Right,
    TICKS_BAR_SIZE: 50,
};
class Colorbar extends _widgets_Widget__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A {
    constructor(props) {
        super(props);
        this._isMouseOver = false;
        this._isInteracting = false;
        this._mouseOverCallback = (evt) => {
            this._isMouseOver = true;
            this.showTicks();
            evt.stopPropagation();
        };
        this._mouseOutCallback = (evt) => {
            this._isMouseOver = false;
            this.hideTicks();
            evt.stopPropagation();
        };
        this._mouseDownCallback = (evt) => {
            this._isInteracting = true;
            this.showTicks();
            this._addVOIEventListeners(evt);
            evt.stopPropagation();
        };
        this._mouseDragCallback = (evt, initialState) => {
            const multipliers = this.getVOIMultipliers();
            const currentPoints = this._getPointsFromMouseEvent(evt);
            const { points: startPoints, voiRange: startVOIRange } = initialState;
            const canvasDelta = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.sub */ .Zc.sub(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), currentPoints.local, startPoints.local);
            const wwDelta = canvasDelta[0] * multipliers[0];
            const wcDelta = canvasDelta[1] * multipliers[1];
            if (!wwDelta && !wcDelta) {
                return;
            }
            const { lower: voiLower, upper: voiUpper } = startVOIRange;
            let { windowWidth, windowCenter } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.windowLevel.toWindowLevel(voiLower, voiUpper);
            windowWidth = Math.max(windowWidth + wwDelta, 1);
            windowCenter += wcDelta;
            const newVoiRange = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.windowLevel.toLowHighRange(windowWidth, windowCenter);
            this.voiRange = newVoiRange;
            evt.stopPropagation();
            evt.preventDefault();
        };
        this._mouseUpCallback = (evt) => {
            this._isInteracting = false;
            this.hideTicks();
            this._removeVOIEventListeners();
            evt.stopPropagation();
        };
        this._eventListenersManager =
            new _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.eventListener.MultiTargetEventListenerManager();
        this._colormaps = Colorbar.getColormapsMap(props);
        this._activeColormapName = Colorbar.getInitialColormapName(props);
        this._canvas = this._createCanvas(props);
        this._ticksBar = this._createTicksBar(props);
        this._rangeTextPosition =
            props.ticks?.position ?? DEFAULTS.RANGE_TEXT_POSITION;
        this._canvas.appendTo(this.rootElement);
        this._ticksBar.appendTo(this.rootElement);
        this._addRootElementEventListeners();
    }
    get activeColormapName() {
        return this._activeColormapName;
    }
    set activeColormapName(colormapName) {
        if (colormapName === this._activeColormapName) {
            return;
        }
        const colormap = this._colormaps.get(colormapName);
        if (!colormap) {
            console.warn(`Invalid colormap name (${colormapName})`);
            return;
        }
        this._activeColormapName = colormapName;
        this._canvas.colormap = colormap;
    }
    get imageRange() {
        return this._canvas.imageRange;
    }
    set imageRange(imageRange) {
        this._canvas.imageRange = imageRange;
        this._ticksBar.imageRange = imageRange;
    }
    get voiRange() {
        return this._canvas.voiRange;
    }
    set voiRange(voiRange) {
        const { voiRange: currentVoiRange } = this._canvas;
        if (!(0,_common__WEBPACK_IMPORTED_MODULE_2__/* .isRangeValid */ .kB)(voiRange) ||
            (0,_common__WEBPACK_IMPORTED_MODULE_2__/* .areColorbarRangesEqual */ .bh)(voiRange, currentVoiRange)) {
            return;
        }
        this._canvas.voiRange = voiRange;
        this._ticksBar.voiRange = voiRange;
        this.onVoiChange(voiRange);
    }
    get showFullImageRange() {
        return this._canvas.showFullImageRange;
    }
    set showFullImageRange(value) {
        this._canvas.showFullImageRange = value;
        this._ticksBar.showFullPixelValueRange = value;
    }
    destroy() {
        super.destroy();
        this._eventListenersManager.reset();
    }
    createRootElement() {
        const rootElement = document.createElement('div');
        Object.assign(rootElement.style, {
            position: 'relative',
            fontSize: '0',
            width: '100%',
            height: '100%',
        });
        return rootElement;
    }
    onContainerResize() {
        super.onContainerResize();
        this.updateTicksBar();
        this._canvas.size = this.containerSize;
    }
    getVOIMultipliers() {
        return [DEFAULTS.MULTIPLIER, DEFAULTS.MULTIPLIER];
    }
    onVoiChange(voiRange) {
    }
    showTicks() {
        this.updateTicksBar();
        this._ticksBar.visible = true;
    }
    hideTicks() {
        if (this._isInteracting || this._isMouseOver) {
            return;
        }
        this._ticksBar.visible = false;
    }
    static getColormapsMap(props) {
        const { colormaps } = props;
        return colormaps.reduce((items, item) => items.set(item.Name, item), new Map());
    }
    static getInitialColormapName(props) {
        const { activeColormapName, colormaps } = props;
        const colormapExists = !!activeColormapName &&
            colormaps.some((cm) => cm.Name === activeColormapName);
        return colormapExists ? activeColormapName : colormaps[0].Name;
    }
    _createCanvas(props) {
        const { imageRange, voiRange, showFullPixelValueRange } = props;
        const colormap = this._colormaps.get(this._activeColormapName);
        return new _ColorbarCanvas__WEBPACK_IMPORTED_MODULE_4__/* .ColorbarCanvas */ .n({
            colormap,
            imageRange,
            voiRange: voiRange,
            showFullPixelValueRange,
        });
    }
    _createTicksBar(props) {
        const ticksProps = props.ticks;
        return new _ColorbarTicks__WEBPACK_IMPORTED_MODULE_5__/* .ColorbarTicks */ .f({
            imageRange: props.imageRange,
            voiRange: props.voiRange,
            ticks: ticksProps,
            showFullPixelValueRange: props.showFullPixelValueRange,
        });
    }
    _getPointsFromMouseEvent(evt) {
        const { rootElement: element } = this;
        const clientPoint = [evt.clientX, evt.clientY];
        const pagePoint = [evt.pageX, evt.pageY];
        const rect = element.getBoundingClientRect();
        const localPoints = [
            pagePoint[0] - rect.left - window.pageXOffset,
            pagePoint[1] - rect.top - window.pageYOffset,
        ];
        return { client: clientPoint, page: pagePoint, local: localPoints };
    }
    updateTicksBar() {
        const { width: containerWidth, height: containerHeight } = this.containerSize;
        if (containerWidth === 0 && containerHeight === 0) {
            return;
        }
        const { _ticksBar: ticksBar, _rangeTextPosition: rangeTextPosition } = this;
        const isHorizontal = containerWidth >= containerHeight;
        const width = isHorizontal ? containerWidth : DEFAULTS.TICKS_BAR_SIZE;
        const height = isHorizontal ? DEFAULTS.TICKS_BAR_SIZE : containerHeight;
        if (!(0,_common_isRangeTextPositionValid__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(containerWidth, containerHeight, rangeTextPosition)) {
            throw new Error('Invalid rangeTextPosition value for the current colobar orientation');
        }
        let ticksBarTop;
        let ticksBarLeft;
        ticksBar.size = { width, height };
        if (isHorizontal) {
            ticksBarLeft = 0;
            ticksBarTop =
                rangeTextPosition === _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Top
                    ? -height
                    : containerHeight;
        }
        else {
            ticksBarTop = 0;
            ticksBarLeft =
                rangeTextPosition === _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Left
                    ? -width
                    : containerWidth;
        }
        ticksBar.top = ticksBarTop;
        ticksBar.left = ticksBarLeft;
    }
    _addRootElementEventListeners() {
        const { _eventListenersManager: manager } = this;
        const { rootElement: element } = this;
        manager.addEventListener(element, 'mouseover', this._mouseOverCallback);
        manager.addEventListener(element, 'mouseout', this._mouseOutCallback);
        manager.addEventListener(element, 'mousedown', this._mouseDownCallback);
    }
    _addVOIEventListeners(evt) {
        const { _eventListenersManager: manager } = this;
        const points = this._getPointsFromMouseEvent(evt);
        const voiRange = { ...this._canvas.voiRange };
        const initialDragState = { points, voiRange };
        this._removeVOIEventListeners();
        manager.addEventListener(document, 'voi.mouseup', this._mouseUpCallback);
        manager.addEventListener(document, 'voi.mousemove', (evt) => this._mouseDragCallback(evt, initialDragState));
    }
    _removeVOIEventListeners() {
        const { _eventListenersManager: manager } = this;
        manager.removeEventListener(document, 'voi.mouseup');
        manager.removeEventListener(document, 'voi.mousemove');
    }
}



/***/ }),

/***/ 81034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ ViewportColorbar)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _Colorbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50112);
/* harmony import */ var _getVOIMultipliers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51954);



const { Events } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.Enums;
const defaultImageRange = { lower: -1000, upper: 1000 };
class ViewportColorbar extends _Colorbar__WEBPACK_IMPORTED_MODULE_1__/* .Colorbar */ .P {
    constructor(props) {
        const { element, volumeId } = props;
        const imageRange = ViewportColorbar._getImageRange(element, volumeId);
        const voiRange = ViewportColorbar._getVOIRange(element, volumeId);
        super({ ...props, imageRange, voiRange });
        this.autoHideTicks = () => {
            if (this._hideTicksTimeoutId) {
                return;
            }
            const timeLeft = this._hideTicksTime - Date.now();
            if (timeLeft <= 0) {
                this.hideTicks();
            }
            else {
                this._hideTicksTimeoutId = window.setTimeout(() => {
                    this._hideTicksTimeoutId = 0;
                    this.autoHideTicks();
                }, timeLeft);
            }
        };
        this._stackNewImageCallback = () => {
            this.imageRange = ViewportColorbar._getImageRange(this._element);
        };
        this._imageVolumeModifiedCallback = (evt) => {
            const { volumeId } = evt.detail.imageVolume;
            if (volumeId !== this._volumeId) {
                return;
            }
            const { _element: element } = this;
            this.imageRange = ViewportColorbar._getImageRange(element, volumeId);
        };
        this._viewportVOIModifiedCallback = (evt) => {
            const { viewportId, volumeId, range: voiRange, colormap } = evt.detail;
            const { viewport } = this.enabledElement;
            if (viewportId !== viewport.id || volumeId !== this._volumeId) {
                return;
            }
            this.voiRange = voiRange;
            if (colormap) {
                this.activeColormapName = colormap.name;
            }
            this.showAndAutoHideTicks();
        };
        this._viewportColormapModifiedCallback = (evt) => {
            const { viewportId, colormap, volumeId } = evt.detail;
            const { viewport } = this.enabledElement;
            if (viewportId !== viewport.id || volumeId !== this._volumeId) {
                return;
            }
            this.activeColormapName = colormap.name;
        };
        this._element = element;
        this._volumeId = volumeId;
        this._addCornerstoneEventListener();
    }
    get element() {
        return this._element;
    }
    get enabledElement() {
        return (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(this._element);
    }
    getVOIMultipliers() {
        const { viewport } = this.enabledElement;
        return (0,_getVOIMultipliers__WEBPACK_IMPORTED_MODULE_2__/* .getVOIMultipliers */ .j)(viewport, this._volumeId);
    }
    onVoiChange(voiRange) {
        super.onVoiChange(voiRange);
        const { viewport } = this.enabledElement;
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
            viewport.setProperties({
                voiRange: voiRange,
            });
            viewport.render();
        }
        else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
            const { _volumeId: volumeId } = this;
            const viewportsContainingVolumeUID = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getViewportsWithVolumeId(volumeId, viewport.renderingEngineId);
            viewport.setProperties({ voiRange }, volumeId);
            viewportsContainingVolumeUID.forEach((vp) => vp.render());
        }
    }
    static _getImageRange(element, volumeId) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const actor = volumeId
            ? viewport.getActor(volumeId)
            : viewport.getDefaultActor();
        if (!actor) {
            return defaultImageRange;
        }
        const imageData = actor.actor.getMapper().getInputData();
        const imageRange = imageData.getPointData().getScalars().getRange();
        return imageRange[0] === 0 && imageRange[1] === 0
            ? defaultImageRange
            : { lower: imageRange[0], upper: imageRange[1] };
    }
    static _getVOIRange(element, volumeId) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const volumeActor = volumeId
            ? viewport.getActor(volumeId)
            : viewport.getDefaultActor();
        if (!volumeActor || !_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isImageActor(volumeActor)) {
            return defaultImageRange;
        }
        const voiRange = volumeActor.actor
            .getProperty()
            .getRGBTransferFunction(0)
            .getRange();
        return voiRange[0] === 0 && voiRange[1] === 0
            ? defaultImageRange
            : { lower: voiRange[0], upper: voiRange[1] };
    }
    showAndAutoHideTicks(interval = 1000) {
        this._hideTicksTime = Date.now() + interval;
        this.showTicks();
        this.autoHideTicks();
    }
    _addCornerstoneEventListener() {
        const { _element: element } = this;
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget.addEventListener(Events.IMAGE_VOLUME_MODIFIED, this._imageVolumeModifiedCallback);
        element.addEventListener(Events.STACK_NEW_IMAGE, this._stackNewImageCallback);
        element.addEventListener(Events.VOI_MODIFIED, this._viewportVOIModifiedCallback);
        element.addEventListener(Events.COLORMAP_MODIFIED, this._viewportColormapModifiedCallback);
    }
}



/***/ }),

/***/ 50614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: () => (/* binding */ ColorbarRangeTextPosition)
/* harmony export */ });
var ColorbarRangeTextPosition;
(function (ColorbarRangeTextPosition) {
    ColorbarRangeTextPosition["Top"] = "top";
    ColorbarRangeTextPosition["Left"] = "left";
    ColorbarRangeTextPosition["Bottom"] = "bottom";
    ColorbarRangeTextPosition["Right"] = "right";
})(ColorbarRangeTextPosition || (ColorbarRangeTextPosition = {}));


/***/ }),

/***/ 73231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ColorbarRangeTextPosition: () => (/* reexport safe */ _ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_0__.U)
/* harmony export */ });
/* harmony import */ var _ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50614);



/***/ }),

/***/ 14149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  colorbar: () => (/* reexport */ colorbar),
  windowLevel: () => (/* reexport */ windowlevel_namespaceObject)
});

// NAMESPACE OBJECT: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/index.js
var windowlevel_namespaceObject = {};
__webpack_require__.r(windowlevel_namespaceObject);
__webpack_require__.d(windowlevel_namespaceObject, {
  calculateMinMaxMean: () => (calculateMinMaxMean),
  extractWindowLevelRegionToolData: () => (extractWindowLevelRegionToolData),
  getLuminanceFromRegion: () => (getLuminanceFromRegion)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/colorbar/index.js
var colorbar = __webpack_require__(64690);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/getLuminanceFromRegion.js
function getLuminanceFromRegion(imageData, x, y, width, height) {
    const luminance = [];
    let index = 0;
    const pixelData = imageData.scalarData;
    let spIndex, row, column;
    if (imageData.color) {
        for (row = 0; row < height; row++) {
            for (column = 0; column < width; column++) {
                spIndex = ((row + y) * imageData.columns + (column + x)) * 4;
                const red = pixelData[spIndex];
                const green = pixelData[spIndex + 1];
                const blue = pixelData[spIndex + 2];
                luminance[index++] = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
            }
        }
    }
    else {
        for (row = 0; row < height; row++) {
            for (column = 0; column < width; column++) {
                spIndex = (row + y) * imageData.columns + (column + x);
                luminance[index++] = pixelData[spIndex];
            }
        }
    }
    return luminance;
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/calculateMinMaxMean.js
function calculateMinMaxMean(pixelLuminance, globalMin, globalMax) {
    const numPixels = pixelLuminance.length;
    let min = globalMax;
    let max = globalMin;
    let sum = 0;
    if (numPixels < 2) {
        return {
            min,
            max,
            mean: (globalMin + globalMax) / 2,
        };
    }
    for (let index = 0; index < numPixels; index++) {
        const spv = pixelLuminance[index];
        min = Math.min(min, spv);
        max = Math.max(max, spv);
        sum += spv;
    }
    return {
        min,
        max,
        mean: sum / numPixels,
    };
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/extractWindowLevelRegionToolData.js

function extractWindowLevelRegionToolData(viewport) {
    if (viewport instanceof esm.VolumeViewport) {
        return extractImageDataVolume(viewport);
    }
    if (viewport instanceof esm.StackViewport) {
        return extractImageDataStack(viewport);
    }
    throw new Error('Viewport not supported');
}
function extractImageDataVolume(viewport) {
    const { scalarData, width, height } = esm.utilities.getCurrentVolumeViewportSlice(viewport);
    const { min: minPixelValue, max: maxPixelValue } = esm.utilities.getMinMax(scalarData);
    const volumeId = viewport.getVolumeId();
    const volume = esm.cache.getVolume(volumeId);
    const { metadata, cornerstoneImageMetaData } = volume;
    const { Rows: rows, Columns: columns } = metadata;
    const { color } = cornerstoneImageMetaData;
    return {
        scalarData,
        width,
        height,
        minPixelValue,
        maxPixelValue,
        rows,
        columns,
        color,
    };
}
function extractImageDataStack(viewport) {
    const imageData = viewport.getImageData();
    const { scalarData } = imageData;
    const { min: minPixelValue, max: maxPixelValue } = esm.utilities.getMinMax(scalarData);
    const width = imageData.dimensions[0];
    const height = imageData.dimensions[1];
    const { rows, columns, color } = viewport.getCornerstoneImage();
    return {
        scalarData,
        width,
        height,
        minPixelValue,
        maxPixelValue,
        rows,
        columns,
        color,
    };
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/index.js





;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/index.js





/***/ }),

/***/ 52754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (/* binding */ vtkImageMarchingSquares$1)
/* harmony export */ });
/* unused harmony exports extend, newInstance */
/* harmony import */ var _macros2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50906);
/* harmony import */ var _Common_DataModel_PolyData_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27398);
/* harmony import */ var _Common_DataModel_EdgeLocator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23410);
/* harmony import */ var _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68749);





const {
  vtkErrorMacro,
  vtkDebugMacro
} = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m;

// ----------------------------------------------------------------------------
// vtkImageMarchingSquares methods
// ----------------------------------------------------------------------------

function vtkImageMarchingSquares(publicAPI, model) {
  /**
   * Get the X,Y kernels based on the set slicing mode.
   * @returns {[number, number]}
   */
  function getKernels() {
    let kernelX = 0; // default K slicing mode
    let kernelY = 1;
    if (model.slicingMode === 1) {
      kernelX = 0;
      kernelY = 2;
    } else if (model.slicingMode === 0) {
      kernelX = 1;
      kernelY = 2;
    }
    return [kernelX, kernelY];
  }

  // Set our className
  model.classHierarchy.push('vtkImageMarchingSquares');

  /**
   * Get the list of contour values.
   * @returns {number[]}
   */
  publicAPI.getContourValues = () => model.contourValues;

  /**
   * Set the list contour values.
   * @param {number[]} cValues
   */
  publicAPI.setContourValues = cValues => {
    model.contourValues = cValues;
    publicAPI.modified();
  };
  const ids = [];
  const pixelScalars = [];
  const pixelPts = [];
  const edgeLocator = _Common_DataModel_EdgeLocator_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.newInstance();

  /**
   * Retrieve scalars and pixel coordinates.
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} dims dimensions of the image
   * @param {TypedArray} scalars list of scalar values
   * @param {Vector3} increments IJK slice increments
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.getPixelScalars = (ijk, dims, scalars, increments, kernelX, kernelY) => {
    const [i, j, k] = ijk;

    // First get the indices for the pixel
    ids[0] = k * dims[1] * dims[0] + j * dims[0] + i; // i, j, k
    ids[1] = ids[0] + increments[kernelX]; // i+1, j, k
    ids[2] = ids[0] + increments[kernelY]; // i, j+1, k
    ids[3] = ids[2] + increments[kernelX]; // i+1, j+1, k

    // Now retrieve the scalars
    for (let ii = 0; ii < 4; ++ii) {
      pixelScalars[ii] = scalars[ids[ii]];
    }
  };

  /**
   * Retrieve pixel coordinates.
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} origin origin of the image
   * @param {Vector3} spacing spacing of the image
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.getPixelPoints = (ijk, origin, spacing, kernelX, kernelY) => {
    const i = ijk[kernelX];
    const j = ijk[kernelY];

    // (i,i+1),(j,j+1),(k,k+1) - i varies fastest; then j; then k
    pixelPts[0] = origin[kernelX] + i * spacing[kernelX]; // 0
    pixelPts[1] = origin[kernelY] + j * spacing[kernelY];
    pixelPts[2] = pixelPts[0] + spacing[kernelX]; // 1
    pixelPts[3] = pixelPts[1];
    pixelPts[4] = pixelPts[0]; // 2
    pixelPts[5] = pixelPts[1] + spacing[kernelY];
    pixelPts[6] = pixelPts[2]; // 3
    pixelPts[7] = pixelPts[5];
  };

  /**
   * Produce points and lines for the polydata.
   * @param {number[]} cVal list of contour values
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} dims dimensions of the image
   * @param {Vector3} origin origin of the image
   * @param {Vector3} spacing sapcing of the image
   * @param {TypedArray} scalars list of scalar values
   * @param {number[]} points list of points
   * @param {number[]} lines list of lines
   * @param {Vector3} increments IJK slice increments
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.produceLines = (cVal, ijk, dims, origin, spacing, scalars, points, lines, increments, kernelX, kernelY) => {
    const k = ijk[model.slicingMode];
    const CASE_MASK = [1, 2, 8, 4]; // case table is actually for quad
    const xyz = [];
    let pId;
    publicAPI.getPixelScalars(ijk, dims, scalars, increments, kernelX, kernelY);
    let index = 0;
    for (let idx = 0; idx < 4; idx++) {
      if (pixelScalars[idx] >= cVal) {
        index |= CASE_MASK[idx]; // eslint-disable-line no-bitwise
      }
    }

    const pixelLines = _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.getCase(index);
    if (pixelLines[0] < 0) {
      return; // don't get the pixel coordinates, nothing to do
    }

    publicAPI.getPixelPoints(ijk, origin, spacing, kernelX, kernelY);
    const z = origin[model.slicingMode] + k * spacing[model.slicingMode];
    for (let idx = 0; pixelLines[idx] >= 0; idx += 2) {
      lines.push(2);
      for (let eid = 0; eid < 2; eid++) {
        const edgeVerts = _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.getEdge(pixelLines[idx + eid]);
        pId = undefined;
        if (model.mergePoints) {
          pId = edgeLocator.isInsertedEdge(ids[edgeVerts[0]], ids[edgeVerts[1]])?.value;
        }
        if (pId === undefined) {
          const t = (cVal - pixelScalars[edgeVerts[0]]) / (pixelScalars[edgeVerts[1]] - pixelScalars[edgeVerts[0]]);
          const x0 = pixelPts.slice(edgeVerts[0] * 2, (edgeVerts[0] + 1) * 2);
          const x1 = pixelPts.slice(edgeVerts[1] * 2, (edgeVerts[1] + 1) * 2);
          xyz[kernelX] = x0[0] + t * (x1[0] - x0[0]);
          xyz[kernelY] = x0[1] + t * (x1[1] - x0[1]);
          xyz[model.slicingMode] = z;
          pId = points.length / 3;
          points.push(xyz[0], xyz[1], xyz[2]);
          if (model.mergePoints) {
            edgeLocator.insertEdge(ids[edgeVerts[0]], ids[edgeVerts[1]], pId);
          }
        }
        lines.push(pId);
      }
    }
  };
  publicAPI.requestData = (inData, outData) => {
    // implement requestData
    const input = inData[0];
    if (!input) {
      vtkErrorMacro('Invalid or missing input');
      return;
    }
    if (model.slicingMode == null || model.slicingMode < 0 || model.slicingMode > 2) {
      vtkErrorMacro('Invalid or missing slicing mode');
      return;
    }
    console.time('msquares');

    // Retrieve output and volume data
    const origin = input.getOrigin();
    const spacing = input.getSpacing();
    const dims = input.getDimensions();
    const extent = input.getExtent();
    const increments = input.computeIncrements(extent);
    const scalars = input.getPointData().getScalars().getData();
    const [kernelX, kernelY] = getKernels();

    // Points - dynamic array
    const points = [];

    // Cells - dynamic array
    const lines = [];

    // Ensure slice is valid
    let k = Math.round(model.slice);
    if (k >= dims[model.slicingMode]) {
      k = 0;
    }

    // Loop over all contour values, and then pixels, determine case and process
    const ijk = [0, 0, 0];
    ijk[model.slicingMode] = k;
    for (let cv = 0; cv < model.contourValues.length; ++cv) {
      for (let j = 0; j < dims[kernelY] - 1; ++j) {
        ijk[kernelY] = j;
        for (let i = 0; i < dims[kernelX] - 1; ++i) {
          ijk[kernelX] = i;
          publicAPI.produceLines(model.contourValues[cv], ijk, dims, origin, spacing, scalars, points, lines, increments, kernelX, kernelY);
        }
      }
      edgeLocator.initialize();
    }

    // Update output
    const polydata = _Common_DataModel_PolyData_js__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    polydata.getPoints().setData(new Float32Array(points), 3);
    polydata.getLines().setData(new Uint32Array(lines));
    outData[0] = polydata;
    vtkDebugMacro('Produced output');
    console.timeEnd('msquares');
  };
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {
  contourValues: [],
  slicingMode: 2,
  slice: 0,
  mergePoints: false
};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);

  // Make this a VTK object
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.obj(publicAPI, model);

  // Also make it an algorithm with one input and one output
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.algo(publicAPI, model, 1, 1);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGet(publicAPI, model, ['slicingMode', 'slice', 'mergePoints']);

  // Object specific methods
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.algo(publicAPI, model, 1, 1);
  vtkImageMarchingSquares(publicAPI, model);
}

// ----------------------------------------------------------------------------

const newInstance = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.newInstance(extend, 'vtkImageMarchingSquares');

// ----------------------------------------------------------------------------

var vtkImageMarchingSquares$1 = {
  newInstance,
  extend
};




/***/ })

}]);