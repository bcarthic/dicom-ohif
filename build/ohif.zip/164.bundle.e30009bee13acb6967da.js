"use strict";
(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([[164,914],{

/***/ 25271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
async function addImageSlicesToViewports(renderingEngine, stackInputs, viewportIds) {
    for (const viewportId of viewportIds) {
        const viewport = renderingEngine.getViewport(viewportId);
        if (!viewport) {
            throw new Error(`Viewport with Id ${viewportId} does not exist`);
        }
        if (!viewport.addImages) {
            console.warn(`Viewport with Id ${viewportId} does not have addImages. Cannot add image segmentation to this viewport.`);
            return;
        }
    }
    const addStackPromises = viewportIds.map(async (viewportId) => {
        const viewport = renderingEngine.getViewport(viewportId);
        return viewport.addImages(stackInputs);
    });
    await Promise.all(addStackPromises);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addImageSlicesToViewports);


/***/ }),

/***/ 74260:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _BaseVolumeViewport__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6203);

async function addVolumesToViewports(renderingEngine, volumeInputs, viewportIds, immediateRender = false, suppressEvents = false) {
    for (const viewportId of viewportIds) {
        const viewport = renderingEngine.getViewport(viewportId);
        if (!viewport) {
            throw new Error(`Viewport with Id ${viewportId} does not exist`);
        }
        if (!(viewport instanceof _BaseVolumeViewport__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)) {
            console.warn(`Viewport with Id ${viewportId} is not a BaseVolumeViewport. Cannot add volume to this viewport.`);
            return;
        }
    }
    const addVolumePromises = viewportIds.map(async (viewportId) => {
        const viewport = renderingEngine.getViewport(viewportId);
        await viewport.addVolumes(volumeInputs, immediateRender, suppressEvents);
    });
    await Promise.all(addVolumePromises);
    return;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (addVolumesToViewports);


/***/ }),

/***/ 78988:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ Settings)
/* harmony export */ });
const DEFAULT_SETTINGS = Symbol('DefaultSettings');
const RUNTIME_SETTINGS = Symbol('RuntimeSettings');
const OBJECT_SETTINGS_MAP = Symbol('ObjectSettingsMap');
const DICTIONARY = Symbol('Dictionary');
class Settings {
    constructor(base) {
        const dictionary = Object.create((base instanceof Settings && DICTIONARY in base
            ? base[DICTIONARY]
            : null));
        Object.seal(Object.defineProperty(this, DICTIONARY, {
            value: dictionary,
        }));
    }
    set(key, value) {
        return set(this[DICTIONARY], key, value, null);
    }
    get(key) {
        return get(this[DICTIONARY], key);
    }
    unset(key) {
        return unset(this[DICTIONARY], key + '');
    }
    forEach(callback) {
        iterate(this[DICTIONARY], callback);
    }
    extend() {
        return new Settings(this);
    }
    import(root) {
        if (isPlainObject(root)) {
            Object.keys(root).forEach((key) => {
                set(this[DICTIONARY], key, root[key], null);
            });
        }
    }
    dump() {
        const context = {};
        iterate(this[DICTIONARY], (key, value) => {
            if (typeof value !== 'undefined') {
                deepSet(context, key, value);
            }
        });
        return context;
    }
    static assert(subject) {
        return subject instanceof Settings
            ? subject
            : Settings.getRuntimeSettings();
    }
    static getDefaultSettings(subfield = null) {
        let defaultSettings = Settings[DEFAULT_SETTINGS];
        if (!(defaultSettings instanceof Settings)) {
            defaultSettings = new Settings();
            Settings[DEFAULT_SETTINGS] = defaultSettings;
        }
        if (subfield) {
            const settingObj = {};
            defaultSettings.forEach((name) => {
                if (name.startsWith(subfield)) {
                    const setting = name.split(`${subfield}.`)[1];
                    settingObj[setting] = defaultSettings.get(name);
                }
            });
            return settingObj;
        }
        return defaultSettings;
    }
    static getRuntimeSettings() {
        let runtimeSettings = Settings[RUNTIME_SETTINGS];
        if (!(runtimeSettings instanceof Settings)) {
            runtimeSettings = new Settings(Settings.getDefaultSettings());
            Settings[RUNTIME_SETTINGS] = runtimeSettings;
        }
        return runtimeSettings;
    }
    static getObjectSettings(subject, from) {
        let settings = null;
        if (subject instanceof Settings) {
            settings = subject;
        }
        else if (typeof subject === 'object' && subject !== null) {
            let objectSettingsMap = Settings[OBJECT_SETTINGS_MAP];
            if (!(objectSettingsMap instanceof WeakMap)) {
                objectSettingsMap = new WeakMap();
                Settings[OBJECT_SETTINGS_MAP] = objectSettingsMap;
            }
            settings = objectSettingsMap.get(subject);
            if (!(settings instanceof Settings)) {
                settings = new Settings(Settings.assert(Settings.getObjectSettings(from)));
                objectSettingsMap.set(subject, settings);
            }
        }
        return settings;
    }
    static extendRuntimeSettings() {
        return Settings.getRuntimeSettings().extend();
    }
}
function unset(dictionary, name) {
    if (name.endsWith('.')) {
        let deleteCount = 0;
        const namespace = name;
        const base = namespace.slice(0, -1);
        const deleteAll = base.length === 0;
        for (const key in dictionary) {
            if (Object.prototype.hasOwnProperty.call(dictionary, key) &&
                (deleteAll || key.startsWith(namespace) || key === base)) {
                delete dictionary[key];
                ++deleteCount;
            }
        }
        return deleteCount > 0;
    }
    return delete dictionary[name];
}
function iterate(dictionary, callback) {
    for (const key in dictionary) {
        callback(key, dictionary[key]);
    }
}
function setAll(dictionary, prefix, record, references) {
    let failCount;
    if (references.has(record)) {
        return set(dictionary, prefix, null, references);
    }
    references.add(record);
    failCount = 0;
    for (const field in record) {
        if (Object.prototype.hasOwnProperty.call(record, field)) {
            const key = field.length === 0 ? prefix : `${prefix}.${field}`;
            if (!set(dictionary, key, record[field], references)) {
                ++failCount;
            }
        }
    }
    references.delete(record);
    return failCount === 0;
}
function set(dictionary, key, value, references) {
    if (isValidKey(key)) {
        if (isPlainObject(value)) {
            return setAll(dictionary, key, value, references instanceof WeakSet ? references : new WeakSet());
        }
        dictionary[key] = value;
        return true;
    }
    return false;
}
function get(dictionary, key) {
    return dictionary[key];
}
function isValidKey(key) {
    let last, current, previous;
    if (typeof key !== 'string' || (last = key.length - 1) < 0) {
        return false;
    }
    previous = -1;
    while ((current = key.indexOf('.', previous + 1)) >= 0) {
        if (current - previous < 2 || current === last) {
            return false;
        }
        previous = current;
    }
    return true;
}
function isPlainObject(subject) {
    if (typeof subject === 'object' && subject !== null) {
        const prototype = Object.getPrototypeOf(subject);
        if (prototype === Object.prototype || prototype === null) {
            return true;
        }
    }
    return false;
}
function deepSet(context, key, value) {
    const separator = key.indexOf('.');
    if (separator >= 0) {
        const subKey = key.slice(0, separator);
        let subContext = context[subKey];
        if (typeof subContext !== 'object' || subContext === null) {
            const subContextValue = subContext;
            subContext = {};
            if (typeof subContextValue !== 'undefined') {
                subContext[''] = subContextValue;
            }
            context[subKey] = subContext;
        }
        deepSet(subContext, key.slice(separator + 1, key.length), value);
    }
    else {
        context[key] = value;
    }
}
Settings.getDefaultSettings().set('useCursors', true);


/***/ }),

/***/ 88903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  EPSILON: () => (/* reexport */ epsilon),
  MPR_CAMERA_VALUES: () => (/* reexport */ mprCameraValues/* default */.A),
  RENDERING_DEFAULTS: () => (/* reexport */ rendering),
  VIEWPORT_PRESETS: () => (/* reexport */ viewportPresets/* default */.A)
});

// UNUSED EXPORTS: BACKGROUND_COLORS, CPU_COLORMAPS

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/cpuColormaps.js
var cpuColormaps = __webpack_require__(21301);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/rendering.js
const RENDERING_DEFAULTS = {
    MINIMUM_SLAB_THICKNESS: 5e-2,
    MAXIMUM_RAY_DISTANCE: 1e6,
};
Object.freeze(RENDERING_DEFAULTS);
/* harmony default export */ const rendering = (RENDERING_DEFAULTS);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/epsilon.js
const EPSILON = 1e-3;
/* harmony default export */ const epsilon = (EPSILON);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/mprCameraValues.js + 1 modules
var mprCameraValues = __webpack_require__(99753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/viewportPresets.js
var viewportPresets = __webpack_require__(59845);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/backgroundColors.js
var backgroundColors = __webpack_require__(61507);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/constants/index.js









/***/ }),

/***/ 15453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var RequestType;
(function (RequestType) {
    RequestType["Interaction"] = "interaction";
    RequestType["Thumbnail"] = "thumbnail";
    RequestType["Prefetch"] = "prefetch";
    RequestType["Compute"] = "compute";
})(RequestType || (RequestType = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RequestType);


/***/ }),

/***/ 17702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ViewportStatus;
(function (ViewportStatus) {
    ViewportStatus["NO_DATA"] = "noData";
    ViewportStatus["LOADING"] = "loading";
    ViewportStatus["PRE_RENDER"] = "preRender";
    ViewportStatus["RESIZE"] = "resize";
    ViewportStatus["RENDERED"] = "rendered";
})(ViewportStatus || (ViewportStatus = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ViewportStatus);


/***/ }),

/***/ 98362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BlendModes: () => (/* reexport */ enums_BlendModes),
  CalibrationTypes: () => (/* reexport */ enums_CalibrationTypes),
  Events: () => (/* reexport */ Events/* default */.A),
  GeometryType: () => (/* reexport */ enums_GeometryType),
  ImageQualityStatus: () => (/* reexport */ ImageQualityStatus/* default */.A),
  InterpolationType: () => (/* reexport */ InterpolationType/* default */.A),
  MetadataModules: () => (/* reexport */ MetadataModules/* default */.A),
  OrientationAxis: () => (/* reexport */ OrientationAxis/* default */.A),
  RequestType: () => (/* reexport */ RequestType/* default */.A),
  SharedArrayBufferModes: () => (/* reexport */ SharedArrayBufferModes/* default */.A),
  VOILUTFunctionType: () => (/* reexport */ VOILUTFunctionType/* default */.A),
  VideoEnums: () => (/* reexport */ VideoEnums),
  ViewportStatus: () => (/* reexport */ ViewportStatus/* default */.A),
  ViewportType: () => (/* reexport */ ViewportType/* default */.A)
});

// UNUSED EXPORTS: ContourType, DynamicOperatorType

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/Events.js
var Events = __webpack_require__(11731);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/RequestType.js
var RequestType = __webpack_require__(15453);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ViewportType.js
var ViewportType = __webpack_require__(21432);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/InterpolationType.js
var InterpolationType = __webpack_require__(67342);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Rendering/Core/VolumeMapper/Constants.js
var Constants = __webpack_require__(16265);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/BlendModes.js

const { BlendMode } = Constants/* default */.Ay;
var BlendModes;
(function (BlendModes) {
    BlendModes[BlendModes["COMPOSITE"] = 0] = "COMPOSITE";
    BlendModes[BlendModes["MAXIMUM_INTENSITY_BLEND"] = 1] = "MAXIMUM_INTENSITY_BLEND";
    BlendModes[BlendModes["MINIMUM_INTENSITY_BLEND"] = 2] = "MINIMUM_INTENSITY_BLEND";
    BlendModes[BlendModes["AVERAGE_INTENSITY_BLEND"] = 3] = "AVERAGE_INTENSITY_BLEND";
})(BlendModes || (BlendModes = {}));
/* harmony default export */ const enums_BlendModes = (BlendModes);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/OrientationAxis.js
var OrientationAxis = __webpack_require__(45919);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/SharedArrayBufferModes.js
var SharedArrayBufferModes = __webpack_require__(38698);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/GeometryType.js
var GeometryType;
(function (GeometryType) {
    GeometryType["CONTOUR"] = "contour";
    GeometryType["SURFACE"] = "Surface";
})(GeometryType || (GeometryType = {}));
/* harmony default export */ const enums_GeometryType = (GeometryType);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ContourType.js
var ContourType = __webpack_require__(99842);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/VOILUTFunctionType.js
var VOILUTFunctionType = __webpack_require__(15381);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/DynamicOperatorType.js
var DynamicOperatorType;
(function (DynamicOperatorType) {
    DynamicOperatorType["SUM"] = "SUM";
    DynamicOperatorType["AVERAGE"] = "AVERAGE";
    DynamicOperatorType["SUBTRACT"] = "SUBTRACT";
})(DynamicOperatorType || (DynamicOperatorType = {}));
/* harmony default export */ const enums_DynamicOperatorType = ((/* unused pure expression or super */ null && (DynamicOperatorType)));

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/CalibrationTypes.js
var CalibrationTypes;
(function (CalibrationTypes) {
    CalibrationTypes["NOT_APPLICABLE"] = "";
    CalibrationTypes["ERMF"] = "ERMF";
    CalibrationTypes["USER"] = "User";
    CalibrationTypes["PROJECTION"] = "Proj";
    CalibrationTypes["REGION"] = "Region";
    CalibrationTypes["ERROR"] = "Error";
    CalibrationTypes["UNCALIBRATED"] = "Uncalibrated";
})(CalibrationTypes || (CalibrationTypes = {}));
/* harmony default export */ const enums_CalibrationTypes = (CalibrationTypes);

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ViewportStatus.js
var ViewportStatus = __webpack_require__(17702);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/ImageQualityStatus.js
var ImageQualityStatus = __webpack_require__(89426);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/VideoEnums.js
var VideoEnums = __webpack_require__(49465);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/MetadataModules.js
var MetadataModules = __webpack_require__(29354);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/enums/index.js



















/***/ }),

/***/ 29870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (/* binding */ getEnabledElement),
/* harmony export */   b1: () => (/* binding */ getEnabledElementByIds),
/* harmony export */   yj: () => (/* binding */ getEnabledElementByViewportId),
/* harmony export */   zb: () => (/* binding */ getEnabledElements)
/* harmony export */ });
/* harmony import */ var _RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49184);

function getEnabledElement(element) {
    if (!element) {
        return;
    }
    const { viewportUid, renderingEngineUid } = element.dataset;
    return getEnabledElementByIds(viewportUid, renderingEngineUid);
}
function getEnabledElementByIds(viewportId, renderingEngineId) {
    if (!renderingEngineId || !viewportId) {
        return;
    }
    const renderingEngine = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Ay)(renderingEngineId);
    if (!renderingEngine || renderingEngine.hasBeenDestroyed) {
        return;
    }
    const viewport = renderingEngine.getViewport(viewportId);
    if (!viewport) {
        return;
    }
    const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
    return {
        viewport,
        renderingEngine,
        viewportId,
        renderingEngineId,
        FrameOfReferenceUID,
    };
}
function getEnabledElementByViewportId(viewportId) {
    const renderingEngines = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* .getRenderingEngines */ .qO)();
    for (let i = 0; i < renderingEngines.length; i++) {
        const renderingEngine = renderingEngines[i];
        const viewport = renderingEngine.getViewport(viewportId);
        if (viewport) {
            return getEnabledElementByIds(viewportId, renderingEngine.id);
        }
    }
}
function getEnabledElements() {
    const enabledElements = [];
    const renderingEngines = (0,_RenderingEngine_getRenderingEngine__WEBPACK_IMPORTED_MODULE_0__/* .getRenderingEngines */ .qO)();
    renderingEngines.forEach((renderingEngine) => {
        const viewports = renderingEngine.getViewports();
        viewports.forEach(({ element }) => {
            enabledElements.push(getEnabledElement(element));
        });
    });
    return enabledElements;
}


/***/ }),

/***/ 79220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cancelLoadAll: () => (/* binding */ cancelLoadAll),
/* harmony export */   cancelLoadImage: () => (/* binding */ cancelLoadImage),
/* harmony export */   cancelLoadImages: () => (/* binding */ cancelLoadImages),
/* harmony export */   createAndCacheDerivedImage: () => (/* binding */ createAndCacheDerivedImage),
/* harmony export */   createAndCacheDerivedImages: () => (/* binding */ createAndCacheDerivedImages),
/* harmony export */   createAndCacheDerivedSegmentationImage: () => (/* binding */ createAndCacheDerivedSegmentationImage),
/* harmony export */   createAndCacheDerivedSegmentationImages: () => (/* binding */ createAndCacheDerivedSegmentationImages),
/* harmony export */   createAndCacheLocalImage: () => (/* binding */ createAndCacheLocalImage),
/* harmony export */   loadAndCacheImage: () => (/* binding */ loadAndCacheImage),
/* harmony export */   loadAndCacheImages: () => (/* binding */ loadAndCacheImages),
/* harmony export */   loadImage: () => (/* binding */ loadImage),
/* harmony export */   registerImageLoader: () => (/* binding */ registerImageLoader),
/* harmony export */   registerUnknownImageLoader: () => (/* binding */ registerUnknownImageLoader),
/* harmony export */   unregisterAllImageLoaders: () => (/* binding */ unregisterAllImageLoaders)
/* harmony export */ });
/* harmony import */ var _cache_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25534);
/* harmony import */ var _cache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13320);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11731);
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51884);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(35678);
/* harmony import */ var _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(775);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92136);







const imageLoaders = {};
let unknownImageLoader;
function loadImageFromImageLoader(imageId, options) {
    const colonIndex = imageId.indexOf(':');
    const scheme = imageId.substring(0, colonIndex);
    const loader = imageLoaders[scheme];
    if (loader === undefined || loader === null) {
        if (unknownImageLoader !== undefined) {
            return unknownImageLoader(imageId);
        }
        throw new Error('loadImageFromImageLoader: no image loader for imageId');
    }
    const imageLoadObject = loader(imageId, options);
    imageLoadObject.promise.then(function (image) {
        (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.triggerEvent)(_eventTarget__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.IMAGE_LOADED, { image });
    }, function (error) {
        const errorObject = {
            imageId,
            error,
        };
        (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.triggerEvent)(_eventTarget__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.IMAGE_LOAD_FAILED, errorObject);
    });
    return imageLoadObject;
}
function loadImageFromCacheOrVolume(imageId, options) {
    if (options.ignoreCache) {
        return loadImageFromImageLoader(imageId, options);
    }
    let imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
    if (imageLoadObject !== undefined) {
        return imageLoadObject;
    }
    const cachedVolumeInfo = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getVolumeContainingImageId(imageId);
    if (cachedVolumeInfo?.volume?.loadStatus?.loaded) {
        const { volume, imageIdIndex } = cachedVolumeInfo;
        if (volume instanceof _cache__WEBPACK_IMPORTED_MODULE_1__/* .ImageVolume */ .QV) {
            imageLoadObject = volume.convertToCornerstoneImage(imageId, imageIdIndex);
        }
        return imageLoadObject;
    }
    const cachedImage = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getCachedImageBasedOnImageURI(imageId);
    if (cachedImage) {
        imageLoadObject = cachedImage.imageLoadObject;
        return imageLoadObject;
    }
    imageLoadObject = loadImageFromImageLoader(imageId, options);
    return imageLoadObject;
}
function loadImage(imageId, options = { priority: 0, requestType: 'prefetch' }) {
    if (imageId === undefined) {
        throw new Error('loadImage: parameter imageId must not be undefined');
    }
    return loadImageFromCacheOrVolume(imageId, options).promise;
}
function loadAndCacheImage(imageId, options = { priority: 0, requestType: 'prefetch' }) {
    if (imageId === undefined) {
        throw new Error('loadAndCacheImage: parameter imageId must not be undefined');
    }
    const imageLoadObject = loadImageFromCacheOrVolume(imageId, options);
    if (!_cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId)) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(imageId, imageLoadObject).catch((err) => {
            console.warn(err);
        });
    }
    return imageLoadObject.promise;
}
function loadAndCacheImages(imageIds, options = { priority: 0, requestType: 'prefetch' }) {
    if (!imageIds || imageIds.length === 0) {
        throw new Error('loadAndCacheImages: parameter imageIds must be list of image Ids');
    }
    const allPromises = imageIds.map((imageId) => {
        return loadAndCacheImage(imageId, options);
    });
    return allPromises;
}
function createAndCacheDerivedImage(referencedImageId, options = {}, preventCache = false) {
    if (referencedImageId === undefined) {
        throw new Error('createAndCacheDerivedImage: parameter imageId must not be undefined');
    }
    if (options.imageId === undefined) {
        options.imageId = `derived:${(0,_utilities__WEBPACK_IMPORTED_MODULE_4__.uuidv4)()}`;
    }
    const { imageId, skipCreateBuffer, onCacheAdd } = options;
    const imagePlaneModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePlaneModule', referencedImageId);
    const length = imagePlaneModule.rows * imagePlaneModule.columns;
    const { TypedArrayConstructor } = (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.getBufferConfiguration)(options.targetBufferType, length);
    const imageScalarData = new TypedArrayConstructor(skipCreateBuffer ? 1 : length);
    const derivedImageId = imageId;
    ['imagePlaneModule', 'generalSeriesModule'].forEach((type) => {
        _utilities__WEBPACK_IMPORTED_MODULE_4__.genericMetadataProvider.add(derivedImageId, {
            type,
            metadata: ___WEBPACK_IMPORTED_MODULE_6__.metaData.get(type, referencedImageId),
        });
    });
    const imagePixelModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePixelModule', referencedImageId);
    _utilities__WEBPACK_IMPORTED_MODULE_4__.genericMetadataProvider.add(derivedImageId, {
        type: 'imagePixelModule',
        metadata: {
            ...imagePixelModule,
            bitsAllocated: 8,
            bitsStored: 8,
            highBit: 7,
            samplesPerPixel: 1,
            pixelRepresentation: 0,
        },
    });
    const localImage = createAndCacheLocalImage({ scalarData: imageScalarData, onCacheAdd, skipCreateBuffer }, imageId, true);
    const imageLoadObject = {
        promise: Promise.resolve(localImage),
    };
    if (!preventCache) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(derivedImageId, imageLoadObject);
    }
    return imageLoadObject.promise;
}
function createAndCacheDerivedImages(referencedImageIds, options = {}) {
    if (referencedImageIds?.length === 0) {
        throw new Error('createAndCacheDerivedImages: parameter imageIds must be list of image Ids');
    }
    const derivedImageIds = [];
    const allPromises = referencedImageIds.map((referencedImageId) => {
        const newOptions = {
            imageId: options.getDerivedImageId?.(referencedImageId) || `derived:${(0,_utilities__WEBPACK_IMPORTED_MODULE_4__.uuidv4)()}`,
            ...options,
        };
        derivedImageIds.push(newOptions.imageId);
        return createAndCacheDerivedImage(referencedImageId, newOptions);
    });
    return { imageIds: derivedImageIds, promises: allPromises };
}
function createAndCacheLocalImage(options, imageId, preventCache = false) {
    const imagePlaneModule = ___WEBPACK_IMPORTED_MODULE_6__.metaData.get('imagePlaneModule', imageId);
    const length = imagePlaneModule.rows * imagePlaneModule.columns;
    const image = {
        imageId: imageId,
        intercept: 0,
        windowCenter: 0,
        windowWidth: 0,
        color: false,
        numComps: 1,
        slope: 1,
        minPixelValue: 0,
        maxPixelValue: 255,
        voiLUTFunction: undefined,
        rows: imagePlaneModule.rows,
        columns: imagePlaneModule.columns,
        getCanvas: undefined,
        height: imagePlaneModule.rows,
        width: imagePlaneModule.columns,
        rgba: undefined,
        columnPixelSpacing: imagePlaneModule.columnPixelSpacing,
        rowPixelSpacing: imagePlaneModule.rowPixelSpacing,
        invert: false,
    };
    if (options.scalarData) {
        const imageScalarData = options.scalarData;
        if (!(imageScalarData instanceof Uint8Array ||
            imageScalarData instanceof Float32Array ||
            imageScalarData instanceof Uint16Array ||
            imageScalarData instanceof Int16Array)) {
            throw new Error('To use createLocalVolume you should pass scalarData of type Uint8Array, Uint16Array, Int16Array or Float32Array');
        }
        image.sizeInBytes = imageScalarData.byteLength;
        image.getPixelData = () => imageScalarData;
    }
    else if (options.skipCreateBuffer !== true) {
        const { numBytes, TypedArrayConstructor } = (0,_utilities__WEBPACK_IMPORTED_MODULE_4__.getBufferConfiguration)(options.targetBufferType, length);
        const imageScalarData = new TypedArrayConstructor(length);
        image.sizeInBytes = numBytes;
        image.getPixelData = () => imageScalarData;
    }
    options.onCacheAdd?.(image);
    const imageLoadObject = {
        promise: Promise.resolve(image),
    };
    if (!preventCache) {
        _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.putImageLoadObject(image.imageId, imageLoadObject);
    }
    return image;
}
function cancelLoadImage(imageId) {
    const filterFunction = ({ additionalDetails }) => {
        if (additionalDetails.imageId) {
            return additionalDetails.imageId !== imageId;
        }
        return true;
    };
    _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.filterRequests(filterFunction);
    const imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
    if (imageLoadObject) {
        imageLoadObject.cancelFn();
    }
}
function cancelLoadImages(imageIds) {
    imageIds.forEach((imageId) => cancelLoadImage(imageId));
}
function cancelLoadAll() {
    const requestPool = _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.getRequestPool();
    Object.keys(requestPool).forEach((type) => {
        const requests = requestPool[type];
        Object.keys(requests).forEach((priority) => {
            const requestDetails = requests[priority].pop();
            const additionalDetails = requestDetails.additionalDetails;
            const { imageId, volumeId } = additionalDetails;
            let loadObject;
            if (imageId) {
                loadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getImageLoadObject(imageId);
            }
            else if (volumeId) {
                loadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
            }
            if (loadObject) {
                loadObject.cancel();
            }
        });
        _requestPool_imageLoadPoolManager__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.clearRequestStack(type);
    });
}
function registerImageLoader(scheme, imageLoader) {
    imageLoaders[scheme] = imageLoader;
}
function registerUnknownImageLoader(imageLoader) {
    const oldImageLoader = unknownImageLoader;
    unknownImageLoader = imageLoader;
    return oldImageLoader;
}
function unregisterAllImageLoaders() {
    Object.keys(imageLoaders).forEach((imageLoader) => delete imageLoaders[imageLoader]);
    unknownImageLoader = undefined;
}
function createAndCacheDerivedSegmentationImages(referencedImageIds, options = {
    targetBufferType: 'Uint8Array',
}) {
    return createAndCacheDerivedImages(referencedImageIds, options);
}
function createAndCacheDerivedSegmentationImage(referencedImageId, options = {
    targetBufferType: 'Uint8Array',
}) {
    return createAndCacheDerivedImage(referencedImageId, options);
}


/***/ }),

/***/ 82041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createAndCacheDerivedSegmentationVolume: () => (/* binding */ createAndCacheDerivedSegmentationVolume),
/* harmony export */   createAndCacheDerivedVolume: () => (/* binding */ createAndCacheDerivedVolume),
/* harmony export */   createAndCacheVolume: () => (/* binding */ createAndCacheVolume),
/* harmony export */   createAndCacheVolumeFromImages: () => (/* binding */ createAndCacheVolumeFromImages),
/* harmony export */   createLocalSegmentationVolume: () => (/* binding */ createLocalSegmentationVolume),
/* harmony export */   createLocalVolume: () => (/* binding */ createLocalVolume),
/* harmony export */   getUnknownVolumeLoaderSchema: () => (/* binding */ getUnknownVolumeLoaderSchema),
/* harmony export */   getVolumeLoaderSchemes: () => (/* binding */ getVolumeLoaderSchemes),
/* harmony export */   loadVolume: () => (/* binding */ loadVolume),
/* harmony export */   registerUnknownVolumeLoader: () => (/* binding */ registerUnknownVolumeLoader),
/* harmony export */   registerVolumeLoader: () => (/* binding */ registerVolumeLoader)
/* harmony export */ });
/* harmony import */ var _kitware_vtk_js_Rendering_Profiles_Volume__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3622);
/* harmony import */ var _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51250);
/* harmony import */ var _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45128);
/* harmony import */ var _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77076);
/* harmony import */ var _cache_cache__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25534);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11731);
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(51884);
/* harmony import */ var _utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(13292);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(48463);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(35678);
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71702);
/* harmony import */ var _utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(51631);












function addScalarDataToImageData(imageData, scalarData, dataArrayAttrs) {
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: `Pixels`,
        values: scalarData,
        ...dataArrayAttrs,
    });
    imageData.getPointData().setScalars(scalarArray);
}
function addScalarDataArraysToImageData(imageData, scalarDataArrays, dataArrayAttrs) {
    scalarDataArrays.forEach((scalarData, i) => {
        const vtkScalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
            name: `timePoint-${i}`,
            values: scalarData,
            ...dataArrayAttrs,
        });
        imageData.getPointData().addArray(vtkScalarArray);
    });
    imageData.getPointData().setActiveScalars('timePoint-0');
}
function createInternalVTKRepresentation(volume) {
    const { dimensions, metadata, spacing, direction, origin } = volume;
    const { PhotometricInterpretation } = metadata;
    let numComponents = 1;
    if (PhotometricInterpretation === 'RGB') {
        numComponents = 3;
    }
    const imageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    const dataArrayAttrs = { numberOfComponents: numComponents };
    imageData.setDimensions(dimensions);
    imageData.setSpacing(spacing);
    imageData.setDirection(direction);
    imageData.setOrigin(origin);
    if (volume.isDynamicVolume()) {
        const scalarDataArrays = (volume).getScalarDataArrays();
        addScalarDataArraysToImageData(imageData, scalarDataArrays, dataArrayAttrs);
    }
    else {
        const scalarData = volume.getScalarData();
        addScalarDataToImageData(imageData, scalarData, dataArrayAttrs);
    }
    return imageData;
}
const volumeLoaders = {};
let unknownVolumeLoader;
function loadVolumeFromVolumeLoader(volumeId, options) {
    const colonIndex = volumeId.indexOf(':');
    const scheme = volumeId.substring(0, colonIndex);
    let loader = volumeLoaders[scheme];
    if (loader === undefined || loader === null) {
        if (unknownVolumeLoader == null ||
            typeof unknownVolumeLoader !== 'function') {
            throw new Error(`No volume loader for scheme ${scheme} has been registered`);
        }
        loader = unknownVolumeLoader;
    }
    const volumeLoadObject = loader(volumeId, options);
    (0,_utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__.setupCacheOptimizationEventListener)(volumeId);
    volumeLoadObject.promise.then(function (volume) {
        (0,_utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A)(_eventTarget__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.VOLUME_LOADED, { volume });
    }, function (error) {
        const errorObject = {
            volumeId,
            error,
        };
        (0,_utilities_triggerEvent__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A)(_eventTarget__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A, _enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.VOLUME_LOADED_FAILED, errorObject);
    });
    return volumeLoadObject;
}
function loadVolume(volumeId, options = { imageIds: [] }) {
    if (volumeId === undefined) {
        throw new Error('loadVolume: parameter volumeId must not be undefined');
    }
    let volumeLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
    if (volumeLoadObject !== undefined) {
        return volumeLoadObject.promise;
    }
    volumeLoadObject = loadVolumeFromVolumeLoader(volumeId, options);
    return volumeLoadObject.promise.then((volume) => {
        volume.imageData = createInternalVTKRepresentation(volume);
        return volume;
    });
}
async function createAndCacheVolume(volumeId, options) {
    if (volumeId === undefined) {
        throw new Error('createAndCacheVolume: parameter volumeId must not be undefined');
    }
    let volumeLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolumeLoadObject(volumeId);
    if (volumeLoadObject !== undefined) {
        return volumeLoadObject.promise;
    }
    volumeLoadObject = loadVolumeFromVolumeLoader(volumeId, options);
    volumeLoadObject.promise.then((volume) => {
        volume.imageData = createInternalVTKRepresentation(volume);
    });
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject).catch((err) => {
        throw err;
    });
    return volumeLoadObject.promise;
}
async function createAndCacheDerivedVolume(referencedVolumeId, options) {
    const referencedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(referencedVolumeId);
    if (!referencedVolume) {
        throw new Error(`Cannot created derived volume: Referenced volume with id ${referencedVolumeId} does not exist.`);
    }
    let { volumeId } = options;
    const { targetBuffer } = options;
    if (volumeId === undefined) {
        volumeId = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.uuidv4)();
    }
    const { metadata, dimensions, spacing, origin, direction } = referencedVolume;
    const scalarData = referencedVolume.getScalarData();
    const scalarLength = scalarData.length;
    const { volumeScalarData, numBytes } = generateVolumeScalarData(targetBuffer, scalarLength);
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: 'Pixels',
        numberOfComponents: 1,
        values: volumeScalarData,
    });
    const derivedImageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    derivedImageData.setDimensions(dimensions);
    derivedImageData.setSpacing(spacing);
    derivedImageData.setDirection(direction);
    derivedImageData.setOrigin(origin);
    derivedImageData.getPointData().setScalars(scalarArray);
    const derivedVolume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        volumeId,
        metadata: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default()(metadata),
        dimensions: [dimensions[0], dimensions[1], dimensions[2]],
        spacing,
        origin,
        direction,
        imageData: derivedImageData,
        scalarData: volumeScalarData,
        sizeInBytes: numBytes,
        imageIds: [],
        referencedVolumeId,
    });
    const volumeLoadObject = {
        promise: Promise.resolve(derivedVolume),
    };
    await _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return derivedVolume;
}
function createLocalVolume(options, volumeId, preventCache = false) {
    const { metadata, dimensions, spacing, origin, direction, targetBuffer } = options;
    let { scalarData } = options;
    const validDataTypes = [
        'Uint8Array',
        'Float32Array',
        'Uint16Array',
        'Int16Array',
    ];
    const scalarLength = dimensions[0] * dimensions[1] * dimensions[2];
    if (!scalarData || !validDataTypes.includes(scalarData.constructor.name)) {
        if (!targetBuffer?.type || !validDataTypes.includes(targetBuffer.type)) {
            throw new Error('createLocalVolume: parameter scalarData must be provided and must be either Uint8Array, Float32Array, Uint16Array or Int16Array');
        }
        ({ volumeScalarData: scalarData } = generateVolumeScalarData(targetBuffer, scalarLength));
    }
    if (volumeId === undefined) {
        volumeId = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.uuidv4)();
    }
    const cachedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(volumeId);
    if (cachedVolume) {
        return cachedVolume;
    }
    const numBytes = scalarData ? scalarData.buffer.byteLength : scalarLength * 4;
    const isCacheable = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.isCacheable(numBytes);
    if (!isCacheable) {
        throw new Error(_enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.CACHE_SIZE_EXCEEDED);
    }
    const scalarArray = _kitware_vtk_js_Common_Core_DataArray__WEBPACK_IMPORTED_MODULE_2__/* ["default"].newInstance */ .Ay.newInstance({
        name: 'Pixels',
        numberOfComponents: 1,
        values: scalarData,
    });
    const imageData = _kitware_vtk_js_Common_DataModel_ImageData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    imageData.setDimensions(dimensions);
    imageData.setSpacing(spacing);
    imageData.setDirection(direction);
    imageData.setOrigin(origin);
    imageData.getPointData().setScalars(scalarArray);
    const derivedVolume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        volumeId,
        metadata: lodash_clonedeep__WEBPACK_IMPORTED_MODULE_8___default()(metadata),
        dimensions: [dimensions[0], dimensions[1], dimensions[2]],
        spacing,
        origin,
        direction,
        imageData: imageData,
        scalarData,
        sizeInBytes: numBytes,
        referencedImageIds: options.referencedImageIds || [],
        referencedVolumeId: options.referencedVolumeId,
        imageIds: options.imageIds || [],
    });
    if (preventCache) {
        return derivedVolume;
    }
    const volumeLoadObject = {
        promise: Promise.resolve(derivedVolume),
    };
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return derivedVolume;
}
async function createAndCacheVolumeFromImages(volumeId, imageIds, options = {}) {
    const { preventCache = false } = options;
    if (imageIds === undefined) {
        throw new Error('createAndCacheVolumeFromImages: parameter imageIds must not be undefined');
    }
    if (volumeId === undefined) {
        throw new Error('createAndCacheVolumeFromImages: parameter volumeId must not be undefined');
    }
    const cachedVolume = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getVolume(volumeId);
    if (cachedVolume) {
        return Promise.resolve(cachedVolume);
    }
    const volumeProps = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.generateVolumePropsFromImageIds)(imageIds, volumeId);
    const imagePromises = volumeProps.imageIds.map((imageId, imageIdIndex) => {
        const imageLoadObject = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.getImageLoadObject(imageId);
        return imageLoadObject.promise.then((image) => {
            const pixelData = image.getPixelData();
            const offset = imageIdIndex * image.rows * image.columns;
            volumeProps.scalarData.set(pixelData, offset);
        });
    });
    await Promise.all(imagePromises);
    const volume = new _cache_classes_ImageVolume__WEBPACK_IMPORTED_MODULE_3__/* .ImageVolume */ .Q({
        ...volumeProps,
        referencedImageIds: imageIds,
        ...options,
    });
    (0,_utilities_cacheUtils__WEBPACK_IMPORTED_MODULE_11__.performCacheOptimizationForVolume)(volume);
    const volumeLoadObject = {
        promise: Promise.resolve(volume),
    };
    if (preventCache) {
        return volumeLoadObject.promise;
    }
    _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.putVolumeLoadObject(volumeId, volumeLoadObject);
    return volumeLoadObject.promise;
}
function registerVolumeLoader(scheme, volumeLoader) {
    volumeLoaders[scheme] = volumeLoader;
}
function getVolumeLoaderSchemes() {
    return Object.keys(volumeLoaders);
}
function registerUnknownVolumeLoader(volumeLoader) {
    const oldVolumeLoader = unknownVolumeLoader;
    unknownVolumeLoader = volumeLoader;
    return oldVolumeLoader;
}
function getUnknownVolumeLoaderSchema() {
    return unknownVolumeLoader.name;
}
async function createAndCacheDerivedSegmentationVolume(referencedVolumeId, options = {}) {
    return createAndCacheDerivedVolume(referencedVolumeId, {
        ...options,
        targetBuffer: {
            type: 'Uint8Array',
        },
    });
}
async function createLocalSegmentationVolume(options, volumeId, preventCache = false) {
    if (!options.scalarData) {
        options.scalarData = new Uint8Array(options.dimensions[0] * options.dimensions[1] * options.dimensions[2]);
    }
    return createLocalVolume(options, volumeId, preventCache);
}
function generateVolumeScalarData(targetBuffer, scalarLength) {
    const { useNorm16Texture } = (0,_init__WEBPACK_IMPORTED_MODULE_10__/* .getConfiguration */ .D0)().rendering;
    const { TypedArrayConstructor, numBytes } = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.getBufferConfiguration)(targetBuffer?.type, scalarLength, {
        use16BitTexture: useNorm16Texture,
        isVolumeBuffer: true,
    });
    const isCacheable = _cache_cache__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A.isCacheable(numBytes);
    if (!isCacheable) {
        throw new Error(_enums_Events__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.CACHE_SIZE_EXCEEDED);
    }
    let volumeScalarData;
    if (targetBuffer?.sharedArrayBuffer ?? (0,_init__WEBPACK_IMPORTED_MODULE_10__/* .getShouldUseSharedArrayBuffer */ .TB)()) {
        switch (targetBuffer.type) {
            case 'Float32Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createFloat32SharedArray)(scalarLength);
                break;
            case 'Uint8Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint8SharedArray)(scalarLength);
                break;
            case 'Uint16Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint16SharedArray)(scalarLength);
                break;
            case 'Int16Array':
                volumeScalarData = (0,_utilities__WEBPACK_IMPORTED_MODULE_9__.createUint16SharedArray)(scalarLength);
                break;
            default:
                throw new Error('generateVolumeScalarData: SharedArrayBuffer is not supported for the specified target buffer type');
        }
    }
    else {
        volumeScalarData = new TypedArrayConstructor(scalarLength);
    }
    return { volumeScalarData, numBytes };
}


/***/ }),

/***/ 55692:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addProvider: () => (/* binding */ addProvider),
/* harmony export */   get: () => (/* binding */ getMetaData),
/* harmony export */   removeAllProviders: () => (/* binding */ removeAllProviders),
/* harmony export */   removeProvider: () => (/* binding */ removeProvider)
/* harmony export */ });
const providers = [];
function addProvider(provider, priority = 0) {
    let i;
    for (i = 0; i < providers.length; i++) {
        if (providers[i].priority <= priority) {
            break;
        }
    }
    providers.splice(i, 0, {
        priority,
        provider,
    });
}
function removeProvider(provider) {
    for (let i = 0; i < providers.length; i++) {
        if (providers[i].provider === provider) {
            providers.splice(i, 1);
            break;
        }
    }
}
function removeAllProviders() {
    while (providers.length > 0) {
        providers.pop();
    }
}
function getMetaData(type, ...queries) {
    for (let i = 0; i < providers.length; i++) {
        const result = providers[i].provider(type, ...queries);
        if (result !== undefined) {
            return result;
        }
    }
}



/***/ }),

/***/ 775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _requestPoolManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79927);
/* harmony import */ var _enums_RequestType__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(15453);


const imageLoadPoolManager = new _requestPoolManager__WEBPACK_IMPORTED_MODULE_0__/* .RequestPoolManager */ .R('imageLoadPool');
imageLoadPoolManager.grabDelay = 0;
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Interaction, 1000);
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Thumbnail, 1000);
imageLoadPoolManager.setMaxSimultaneousRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Prefetch, 1000);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (imageLoadPoolManager);


/***/ }),

/***/ 79927:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ RequestPoolManager)
/* harmony export */ });
/* harmony import */ var _enums_RequestType__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15453);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35678);


class RequestPoolManager {
    constructor(id) {
        this.numRequests = {
            interaction: 0,
            thumbnail: 0,
            prefetch: 0,
            compute: 0,
        };
        this.id = id ? id : (0,_utilities__WEBPACK_IMPORTED_MODULE_1__.uuidv4)();
        this.requestPool = {
            interaction: { 0: [] },
            thumbnail: { 0: [] },
            prefetch: { 0: [] },
            compute: { 0: [] },
        };
        this.grabDelay = 5;
        this.awake = false;
        this.numRequests = {
            interaction: 0,
            thumbnail: 0,
            prefetch: 0,
            compute: 0,
        };
        this.maxNumRequests = {
            interaction: 6,
            thumbnail: 6,
            prefetch: 5,
            compute: 1000,
        };
    }
    setMaxSimultaneousRequests(type, maxNumRequests) {
        this.maxNumRequests[type] = maxNumRequests;
    }
    getMaxSimultaneousRequests(type) {
        return this.maxNumRequests[type];
    }
    destroy() {
        if (this.timeoutHandle) {
            window.clearTimeout(this.timeoutHandle);
        }
    }
    addRequest(requestFn, type, additionalDetails, priority = 0) {
        const requestDetails = {
            requestFn,
            type,
            additionalDetails,
        };
        if (this.requestPool[type][priority] === undefined) {
            this.requestPool[type][priority] = [];
        }
        this.requestPool[type][priority].push(requestDetails);
        this.startGrabbing();
    }
    filterRequests(filterFunction) {
        Object.keys(this.requestPool).forEach((type) => {
            const requestType = this.requestPool[type];
            Object.keys(requestType).forEach((priority) => {
                requestType[priority] = requestType[priority].filter((requestDetails) => {
                    return filterFunction(requestDetails);
                });
            });
        });
    }
    clearRequestStack(type) {
        if (!this.requestPool[type]) {
            throw new Error(`No category for the type ${type} found`);
        }
        this.requestPool[type] = { 0: [] };
    }
    sendRequests(type) {
        const requestsToSend = this.maxNumRequests[type] - this.numRequests[type];
        let syncImageCount = 0;
        for (let i = 0; i < requestsToSend; i++) {
            const requestDetails = this.getNextRequest(type);
            if (requestDetails === null) {
                return false;
            }
            else if (requestDetails) {
                this.numRequests[type]++;
                this.awake = true;
                let requestResult;
                try {
                    requestResult = requestDetails.requestFn();
                }
                catch (e) {
                    console.warn('sendRequest failed', e);
                }
                if (requestResult?.finally) {
                    requestResult.finally(() => {
                        this.numRequests[type]--;
                        this.startAgain();
                    });
                }
                else {
                    this.numRequests[type]--;
                    syncImageCount++;
                }
            }
        }
        if (syncImageCount) {
            this.startAgain();
        }
        return true;
    }
    getNextRequest(type) {
        const interactionPriorities = this.getSortedPriorityGroups(type);
        for (const priority of interactionPriorities) {
            if (this.requestPool[type][priority].length) {
                return this.requestPool[type][priority].shift();
            }
        }
        return null;
    }
    startGrabbing() {
        const hasRemainingInteractionRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Interaction);
        const hasRemainingThumbnailRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Thumbnail);
        const hasRemainingPrefetchRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Prefetch);
        const hasRemainingComputeRequests = this.sendRequests(_enums_RequestType__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Compute);
        if (!hasRemainingInteractionRequests &&
            !hasRemainingThumbnailRequests &&
            !hasRemainingPrefetchRequests &&
            !hasRemainingComputeRequests) {
            this.awake = false;
        }
    }
    startAgain() {
        if (!this.awake) {
            return;
        }
        if (this.grabDelay !== undefined) {
            if (!this.timeoutHandle) {
                this.timeoutHandle = window.setTimeout(() => {
                    this.timeoutHandle = null;
                    this.startGrabbing();
                }, this.grabDelay);
            }
        }
        else {
            this.startGrabbing();
        }
    }
    getSortedPriorityGroups(type) {
        const priorities = Object.keys(this.requestPool[type])
            .map(Number)
            .filter((priority) => this.requestPool[type][priority].length)
            .sort((a, b) => a - b);
        return priorities;
    }
    getRequestPool() {
        return this.requestPool;
    }
}



/***/ }),

/***/ 13292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ triggerEvent)
/* harmony export */ });
/* harmony import */ var _eventTarget__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(51884);

function triggerEvent(el = _eventTarget__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A, type, detail = null) {
    if (!type) {
        throw new Error('Event type was not defined');
    }
    const event = new CustomEvent(type, {
        detail,
        cancelable: true,
    });
    return el.dispatchEvent(event);
}


/***/ }),

/***/ 61874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var comlink__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99178);
/* harmony import */ var _enums___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98362);
/* harmony import */ var _requestPool_requestPoolManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(79927);



class CentralizedWorkerManager {
    constructor() {
        this.workerRegistry = {};
        this.workerPoolManager = new _requestPool_requestPoolManager__WEBPACK_IMPORTED_MODULE_2__/* .RequestPoolManager */ .R('webworker');
    }
    registerWorker(workerName, workerFn, options = {}) {
        const { maxWorkerInstances = 1, overwrite = false, autoTerminateOnIdle = {
            enabled: false,
            idleTimeThreshold: 3000,
        }, } = options;
        if (this.workerRegistry[workerName] && !overwrite) {
            console.warn(`Worker type '${workerName}' is already registered...`);
            return;
        }
        if (overwrite && this.workerRegistry[workerName]?.idleCheckIntervalId) {
            clearInterval(this.workerRegistry[workerName].idleCheckIntervalId);
        }
        const workerProperties = {
            workerFn: null,
            instances: [],
            loadCounters: [],
            lastActiveTime: [],
            nativeWorkers: [],
            autoTerminateOnIdle: autoTerminateOnIdle.enabled,
            idleCheckIntervalId: null,
            idleTimeThreshold: autoTerminateOnIdle.idleTimeThreshold,
        };
        workerProperties.loadCounters = Array(maxWorkerInstances).fill(0);
        workerProperties.lastActiveTime = Array(maxWorkerInstances).fill(null);
        for (let i = 0; i < maxWorkerInstances; i++) {
            const worker = workerFn();
            workerProperties.instances.push(comlink__WEBPACK_IMPORTED_MODULE_0__/* .wrap */ .LV(worker));
            workerProperties.nativeWorkers.push(worker);
            workerProperties.workerFn = workerFn;
        }
        this.workerRegistry[workerName] = workerProperties;
    }
    getNextWorkerAPI(workerName) {
        const workerProperties = this.workerRegistry[workerName];
        if (!workerProperties) {
            console.error(`Worker type '${workerName}' is not registered.`);
            return null;
        }
        const workerInstances = workerProperties.instances.filter((instance) => instance !== null);
        let minLoadIndex = 0;
        let minLoadValue = workerProperties.loadCounters[0] || 0;
        for (let i = 1; i < workerInstances.length; i++) {
            const currentLoadValue = workerProperties.loadCounters[i] || 0;
            if (currentLoadValue < minLoadValue) {
                minLoadIndex = i;
                minLoadValue = currentLoadValue;
            }
        }
        if (workerProperties.instances[minLoadIndex] === null) {
            const worker = workerProperties.workerFn();
            workerProperties.instances[minLoadIndex] = comlink__WEBPACK_IMPORTED_MODULE_0__/* .wrap */ .LV(worker);
            workerProperties.nativeWorkers[minLoadIndex] = worker;
        }
        workerProperties.loadCounters[minLoadIndex] += 1;
        return {
            api: workerProperties.instances[minLoadIndex],
            index: minLoadIndex,
        };
    }
    executeTask(workerName, methodName, args = {}, { requestType = _enums___WEBPACK_IMPORTED_MODULE_1__.RequestType.Compute, priority = 0, options = {}, callbacks = [], } = {}) {
        return new Promise((resolve, reject) => {
            const requestFn = async () => {
                const { api, index } = this.getNextWorkerAPI(workerName);
                if (!api) {
                    const error = new Error(`No available worker instance for '${workerName}'`);
                    console.error(error);
                    reject(error);
                    return;
                }
                try {
                    let finalCallbacks = [];
                    if (callbacks.length) {
                        finalCallbacks = callbacks.map((cb) => {
                            return comlink__WEBPACK_IMPORTED_MODULE_0__/* .proxy */ .BX(cb);
                        });
                    }
                    const workerProperties = this.workerRegistry[workerName];
                    workerProperties.processing = true;
                    const results = await api[methodName](args, ...finalCallbacks);
                    workerProperties.processing = false;
                    workerProperties.lastActiveTime[index] = Date.now();
                    if (workerProperties.autoTerminateOnIdle &&
                        !workerProperties.idleCheckIntervalId &&
                        workerProperties.idleTimeThreshold) {
                        workerProperties.idleCheckIntervalId = setInterval(() => {
                            this.terminateIdleWorkers(workerName, workerProperties.idleTimeThreshold);
                        }, workerProperties.idleTimeThreshold);
                    }
                    resolve(results);
                }
                catch (err) {
                    console.error(`Error executing method '${methodName}' on worker '${workerName}':`, err);
                    reject(err);
                }
                finally {
                    this.workerRegistry[workerName].loadCounters[index]--;
                }
            };
            this.workerPoolManager.addRequest(requestFn, requestType, options, priority);
        });
    }
    terminateIdleWorkers(workerName, idleTimeThreshold) {
        const workerProperties = this.workerRegistry[workerName];
        if (workerProperties.processing) {
            return;
        }
        const now = Date.now();
        workerProperties.instances.forEach((_, index) => {
            const lastActiveTime = workerProperties.lastActiveTime[index];
            const isWorkerActive = lastActiveTime !== null && workerProperties.loadCounters[index] > 0;
            const idleTime = now - lastActiveTime;
            if (!isWorkerActive && idleTime > idleTimeThreshold) {
                this.terminateWorkerInstance(workerName, index);
            }
        });
    }
    terminate(workerName) {
        const workerProperties = this.workerRegistry[workerName];
        if (!workerProperties) {
            console.error(`Worker type '${workerName}' is not registered.`);
            return;
        }
        workerProperties.instances.forEach((_, index) => {
            this.terminateWorkerInstance(workerName, index);
        });
    }
    terminateWorkerInstance(workerName, index) {
        const workerProperties = this.workerRegistry[workerName];
        const workerInstance = workerProperties.instances[index];
        if (workerInstance !== null) {
            workerInstance[comlink__WEBPACK_IMPORTED_MODULE_0__/* .releaseProxy */ .A2]();
            workerProperties.nativeWorkers[index].terminate();
            workerProperties.instances[index] = null;
            workerProperties.lastActiveTime[index] = null;
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CentralizedWorkerManager);


/***/ }),

/***/ 39371:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   segmentation: () => (/* reexport module object */ _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_9__)
/* harmony export */ });
/* harmony import */ var _init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35373);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61738);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(55965);
/* harmony import */ var _synchronizers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42375);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(49574);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74119);
/* harmony import */ var _cursors__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(32916);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(40969);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(45238);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(63421);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(81848);
/* harmony import */ var _tools_annotation_VideoRedactionTool__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(65043);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(84901);
















/***/ }),

/***/ 35837:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getState: () => (/* reexport safe */ _getState__WEBPACK_IMPORTED_MODULE_0__.A)
/* harmony export */ });
/* harmony import */ var _getState__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(70692);
/* harmony import */ var _getFont__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(80456);
/* harmony import */ var _ToolStyle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31862);






/***/ }),

/***/ 45238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   state: () => (/* reexport module object */ _annotationState__WEBPACK_IMPORTED_MODULE_3__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35837);
/* harmony import */ var _annotationLocking__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48428);
/* harmony import */ var _annotationSelection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42351);
/* harmony import */ var _annotationState__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38296);
/* harmony import */ var _annotationVisibility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21009);
/* harmony import */ var _FrameOfReferenceSpecificAnnotationManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22581);
/* harmony import */ var _AnnotationGroup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16122);










/***/ }),

/***/ 50720:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);
/* harmony import */ var _utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24592);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74119);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(96214);
/* harmony import */ var _utilities_throttle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(21090);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(38296);
/* harmony import */ var _stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(48428);
/* harmony import */ var _stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(21009);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(54177);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(49574);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(61738);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(84901);
/* harmony import */ var _utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(90252);
/* harmony import */ var _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(21954);
/* harmony import */ var _utilities_drawing__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(10910);
/* harmony import */ var _cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(40233);
/* harmony import */ var _utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(23072);


















const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities;
class BidirectionalTool extends _base__WEBPACK_IMPORTED_MODULE_4__/* .AnnotationTool */ .EC {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            preventHandleOutsideImage: false,
            getTextLines: defaultGetTextLines,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.isPointNearTool = (element, annotation, canvasCoords, proximity) => {
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { data } = annotation;
            const { points } = data.handles;
            let canvasPoint1 = viewport.worldToCanvas(points[0]);
            let canvasPoint2 = viewport.worldToCanvas(points[1]);
            let line = {
                start: {
                    x: canvasPoint1[0],
                    y: canvasPoint1[1],
                },
                end: {
                    x: canvasPoint2[0],
                    y: canvasPoint2[1],
                },
            };
            let distanceToPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.distanceToPoint([line.start.x, line.start.y], [line.end.x, line.end.y], [canvasCoords[0], canvasCoords[1]]);
            if (distanceToPoint <= proximity) {
                return true;
            }
            canvasPoint1 = viewport.worldToCanvas(points[2]);
            canvasPoint2 = viewport.worldToCanvas(points[3]);
            line = {
                start: {
                    x: canvasPoint1[0],
                    y: canvasPoint1[1],
                },
                end: {
                    x: canvasPoint2[0],
                    y: canvasPoint2[1],
                },
            };
            distanceToPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.distanceToPoint([line.start.x, line.start.y], [line.end.x, line.end.y], [canvasCoords[0], canvasCoords[1]]);
            if (distanceToPoint <= proximity) {
                return true;
            }
            return false;
        };
        this.toolSelectedCallback = (evt, annotation) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            annotation.highlighted = true;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                movingTextBox: false,
            };
            this._activateModify(element);
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
            evt.preventDefault();
        };
        this.handleSelectedCallback = (evt, annotation, handle) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const data = annotation.data;
            annotation.highlighted = true;
            let movingTextBox = false;
            let handleIndex;
            if (handle.worldPosition) {
                movingTextBox = true;
            }
            else {
                handleIndex = data.handles.points.findIndex((p) => p === handle);
            }
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex,
                movingTextBox,
            };
            this._activateModify(element);
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            evt.preventDefault();
        };
        this._endCallback = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const { annotation, viewportIdsToRender, newAnnotation, hasMoved } = this.editData;
            const { data } = annotation;
            if (newAnnotation && !hasMoved) {
                return;
            }
            data.handles.activeHandleIndex = null;
            this._deactivateModify(element);
            this._deactivateDraw(element);
            (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.resetElementCursor)(element);
            const { renderingEngine } = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            if (this.editData.handleIndex !== undefined) {
                const { points } = data.handles;
                const firstLineSegmentLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.distance */ .eR.distance(points[0], points[1]);
                const secondLineSegmentLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.distance */ .eR.distance(points[2], points[3]);
                if (secondLineSegmentLength > firstLineSegmentLength) {
                    const longAxis = [[...points[2]], [...points[3]]];
                    const shortAxisPoint0 = [...points[0]];
                    const shortAxisPoint1 = [...points[1]];
                    const longAxisVector = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(longAxisVector, longAxis[1][0] - longAxis[0][0], longAxis[1][1] - longAxis[1][0]);
                    const counterClockWisePerpendicularToLongAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(counterClockWisePerpendicularToLongAxis, -longAxisVector[1], longAxisVector[0]);
                    const currentShortAxisVector = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
                    gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(currentShortAxisVector, shortAxisPoint1[0] - shortAxisPoint0[0], shortAxisPoint1[1] - shortAxisPoint0[0]);
                    let shortAxis;
                    if (gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.dot */ .Zc.dot(currentShortAxisVector, counterClockWisePerpendicularToLongAxis) > 0) {
                        shortAxis = [shortAxisPoint0, shortAxisPoint1];
                    }
                    else {
                        shortAxis = [shortAxisPoint1, shortAxisPoint0];
                    }
                    data.handles.points = [
                        longAxis[0],
                        longAxis[1],
                        shortAxis[0],
                        shortAxis[1],
                    ];
                }
            }
            if (this.isHandleOutsideImage &&
                this.configuration.preventHandleOutsideImage) {
                (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.removeAnnotation)(annotation.annotationUID);
            }
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            if (newAnnotation) {
                (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationCompleted */ .dZ)(annotation);
            }
            this.editData = null;
            this.isDrawing = false;
        };
        this._dragDrawCallback = (evt) => {
            this.isDrawing = true;
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine, viewport } = enabledElement;
            const { worldToCanvas } = viewport;
            const { annotation, viewportIdsToRender, handleIndex } = this.editData;
            const { data } = annotation;
            const worldPos = currentPoints.world;
            data.handles.points[handleIndex] = [...worldPos];
            const canvasCoordPoints = data.handles.points.map(worldToCanvas);
            const canvasCoords = {
                longLineSegment: {
                    start: {
                        x: canvasCoordPoints[0][0],
                        y: canvasCoordPoints[0][1],
                    },
                    end: {
                        x: canvasCoordPoints[1][0],
                        y: canvasCoordPoints[1][1],
                    },
                },
                shortLineSegment: {
                    start: {
                        x: canvasCoordPoints[2][0],
                        y: canvasCoordPoints[2][1],
                    },
                    end: {
                        x: canvasCoordPoints[3][0],
                        y: canvasCoordPoints[3][1],
                    },
                },
            };
            const dist = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.distance */ .Zc.distance(canvasCoordPoints[0], canvasCoordPoints[1]);
            const shortAxisDistFromCenter = dist / 3;
            const dx = canvasCoords.longLineSegment.start.x - canvasCoords.longLineSegment.end.x;
            const dy = canvasCoords.longLineSegment.start.y - canvasCoords.longLineSegment.end.y;
            const length = Math.sqrt(dx * dx + dy * dy);
            const vectorX = dx / length;
            const vectorY = dy / length;
            const xMid = (canvasCoords.longLineSegment.start.x +
                canvasCoords.longLineSegment.end.x) /
                2;
            const yMid = (canvasCoords.longLineSegment.start.y +
                canvasCoords.longLineSegment.end.y) /
                2;
            const startX = xMid + shortAxisDistFromCenter * vectorY;
            const startY = yMid - shortAxisDistFromCenter * vectorX;
            const endX = xMid - shortAxisDistFromCenter * vectorY;
            const endY = yMid + shortAxisDistFromCenter * vectorX;
            data.handles.points[2] = viewport.canvasToWorld([startX, startY]);
            data.handles.points[3] = viewport.canvasToWorld([endX, endY]);
            annotation.invalidated = true;
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            this.editData.hasMoved = true;
        };
        this._dragModifyCallback = (evt) => {
            this.isDrawing = true;
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            const { annotation, viewportIdsToRender, handleIndex, movingTextBox } = this.editData;
            const { data } = annotation;
            if (movingTextBox) {
                const { deltaPoints } = eventDetail;
                const worldPosDelta = deltaPoints.world;
                const { textBox } = data.handles;
                const { worldPosition } = textBox;
                worldPosition[0] += worldPosDelta[0];
                worldPosition[1] += worldPosDelta[1];
                worldPosition[2] += worldPosDelta[2];
                textBox.hasMoved = true;
            }
            else if (handleIndex === undefined) {
                const { deltaPoints } = eventDetail;
                const worldPosDelta = deltaPoints.world;
                const points = data.handles.points;
                points.forEach((point) => {
                    point[0] += worldPosDelta[0];
                    point[1] += worldPosDelta[1];
                    point[2] += worldPosDelta[2];
                });
                annotation.invalidated = true;
            }
            else {
                this._dragModifyHandle(evt);
                annotation.invalidated = true;
            }
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
        };
        this._dragModifyHandle = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { annotation, handleIndex: movingHandleIndex } = this.editData;
            const { data } = annotation;
            const worldPos = currentPoints.world;
            const canvasCoordHandlesCurrent = [
                viewport.worldToCanvas(data.handles.points[0]),
                viewport.worldToCanvas(data.handles.points[1]),
                viewport.worldToCanvas(data.handles.points[2]),
                viewport.worldToCanvas(data.handles.points[3]),
            ];
            const firstLineSegment = {
                start: {
                    x: canvasCoordHandlesCurrent[0][0],
                    y: canvasCoordHandlesCurrent[0][1],
                },
                end: {
                    x: canvasCoordHandlesCurrent[1][0],
                    y: canvasCoordHandlesCurrent[1][1],
                },
            };
            const secondLineSegment = {
                start: {
                    x: canvasCoordHandlesCurrent[2][0],
                    y: canvasCoordHandlesCurrent[2][1],
                },
                end: {
                    x: canvasCoordHandlesCurrent[3][0],
                    y: canvasCoordHandlesCurrent[3][1],
                },
            };
            const proposedPoint = [...worldPos];
            const proposedCanvasCoord = viewport.worldToCanvas(proposedPoint);
            if (movingHandleIndex === 0 || movingHandleIndex === 1) {
                const fixedHandleIndex = movingHandleIndex === 0 ? 1 : 0;
                const fixedHandleCanvasCoord = canvasCoordHandlesCurrent[fixedHandleIndex];
                const fixedHandleToProposedCoordVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), proposedCanvasCoord[0] - fixedHandleCanvasCoord[0], proposedCanvasCoord[1] - fixedHandleCanvasCoord[1]);
                const fixedHandleToOldCoordVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), canvasCoordHandlesCurrent[movingHandleIndex][0] -
                    fixedHandleCanvasCoord[0], canvasCoordHandlesCurrent[movingHandleIndex][1] -
                    fixedHandleCanvasCoord[1]);
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(fixedHandleToProposedCoordVec, fixedHandleToProposedCoordVec);
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(fixedHandleToOldCoordVec, fixedHandleToOldCoordVec);
                const proposedFirstLineSegment = {
                    start: {
                        x: fixedHandleCanvasCoord[0],
                        y: fixedHandleCanvasCoord[1],
                    },
                    end: {
                        x: proposedCanvasCoord[0],
                        y: proposedCanvasCoord[1],
                    },
                };
                if (this._movingLongAxisWouldPutItThroughShortAxis(proposedFirstLineSegment, secondLineSegment)) {
                    return;
                }
                const centerOfRotation = fixedHandleCanvasCoord;
                const angle = this._getSignedAngle(fixedHandleToOldCoordVec, fixedHandleToProposedCoordVec);
                let firstPointX = canvasCoordHandlesCurrent[2][0];
                let firstPointY = canvasCoordHandlesCurrent[2][1];
                let secondPointX = canvasCoordHandlesCurrent[3][0];
                let secondPointY = canvasCoordHandlesCurrent[3][1];
                firstPointX -= centerOfRotation[0];
                firstPointY -= centerOfRotation[1];
                secondPointX -= centerOfRotation[0];
                secondPointY -= centerOfRotation[1];
                const rotatedFirstPoint = firstPointX * Math.cos(angle) - firstPointY * Math.sin(angle);
                const rotatedFirstPointY = firstPointX * Math.sin(angle) + firstPointY * Math.cos(angle);
                const rotatedSecondPoint = secondPointX * Math.cos(angle) - secondPointY * Math.sin(angle);
                const rotatedSecondPointY = secondPointX * Math.sin(angle) + secondPointY * Math.cos(angle);
                firstPointX = rotatedFirstPoint + centerOfRotation[0];
                firstPointY = rotatedFirstPointY + centerOfRotation[1];
                secondPointX = rotatedSecondPoint + centerOfRotation[0];
                secondPointY = rotatedSecondPointY + centerOfRotation[1];
                const newFirstPoint = viewport.canvasToWorld([firstPointX, firstPointY]);
                const newSecondPoint = viewport.canvasToWorld([
                    secondPointX,
                    secondPointY,
                ]);
                data.handles.points[movingHandleIndex] = proposedPoint;
                data.handles.points[2] = newFirstPoint;
                data.handles.points[3] = newSecondPoint;
            }
            else {
                const translateHandleIndex = movingHandleIndex === 2 ? 3 : 2;
                const canvasCoordsCurrent = {
                    longLineSegment: {
                        start: firstLineSegment.start,
                        end: firstLineSegment.end,
                    },
                    shortLineSegment: {
                        start: secondLineSegment.start,
                        end: secondLineSegment.end,
                    },
                };
                const longLineSegmentVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.subtract */ .Zc.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [
                    canvasCoordsCurrent.longLineSegment.end.x,
                    canvasCoordsCurrent.longLineSegment.end.y,
                ], [
                    canvasCoordsCurrent.longLineSegment.start.x,
                    canvasCoordsCurrent.longLineSegment.start.y,
                ]);
                const longLineSegmentVecNormalized = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), longLineSegmentVec);
                const proposedToCurrentVec = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.subtract */ .Zc.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [proposedCanvasCoord[0], proposedCanvasCoord[1]], [
                    canvasCoordHandlesCurrent[movingHandleIndex][0],
                    canvasCoordHandlesCurrent[movingHandleIndex][1],
                ]);
                const movementLength = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.length */ .Zc.length(proposedToCurrentVec);
                const angle = this._getSignedAngle(longLineSegmentVecNormalized, proposedToCurrentVec);
                const movementAlongLineSegmentLength = Math.cos(angle) * movementLength;
                const newTranslatedPoint = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.scaleAndAdd */ .Zc.scaleAndAdd(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), [
                    canvasCoordHandlesCurrent[translateHandleIndex][0],
                    canvasCoordHandlesCurrent[translateHandleIndex][1],
                ], longLineSegmentVecNormalized, movementAlongLineSegmentLength);
                if (this._movingLongAxisWouldPutItThroughShortAxis({
                    start: {
                        x: proposedCanvasCoord[0],
                        y: proposedCanvasCoord[1],
                    },
                    end: {
                        x: newTranslatedPoint[0],
                        y: newTranslatedPoint[1],
                    },
                }, {
                    start: {
                        x: canvasCoordsCurrent.longLineSegment.start.x,
                        y: canvasCoordsCurrent.longLineSegment.start.y,
                    },
                    end: {
                        x: canvasCoordsCurrent.longLineSegment.end.x,
                        y: canvasCoordsCurrent.longLineSegment.end.y,
                    },
                })) {
                    return;
                }
                const intersectionPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.intersectLine([proposedCanvasCoord[0], proposedCanvasCoord[1]], [newTranslatedPoint[0], newTranslatedPoint[1]], [firstLineSegment.start.x, firstLineSegment.start.y], [firstLineSegment.end.x, firstLineSegment.end.y]);
                if (!intersectionPoint) {
                    return;
                }
                data.handles.points[translateHandleIndex] = viewport.canvasToWorld(newTranslatedPoint);
                data.handles.points[movingHandleIndex] = proposedPoint;
            }
        };
        this.cancel = (element) => {
            if (this.isDrawing) {
                this.isDrawing = false;
                this._deactivateDraw(element);
                this._deactivateModify(element);
                (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.resetElementCursor)(element);
                const { annotation, viewportIdsToRender, newAnnotation } = this.editData;
                const { data } = annotation;
                annotation.highlighted = false;
                data.handles.activeHandleIndex = null;
                const { renderingEngine } = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
                (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
                if (newAnnotation) {
                    (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationCompleted */ .dZ)(annotation);
                }
                this.editData = null;
                return annotation.annotationUID;
            }
        };
        this._activateDraw = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = true;
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragDrawCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_MOVE, this._dragDrawCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragDrawCallback);
        };
        this._deactivateDraw = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = false;
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragDrawCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_MOVE, this._dragDrawCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragDrawCallback);
        };
        this._activateModify = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = true;
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragModifyCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragModifyCallback);
            element.addEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
        };
        this._deactivateModify = (element) => {
            _store__WEBPACK_IMPORTED_MODULE_11__/* .state */ .wk.isInteractingWithTool = false;
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_UP, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_DRAG, this._dragModifyCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.MOUSE_CLICK, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_END, this._endCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_DRAG, this._dragModifyCallback);
            element.removeEventListener(_enums__WEBPACK_IMPORTED_MODULE_12__.Events.TOUCH_TAP, this._endCallback);
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = true;
            const { viewport } = enabledElement;
            const { element } = viewport;
            let annotations = (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.getAnnotations)(this.getToolName(), element);
            if (!annotations?.length) {
                return renderStatus;
            }
            annotations = this.filterInteractableAnnotationsForElement(element, annotations);
            if (!annotations?.length) {
                return renderStatus;
            }
            const targetId = this.getTargetId(viewport);
            const renderingEngine = viewport.getRenderingEngine();
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const { color, lineWidth, lineDash, shadow } = this.getAnnotationStyle({
                    annotation,
                    styleSpecifier,
                });
                if (!data.cachedStats[targetId] ||
                    data.cachedStats[targetId].unit == null) {
                    data.cachedStats[targetId] = {
                        length: null,
                        width: null,
                        unit: null,
                    };
                    this._calculateCachedStats(annotation, renderingEngine, enabledElement);
                }
                else if (annotation.invalidated) {
                    this._throttledCalculateCachedStats(annotation, renderingEngine, enabledElement);
                }
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                let activeHandleCanvasCoords;
                if (!(0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_8__.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_7__.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                const dataId1 = `${annotationUID}-line-1`;
                const dataId2 = `${annotationUID}-line-2`;
                const lineUID = '0';
                (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLine)(svgDrawingHelper, annotationUID, lineUID, canvasCoordinates[0], canvasCoordinates[1], {
                    color,
                    lineDash,
                    lineWidth,
                    shadow,
                }, dataId1);
                const secondLineUID = '1';
                (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLine)(svgDrawingHelper, annotationUID, secondLineUID, canvasCoordinates[2], canvasCoordinates[3], {
                    color,
                    lineDash,
                    lineWidth,
                    shadow,
                }, dataId2);
                renderStatus = true;
                const options = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
                if (!options.visibility) {
                    data.handles.textBox = {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    };
                    continue;
                }
                const textLines = this.configuration.getTextLines(data, targetId);
                if (!textLines || textLines.length === 0) {
                    continue;
                }
                let canvasTextBoxCoords;
                if (!data.handles.textBox.hasMoved) {
                    canvasTextBoxCoords = (0,_utilities_drawing__WEBPACK_IMPORTED_MODULE_15__.getTextBoxCoordsCanvas)(canvasCoordinates);
                    data.handles.textBox.worldPosition =
                        viewport.canvasToWorld(canvasTextBoxCoords);
                }
                const textBoxPosition = viewport.worldToCanvas(data.handles.textBox.worldPosition);
                const textBoxUID = '1';
                const boundingBox = (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_10__.drawLinkedTextBox)(svgDrawingHelper, annotationUID, textBoxUID, textLines, textBoxPosition, canvasCoordinates, {}, options);
                const { x: left, y: top, width, height } = boundingBox;
                data.handles.textBox.worldBoundingBox = {
                    topLeft: viewport.canvasToWorld([left, top]),
                    topRight: viewport.canvasToWorld([left + width, top]),
                    bottomLeft: viewport.canvasToWorld([left, top + height]),
                    bottomRight: viewport.canvasToWorld([left + width, top + height]),
                };
            }
            return renderStatus;
        };
        this._movingLongAxisWouldPutItThroughShortAxis = (firstLineSegment, secondLineSegment) => {
            const vectorInSecondLineDirection = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create();
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.set */ .Zc.set(vectorInSecondLineDirection, secondLineSegment.end.x - secondLineSegment.start.x, secondLineSegment.end.y - secondLineSegment.start.y);
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.normalize */ .Zc.normalize(vectorInSecondLineDirection, vectorInSecondLineDirection);
            const extendedSecondLineSegment = {
                start: {
                    x: secondLineSegment.start.x - vectorInSecondLineDirection[0] * 10,
                    y: secondLineSegment.start.y - vectorInSecondLineDirection[1] * 10,
                },
                end: {
                    x: secondLineSegment.end.x + vectorInSecondLineDirection[0] * 10,
                    y: secondLineSegment.end.y + vectorInSecondLineDirection[1] * 10,
                },
            };
            const proposedIntersectionPoint = _utilities_math_line__WEBPACK_IMPORTED_MODULE_14__.intersectLine([extendedSecondLineSegment.start.x, extendedSecondLineSegment.start.y], [extendedSecondLineSegment.end.x, extendedSecondLineSegment.end.y], [firstLineSegment.start.x, firstLineSegment.start.y], [firstLineSegment.end.x, firstLineSegment.end.y]);
            const wouldPutThroughShortAxis = !proposedIntersectionPoint;
            return wouldPutThroughShortAxis;
        };
        this._calculateCachedStats = (annotation, renderingEngine, enabledElement) => {
            const { data } = annotation;
            const { element } = enabledElement.viewport;
            const worldPos1 = data.handles.points[0];
            const worldPos2 = data.handles.points[1];
            const worldPos3 = data.handles.points[2];
            const worldPos4 = data.handles.points[3];
            const { cachedStats } = data;
            const targetIds = Object.keys(cachedStats);
            for (let i = 0; i < targetIds.length; i++) {
                const targetId = targetIds[i];
                const image = this.getTargetIdImage(targetId, renderingEngine);
                if (!image) {
                    continue;
                }
                const { imageData, dimensions } = image;
                const index1 = transformWorldToIndex(imageData, worldPos1);
                const index2 = transformWorldToIndex(imageData, worldPos2);
                const index3 = transformWorldToIndex(imageData, worldPos3);
                const index4 = transformWorldToIndex(imageData, worldPos4);
                const handles1 = [index1, index2];
                const handles2 = [index3, index4];
                const { scale: scale1, units: units1 } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, handles1);
                const { scale: scale2, units: units2 } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, handles2);
                const dist1 = this._calculateLength(worldPos1, worldPos2) / scale1;
                const dist2 = this._calculateLength(worldPos3, worldPos4) / scale2;
                const length = dist1 > dist2 ? dist1 : dist2;
                const width = dist1 > dist2 ? dist2 : dist1;
                const lengthUnit = dist1 > dist2 ? units1 : units2;
                const widthUnit = dist1 > dist2 ? units2 : units1;
                this._isInsideVolume(index1, index2, index3, index4, dimensions)
                    ? (this.isHandleOutsideImage = false)
                    : (this.isHandleOutsideImage = true);
                cachedStats[targetId] = {
                    length,
                    width,
                    unit: units1,
                    lengthUnit,
                    widthUnit,
                };
            }
            annotation.invalidated = false;
            (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_9__/* .triggerAnnotationModified */ .XF)(annotation, element);
            return cachedStats;
        };
        this._isInsideVolume = (index1, index2, index3, index4, dimensions) => {
            return (_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index1, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index2, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index3, dimensions) &&
                _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.indexWithinDimensions(index4, dimensions));
        };
        this._getSignedAngle = (vector1, vector2) => {
            return Math.atan2(vector1[0] * vector2[1] - vector1[1] * vector2[0], vector1[0] * vector2[0] + vector1[1] * vector2[1]);
        };
        this._throttledCalculateCachedStats = (0,_utilities_throttle__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A)(this._calculateCachedStats, 100, { trailing: true });
    }
    addNewAnnotation(evt) {
        const eventDetail = evt.detail;
        const { currentPoints, element } = eventDetail;
        const worldPos = currentPoints.world;
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.getEnabledElement)(element);
        const { viewport, renderingEngine } = enabledElement;
        this.isDrawing = true;
        const camera = viewport.getCamera();
        const { viewPlaneNormal, viewUp } = camera;
        const referencedImageId = this.getReferencedImageId(viewport, worldPos, viewPlaneNormal, viewUp);
        const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
        const annotation = {
            highlighted: true,
            invalidated: true,
            metadata: {
                toolName: this.getToolName(),
                viewPlaneNormal: [...viewPlaneNormal],
                viewUp: [...viewUp],
                FrameOfReferenceUID,
                referencedImageId,
                ...viewport.getViewReference({ points: [worldPos] }),
            },
            data: {
                handles: {
                    points: [
                        [...worldPos],
                        [...worldPos],
                        [...worldPos],
                        [...worldPos],
                    ],
                    textBox: {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    },
                    activeHandleIndex: null,
                },
                label: '',
                cachedStats: {},
            },
        };
        (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_6__.addAnnotation)(annotation, element);
        const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_13__.getViewportIdsWithToolToRender)(element, this.getToolName());
        this.editData = {
            annotation,
            viewportIdsToRender,
            handleIndex: 1,
            movingTextBox: false,
            newAnnotation: true,
            hasMoved: false,
        };
        this._activateDraw(element);
        (0,_cursors_elementCursor__WEBPACK_IMPORTED_MODULE_16__.hideElementCursor)(element);
        evt.preventDefault();
        (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
        return annotation;
    }
    _calculateLength(pos1, pos2) {
        const dx = pos1[0] - pos2[0];
        const dy = pos1[1] - pos2[1];
        const dz = pos1[2] - pos2[2];
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
function defaultGetTextLines(data, targetId) {
    const { cachedStats, label } = data;
    const { length, width, unit, lengthUnit, widthUnit } = cachedStats[targetId];
    const textLines = [];
    if (label) {
        textLines.push(label);
    }
    if (length === undefined) {
        return textLines;
    }
    textLines.push(`L: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(length)} ${lengthUnit || unit}`, `W: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(width)} ${widthUnit || unit}`);
    return textLines;
}
BidirectionalTool.toolName = 'Bidirectional';
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (BidirectionalTool)));


/***/ }),

/***/ 52454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _AnnotationDisplayTool__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28062);
/* harmony import */ var _stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48428);
/* harmony import */ var _stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(21009);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38296);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(54177);







class AnnotationTool extends _AnnotationDisplayTool__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A {
    constructor(toolProps, defaultToolProps) {
        super(toolProps, defaultToolProps);
        this.mouseMoveCallback = (evt, filteredAnnotations) => {
            if (!filteredAnnotations) {
                return false;
            }
            const { element, currentPoints } = evt.detail;
            const canvasCoords = currentPoints.canvas;
            let annotationsNeedToBeRedrawn = false;
            for (const annotation of filteredAnnotations) {
                if ((0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__.isAnnotationLocked)(annotation) ||
                    !(0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__.isAnnotationVisible)(annotation.annotationUID)) {
                    continue;
                }
                const { data } = annotation;
                const activateHandleIndex = data.handles
                    ? data.handles.activeHandleIndex
                    : undefined;
                const near = this._imagePointNearToolOrHandle(element, annotation, canvasCoords, 6);
                const nearToolAndNotMarkedActive = near && !annotation.highlighted;
                const notNearToolAndMarkedActive = !near && annotation.highlighted;
                if (nearToolAndNotMarkedActive || notNearToolAndMarkedActive) {
                    annotation.highlighted = !annotation.highlighted;
                    annotationsNeedToBeRedrawn = true;
                }
                else if (data.handles &&
                    data.handles.activeHandleIndex !== activateHandleIndex) {
                    annotationsNeedToBeRedrawn = true;
                }
            }
            return annotationsNeedToBeRedrawn;
        };
        if (toolProps.configuration?.getTextLines) {
            this.configuration.getTextLines = toolProps.configuration.getTextLines;
        }
        if (toolProps.configuration?.statsCalculator) {
            this.configuration.statsCalculator =
                toolProps.configuration.statsCalculator;
        }
    }
    static createAnnotation(...annotationBaseData) {
        let annotation = {
            annotationUID: null,
            highlighted: true,
            invalidated: true,
            metadata: {
                toolName: this.toolName,
            },
            data: {
                text: '',
                handles: {
                    points: new Array(),
                    textBox: {
                        hasMoved: false,
                        worldPosition: [0, 0, 0],
                        worldBoundingBox: {
                            topLeft: [0, 0, 0],
                            topRight: [0, 0, 0],
                            bottomLeft: [0, 0, 0],
                            bottomRight: [0, 0, 0],
                        },
                    },
                },
                label: '',
            },
        };
        for (const baseData of annotationBaseData) {
            annotation = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(annotation, baseData);
        }
        return annotation;
    }
    static createAnnotationForViewport(viewport, ...annotationBaseData) {
        return this.createAnnotation({ metadata: viewport.getViewReference() }, ...annotationBaseData);
    }
    static createAndAddAnnotation(viewport, ...annotationBaseData) {
        const annotation = this.createAnnotationForViewport(viewport, ...annotationBaseData);
        (0,_stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_5__.addAnnotation)(annotation, viewport.element);
        (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_6__/* .triggerAnnotationModified */ .XF)(annotation, viewport.element);
    }
    getHandleNearImagePoint(element, annotation, canvasCoords, proximity) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const { data } = annotation;
        const { isCanvasAnnotation } = data;
        const { points, textBox } = data.handles;
        if (textBox) {
            const { worldBoundingBox } = textBox;
            if (worldBoundingBox) {
                const canvasBoundingBox = {
                    topLeft: viewport.worldToCanvas(worldBoundingBox.topLeft),
                    topRight: viewport.worldToCanvas(worldBoundingBox.topRight),
                    bottomLeft: viewport.worldToCanvas(worldBoundingBox.bottomLeft),
                    bottomRight: viewport.worldToCanvas(worldBoundingBox.bottomRight),
                };
                if (canvasCoords[0] >= canvasBoundingBox.topLeft[0] &&
                    canvasCoords[0] <= canvasBoundingBox.bottomRight[0] &&
                    canvasCoords[1] >= canvasBoundingBox.topLeft[1] &&
                    canvasCoords[1] <= canvasBoundingBox.bottomRight[1]) {
                    data.handles.activeHandleIndex = null;
                    return textBox;
                }
            }
        }
        for (let i = 0; i < points?.length; i++) {
            const point = points[i];
            const annotationCanvasCoordinate = isCanvasAnnotation
                ? point.slice(0, 2)
                : viewport.worldToCanvas(point);
            const near = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec2.distance */ .Zc.distance(canvasCoords, annotationCanvasCoordinate) < proximity;
            if (near === true) {
                data.handles.activeHandleIndex = i;
                return point;
            }
        }
        data.handles.activeHandleIndex = null;
    }
    getLinkedTextBoxStyle(specifications, annotation) {
        return {
            visibility: this.getStyle('textBoxVisibility', specifications, annotation),
            fontFamily: this.getStyle('textBoxFontFamily', specifications, annotation),
            fontSize: this.getStyle('textBoxFontSize', specifications, annotation),
            color: this.getStyle('textBoxColor', specifications, annotation),
            shadow: this.getStyle('textBoxShadow', specifications, annotation),
            background: this.getStyle('textBoxBackground', specifications, annotation),
            lineWidth: this.getStyle('textBoxLinkLineWidth', specifications, annotation),
            lineDash: this.getStyle('textBoxLinkLineDash', specifications, annotation),
        };
    }
    isSuvScaled(viewport, targetId, imageId) {
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
            const volumeId = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getVolumeId(targetId);
            const volume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
            return volume?.scaling?.PT !== undefined;
        }
        const scalingModule = imageId && _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.metaData.get('scalingModule', imageId);
        return typeof scalingModule?.suvbw === 'number';
    }
    getAnnotationStyle(context) {
        const { annotation, styleSpecifier } = context;
        const getStyle = (property) => this.getStyle(property, styleSpecifier, annotation);
        const { annotationUID } = annotation;
        const visibility = (0,_stateManagement_annotation_annotationVisibility__WEBPACK_IMPORTED_MODULE_4__.isAnnotationVisible)(annotationUID);
        const locked = (0,_stateManagement_annotation_annotationLocking__WEBPACK_IMPORTED_MODULE_3__.isAnnotationLocked)(annotation);
        const lineWidth = getStyle('lineWidth');
        const lineDash = getStyle('lineDash');
        const color = getStyle('color');
        const shadow = getStyle('shadow');
        const textboxStyle = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
        return {
            visibility,
            locked,
            color,
            lineWidth,
            lineDash,
            lineOpacity: 1,
            fillColor: color,
            fillOpacity: 0,
            shadow,
            textbox: textboxStyle,
        };
    }
    _imagePointNearToolOrHandle(element, annotation, canvasCoords, proximity) {
        const handleNearImagePoint = this.getHandleNearImagePoint(element, annotation, canvasCoords, proximity);
        if (handleNearImagePoint) {
            return true;
        }
        const toolNewImagePoint = this.isPointNearTool(element, annotation, canvasCoords, proximity, 'mouse');
        if (toolNewImagePoint) {
            return true;
        }
    }
}
AnnotationTool.toolName = 'AnnotationTool';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AnnotationTool);


/***/ }),

/***/ 44350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export isValidLabelmapConfig */
const defaultLabelmapConfig = {
    renderOutline: true,
    outlineWidthActive: 3,
    outlineWidthInactive: 2,
    activeSegmentOutlineWidthDelta: 0,
    renderFill: true,
    renderFillInactive: true,
    fillAlpha: 0.7,
    fillAlphaInactive: 0.65,
    outlineOpacity: 1,
    outlineOpacityInactive: 0.85,
};
function getDefaultLabelmapConfig() {
    return defaultLabelmapConfig;
}
function isValidLabelmapConfig(config) {
    return (config &&
        typeof config.renderOutline === 'boolean' &&
        typeof config.outlineWidthActive === 'number' &&
        typeof config.outlineWidthInactive === 'number' &&
        typeof config.activeSegmentOutlineWidthDelta === 'number' &&
        typeof config.renderFill === 'boolean' &&
        typeof config.renderFillInactive === 'boolean' &&
        typeof config.fillAlpha === 'number' &&
        typeof config.fillAlphaInactive === 'number' &&
        typeof config.outlineOpacity === 'number' &&
        typeof config.outlineOpacityInactive === 'number');
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getDefaultLabelmapConfig);



/***/ }),

/***/ 81848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  M$: () => (/* reexport */ AdvancedMagnifyTool/* default */.A),
  EC: () => (/* reexport */ base/* AnnotationTool */.EC),
  PlanarFreehandContourSegmentationTool: () => (/* reexport */ PlanarFreehandContourSegmentationTool/* default */.A),
  ex: () => (/* reexport */ PlanarFreehandROITool/* default */.A),
  t0: () => (/* reexport */ SegmentationDisplayTool/* default */.A)
});

// UNUSED EXPORTS: AngleTool, AnnotationDisplayTool, ArrowAnnotateTool, BaseTool, BidirectionalTool, BrushTool, CircleROIStartEndThresholdTool, CircleROITool, CircleScissorsTool, CobbAngleTool, CrosshairsTool, DragProbeTool, EllipticalROITool, EraserTool, KeyImageTool, LengthTool, LivewireContourSegmentationTool, LivewireContourTool, MIPJumpToClickTool, MagnifyTool, OrientationMarkerTool, OverlayGridTool, PaintFillTool, PanTool, PlanarRotateTool, ProbeTool, RectangleROIStartEndThresholdTool, RectangleROIThresholdTool, RectangleROITool, RectangleScissorsTool, ReferenceCursors, ReferenceLines, ReferenceLinesTool, ScaleOverlayTool, SculptorTool, SegmentSelectTool, SegmentationIntersectionTool, SphereScissorsTool, SplineContourSegmentationTool, SplineROITool, StackScrollMouseWheelTool, StackScrollTool, TrackballRotateTool, UltrasoundDirectionalTool, VolumeRotateMouseWheelTool, WindowLevelRegionTool, WindowLevelTool, ZoomTool

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/base/index.js
var base = __webpack_require__(96214);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/PanTool.js
var PanTool = __webpack_require__(25294);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/TrackballRotateTool.js
var TrackballRotateTool = __webpack_require__(15924);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/WindowLevelTool.js
var WindowLevelTool = __webpack_require__(455);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/WindowLevelRegionTool.js
var WindowLevelRegionTool = __webpack_require__(60747);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/StackScrollTool.js
var StackScrollTool = __webpack_require__(20132);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/PlanarRotateTool.js
var PlanarRotateTool = __webpack_require__(15354);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/StackScrollToolMouseWheelTool.js
var StackScrollToolMouseWheelTool = __webpack_require__(57008);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ZoomTool.js
var ZoomTool = __webpack_require__(20842);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/VolumeRotateMouseWheelTool.js
var VolumeRotateMouseWheelTool = __webpack_require__(94574);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/MIPJumpToClickTool.js
var MIPJumpToClickTool = __webpack_require__(57424);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/CrosshairsTool.js
var CrosshairsTool = __webpack_require__(91976);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/MagnifyTool.js
var MagnifyTool = __webpack_require__(93970);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/AdvancedMagnifyTool.js
var AdvancedMagnifyTool = __webpack_require__(73168);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ReferenceLinesTool.js
var ReferenceLinesTool = __webpack_require__(54541);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/OverlayGridTool.js
var OverlayGridTool = __webpack_require__(87841);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/SegmentationIntersectionTool.js
var SegmentationIntersectionTool = __webpack_require__(70494);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ReferenceCursors.js
var ReferenceCursors = __webpack_require__(1143);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/ScaleOverlayTool.js
var ScaleOverlayTool = __webpack_require__(92807);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/SculptorTool.js
var SculptorTool = __webpack_require__(16151);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/BidirectionalTool.js
var BidirectionalTool = __webpack_require__(50720);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LengthTool.js
var LengthTool = __webpack_require__(72655);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/ProbeTool.js
var ProbeTool = __webpack_require__(30049);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/DragProbeTool.js
var DragProbeTool = __webpack_require__(28087);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/RectangleROITool.js
var RectangleROITool = __webpack_require__(19994);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/EllipticalROITool.js
var EllipticalROITool = __webpack_require__(19116);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/CircleROITool.js
var CircleROITool = __webpack_require__(42865);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/SplineROITool.js
var SplineROITool = __webpack_require__(42058);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/SplineContourSegmentationTool.js
var SplineContourSegmentationTool = __webpack_require__(67540);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/PlanarFreehandROITool.js
var PlanarFreehandROITool = __webpack_require__(39244);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/PlanarFreehandContourSegmentationTool.js
var PlanarFreehandContourSegmentationTool = __webpack_require__(20070);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LivewireContourTool.js
var LivewireContourTool = __webpack_require__(19904);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/LivewireContourSegmentationTool.js
var LivewireContourSegmentationTool = __webpack_require__(88854);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/ArrowAnnotateTool.js
var ArrowAnnotateTool = __webpack_require__(65314);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/AngleTool.js
var AngleTool = __webpack_require__(1368);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/CobbAngleTool.js
var CobbAngleTool = __webpack_require__(40310);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/UltrasoundDirectionalTool.js
var UltrasoundDirectionalTool = __webpack_require__(95608);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/annotation/KeyImageTool.js
var KeyImageTool = __webpack_require__(72799);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/AnnotationEraserTool.js
var AnnotationEraserTool = __webpack_require__(7336);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/displayTools/SegmentationDisplayTool.js
var SegmentationDisplayTool = __webpack_require__(31163);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleScissorsTool.js
var RectangleScissorsTool = __webpack_require__(81502);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/CircleScissorsTool.js
var CircleScissorsTool = __webpack_require__(34229);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/SphereScissorsTool.js
var SphereScissorsTool = __webpack_require__(55108);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/index.js
var stateManagement = __webpack_require__(95778);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/annotationLocking.js
var annotationLocking = __webpack_require__(48428);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/index.js + 18 modules
var drawingSvg = __webpack_require__(49574);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js + 4 modules
var viewportFilters = __webpack_require__(90252);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/elementCursor.js
var elementCursor = __webpack_require__(40233);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForViewportIds.js
var triggerAnnotationRenderForViewportIds = __webpack_require__(23072);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/annotationVisibility.js
var annotationVisibility = __webpack_require__(21009);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/annotation/helpers/state.js
var state = __webpack_require__(54177);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleROIThresholdTool.js










class RectangleROIThresholdTool extends RectangleROITool/* default */.A {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            shadow: true,
            preventHandleOutsideImage: false,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const worldPos = currentPoints.world;
            const enabledElement = (0,esm.getEnabledElement)(element);
            const { viewport, renderingEngine } = enabledElement;
            this.isDrawing = true;
            const camera = viewport.getCamera();
            const { viewPlaneNormal, viewUp } = camera;
            const targetId = this.getTargetId(viewport);
            let referencedImageId, volumeId;
            if (viewport instanceof esm.StackViewport) {
                referencedImageId = targetId.split('imageId:')[1];
            }
            else {
                volumeId = esm.utilities.getVolumeId(targetId);
                const imageVolume = esm.cache.getVolume(volumeId);
                referencedImageId = esm.utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
            }
            const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
            const annotation = {
                highlighted: true,
                invalidated: true,
                metadata: {
                    viewPlaneNormal: [...viewPlaneNormal],
                    enabledElement,
                    viewUp: [...viewUp],
                    FrameOfReferenceUID,
                    referencedImageId,
                    toolName: this.getToolName(),
                    volumeId,
                },
                data: {
                    label: '',
                    handles: {
                        textBox: {
                            hasMoved: false,
                            worldPosition: null,
                            worldBoundingBox: null,
                        },
                        points: [
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                        ],
                        activeHandleIndex: null,
                    },
                    segmentationId: null,
                },
            };
            (0,stateManagement/* addAnnotation */.lC)(annotation, element);
            const viewportIdsToRender = (0,viewportFilters.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex: 3,
                newAnnotation: true,
                hasMoved: false,
            };
            this._activateDraw(element);
            (0,elementCursor.hideElementCursor)(element);
            evt.preventDefault();
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = false;
            const { viewport } = enabledElement;
            const { element } = viewport;
            let annotations = (0,stateManagement/* getAnnotations */.Rh)(this.getToolName(), element);
            if (!annotations?.length) {
                return renderStatus;
            }
            annotations = this.filterInteractableAnnotationsForElement(element, annotations);
            if (!annotations?.length) {
                return renderStatus;
            }
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const lineWidth = this.getStyle('lineWidth', styleSpecifier, annotation);
                const lineDash = this.getStyle('lineDash', styleSpecifier, annotation);
                const color = this.getStyle('color', styleSpecifier, annotation);
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                (0,state/* triggerAnnotationModified */.XF)(annotation, element);
                let activeHandleCanvasCoords;
                if (!(0,annotationVisibility.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,annotationLocking.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,drawingSvg.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                const rectangleUID = '0';
                (0,drawingSvg.drawRect)(svgDrawingHelper, annotationUID, rectangleUID, canvasCoordinates[0], canvasCoordinates[3], {
                    color,
                    lineDash,
                    lineWidth,
                });
                renderStatus = true;
            }
            return renderStatus;
        };
    }
}
RectangleROIThresholdTool.toolName = 'RectangleROIThreshold';
/* harmony default export */ const segmentation_RectangleROIThresholdTool = ((/* unused pure expression or super */ null && (RectangleROIThresholdTool)));

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var gl_matrix_esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/throttle.js
var throttle = __webpack_require__(21090);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js + 1 modules
var utilities = __webpack_require__(74119);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/RectangleROIStartEndThresholdTool.js














const { transformWorldToIndex } = esm.utilities;
class RectangleROIStartEndThresholdTool extends RectangleROITool/* default */.A {
    constructor(toolProps = {}, defaultToolProps = {
        configuration: {
            numSlicesToPropagate: 10,
            computePointsInsideVolume: false,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { currentPoints, element } = eventDetail;
            const worldPos = currentPoints.world;
            const enabledElement = (0,esm.getEnabledElement)(element);
            const { viewport, renderingEngine } = enabledElement;
            this.isDrawing = true;
            const camera = viewport.getCamera();
            const { viewPlaneNormal, viewUp } = camera;
            let referencedImageId, imageVolume, volumeId;
            if (viewport instanceof esm.StackViewport) {
                throw new Error('Stack Viewport Not implemented');
            }
            else {
                const targetId = this.getTargetId(viewport);
                volumeId = esm.utilities.getVolumeId(targetId);
                imageVolume = esm.cache.getVolume(volumeId);
                referencedImageId = esm.utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
            }
            if (!referencedImageId) {
                throw new Error('This tool does not work on non-acquisition planes');
            }
            const startIndex = viewport.getCurrentImageIdIndex();
            const spacingInNormal = esm.utilities.getSpacingInNormalDirection(imageVolume, viewPlaneNormal);
            const endIndex = this._getEndSliceIndex(imageVolume, worldPos, spacingInNormal, viewPlaneNormal);
            const FrameOfReferenceUID = viewport.getFrameOfReferenceUID();
            const annotation = {
                highlighted: true,
                invalidated: true,
                metadata: {
                    viewPlaneNormal: [...viewPlaneNormal],
                    enabledElement,
                    viewUp: [...viewUp],
                    FrameOfReferenceUID,
                    referencedImageId,
                    toolName: this.getToolName(),
                    volumeId,
                    spacingInNormal,
                },
                data: {
                    label: '',
                    startSlice: startIndex,
                    endSlice: endIndex,
                    cachedStats: {
                        pointsInVolume: [],
                        projectionPoints: [],
                        projectionPointsImageIds: [referencedImageId],
                    },
                    handles: {
                        textBox: {
                            hasMoved: false,
                            worldPosition: null,
                            worldBoundingBox: null,
                        },
                        points: [
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                            [...worldPos],
                        ],
                        activeHandleIndex: null,
                    },
                    labelmapUID: null,
                },
            };
            this._computeProjectionPoints(annotation, imageVolume);
            (0,stateManagement/* addAnnotation */.lC)(annotation, element);
            const viewportIdsToRender = (0,viewportFilters.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.editData = {
                annotation,
                viewportIdsToRender,
                handleIndex: 3,
                newAnnotation: true,
                hasMoved: false,
            };
            this._activateDraw(element);
            (0,elementCursor.hideElementCursor)(element);
            evt.preventDefault();
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this._endCallback = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const { annotation, viewportIdsToRender, newAnnotation, hasMoved } = this.editData;
            const { data } = annotation;
            if (newAnnotation && !hasMoved) {
                return;
            }
            data.handles.activeHandleIndex = null;
            this._deactivateModify(element);
            this._deactivateDraw(element);
            (0,elementCursor.resetElementCursor)(element);
            const enabledElement = (0,esm.getEnabledElement)(element);
            this.editData = null;
            this.isDrawing = false;
            if (this.isHandleOutsideImage &&
                this.configuration.preventHandleOutsideImage) {
                (0,stateManagement/* removeAnnotation */.O8)(annotation.annotationUID);
            }
            const targetId = this.getTargetId(enabledElement.viewport);
            const imageVolume = esm.cache.getVolume(targetId.split(/volumeId:|\?/)[1]);
            if (this.configuration.calculatePointsInsideVolume) {
                this._computePointsInsideVolume(annotation, imageVolume, enabledElement);
            }
            (0,triggerAnnotationRenderForViewportIds/* default */.A)(enabledElement.renderingEngine, viewportIdsToRender);
            if (newAnnotation) {
                (0,state/* triggerAnnotationCompleted */.dZ)(annotation);
            }
        };
        this.renderAnnotation = (enabledElement, svgDrawingHelper) => {
            let renderStatus = false;
            const { viewport } = enabledElement;
            const annotations = (0,stateManagement/* getAnnotations */.Rh)(this.getToolName(), viewport.element);
            if (!annotations?.length) {
                return renderStatus;
            }
            const sliceIndex = viewport.getCurrentImageIdIndex();
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            for (let i = 0; i < annotations.length; i++) {
                const annotation = annotations[i];
                const { annotationUID, data } = annotation;
                const { startSlice, endSlice } = data;
                const { points, activeHandleIndex } = data.handles;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                styleSpecifier.annotationUID = annotationUID;
                const lineWidth = this.getStyle('lineWidth', styleSpecifier, annotation);
                const lineDash = this.getStyle('lineDash', styleSpecifier, annotation);
                const color = this.getStyle('color', styleSpecifier, annotation);
                if (sliceIndex < Math.min(startSlice, endSlice) ||
                    sliceIndex > Math.max(startSlice, endSlice)) {
                    continue;
                }
                if (annotation.invalidated) {
                    this._throttledCalculateCachedStats(annotation, enabledElement);
                }
                let firstOrLastSlice = false;
                if (sliceIndex === startSlice || sliceIndex === endSlice) {
                    firstOrLastSlice = true;
                }
                if (!viewport.getRenderingEngine()) {
                    console.warn('Rendering Engine has been destroyed');
                    return renderStatus;
                }
                let activeHandleCanvasCoords;
                if (!(0,annotationVisibility.isAnnotationVisible)(annotationUID)) {
                    continue;
                }
                if (!(0,annotationLocking.isAnnotationLocked)(annotation) &&
                    !this.editData &&
                    activeHandleIndex !== null &&
                    firstOrLastSlice) {
                    activeHandleCanvasCoords = [canvasCoordinates[activeHandleIndex]];
                }
                if (activeHandleCanvasCoords) {
                    const handleGroupUID = '0';
                    (0,drawingSvg.drawHandles)(svgDrawingHelper, annotationUID, handleGroupUID, activeHandleCanvasCoords, {
                        color,
                    });
                }
                let lineDashToUse = lineDash;
                if (!firstOrLastSlice) {
                    lineDashToUse = 2;
                }
                const rectangleUID = '0';
                (0,drawingSvg.drawRect)(svgDrawingHelper, annotationUID, rectangleUID, canvasCoordinates[0], canvasCoordinates[3], {
                    color,
                    lineDash: lineDashToUse,
                    lineWidth,
                });
                renderStatus = true;
            }
            return renderStatus;
        };
        this._throttledCalculateCachedStats = (0,throttle/* default */.A)(this._calculateCachedStatsTool, 100, { trailing: true });
    }
    _computeProjectionPoints(annotation, imageVolume) {
        const { data, metadata } = annotation;
        const { viewPlaneNormal, spacingInNormal } = metadata;
        const { imageData } = imageVolume;
        const { startSlice, endSlice } = data;
        const { points } = data.handles;
        const startIJK = transformWorldToIndex(imageData, points[0]);
        if (startIJK[2] !== startSlice) {
            throw new Error('Start slice does not match');
        }
        const endIJK = gl_matrix_esm/* vec3.fromValues */.eR.fromValues(startIJK[0], startIJK[1], endSlice);
        const startWorld = gl_matrix_esm/* vec3.create */.eR.create();
        imageData.indexToWorldVec3(startIJK, startWorld);
        const endWorld = gl_matrix_esm/* vec3.create */.eR.create();
        imageData.indexToWorldVec3(endIJK, endWorld);
        const distance = gl_matrix_esm/* vec3.distance */.eR.distance(startWorld, endWorld);
        const newProjectionPoints = [];
        for (let dist = 0; dist < distance; dist += spacingInNormal) {
            newProjectionPoints.push(points.map((point) => {
                const newPoint = gl_matrix_esm/* vec3.create */.eR.create();
                gl_matrix_esm/* vec3.scaleAndAdd */.eR.scaleAndAdd(newPoint, point, viewPlaneNormal, dist);
                return Array.from(newPoint);
            }));
        }
        data.cachedStats.projectionPoints = newProjectionPoints;
        const projectionPointsImageIds = [];
        for (const RectanglePoints of newProjectionPoints) {
            const imageId = esm.utilities.getClosestImageId(imageVolume, RectanglePoints[0], viewPlaneNormal);
            projectionPointsImageIds.push(imageId);
        }
        data.cachedStats.projectionPointsImageIds = projectionPointsImageIds;
    }
    _computePointsInsideVolume(annotation, imageVolume, enabledElement) {
        const { data } = annotation;
        const projectionPoints = data.cachedStats.projectionPoints;
        const pointsInsideVolume = [[]];
        for (let i = 0; i < projectionPoints.length; i++) {
            if (!imageVolume) {
                continue;
            }
            const projectionPoint = projectionPoints[i][0];
            const worldPos1 = data.handles.points[0];
            const worldPos2 = data.handles.points[3];
            const { dimensions, imageData } = imageVolume;
            const worldPos1Index = transformWorldToIndex(imageData, worldPos1);
            const worldProjectionPointIndex = transformWorldToIndex(imageData, projectionPoint);
            worldPos1Index[0] = Math.floor(worldPos1Index[0]);
            worldPos1Index[1] = Math.floor(worldPos1Index[1]);
            worldPos1Index[2] = Math.floor(worldProjectionPointIndex[2]);
            const worldPos2Index = transformWorldToIndex(imageData, worldPos2);
            worldPos2Index[0] = Math.floor(worldPos2Index[0]);
            worldPos2Index[1] = Math.floor(worldPos2Index[1]);
            worldPos2Index[2] = Math.floor(worldProjectionPointIndex[2]);
            if (this._isInsideVolume(worldPos1Index, worldPos2Index, dimensions)) {
                this.isHandleOutsideImage = false;
                const iMin = Math.min(worldPos1Index[0], worldPos2Index[0]);
                const iMax = Math.max(worldPos1Index[0], worldPos2Index[0]);
                const jMin = Math.min(worldPos1Index[1], worldPos2Index[1]);
                const jMax = Math.max(worldPos1Index[1], worldPos2Index[1]);
                const kMin = Math.min(worldPos1Index[2], worldPos2Index[2]);
                const kMax = Math.max(worldPos1Index[2], worldPos2Index[2]);
                const boundsIJK = [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ];
                const pointsInShape = (0,utilities.pointInShapeCallback)(imageData, () => true, null, boundsIJK);
                pointsInsideVolume.push(pointsInShape);
            }
        }
        data.cachedStats.pointsInVolume = pointsInsideVolume;
    }
    _calculateCachedStatsTool(annotation, enabledElement) {
        const data = annotation.data;
        const { viewport } = enabledElement;
        const { cachedStats } = data;
        const targetId = this.getTargetId(viewport);
        const imageVolume = esm.cache.getVolume(targetId.split(/volumeId:|\?/)[1]);
        this._computeProjectionPoints(annotation, imageVolume);
        annotation.invalidated = false;
        (0,state/* triggerAnnotationModified */.XF)(annotation, viewport.element);
        return cachedStats;
    }
    _getEndSliceIndex(imageVolume, worldPos, spacingInNormal, viewPlaneNormal) {
        const numSlicesToPropagate = this.configuration.numSlicesToPropagate;
        const endPos = gl_matrix_esm/* vec3.create */.eR.create();
        gl_matrix_esm/* vec3.scaleAndAdd */.eR.scaleAndAdd(endPos, worldPos, viewPlaneNormal, numSlicesToPropagate * spacingInNormal);
        const halfSpacingInNormalDirection = spacingInNormal / 2;
        const { imageIds } = imageVolume;
        let imageIdIndex;
        for (let i = 0; i < imageIds.length; i++) {
            const imageId = imageIds[i];
            const { imagePositionPatient } = esm.metaData.get('imagePlaneModule', imageId);
            const dir = gl_matrix_esm/* vec3.create */.eR.create();
            gl_matrix_esm/* vec3.sub */.eR.sub(dir, endPos, imagePositionPatient);
            const dot = gl_matrix_esm/* vec3.dot */.eR.dot(dir, viewPlaneNormal);
            if (Math.abs(dot) < halfSpacingInNormalDirection) {
                imageIdIndex = i;
            }
        }
        return imageIdIndex;
    }
}
RectangleROIStartEndThresholdTool.toolName = 'RectangleROIStartEndThreshold';
/* harmony default export */ const segmentation_RectangleROIStartEndThresholdTool = ((/* unused pure expression or super */ null && (RectangleROIStartEndThresholdTool)));

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/CircleROIStartEndThresholdTool.js
var CircleROIStartEndThresholdTool = __webpack_require__(94932);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/BrushTool.js
var BrushTool = __webpack_require__(53712);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/PaintFillTool.js
var PaintFillTool = __webpack_require__(70817);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/OrientationMarkerTool.js
var OrientationMarkerTool = __webpack_require__(36129);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/segmentation/SegmentSelectTool.js
var SegmentSelectTool = __webpack_require__(34041);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/tools/index.js






















































/***/ }),

/***/ 41209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums_Events__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28117);


class AnnotationFrameRange {
    static { this.frameRangeExtractor = /(\/frames\/|[&?]frameNumber=)([^/&?]*)/i; }
    static imageIdToFrames(imageId) {
        const match = imageId.match(this.frameRangeExtractor);
        if (!match || !match[2]) {
            return null;
        }
        const range = match[2].split('-').map((it) => Number(it));
        if (range.length === 1) {
            return range[0];
        }
        return range;
    }
    static framesToString(range) {
        if (Array.isArray(range)) {
            return `${range[0]}-${range[1]}`;
        }
        return String(range);
    }
    static framesToImageId(imageId, range) {
        const match = imageId.match(this.frameRangeExtractor);
        if (!match || !match[2]) {
            return null;
        }
        const newRangeString = this.framesToString(range);
        return imageId.replace(this.frameRangeExtractor, `${match[1]}${newRangeString}`);
    }
    static setFrameRange(annotation, range, eventBase) {
        const { referencedImageId } = annotation.metadata;
        annotation.metadata.referencedImageId = this.framesToImageId(referencedImageId, range);
        const eventDetail = {
            ...eventBase,
            annotation,
        };
        (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.triggerEvent)(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _enums_Events__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.ANNOTATION_MODIFIED, eventDetail);
    }
    static getFrameRange(annotation) {
        return this.imageIdToFrames(annotation.metadata.referencedImageId);
    }
}


/***/ }),

/***/ 25781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ getClosestImageIdForStackViewport)
/* harmony export */ });
/* unused harmony export annotationHydration */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(95778);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(44753);



function annotationHydration(viewport, toolName, worldPoints, options) {
    const viewReference = viewport.getViewReference();
    const { viewPlaneNormal, FrameOfReferenceUID } = viewReference;
    const annotation = {
        annotationUID: options?.annotationUID || utilities.uuidv4(),
        data: {
            handles: {
                points: worldPoints,
            },
        },
        highlighted: false,
        autoGenerated: false,
        invalidated: false,
        isLocked: false,
        isVisible: true,
        metadata: {
            toolName,
            viewPlaneNormal,
            FrameOfReferenceUID,
            referencedImageId: getReferencedImageId(viewport, worldPoints[0], viewPlaneNormal),
            ...options,
        },
    };
    addAnnotation(annotation, viewport.element);
    return annotation;
}
function getReferencedImageId(viewport, worldPos, viewPlaneNormal) {
    let referencedImageId;
    if (viewport instanceof StackViewport) {
        referencedImageId = getClosestImageIdForStackViewport(viewport, worldPos, viewPlaneNormal);
    }
    else if (viewport instanceof BaseVolumeViewport) {
        const targetId = getTargetId(viewport);
        const volumeId = utilities.getVolumeId(targetId);
        const imageVolume = cache.getVolume(volumeId);
        referencedImageId = utilities.getClosestImageId(imageVolume, worldPos, viewPlaneNormal);
    }
    else {
        throw new Error('getReferencedImageId: viewport must be a StackViewport or BaseVolumeViewport');
    }
    return referencedImageId;
}
function getTargetId(viewport) {
    const targetId = viewport.getReferenceId?.();
    if (targetId) {
        return targetId;
    }
    if (viewport instanceof BaseVolumeViewport) {
        return `volumeId:${getTargetVolumeId(viewport)}`;
    }
    throw new Error('getTargetId: viewport must have a getTargetId method');
}
function getTargetVolumeId(viewport) {
    const actorEntries = viewport.getActors();
    if (!actorEntries) {
        return;
    }
    return actorEntries.find((actorEntry) => actorEntry.actor.getClassName() === 'vtkVolume')?.uid;
}
function getClosestImageIdForStackViewport(viewport, worldPos, viewPlaneNormal) {
    const imageIds = viewport.getImageIds();
    if (!imageIds || !imageIds.length) {
        return;
    }
    const distanceImagePairs = imageIds.map((imageId) => {
        const { imagePositionPatient } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.metaData.get('imagePlaneModule', imageId);
        const distance = calculateDistanceToImage(worldPos, imagePositionPatient, viewPlaneNormal);
        return { imageId, distance };
    });
    distanceImagePairs.sort((a, b) => a.distance - b.distance);
    return distanceImagePairs[0].imageId;
}
function calculateDistanceToImage(worldPos, ImagePositionPatient, viewPlaneNormal) {
    const dir = gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.sub */ .eR.sub(dir, worldPos, ImagePositionPatient);
    const dot = gl_matrix__WEBPACK_IMPORTED_MODULE_2__/* .vec3.dot */ .eR.dot(dir, viewPlaneNormal);
    return Math.abs(dot);
}



/***/ }),

/***/ 42290:
/***/ (() => {

function extend2DBoundingBoxInViewAxis(boundsIJK, numSlicesToProject) {
    const sliceNormalIndex = boundsIJK.findIndex(([min, max]) => min === max);
    if (sliceNormalIndex === -1) {
        throw new Error('3D bounding boxes not supported in an oblique plane');
    }
    boundsIJK[sliceNormalIndex][0] -= numSlicesToProject;
    boundsIJK[sliceNormalIndex][1] += numSlicesToProject;
    return boundsIJK;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (extend2DBoundingBoxInViewAxis)));


/***/ }),

/***/ 14471:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ getBoundingBoxAroundShapeWorld),
/* harmony export */   g: () => (/* binding */ getBoundingBoxAroundShapeIJK)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { EPSILON } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.CONSTANTS;
function calculateBoundingBox(points, dimensions, isWorld = false) {
    let xMin = Infinity;
    let xMax = isWorld ? -Infinity : 0;
    let yMin = Infinity;
    let yMax = isWorld ? -Infinity : 0;
    let zMin = Infinity;
    let zMax = isWorld ? -Infinity : 0;
    const is3D = points[0]?.length === 3;
    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        xMin = Math.min(p[0], xMin);
        xMax = Math.max(p[0], xMax);
        yMin = Math.min(p[1], yMin);
        yMax = Math.max(p[1], yMax);
        if (is3D) {
            zMin = Math.min(p[2] ?? zMin, zMin);
            zMax = Math.max(p[2] ?? zMax, zMax);
        }
    }
    if (dimensions) {
        xMin = Math.max(isWorld ? dimensions[0] + EPSILON : 0, xMin);
        xMax = Math.min(isWorld ? dimensions[0] - EPSILON : dimensions[0] - 1, xMax);
        yMin = Math.max(isWorld ? dimensions[1] + EPSILON : 0, yMin);
        yMax = Math.min(isWorld ? dimensions[1] - EPSILON : dimensions[1] - 1, yMax);
        if (is3D && dimensions.length === 3) {
            zMin = Math.max(isWorld ? dimensions[2] + EPSILON : 0, zMin);
            zMax = Math.min(isWorld ? dimensions[2] - EPSILON : dimensions[2] - 1, zMax);
        }
    }
    else if (!isWorld) {
        xMin = Math.max(0, xMin);
        xMax = Math.min(Infinity, xMax);
        yMin = Math.max(0, yMin);
        yMax = Math.min(Infinity, yMax);
        if (is3D) {
            zMin = Math.max(0, zMin);
            zMax = Math.min(Infinity, zMax);
        }
    }
    return is3D
        ? [
            [xMin, xMax],
            [yMin, yMax],
            [zMin, zMax],
        ]
        : [[xMin, xMax], [yMin, yMax], null];
}
function getBoundingBoxAroundShapeIJK(points, dimensions) {
    return calculateBoundingBox(points, dimensions, false);
}
function getBoundingBoxAroundShapeWorld(points, clipBounds) {
    return calculateBoundingBox(points, clipBounds, true);
}


/***/ }),

/***/ 15306:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getBoundingBoxAroundShapeIJK: () => (/* reexport safe */ _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__.g),
/* harmony export */   getBoundingBoxAroundShapeWorld: () => (/* reexport safe */ _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__.C)
/* harmony export */ });
/* harmony import */ var _extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42290);
/* harmony import */ var _getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14471);





/***/ }),

/***/ 17167:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { calibratedPixelSpacingMetadataProvider } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function calibrateImageSpacing(imageId, renderingEngine, calibrationOrScale) {
    if (typeof calibrationOrScale === 'number') {
        calibrationOrScale = {
            type: Enums.CalibrationTypes.USER,
            scale: calibrationOrScale,
        };
    }
    calibratedPixelSpacingMetadataProvider.add(imageId, calibrationOrScale);
    const viewports = renderingEngine.getStackViewports();
    viewports.forEach((viewport) => {
        const imageIds = viewport.getImageIds();
        if (imageIds.includes(imageId)) {
            viewport.calibrateSpacing(imageId);
        }
    });
}


/***/ }),

/***/ 60001:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: Events, addToolState, getToolState, playClip, stopClip

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/events.js
var Events;
(function (Events) {
    Events["CLIP_STOPPED"] = "CORNERSTONE_CINE_TOOL_STOPPED";
    Events["CLIP_STARTED"] = "CORNERSTONE_CINE_TOOL_STARTED";
})(Events || (Events = {}));
/* harmony default export */ const events = ((/* unused pure expression or super */ null && (Events)));

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/state.js

const state = {};
function state_addToolState(element, data) {
    const enabledElement = getEnabledElement(element);
    const { viewportId } = enabledElement;
    state[viewportId] = data;
}
function state_getToolState(element) {
    const enabledElement = getEnabledElement(element);
    const { viewportId } = enabledElement;
    return state[viewportId];
}
function state_getToolStateByViewportId(viewportId) {
    return state[viewportId];
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/scroll.js
var utilities_scroll = __webpack_require__(21783);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/playClip.js





const { ViewportStatus } = dist_esm.Enums;
const { triggerEvent } = dist_esm.utilities;
const debounced = true;
const dynamicVolumesPlayingMap = new Map();
function playClip(element, playClipOptions) {
    let playClipTimeouts;
    let playClipIsTimeVarying;
    if (element === undefined) {
        throw new Error('playClip: element must not be undefined');
    }
    const enabledElement = getEnabledElement(element);
    if (!enabledElement) {
        throw new Error('playClip: element must be a valid Cornerstone enabled element');
    }
    if (!playClipOptions) {
        playClipOptions = {};
    }
    playClipOptions.dynamicCineEnabled =
        playClipOptions.dynamicCineEnabled ?? true;
    const { viewport } = enabledElement;
    const volume = _getVolumeFromViewport(viewport);
    const playClipContext = _createCinePlayContext(viewport, playClipOptions);
    let playClipData = getToolState(element);
    const isDynamicCinePlaying = playClipOptions.dynamicCineEnabled && volume?.isDynamicVolume();
    if (isDynamicCinePlaying) {
        _stopDynamicVolumeCine(element);
    }
    if (!playClipData) {
        playClipData = {
            intervalId: undefined,
            framesPerSecond: 30,
            lastFrameTimeStamp: undefined,
            ignoreFrameTimeVector: false,
            usingFrameTimeVector: false,
            frameTimeVector: playClipOptions.frameTimeVector ?? undefined,
            speed: playClipOptions.frameTimeVectorSpeedMultiplier ?? 1,
            reverse: playClipOptions.reverse ?? false,
            loop: playClipOptions.loop ?? true,
        };
        addToolState(element, playClipData);
    }
    else {
        _stopClip(element, {
            stopDynamicCine: !isDynamicCinePlaying,
            viewportId: viewport.id,
        });
    }
    playClipData.dynamicCineEnabled = playClipOptions.dynamicCineEnabled;
    if (playClipOptions.framesPerSecond < 0 ||
        playClipOptions.framesPerSecond > 0) {
        playClipData.framesPerSecond = Number(playClipOptions.framesPerSecond);
        playClipData.reverse = playClipData.framesPerSecond < 0;
        playClipData.ignoreFrameTimeVector = true;
    }
    if (playClipData.ignoreFrameTimeVector !== true &&
        playClipData.frameTimeVector &&
        playClipData.frameTimeVector.length === playClipContext.numScrollSteps &&
        playClipContext.frameTimeVectorEnabled) {
        const { timeouts, isTimeVarying } = _getPlayClipTimeouts(playClipData.frameTimeVector, playClipData.speed);
        playClipTimeouts = timeouts;
        playClipIsTimeVarying = isTimeVarying;
    }
    const playClipAction = () => {
        const { numScrollSteps, currentStepIndex } = playClipContext;
        let newStepIndex = currentStepIndex + (playClipData.reverse ? -1 : 1);
        const newStepIndexOutOfRange = newStepIndex < 0 || newStepIndex >= numScrollSteps;
        if (!playClipData.loop && newStepIndexOutOfRange) {
            _stopClip(element, {
                stopDynamicCine: !isDynamicCinePlaying,
                viewportId: viewport.id,
            });
            const eventDetail = { element };
            triggerEvent(element, CINE_EVENTS.CLIP_STOPPED, eventDetail);
            return;
        }
        if (newStepIndex >= numScrollSteps) {
            newStepIndex = 0;
        }
        else if (newStepIndex < 0) {
            newStepIndex = numScrollSteps - 1;
        }
        const delta = newStepIndex - currentStepIndex;
        if (delta) {
            playClipContext.scroll(delta);
        }
    };
    if (isDynamicCinePlaying) {
        dynamicVolumesPlayingMap.set(volume.volumeId, element);
    }
    if (playClipTimeouts &&
        playClipTimeouts.length > 0 &&
        playClipIsTimeVarying) {
        playClipData.usingFrameTimeVector = true;
        playClipData.intervalId = window.setTimeout(function playClipTimeoutHandler() {
            playClipData.intervalId = window.setTimeout(playClipTimeoutHandler, playClipTimeouts[playClipContext.currentStepIndex]);
            playClipAction();
        }, 0);
    }
    else {
        playClipData.usingFrameTimeVector = false;
        playClipData.intervalId = window.setInterval(playClipAction, 1000 / Math.abs(playClipData.framesPerSecond));
    }
    const eventDetail = {
        element,
    };
    triggerEvent(element, CINE_EVENTS.CLIP_STARTED, eventDetail);
}
function stopClip(element, options = {}) {
    _stopClip(element, {
        stopDynamicCine: true,
        ...options,
    });
}
function _stopClip(element, options = { stopDynamicCine: true, viewportId: undefined }) {
    const { stopDynamicCine, viewportId } = options;
    const enabledElement = getEnabledElement(element);
    let toolState;
    if (!enabledElement) {
        if (viewportId) {
            toolState = getToolStateByViewportId(viewportId);
        }
        else {
            return;
        }
    }
    else {
        const { viewport } = enabledElement;
        toolState = getToolState(viewport.element);
    }
    if (toolState) {
        _stopClipWithData(toolState);
    }
    if (stopDynamicCine &&
        enabledElement?.viewport instanceof BaseVolumeViewport) {
        _stopDynamicVolumeCine(element);
    }
}
function _stopDynamicVolumeCine(element) {
    const { viewport } = getEnabledElement(element);
    const volume = _getVolumeFromViewport(viewport);
    if (volume?.isDynamicVolume()) {
        const dynamicCineElement = dynamicVolumesPlayingMap.get(volume.volumeId);
        dynamicVolumesPlayingMap.delete(volume.volumeId);
        if (dynamicCineElement && dynamicCineElement !== element) {
            stopClip(dynamicCineElement);
        }
    }
}
function _getPlayClipTimeouts(vector, speed) {
    let i;
    let sample;
    let delay;
    let sum = 0;
    const limit = vector.length;
    const timeouts = [];
    let isTimeVarying = false;
    if (typeof speed !== 'number' || speed <= 0) {
        speed = 1;
    }
    for (i = 1; i < limit; i++) {
        delay = (Number(vector[i]) / speed) | 0;
        timeouts.push(delay);
        if (i === 1) {
            sample = delay;
        }
        else if (delay !== sample) {
            isTimeVarying = true;
        }
        sum += delay;
    }
    if (timeouts.length > 0) {
        if (isTimeVarying) {
            delay = (sum / timeouts.length) | 0;
        }
        else {
            delay = timeouts[0];
        }
        timeouts.push(delay);
    }
    return { timeouts, isTimeVarying };
}
function _stopClipWithData(playClipData) {
    const id = playClipData.intervalId;
    if (typeof id !== 'undefined') {
        playClipData.intervalId = undefined;
        if (playClipData.usingFrameTimeVector) {
            clearTimeout(id);
        }
        else {
            clearInterval(id);
        }
    }
}
function _getVolumesFromViewport(viewport) {
    return viewport
        .getActors()
        .map((actor) => cache.getVolume(actor.uid))
        .filter((volume) => !!volume);
}
function _getVolumeFromViewport(viewport) {
    const volumes = _getVolumesFromViewport(viewport);
    const dynamicVolume = volumes.find((volume) => volume.isDynamicVolume());
    return dynamicVolume ?? volumes[0];
}
function _createStackViewportCinePlayContext(viewport, waitForRendered) {
    const imageIds = viewport.getImageIds();
    return {
        get numScrollSteps() {
            return imageIds.length;
        },
        get currentStepIndex() {
            return viewport.getTargetImageIdIndex();
        },
        get frameTimeVectorEnabled() {
            return true;
        },
        waitForRenderedCount: 0,
        scroll(delta) {
            if (this.waitForRenderedCount <= waitForRendered &&
                viewport.viewportStatus !== ViewportStatus.RENDERED) {
                this.waitForRenderedCount++;
                return;
            }
            this.waitForRenderedCount = 0;
            scroll(viewport, { delta, debounceLoading: debounced });
        },
    };
}
function _createVolumeViewportCinePlayContext(viewport, volume) {
    const { volumeId } = volume;
    const cachedScrollInfo = {
        viewPlaneNormal: vec3.create(),
        scrollInfo: null,
    };
    const getScrollInfo = () => {
        const camera = viewport.getCamera();
        const updateCache = !cachedScrollInfo.scrollInfo ||
            !vec3.equals(camera.viewPlaneNormal, cachedScrollInfo.viewPlaneNormal);
        if (updateCache) {
            const scrollInfo = csUtils.getVolumeViewportScrollInfo(viewport, volumeId);
            cachedScrollInfo.viewPlaneNormal = camera.viewPlaneNormal;
            cachedScrollInfo.scrollInfo = scrollInfo;
        }
        return cachedScrollInfo.scrollInfo;
    };
    return {
        get numScrollSteps() {
            return getScrollInfo().numScrollSteps;
        },
        get currentStepIndex() {
            return getScrollInfo().currentStepIndex;
        },
        get frameTimeVectorEnabled() {
            const camera = viewport.getCamera();
            const volumeViewPlaneNormal = volume.direction
                .slice(6, 9)
                .map((x) => -x);
            const dot = vec3.dot(volumeViewPlaneNormal, camera.viewPlaneNormal);
            return glMatrix.equals(dot, 1);
        },
        scroll(delta) {
            getScrollInfo().currentStepIndex += delta;
            scroll(viewport, { delta });
        },
    };
}
function _createDynamicVolumeViewportCinePlayContext(volume) {
    return {
        get numScrollSteps() {
            return volume.numTimePoints;
        },
        get currentStepIndex() {
            return volume.timePointIndex;
        },
        get frameTimeVectorEnabled() {
            return false;
        },
        scroll(delta) {
            volume.timePointIndex += delta;
        },
    };
}
function _createCinePlayContext(viewport, playClipOptions) {
    if (viewport instanceof StackViewport) {
        return _createStackViewportCinePlayContext(viewport, playClipOptions.waitForRendered ?? 30);
    }
    if (viewport instanceof VolumeViewport) {
        const volume = _getVolumeFromViewport(viewport);
        if (playClipOptions.dynamicCineEnabled && volume?.isDynamicVolume()) {
            return _createDynamicVolumeViewportCinePlayContext(volume);
        }
        return _createVolumeViewportCinePlayContext(viewport, volume);
    }
    throw new Error('Unknown viewport type');
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/index.js






/***/ }),

/***/ 88484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports clip, clipToBox */
function clip(val, low, high) {
    return Math.min(Math.max(low, val), high);
}
function clipToBox(point, box) {
    point.x = clip(point.x, 0, box.width);
    point.y = clip(point.y, 0, box.height);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clip);


/***/ }),

/***/ 32415:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ addContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30322);

function addContourSegmentationAnnotation(annotation) {
    if (annotation.parentAnnotationUID) {
        return;
    }
    if (!annotation.data.segmentation) {
        throw new Error('addContourSegmentationAnnotation: annotation does not have a segmentation data');
    }
    const { segmentationId, segmentIndex } = annotation.data.segmentation;
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_0__.getSegmentation)(segmentationId);
    if (!segmentation.representationData.CONTOUR) {
        segmentation.representationData.CONTOUR = { annotationUIDsMap: new Map() };
    }
    const { annotationUIDsMap } = segmentation.representationData.CONTOUR;
    let annotationsUIDsSet = annotationUIDsMap.get(segmentIndex);
    if (!annotationsUIDsSet) {
        annotationsUIDsSet = new Set();
        annotationUIDsMap.set(segmentIndex, annotationsUIDsSet);
    }
    annotationUIDsMap.set(segmentIndex, annotationsUIDsSet.add(annotation.annotationUID));
}


/***/ }),

/***/ 3030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
function areSameSegment(firstAnnotation, secondAnnotation) {
    const { segmentation: firstSegmentation } = firstAnnotation.data;
    const { segmentation: secondSegmentation } = secondAnnotation.data;
    return (firstSegmentation.segmentationId === secondSegmentation.segmentationId &&
        firstSegmentation.segmentIndex === secondSegmentation.segmentIndex);
}


/***/ }),

/***/ 7259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addContourSegmentationAnnotation: () => (/* reexport safe */ _addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_2__.V),
/* harmony export */   removeContourSegmentationAnnotation: () => (/* reexport safe */ _removeContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_3__.M)
/* harmony export */ });
/* harmony import */ var _areSameSegment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3030);
/* harmony import */ var _isContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84354);
/* harmony import */ var _addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32415);
/* harmony import */ var _removeContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78170);






/***/ }),

/***/ 84354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
function isContourSegmentationAnnotation(annotation) {
    return !!annotation.data?.segmentation;
}


/***/ }),

/***/ 78170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ removeContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63421);

function removeContourSegmentationAnnotation(annotation) {
    if (!annotation.data.segmentation) {
        throw new Error('removeContourSegmentationAnnotation: annotation does not have a segmentation data');
    }
    const { segmentationId, segmentIndex } = annotation.data.segmentation;
    const segmentation = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_0__.state.getSegmentation(segmentationId);
    const { annotationUIDsMap } = segmentation?.representationData.CONTOUR || {};
    const annotationsUIDsSet = annotationUIDsMap?.get(segmentIndex);
    if (!annotationsUIDsSet) {
        return;
    }
    annotationsUIDsSet.delete(annotation.annotationUID);
    if (!annotationsUIDsSet.size) {
        annotationUIDsMap.delete(segmentIndex);
    }
}


/***/ }),

/***/ 53891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function calculatePerimeter(polyline, closed) {
    let perimeter = 0;
    for (let i = 0; i < polyline.length - 1; i++) {
        const point1 = polyline[i];
        const point2 = polyline[i + 1];
        perimeter += Math.sqrt(Math.pow(point2[0] - point1[0], 2) + Math.pow(point2[1] - point1[1], 2));
    }
    if (closed) {
        const firstPoint = polyline[0];
        const lastPoint = polyline[polyline.length - 1];
        perimeter += Math.sqrt(Math.pow(lastPoint[0] - firstPoint[0], 2) +
            Math.pow(lastPoint[1] - firstPoint[1], 2));
    }
    return perimeter;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (calculatePerimeter);


/***/ }),

/***/ 84045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ findHandlePolylineIndex)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);


const { isEqual } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function findHandlePolylineIndex(annotation, handleIndex) {
    const { polyline } = annotation.data.contour;
    const { points } = annotation.data.handles;
    const { length } = points;
    if (handleIndex === length) {
        return polyline.length;
    }
    if (handleIndex < 0) {
        handleIndex = (handleIndex + length) % length;
    }
    if (handleIndex === 0) {
        return 0;
    }
    const handle = points[handleIndex];
    const index = polyline.findIndex((point) => isEqual(handle, point));
    if (index !== -1) {
        return index;
    }
    let closestDistance = Infinity;
    return polyline.reduce((closestIndex, point, testIndex) => {
        const distance = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.squaredDistance */ .eR.squaredDistance(point, handle);
        if (distance < closestDistance) {
            closestDistance = distance;
            return testIndex;
        }
        return closestIndex;
    }, -1);
}


/***/ }),

/***/ 75908:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  getContourHolesDataCanvas: () => (/* reexport */ getContourHolesDataCanvas),
  updateContourPolyline: () => (/* reexport */ updateContourPolyline/* default */.A)
});

// UNUSED EXPORTS: AnnotationToPointData, acceptAutogeneratedInterpolations, areCoplanarContours, calculatePerimeter, contourFinder, detectContourHoles, findHandlePolylineIndex, generateContourSetsFromLabelmap, getContourHolesDataWorld, getDeduplicatedVTKPolyDataPoints, interpolation

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/areCoplanarContours.js

function areCoplanarContours(firstAnnotation, secondAnnotation) {
    const { viewPlaneNormal: firstViewPlaneNormal } = firstAnnotation.metadata;
    const { viewPlaneNormal: secondViewPlaneNormal } = secondAnnotation.metadata;
    const dot = vec3.dot(firstViewPlaneNormal, secondViewPlaneNormal);
    const parallelPlanes = glMatrix.equals(1, Math.abs(dot));
    if (!parallelPlanes) {
        return false;
    }
    const { polyline: firstPolyline } = firstAnnotation.data.contour;
    const { polyline: secondPolyline } = secondAnnotation.data.contour;
    const firstDistance = vec3.dot(firstViewPlaneNormal, firstPolyline[0]);
    const secondDistance = vec3.dot(firstViewPlaneNormal, secondPolyline[0]);
    return glMatrix.equals(firstDistance, secondDistance);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/contourFinder.js
function findNextLink(line, lines, contourPoints) {
    let index = -1;
    lines.forEach((cell, i) => {
        if (index >= 0) {
            return;
        }
        if (cell.a == line.b) {
            index = i;
        }
    });
    if (index >= 0) {
        const nextLine = lines[index];
        lines.splice(index, 1);
        contourPoints.push(nextLine.b);
        if (contourPoints[0] == nextLine.b) {
            return {
                remainingLines: lines,
                contourPoints,
                type: 'CLOSED_PLANAR',
            };
        }
        return findNextLink(nextLine, lines, contourPoints);
    }
    return {
        remainingLines: lines,
        contourPoints,
        type: 'OPEN_PLANAR',
    };
}
function findContours(lines) {
    if (lines.length == 0) {
        return [];
    }
    const contourPoints = [];
    const firstCell = lines.shift();
    contourPoints.push(firstCell.a);
    contourPoints.push(firstCell.b);
    const result = findNextLink(firstCell, lines, contourPoints);
    if (result.remainingLines.length == 0) {
        return [
            {
                type: result.type,
                contourPoints: result.contourPoints,
            },
        ];
    }
    else {
        const extraContours = findContours(result.remainingLines);
        extraContours.push({
            type: result.type,
            contourPoints: result.contourPoints,
        });
        return extraContours;
    }
}
function contourFinder_findContoursFromReducedSet(lines) {
    return findContours(lines);
}
/* harmony default export */ const contourFinder = ({
    findContours,
    findContoursFromReducedSet: contourFinder_findContoursFromReducedSet,
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getDeduplicatedVTKPolyDataPoints.js
function getDeduplicatedVTKPolyDataPoints_getDeduplicatedVTKPolyDataPoints(polyData, bypass = false) {
    const points = polyData.getPoints();
    const lines = polyData.getLines();
    const pointsArray = new Array(points.getNumberOfPoints())
        .fill(0)
        .map((_, i) => points.getPoint(i).slice());
    const linesArray = new Array(lines.getNumberOfCells()).fill(0).map((_, i) => {
        const cell = lines.getCell(i * 3).slice();
        return { a: cell[0], b: cell[1] };
    });
    if (bypass) {
        return { points: pointsArray, lines: linesArray };
    }
    const newPoints = [];
    for (const [i, pt] of pointsArray.entries()) {
        const index = newPoints.findIndex((point) => point[0] === pt[0] && point[1] === pt[1] && point[2] === pt[2]);
        if (index >= 0) {
            linesArray.map((line) => {
                if (line.a === i) {
                    line.a = index;
                }
                if (line.b === i) {
                    line.b = index;
                }
                return line;
            });
        }
        else {
            const newIndex = newPoints.length;
            newPoints.push(pt);
            linesArray.map((line) => {
                if (line.a === i) {
                    line.a = newIndex;
                }
                if (line.b === i) {
                    line.b = newIndex;
                }
                return line;
            });
        }
    }
    const newLines = linesArray.filter((line) => line.a !== line.b);
    return { points: newPoints, lines: newLines };
}
/* harmony default export */ const contours_getDeduplicatedVTKPolyDataPoints = ({ getDeduplicatedVTKPolyDataPoints: getDeduplicatedVTKPolyDataPoints_getDeduplicatedVTKPolyDataPoints });

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/detectContourHoles.js
const getIsPointInsidePolygon = (point, vertices) => {
    const x = point[0];
    const y = point[1];
    let inside = false;
    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
        const xi = vertices[i][0], yi = vertices[i][1];
        const xj = vertices[j][0], yj = vertices[j][1];
        const intersect = yi > y != yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;
        if (intersect) {
            inside = !inside;
        }
    }
    return inside;
};
function checkEnclosed(outerContour, innerContour, points) {
    const vertices = [];
    outerContour.contourPoints.forEach((point) => {
        vertices.push([points[point][0], points[point][1]]);
    });
    let pointsNotEnclosed = 0;
    innerContour.contourPoints.forEach((point) => {
        const result = getIsPointInsidePolygon([points[point][0], points[point][1]], vertices);
        if (!result) {
            pointsNotEnclosed++;
        }
    });
    return pointsNotEnclosed === 0;
}
function processContourHoles(contours, points, useXOR = true) {
    const retContours = contours.filter((contour) => contour.type !== 'CLOSED_PLANAR');
    const closedContours = contours.filter((contour) => contour.type === 'CLOSED_PLANAR');
    const contourWithHoles = [];
    let contourWithoutHoles = [];
    closedContours.forEach((contour, index) => {
        const holes = [];
        closedContours.forEach((hContour, hIndex) => {
            if (index != hIndex) {
                if (checkEnclosed(contour, hContour, points)) {
                    holes.push(hIndex);
                }
            }
        });
        if (holes.length > 0) {
            contourWithHoles.push({
                contour,
                holes,
            });
        }
        else {
            contourWithoutHoles.push(index);
        }
    });
    if (useXOR) {
        contourWithHoles.forEach((contourHoleSet) => {
            contourHoleSet.contour.type = 'CLOSEDPLANAR_XOR';
            retContours.push(contourHoleSet.contour);
            contourHoleSet.holes.forEach((holeIndex) => {
                closedContours[holeIndex].type = 'CLOSEDPLANAR_XOR';
                retContours.push(closedContours[holeIndex]);
                contourWithoutHoles = contourWithoutHoles.filter((contourIndex) => {
                    return contourIndex !== holeIndex;
                });
            });
        });
        contourWithoutHoles.forEach((contourIndex) => {
            retContours.push(closedContours[contourIndex]);
        });
    }
    else {
    }
    return retContours;
}
/* harmony default export */ const detectContourHoles = ({ processContourHoles });

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Filters/General/ImageMarchingSquares.js
var ImageMarchingSquares = __webpack_require__(52754);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/Core/DataArray.js
var DataArray = __webpack_require__(45128);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/DataModel/ImageData.js
var ImageData = __webpack_require__(51250);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/SegmentationRepresentations.js
var SegmentationRepresentations = __webpack_require__(83946);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/generateContourSetsFromLabelmap.js







const { Labelmap } = SegmentationRepresentations/* default */.A;
function generateContourSetsFromLabelmap({ segmentations }) {
    const { representationData, segments = [0, 1] } = segmentations;
    const { volumeId: segVolumeId } = representationData[Labelmap];
    const vol = cornerstoneCache.getVolume(segVolumeId);
    if (!vol) {
        console.warn(`No volume found for ${segVolumeId}`);
        return;
    }
    const numSlices = vol.dimensions[2];
    const segData = vol.imageData.getPointData().getScalars().getData();
    const pixelsPerSlice = vol.dimensions[0] * vol.dimensions[1];
    for (let z = 0; z < numSlices; z++) {
        for (let y = 0; y < vol.dimensions[1]; y++) {
            const index = y * vol.dimensions[0] + z * pixelsPerSlice;
            segData[index] = 0;
            segData[index + vol.dimensions[0] - 1] = 0;
        }
    }
    const ContourSets = [];
    const { FrameOfReferenceUID } = vol.metadata;
    const numSegments = segments.length;
    for (let segIndex = 0; segIndex < numSegments; segIndex++) {
        const segment = segments[segIndex];
        if (!segment) {
            continue;
        }
        const sliceContours = [];
        const scalars = vtkDataArray.newInstance({
            name: 'Scalars',
            numberOfComponents: 1,
            size: pixelsPerSlice * numSlices,
            dataType: 'Uint8Array',
        });
        const { containedSegmentIndices } = segment;
        for (let sliceIndex = 0; sliceIndex < numSlices; sliceIndex++) {
            if (isSliceEmptyForSegment(sliceIndex, segData, pixelsPerSlice, segIndex)) {
                continue;
            }
            const frameStart = sliceIndex * pixelsPerSlice;
            try {
                for (let i = 0; i < pixelsPerSlice; i++) {
                    const value = segData[i + frameStart];
                    if (value === segIndex || containedSegmentIndices?.has(value)) {
                        scalars.setValue(i + frameStart, 1);
                    }
                    else {
                        scalars.setValue(i, 0);
                    }
                }
                const mSquares = vtkImageMarchingSquares.newInstance({
                    slice: sliceIndex,
                });
                const imageDataCopy = vtkImageData.newInstance();
                imageDataCopy.shallowCopy(vol.imageData);
                imageDataCopy.getPointData().setScalars(scalars);
                mSquares.setInputData(imageDataCopy);
                const cValues = [1];
                mSquares.setContourValues(cValues);
                mSquares.setMergePoints(false);
                const msOutput = mSquares.getOutputData();
                const reducedSet = getDeduplicatedVTKPolyDataPoints(msOutput);
                if (reducedSet.points?.length) {
                    const contours = findContoursFromReducedSet(reducedSet.lines);
                    sliceContours.push({
                        contours,
                        polyData: reducedSet,
                        FrameNumber: sliceIndex + 1,
                        sliceIndex,
                        FrameOfReferenceUID,
                    });
                }
            }
            catch (e) {
                console.warn(sliceIndex);
                console.warn(e);
            }
        }
        const metadata = {
            FrameOfReferenceUID,
        };
        const ContourSet = {
            label: segment.label,
            color: segment.color,
            metadata,
            sliceContours,
        };
        ContourSets.push(ContourSet);
    }
    return ContourSets;
}
function isSliceEmptyForSegment(sliceIndex, segData, pixelsPerSlice, segIndex) {
    const startIdx = sliceIndex * pixelsPerSlice;
    const endIdx = startIdx + pixelsPerSlice;
    for (let i = startIdx; i < endIdx; i++) {
        if (segData[i] === segIndex) {
            return false;
        }
    }
    return true;
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/RectangleROIStartEndThreshold.js
var RectangleROIStartEndThreshold = __webpack_require__(69405);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/AnnotationToPointData.js

function validateAnnotation(annotation) {
    if (!annotation?.data) {
        throw new Error('Tool data is empty');
    }
    if (!annotation.metadata || annotation.metadata.referenceImageId) {
        throw new Error('Tool data is not associated with any imageId');
    }
}
class AnnotationToPointData {
    constructor() {
    }
    static { this.TOOL_NAMES = {}; }
    static convert(annotation, index, metadataProvider) {
        validateAnnotation(annotation);
        const { toolName } = annotation.metadata;
        const toolClass = AnnotationToPointData.TOOL_NAMES[toolName];
        if (!toolClass) {
            throw new Error(`Unknown tool type: ${toolName}, cannot convert to RTSSReport`);
        }
        const ContourSequence = toolClass.getContourSequence(annotation, metadataProvider);
        const color = [
            Math.floor(Math.random() * 255),
            Math.floor(Math.random() * 255),
            Math.floor(Math.random() * 255),
        ];
        return {
            ReferencedROINumber: index + 1,
            ROIDisplayColor: color,
            ContourSequence,
        };
    }
    static register(toolClass) {
        AnnotationToPointData.TOOL_NAMES[toolClass.toolName] = toolClass;
    }
}
AnnotationToPointData.register(RectangleROIStartEndThreshold/* default */.A);
/* harmony default export */ const contours_AnnotationToPointData = ((/* unused pure expression or super */ null && (AnnotationToPointData)));

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/stateManagement/index.js
var stateManagement = __webpack_require__(95778);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getContourHolesDataWorld.js

function getContourHolesDataWorld(annotation) {
    const childAnnotationUIDs = annotation.childAnnotationUIDs ?? [];
    return childAnnotationUIDs.map((uid) => (0,stateManagement/* getAnnotation */.gw)(uid).data.contour.polyline);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/getContourHolesDataCanvas.js

function getContourHolesDataCanvas(annotation, viewport) {
    const worldHoleContours = getContourHolesDataWorld(annotation);
    const canvasHoleContours = [];
    worldHoleContours.forEach((worldHoleContour) => {
        const numPoints = worldHoleContour.length;
        const canvasHoleContour = new Array(numPoints);
        for (let i = 0; i < numPoints; i++) {
            canvasHoleContour[i] = viewport.worldToCanvas(worldHoleContour[i]);
        }
        canvasHoleContours.push(canvasHoleContour);
    });
    return canvasHoleContours;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/updateContourPolyline.js
var updateContourPolyline = __webpack_require__(89111);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/InterpolationManager/InterpolationManager.js
var InterpolationManager_InterpolationManager = __webpack_require__(33836);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/interpolation/acceptAutogeneratedInterpolations.js

function acceptAutogeneratedInterpolations(annotationGroupSelector, selector) {
    InterpolationManager.acceptAutoGenerated(annotationGroupSelector, selector);
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/interpolation/index.js
var interpolation = __webpack_require__(69115);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/findHandlePolylineIndex.js
var findHandlePolylineIndex = __webpack_require__(84045);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/calculatePerimeter.js
var calculatePerimeter = __webpack_require__(53891);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js
















/***/ }),

/***/ 69115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterpolationManager: () => (/* reexport safe */ _segmentation_InterpolationManager_InterpolationManager__WEBPACK_IMPORTED_MODULE_0__.A)
/* harmony export */ });
/* harmony import */ var _segmentation_InterpolationManager_InterpolationManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(33836);




/***/ }),

/***/ 89111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ updateContourPolyline)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _math__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(73047);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(95778);



function updateContourPolyline(annotation, polylineData, transforms, options) {
    const { canvasToWorld, worldToCanvas } = transforms;
    const { data } = annotation;
    const { targetWindingDirection } = polylineData;
    let { points: polyline } = polylineData;
    if (options?.decimate?.enabled) {
        polyline = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.decimate(polylineData.points, options?.decimate?.epsilon);
    }
    let { closed } = polylineData;
    const numPoints = polyline.length;
    const polylineWorldPoints = new Array(numPoints);
    const currentPolylineWindingDirection = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.getWindingDirection(polyline);
    const parentAnnotation = (0,_stateManagement__WEBPACK_IMPORTED_MODULE_2__/* .getParentAnnotation */ .Ay)(annotation);
    if (closed === undefined) {
        let currentClosedState = false;
        if (polyline.length > 3) {
            const lastToFirstDist = _math__WEBPACK_IMPORTED_MODULE_1__.point.distanceToPointSquared(polyline[0], polyline[numPoints - 1]);
            currentClosedState = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(0, lastToFirstDist);
        }
        closed = currentClosedState;
    }
    let windingDirection = parentAnnotation
        ? parentAnnotation.data.contour.windingDirection * -1
        : targetWindingDirection;
    if (windingDirection === undefined) {
        windingDirection = currentPolylineWindingDirection;
    }
    if (windingDirection !== currentPolylineWindingDirection) {
        polyline.reverse();
    }
    const handlePoints = data.handles.points.map((p) => worldToCanvas(p));
    if (handlePoints.length > 2) {
        const currentHandlesWindingDirection = _math__WEBPACK_IMPORTED_MODULE_1__.polyline.getWindingDirection(handlePoints);
        if (currentHandlesWindingDirection !== windingDirection) {
            data.handles.points.reverse();
        }
    }
    for (let i = 0; i < numPoints; i++) {
        polylineWorldPoints[i] = canvasToWorld(polyline[i]);
    }
    data.contour.polyline = polylineWorldPoints;
    data.contour.closed = closed;
    data.contour.windingDirection = windingDirection;
    (0,_stateManagement__WEBPACK_IMPORTED_MODULE_2__/* .invalidateAnnotation */ .zH)(annotation);
}


/***/ }),

/***/ 64857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _isObject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11857);

function debounce(func, wait, options) {
    let lastArgs, lastThis, maxWait, result, timerId, lastCallTime;
    let lastInvokeTime = 0;
    let leading = false;
    let maxing = false;
    let trailing = true;
    const useRAF = !wait && wait !== 0 && typeof window.requestAnimationFrame === 'function';
    if (typeof func !== 'function') {
        throw new TypeError('Expected a function');
    }
    wait = Number(wait) || 0;
    if ((0,_isObject__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(options)) {
        leading = Boolean(options.leading);
        maxing = 'maxWait' in options;
        maxWait = maxing ? Math.max(Number(options.maxWait) || 0, wait) : maxWait;
        trailing = 'trailing' in options ? Boolean(options.trailing) : trailing;
    }
    function invokeFunc(time) {
        const args = lastArgs;
        const thisArg = lastThis;
        lastArgs = lastThis = undefined;
        lastInvokeTime = time;
        result = func.apply(thisArg, args);
        return result;
    }
    function startTimer(pendingFunc, wait) {
        if (useRAF) {
            return window.requestAnimationFrame(pendingFunc);
        }
        return setTimeout(pendingFunc, wait);
    }
    function cancelTimer(id) {
        if (useRAF) {
            return window.cancelAnimationFrame(id);
        }
        clearTimeout(id);
    }
    function leadingEdge(time) {
        lastInvokeTime = time;
        timerId = startTimer(timerExpired, wait);
        return leading ? invokeFunc(time) : result;
    }
    function remainingWait(time) {
        const timeSinceLastCall = time - lastCallTime;
        const timeSinceLastInvoke = time - lastInvokeTime;
        const timeWaiting = wait - timeSinceLastCall;
        return maxing
            ? Math.min(timeWaiting, maxWait - timeSinceLastInvoke)
            : timeWaiting;
    }
    function shouldInvoke(time) {
        const timeSinceLastCall = time - lastCallTime;
        const timeSinceLastInvoke = time - lastInvokeTime;
        return (lastCallTime === undefined ||
            timeSinceLastCall >= wait ||
            timeSinceLastCall < 0 ||
            (maxing && timeSinceLastInvoke >= maxWait));
    }
    function timerExpired() {
        const time = Date.now();
        if (shouldInvoke(time)) {
            return trailingEdge(time);
        }
        timerId = startTimer(timerExpired, remainingWait(time));
    }
    function trailingEdge(time) {
        timerId = undefined;
        if (trailing && lastArgs) {
            return invokeFunc(time);
        }
        lastArgs = lastThis = undefined;
        return result;
    }
    function cancel() {
        if (timerId !== undefined) {
            cancelTimer(timerId);
        }
        lastInvokeTime = 0;
        lastArgs = lastCallTime = lastThis = timerId = undefined;
    }
    function flush() {
        return timerId === undefined ? result : trailingEdge(Date.now());
    }
    function pending() {
        return timerId !== undefined;
    }
    function debounced(...args) {
        const time = Date.now();
        const isInvoking = shouldInvoke(time);
        lastArgs = args;
        lastThis = this;
        lastCallTime = time;
        if (isInvoking) {
            if (timerId === undefined) {
                return leadingEdge(lastCallTime);
            }
            if (maxing) {
                timerId = startTimer(timerExpired, wait);
                return invokeFunc(lastCallTime);
            }
        }
        if (timerId === undefined) {
            timerId = startTimer(timerExpired, wait);
        }
        return result;
    }
    debounced.cancel = cancel;
    debounced.flush = flush;
    debounced.pending = pending;
    return debounced;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (debounce);


/***/ }),

/***/ 10910:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  getTextBoxCoordsCanvas: () => (/* reexport */ getTextBoxCoordsCanvas)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/getTextBoxCoordsCanvas.js
function getTextBoxCoordsCanvas(annotationCanvasPoints) {
    const corners = _determineCorners(annotationCanvasPoints);
    const centerY = (corners.top[1] + corners.bottom[1]) / 2;
    const textBoxCanvas = [corners.right[0], centerY];
    return textBoxCanvas;
}
function _determineCorners(canvasPoints) {
    const handlesLeftToRight = [canvasPoints[0], canvasPoints[1]].sort(_compareX);
    const handlesTopToBottom = [canvasPoints[0], canvasPoints[1]].sort(_compareY);
    const right = handlesLeftToRight[handlesLeftToRight.length - 1];
    const top = handlesTopToBottom[0];
    const bottom = handlesTopToBottom[handlesTopToBottom.length - 1];
    return {
        top,
        bottom,
        right,
    };
    function _compareX(a, b) {
        return a[0] < b[0] ? -1 : 1;
    }
    function _compareY(a, b) {
        return a[1] < b[1] ? -1 : 1;
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/index.js




/***/ }),

/***/ 16390:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: generateImageFromTimeData, getDataInTime

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/utilities.js
var segmentation_utilities = __webpack_require__(77071);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInShapeCallback.js
var utilities_pointInShapeCallback = __webpack_require__(75403);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/getDataInTime.js



function getDataInTime(dynamicVolume, options) {
    let dataInTime;
    const frames = options.frameNumbers || [
        ...Array(dynamicVolume.numTimePoints).keys(),
    ];
    if (!options.maskVolumeId && !options.imageCoordinate) {
        throw new Error('You should provide either maskVolumeId or imageCoordinate');
    }
    if (options.maskVolumeId && options.imageCoordinate) {
        throw new Error('You can only use one of maskVolumeId or imageCoordinate');
    }
    if (options.maskVolumeId) {
        const segmentationVolume = cache.getVolume(options.maskVolumeId);
        const [dataInTime, ijkCoords] = _getTimePointDataMask(frames, dynamicVolume, segmentationVolume);
        return [dataInTime, ijkCoords];
    }
    if (options.imageCoordinate) {
        const dataInTime = _getTimePointDataCoordinate(frames, options.imageCoordinate, dynamicVolume);
        return dataInTime;
    }
    return dataInTime;
}
function _getTimePointDataCoordinate(frames, coordinate, volume) {
    const { dimensions, imageData } = volume;
    const index = imageData.worldToIndex(coordinate);
    index[0] = Math.floor(index[0]);
    index[1] = Math.floor(index[1]);
    index[2] = Math.floor(index[2]);
    if (!utilities.indexWithinDimensions(index, dimensions)) {
        throw new Error('outside bounds');
    }
    const yMultiple = dimensions[0];
    const zMultiple = dimensions[0] * dimensions[1];
    const allScalarData = volume.getScalarDataArrays();
    const value = [];
    frames.forEach((frame) => {
        const activeScalarData = allScalarData[frame];
        const scalarIndex = index[2] * zMultiple + index[1] * yMultiple + index[0];
        value.push(activeScalarData[scalarIndex]);
    });
    return value;
}
function _getTimePointDataMask(frames, dynamicVolume, segmentationVolume) {
    const { imageData: maskImageData } = segmentationVolume;
    const segScalarData = segmentationVolume.getScalarData();
    const len = segScalarData.length;
    const nonZeroVoxelIndices = [];
    nonZeroVoxelIndices.length = len;
    const ijkCoords = [];
    const dimensions = segmentationVolume.dimensions;
    let actualLen = 0;
    for (let i = 0, len = segScalarData.length; i < len; i++) {
        if (segScalarData[i] !== 0) {
            ijkCoords.push([
                i % dimensions[0],
                Math.floor((i / dimensions[0]) % dimensions[1]),
                Math.floor(i / (dimensions[0] * dimensions[1])),
            ]);
            nonZeroVoxelIndices[actualLen++] = i;
        }
    }
    nonZeroVoxelIndices.length = actualLen;
    const dynamicVolumeScalarDataArray = dynamicVolume.getScalarDataArrays();
    const values = [];
    const isSameVolume = dynamicVolumeScalarDataArray[0].length === len &&
        JSON.stringify(dynamicVolume.spacing) ===
            JSON.stringify(segmentationVolume.spacing);
    if (isSameVolume) {
        for (let i = 0; i < nonZeroVoxelIndices.length; i++) {
            const indexValues = [];
            frames.forEach((frame) => {
                const activeScalarData = dynamicVolumeScalarDataArray[frame];
                indexValues.push(activeScalarData[nonZeroVoxelIndices[i]]);
            });
            values.push(indexValues);
        }
        return [values, ijkCoords];
    }
    const callback = ({ pointLPS: segPointLPS, value: segValue, pointIJK: segPointIJK, }) => {
        if (segValue === 0) {
            return;
        }
        const overlapIJKMinMax = getVoxelOverlap(dynamicVolume.imageData, dynamicVolume.dimensions, dynamicVolume.spacing, segPointLPS);
        let count = 0;
        const perFrameSum = new Map();
        frames.forEach((frame) => perFrameSum.set(frame, 0));
        const averageCallback = ({ index }) => {
            for (let i = 0; i < frames.length; i++) {
                const value = dynamicVolumeScalarDataArray[i][index];
                const frame = frames[i];
                perFrameSum.set(frame, perFrameSum.get(frame) + value);
            }
            count++;
        };
        pointInShapeCallback(dynamicVolume.imageData, () => true, averageCallback, overlapIJKMinMax);
        const averageValues = [];
        perFrameSum.forEach((sum) => {
            averageValues.push(sum / count);
        });
        ijkCoords.push(segPointIJK);
        values.push(averageValues);
    };
    pointInShapeCallback(maskImageData, () => true, callback);
    return [values, ijkCoords];
}
/* harmony default export */ const dynamicVolume_getDataInTime = ((/* unused pure expression or super */ null && (getDataInTime)));

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/generateImageFromTimeData.js

function generateImageFromTimeData(dynamicVolume, operation, frameNumbers) {
    const frames = frameNumbers || [...Array(dynamicVolume.numTimePoints).keys()];
    const numFrames = frames.length;
    if (frames.length <= 1) {
        throw new Error('Please provide two or more time points');
    }
    const typedArrays = dynamicVolume.getScalarDataArrays();
    const arrayLength = typedArrays[0].length;
    const finalArray = new Float32Array(arrayLength);
    if (operation === Enums.DynamicOperatorType.SUM) {
        for (let i = 0; i < numFrames; i++) {
            const currentArray = typedArrays[frames[i]];
            for (let j = 0; j < arrayLength; j++) {
                finalArray[j] += currentArray[j];
            }
        }
        return finalArray;
    }
    if (operation === Enums.DynamicOperatorType.SUBTRACT) {
        if (frames.length > 2) {
            throw new Error('Please provide only 2 time points for subtraction.');
        }
        for (let j = 0; j < arrayLength; j++) {
            finalArray[j] += typedArrays[frames[0]][j] - typedArrays[frames[1]][j];
        }
        return finalArray;
    }
    if (operation === Enums.DynamicOperatorType.AVERAGE) {
        for (let i = 0; i < numFrames; i++) {
            const currentArray = typedArrays[frames[i]];
            for (let j = 0; j < arrayLength; j++) {
                finalArray[j] += currentArray[j];
            }
        }
        for (let k = 0; k < arrayLength; k++) {
            finalArray[k] = finalArray[k] / numFrames;
        }
        return finalArray;
    }
}
/* harmony default export */ const dynamicVolume_generateImageFromTimeData = ((/* unused pure expression or super */ null && (generateImageFromTimeData)));

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/index.js






/***/ }),

/***/ 66429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports getAnnotationNearPoint, getAnnotationNearPointOnEnabledElement */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_annotation_annotationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38296);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52610);



function getAnnotationNearPoint(element, canvasPoint, proximity = 5) {
    const enabledElement = getEnabledElement(element);
    if (!enabledElement) {
        throw new Error('getAnnotationNearPoint: enabledElement not found');
    }
    return getAnnotationNearPointOnEnabledElement(enabledElement, canvasPoint, proximity);
}
function getAnnotationNearPointOnEnabledElement(enabledElement, point, proximity) {
    const { renderingEngineId, viewportId } = enabledElement;
    const toolGroup = ToolGroupManager.getToolGroupForViewport(viewportId, renderingEngineId);
    if (!toolGroup) {
        return null;
    }
    const { _toolInstances: tools } = toolGroup;
    for (const name in tools) {
        const found = findAnnotationNearPointByTool(tools[name], enabledElement, point, proximity);
        if (found) {
            return found;
        }
    }
    return null;
}
function findAnnotationNearPointByTool(tool, enabledElement, point, proximity) {
    const { viewport } = enabledElement;
    const annotations = getAnnotations(tool.constructor.toolName, viewport?.element);
    const currentId = viewport?.getCurrentImageId?.();
    if (annotations?.length) {
        const { element } = enabledElement.viewport;
        for (const annotation of annotations) {
            const referencedImageId = annotation.metadata?.referencedImageId;
            if ((currentId && referencedImageId && currentId !== referencedImageId) ||
                !tool.isPointNearTool) {
                continue;
            }
            if (tool.isPointNearTool(element, annotation, point, proximity, '') ||
                tool.getHandleNearImagePoint(element, annotation, point, proximity)) {
                return annotation;
            }
        }
    }
    return null;
}



/***/ }),

/***/ 24592:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CQ: () => (/* binding */ getCalibratedAspect),
/* harmony export */   Op: () => (/* binding */ getCalibratedLengthUnitsAndScale),
/* harmony export */   Xw: () => (/* binding */ getCalibratedProbeUnitsAndValue)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

const { CalibrationTypes } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.Enums;
const PIXEL_UNITS = 'px';
const SUPPORTED_REGION_DATA_TYPES = [
    1,
];
const SUPPORTED_LENGTH_VARIANT = [
    '3,3',
];
const SUPPORTED_PROBE_VARIANT = [
    '4,3',
];
const UNIT_MAPPING = {
    3: 'cm',
    4: 'seconds',
};
const EPS = 1e-3;
const SQUARE = '\xb2';
const getCalibratedLengthUnitsAndScale = (image, handles) => {
    const { calibration, hasPixelSpacing } = image;
    let units = hasPixelSpacing ? 'mm' : PIXEL_UNITS;
    let areaUnits = units + SQUARE;
    let scale = 1;
    let calibrationType = '';
    if (!calibration ||
        (!calibration.type && !calibration.sequenceOfUltrasoundRegions)) {
        return { units, areaUnits, scale };
    }
    if (calibration.type === CalibrationTypes.UNCALIBRATED) {
        return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
    }
    if (calibration.sequenceOfUltrasoundRegions) {
        let imageIndex1, imageIndex2;
        if (Array.isArray(handles) && handles.length === 2) {
            [imageIndex1, imageIndex2] = handles;
        }
        else if (typeof handles === 'function') {
            const points = handles();
            imageIndex1 = points[0];
            imageIndex2 = points[1];
        }
        let regions = calibration.sequenceOfUltrasoundRegions.filter((region) => imageIndex1[0] >= region.regionLocationMinX0 &&
            imageIndex1[0] <= region.regionLocationMaxX1 &&
            imageIndex1[1] >= region.regionLocationMinY0 &&
            imageIndex1[1] <= region.regionLocationMaxY1 &&
            imageIndex2[0] >= region.regionLocationMinX0 &&
            imageIndex2[0] <= region.regionLocationMaxX1 &&
            imageIndex2[1] >= region.regionLocationMinY0 &&
            imageIndex2[1] <= region.regionLocationMaxY1);
        if (!regions?.length) {
            return { units, areaUnits, scale };
        }
        regions = regions.filter((region) => SUPPORTED_REGION_DATA_TYPES.includes(region.regionDataType) &&
            SUPPORTED_LENGTH_VARIANT.includes(`${region.physicalUnitsXDirection},${region.physicalUnitsYDirection}`));
        if (!regions.length) {
            return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
        }
        const region = regions[0];
        const physicalDeltaX = Math.abs(region.physicalDeltaX);
        const physicalDeltaY = Math.abs(region.physicalDeltaY);
        const isSamePhysicalDelta = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(physicalDeltaX, physicalDeltaY, EPS);
        if (isSamePhysicalDelta) {
            scale = 1 / (physicalDeltaX * 10);
            calibrationType = 'US Region';
            units = 'mm';
            areaUnits = 'mm' + SQUARE;
        }
        else {
            return { units: PIXEL_UNITS, areaUnits: PIXEL_UNITS + SQUARE, scale };
        }
    }
    else if (calibration.scale) {
        scale = calibration.scale;
    }
    const types = [
        CalibrationTypes.ERMF,
        CalibrationTypes.USER,
        CalibrationTypes.ERROR,
        CalibrationTypes.PROJECTION,
    ];
    if (types.includes(calibration?.type)) {
        calibrationType = calibration.type;
    }
    return {
        units: units + (calibrationType ? ` ${calibrationType}` : ''),
        areaUnits: areaUnits + (calibrationType ? ` ${calibrationType}` : ''),
        scale,
    };
};
const getCalibratedProbeUnitsAndValue = (image, handles) => {
    const [imageIndex] = handles;
    const { calibration } = image;
    let units = ['raw'];
    let values = [null];
    let calibrationType = '';
    if (!calibration ||
        (!calibration.type && !calibration.sequenceOfUltrasoundRegions)) {
        return { units, values };
    }
    if (calibration.sequenceOfUltrasoundRegions) {
        const supportedRegionsMetadata = calibration.sequenceOfUltrasoundRegions.filter((region) => SUPPORTED_REGION_DATA_TYPES.includes(region.regionDataType) &&
            SUPPORTED_PROBE_VARIANT.includes(`${region.physicalUnitsXDirection},${region.physicalUnitsYDirection}`));
        if (!supportedRegionsMetadata?.length) {
            return { units, values };
        }
        const region = supportedRegionsMetadata.find((region) => imageIndex[0] >= region.regionLocationMinX0 &&
            imageIndex[0] <= region.regionLocationMaxX1 &&
            imageIndex[1] >= region.regionLocationMinY0 &&
            imageIndex[1] <= region.regionLocationMaxY1);
        if (!region) {
            return { units, values };
        }
        const { referencePixelX0 = 0, referencePixelY0 = 0 } = region;
        const { physicalDeltaX, physicalDeltaY } = region;
        const yValue = (imageIndex[1] - region.regionLocationMinY0 - referencePixelY0) *
            physicalDeltaY;
        const xValue = (imageIndex[0] - region.regionLocationMinX0 - referencePixelX0) *
            physicalDeltaX;
        calibrationType = 'US Region';
        values = [xValue, yValue];
        units = [
            UNIT_MAPPING[region.physicalUnitsXDirection],
            UNIT_MAPPING[region.physicalUnitsYDirection],
        ];
    }
    return {
        units,
        values,
        calibrationType,
    };
};
const getCalibratedAspect = (image) => image.calibration?.aspect || 1;



/***/ }),

/***/ 96760:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   R: () => (/* binding */ getSphereBoundsInfo)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _boundingBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15306);



const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function getSphereBoundsInfo(circlePoints, imageData, viewport) {
    const [bottom, top] = circlePoints;
    const centerWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues((bottom[0] + top[0]) / 2, (bottom[1] + top[1]) / 2, (bottom[2] + top[2]) / 2);
    const radiusWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(bottom, top) / 2;
    if (!viewport) {
        throw new Error('viewport is required in order to calculate the sphere bounds');
    }
    const { boundsIJK, topLeftWorld, bottomRightWorld } = _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld);
    return {
        boundsIJK,
        centerWorld: centerWorld,
        radiusWorld,
        topLeftWorld: topLeftWorld,
        bottomRightWorld: bottomRightWorld,
    };
}
function _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld) {
    const [bottom, top] = circlePoints;
    const dimensions = imageData.getDimensions();
    const camera = viewport.getCamera();
    const viewUp = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewUp[0], camera.viewUp[1], camera.viewUp[2]);
    const viewPlaneNormal = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(camera.viewPlaneNormal[0], camera.viewPlaneNormal[1], camera.viewPlaneNormal[2]);
    const viewRight = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.cross */ .eR.cross(viewRight, viewUp, viewPlaneNormal);
    const topLeftWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    const bottomRightWorld = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, top, viewPlaneNormal, radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottom, viewPlaneNormal, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(topLeftWorld, topLeftWorld, viewRight, -radiusWorld);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scaleAndAdd */ .eR.scaleAndAdd(bottomRightWorld, bottomRightWorld, viewRight, radiusWorld);
    const topLeftIJK = transformWorldToIndex(imageData, topLeftWorld);
    const bottomRightIJK = transformWorldToIndex(imageData, bottomRightWorld);
    const pointsIJK = circlePoints.map((p) => transformWorldToIndex(imageData, p));
    const boundsIJK = (0,_boundingBox__WEBPACK_IMPORTED_MODULE_2__.getBoundingBoxAroundShapeIJK)([topLeftIJK, bottomRightIJK, ...pointsIJK], dimensions);
    return { boundsIJK, topLeftWorld, bottomRightWorld };
}



/***/ }),

/***/ 39490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ getViewportForAnnotation)
/* harmony export */ });
/* harmony import */ var _getViewportsForAnnotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65903);

function getViewportForAnnotation(annotation) {
    const viewports = (0,_getViewportsForAnnotation__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(annotation);
    return viewports.length ? viewports[0] : undefined;
}


/***/ }),

/***/ 74119:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  clip: () => (/* reexport */ clip/* default */.Ay),
  debounce: () => (/* reexport */ debounce/* default */.A),
  getCalibratedLengthUnitsAndScale: () => (/* reexport */ getCalibratedUnits/* getCalibratedLengthUnitsAndScale */.Op),
  math: () => (/* reexport */ math),
  pointInShapeCallback: () => (/* reexport */ pointInShapeCallback/* default */.A),
  pointToString: () => (/* reexport */ pointToString/* pointToString */.l),
  polyDataUtils: () => (/* reexport */ utils),
  roundNumber: () => (/* binding */ roundNumber),
  scroll: () => (/* reexport */ utilities_scroll/* default */.A),
  throttle: () => (/* reexport */ throttle/* default */.A),
  triggerAnnotationRenderForToolGroupIds: () => (/* reexport */ triggerAnnotationRenderForToolGroupIds/* default */.A),
  triggerAnnotationRenderForViewportIds: () => (/* reexport */ triggerAnnotationRenderForViewportIds/* default */.A)
});

// UNUSED EXPORTS: annotationFrameRange, annotationHydration, boundingBox, calibrateImageSpacing, cine, contourSegmentation, contours, drawing, dynamicVolume, getAnnotationNearPoint, getAnnotationNearPointOnEnabledElement, getCalibratedAspect, getCalibratedProbeUnitsAndValue, getClosestImageIdForStackViewport, getSphereBoundsInfo, getViewportForAnnotation, isObject, jumpToSlice, orientation, planar, planarFreehandROITool, pointInSurroundingSphereCallback, rectangleROITool, segmentation, stackContextPrefetch, stackPrefetch, touch, triggerAnnotationRender, triggerEvent, viewport, viewportFilters, voi

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getAnnotationNearPoint.js
var getAnnotationNearPoint = __webpack_require__(66429);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/debounce.js
var debounce = __webpack_require__(64857);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/throttle.js
var throttle = __webpack_require__(21090);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/isObject.js
var isObject = __webpack_require__(11857);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/clip.js
var clip = __webpack_require__(88484);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/calibrateImageSpacing.js
var calibrateImageSpacing = __webpack_require__(17167);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getCalibratedUnits.js
var getCalibratedUnits = __webpack_require__(24592);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForViewportIds.js
var triggerAnnotationRenderForViewportIds = __webpack_require__(23072);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRenderForToolGroupIds.js
var triggerAnnotationRenderForToolGroupIds = __webpack_require__(27819);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/triggerAnnotationRender.js
var triggerAnnotationRender = __webpack_require__(6805);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewport/jumpToSlice.js
var jumpToSlice = __webpack_require__(11666);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInShapeCallback.js
var pointInShapeCallback = __webpack_require__(75403);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getSphereBoundsInfo.js
var getSphereBoundsInfo = __webpack_require__(96760);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/scroll.js
var utilities_scroll = __webpack_require__(21783);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointToString.js
var pointToString = __webpack_require__(60438);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/annotationFrameRange.js
var annotationFrameRange = __webpack_require__(41209);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/pointInSurroundingSphereCallback.js
var pointInSurroundingSphereCallback = __webpack_require__(5093);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/getViewportForAnnotation.js
var getViewportForAnnotation = __webpack_require__(39490);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/annotationHydration.js
var annotationHydration = __webpack_require__(25781);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js + 9 modules
var contours = __webpack_require__(75908);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/index.js
var segmentation = __webpack_require__(10351);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/drawing/index.js + 1 modules
var drawing = __webpack_require__(10910);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/planar/index.js
var planar = __webpack_require__(84797);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js + 4 modules
var viewportFilters = __webpack_require__(90252);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/getOrientationStringLPS.js
var getOrientationStringLPS = __webpack_require__(80393);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/invertOrientationStringLPS.js
var invertOrientationStringLPS = __webpack_require__(39365);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/orientation/index.js




// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/cine/index.js + 3 modules
var cine = __webpack_require__(60001);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/boundingBox/index.js
var boundingBox = __webpack_require__(15306);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/planarFreehandROITool/index.js
var planarFreehandROITool = __webpack_require__(44074);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/rectangleROITool/index.js
var rectangleROITool = __webpack_require__(15874);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/index.js + 2 modules
var stackPrefetch = __webpack_require__(90387);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewport/index.js
var viewport = __webpack_require__(31555);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/touch/index.js
var touch = __webpack_require__(54868);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/dynamicVolume/index.js + 2 modules
var dynamicVolume = __webpack_require__(16390);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/polyData/utils.js
var utils = __webpack_require__(46514);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/index.js + 4 modules
var voi = __webpack_require__(14149);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contourSegmentation/index.js
var contourSegmentation = __webpack_require__(7259);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js






































const roundNumber = esm.utilities.roundNumber;




/***/ }),

/***/ 11857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function isObject(value) {
    const type = typeof value;
    return value !== null && (type === 'object' || type === 'function');
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isObject);


/***/ }),

/***/ 27924:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint),
  distanceToPointSquared: () => (/* reexport */ distanceToPointSquared),
  intersectAABB: () => (/* reexport */ intersectAABB)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/intersectAABB.js
function intersectAABB(aabb1, aabb2) {
    return (aabb1.minX <= aabb2.maxX &&
        aabb1.maxX >= aabb2.minX &&
        aabb1.minY <= aabb2.maxY &&
        aabb1.maxY >= aabb2.minY);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/distanceToPointSquared.js
function distanceToPointSquared(aabb, point) {
    const aabbWidth = aabb.maxX - aabb.minX;
    const aabbHeight = aabb.maxY - aabb.minY;
    const aabbSize = [aabbWidth, aabbHeight];
    const aabbCenter = [
        aabb.minX + aabbWidth / 2,
        aabb.minY + aabbHeight / 2,
    ];
    const translatedPoint = [
        Math.abs(point[0] - aabbCenter[0]),
        Math.abs(point[1] - aabbCenter[1]),
    ];
    const dx = translatedPoint[0] - aabbSize[0] * 0.5;
    const dy = translatedPoint[1] - aabbSize[1] * 0.5;
    if (dx > 0 && dy > 0) {
        return dx * dx + dy * dy;
    }
    const dist = Math.max(dx, 0) + Math.max(dy, 0);
    return dist * dist;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/distanceToPoint.js

function distanceToPoint(aabb, point) {
    return Math.sqrt(distanceToPointSquared(aabb, point));
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/aabb/index.js





/***/ }),

/***/ 83112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  BasicStatsCalculator: () => (/* reexport */ BasicStatsCalculator)
});

// UNUSED EXPORTS: Calculator

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/Calculator.js
class Calculator {
}
/* harmony default export */ const basic_Calculator = (Calculator);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/BasicStatsCalculator.js


const { PointsManager } = esm.utilities;
class BasicStatsCalculator extends basic_Calculator {
    static { this.max = [-Infinity]; }
    static { this.min = [Infinity]; }
    static { this.sum = [0]; }
    static { this.count = 0; }
    static { this.runMean = [0]; }
    static { this.m2 = [0]; }
    static { this.pointsInShape = PointsManager.create3(1024); }
    static statsInit(options) {
        if (options.noPointsCollection) {
            BasicStatsCalculator.pointsInShape = null;
        }
    }
    static { this.statsCallback = ({ value: newValue, pointLPS = null }) => {
        if (Array.isArray(newValue) &&
            newValue.length > 1 &&
            this.max.length === 1) {
            this.max.push(this.max[0], this.max[0]);
            this.min.push(this.min[0], this.min[0]);
            this.sum.push(this.sum[0], this.sum[0]);
            this.runMean.push(0, 0);
            this.m2.push(this.m2[0], this.m2[0]);
        }
        this.pointsInShape?.push(pointLPS);
        const newArray = Array.isArray(newValue) ? newValue : [newValue];
        this.count += 1;
        this.max.map((it, idx) => {
            const value = newArray[idx];
            const delta = value - this.runMean[idx];
            this.sum[idx] += value;
            this.runMean[idx] += delta / this.count;
            const delta2 = value - this.runMean[idx];
            this.m2[idx] += delta * delta2;
            this.min[idx] = Math.min(this.min[idx], value);
            this.max[idx] = Math.max(it, value);
        });
    }; }
    static { this.getStatistics = (options) => {
        const mean = this.sum.map((sum) => sum / this.count);
        const stdDev = this.m2.map((squaredDiffSum) => Math.sqrt(squaredDiffSum / this.count));
        const unit = options?.unit || null;
        const named = {
            max: {
                name: 'max',
                label: 'Max Pixel',
                value: singleArrayAsNumber(this.max),
                unit,
            },
            min: {
                name: 'min',
                label: 'Min Pixel',
                value: singleArrayAsNumber(this.min),
                unit,
            },
            mean: {
                name: 'mean',
                label: 'Mean Pixel',
                value: singleArrayAsNumber(mean),
                unit,
            },
            stdDev: {
                name: 'stdDev',
                label: 'Standard Deviation',
                value: singleArrayAsNumber(stdDev),
                unit,
            },
            count: {
                name: 'count',
                label: 'Pixel Count',
                value: this.count,
                unit: null,
            },
            pointsInShape: this.pointsInShape,
            array: [],
        };
        named.array.push(named.max, named.mean, named.stdDev, named.stdDev, named.count);
        this.max = [-Infinity];
        this.min = [Infinity];
        this.sum = [0];
        this.m2 = [0];
        this.runMean = [0];
        this.count = 0;
        this.pointsInShape = PointsManager.create3(1024);
        return named;
    }; }
}
function singleArrayAsNumber(val) {
    return val.length === 1 ? val[0] : val;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/basic/index.js





/***/ }),

/***/ 2264:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  getCanvasEllipseCorners: () => (/* reexport */ getCanvasEllipseCorners),
  pointInEllipse: () => (/* reexport */ pointInEllipse),
  precalculatePointInEllipse: () => (/* reexport */ precalculatePointInEllipse)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/pointInEllipse.js
function pointInEllipse(ellipse, pointLPS, inverts = {}) {
    if (!inverts.precalculated) {
        precalculatePointInEllipse(ellipse, inverts);
    }
    return inverts.precalculated(pointLPS);
}
const precalculatePointInEllipse = (ellipse, inverts = {}) => {
    const { xRadius, yRadius, zRadius } = ellipse;
    if (inverts.invXRadiusSq === undefined ||
        inverts.invYRadiusSq === undefined ||
        inverts.invZRadiusSq === undefined) {
        inverts.invXRadiusSq = xRadius !== 0 ? 1 / xRadius ** 2 : 0;
        inverts.invYRadiusSq = yRadius !== 0 ? 1 / yRadius ** 2 : 0;
        inverts.invZRadiusSq = zRadius !== 0 ? 1 / zRadius ** 2 : 0;
    }
    const { invXRadiusSq, invYRadiusSq, invZRadiusSq } = inverts;
    const { center } = ellipse;
    const [centerL, centerP, centerS] = center;
    inverts.precalculated = (pointLPS) => {
        const dx = pointLPS[0] - centerL;
        let inside = dx * dx * invXRadiusSq;
        if (inside > 1) {
            return false;
        }
        const dy = pointLPS[1] - centerP;
        inside += dy * dy * invYRadiusSq;
        if (inside > 1) {
            return false;
        }
        const dz = pointLPS[2] - centerS;
        inside += dz * dz * invZRadiusSq;
        return inside <= 1;
    };
    return inverts;
};


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/getCanvasEllipseCorners.js
function getCanvasEllipseCorners(ellipseCanvasPoints) {
    const [bottom, top, left, right] = ellipseCanvasPoints;
    const topLeft = [left[0], top[1]];
    const bottomRight = [right[0], bottom[1]];
    return [topLeft, bottomRight];
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/ellipse/index.js





/***/ }),

/***/ 73047:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   aabb: () => (/* reexport module object */ _aabb__WEBPACK_IMPORTED_MODULE_0__),
/* harmony export */   lineSegment: () => (/* reexport module object */ _line__WEBPACK_IMPORTED_MODULE_3__),
/* harmony export */   point: () => (/* reexport module object */ _point__WEBPACK_IMPORTED_MODULE_4__),
/* harmony export */   polyline: () => (/* reexport module object */ _polyline__WEBPACK_IMPORTED_MODULE_5__)
/* harmony export */ });
/* harmony import */ var _aabb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27924);
/* harmony import */ var _basic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83112);
/* harmony import */ var _ellipse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2264);
/* harmony import */ var _line__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21954);
/* harmony import */ var _point__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(14846);
/* harmony import */ var _polyline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(56634);
/* harmony import */ var _rectangle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23345);
/* harmony import */ var _vec2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(73100);











/***/ }),

/***/ 21954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint),
  distanceToPointSquared: () => (/* reexport */ distanceToPointSquared),
  distanceToPointSquaredInfo: () => (/* reexport */ distanceToPointSquaredInfo),
  intersectLine: () => (/* reexport */ intersectLine),
  isPointOnLineSegment: () => (/* reexport */ isPointOnLineSegment)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPointSquaredInfo.js

function distanceToPointSquaredInfo(lineStart, lineEnd, point) {
    let closestPoint;
    const distanceSquared = math.point.distanceToPointSquared(lineStart, lineEnd);
    if (lineStart[0] === lineEnd[0] && lineStart[1] === lineEnd[1]) {
        closestPoint = lineStart;
    }
    if (!closestPoint) {
        const dotProduct = ((point[0] - lineStart[0]) * (lineEnd[0] - lineStart[0]) +
            (point[1] - lineStart[1]) * (lineEnd[1] - lineStart[1])) /
            distanceSquared;
        if (dotProduct < 0) {
            closestPoint = lineStart;
        }
        else if (dotProduct > 1) {
            closestPoint = lineEnd;
        }
        else {
            closestPoint = [
                lineStart[0] + dotProduct * (lineEnd[0] - lineStart[0]),
                lineStart[1] + dotProduct * (lineEnd[1] - lineStart[1]),
            ];
        }
    }
    return {
        point: [...closestPoint],
        distanceSquared: math.point.distanceToPointSquared(point, closestPoint),
    };
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPointSquared.js

function distanceToPointSquared(lineStart, lineEnd, point) {
    return distanceToPointSquaredInfo(lineStart, lineEnd, point).distanceSquared;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/distanceToPoint.js

function distanceToPoint(lineStart, lineEnd, point) {
    if (lineStart.length !== 2 || lineEnd.length !== 2 || point.length !== 2) {
        throw Error('lineStart, lineEnd, and point should have 2 elements of [x, y]');
    }
    return Math.sqrt(distanceToPointSquared(lineStart, lineEnd, point));
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/intersectLine.js
function sign(x) {
    return typeof x === 'number'
        ? x
            ? x < 0
                ? -1
                : 1
            : x === x
                ? 0
                : NaN
        : NaN;
}
function intersectLine(line1Start, line1End, line2Start, line2End) {
    const [x1, y1] = line1Start;
    const [x2, y2] = line1End;
    const [x3, y3] = line2Start;
    const [x4, y4] = line2End;
    const a1 = y2 - y1;
    const b1 = x1 - x2;
    const c1 = x2 * y1 - x1 * y2;
    const r3 = a1 * x3 + b1 * y3 + c1;
    const r4 = a1 * x4 + b1 * y4 + c1;
    if (r3 !== 0 && r4 !== 0 && sign(r3) === sign(r4)) {
        return;
    }
    const a2 = y4 - y3;
    const b2 = x3 - x4;
    const c2 = x4 * y3 - x3 * y4;
    const r1 = a2 * x1 + b2 * y1 + c2;
    const r2 = a2 * x2 + b2 * y2 + c2;
    if (r1 !== 0 && r2 !== 0 && sign(r1) === sign(r2)) {
        return;
    }
    const denom = a1 * b2 - a2 * b1;
    let num;
    num = b1 * c2 - b2 * c1;
    const x = num / denom;
    num = a2 * c1 - a1 * c2;
    const y = num / denom;
    const intersectionPoint = [x, y];
    return intersectionPoint;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/isPointOnLineSegment.js
const ORIENTATION_TOLERANCE = 1e-2;
function isPointOnLineSegment(lineStart, lineEnd, point) {
    const minX = lineStart[0] <= lineEnd[0] ? lineStart[0] : lineEnd[0];
    const maxX = lineStart[0] >= lineEnd[0] ? lineStart[0] : lineEnd[0];
    const minY = lineStart[1] <= lineEnd[1] ? lineStart[1] : lineEnd[1];
    const maxY = lineStart[1] >= lineEnd[1] ? lineStart[1] : lineEnd[1];
    const aabbContainsPoint = point[0] >= minX - ORIENTATION_TOLERANCE &&
        point[0] <= maxX + ORIENTATION_TOLERANCE &&
        point[1] >= minY - ORIENTATION_TOLERANCE &&
        point[1] <= maxY + ORIENTATION_TOLERANCE;
    if (!aabbContainsPoint) {
        return false;
    }
    const orientation = (lineEnd[1] - lineStart[1]) * (point[0] - lineEnd[0]) -
        (lineEnd[0] - lineStart[0]) * (point[1] - lineEnd[1]);
    const absOrientation = orientation >= 0 ? orientation : -orientation;
    return absOrientation <= ORIENTATION_TOLERANCE;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js








/***/ }),

/***/ 38566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ distanceToPoint)
/* harmony export */ });
/* harmony import */ var _distanceToPointSquared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14257);

function distanceToPoint(p1, p2) {
    return Math.sqrt((0,_distanceToPointSquared__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(p1, p2));
}


/***/ }),

/***/ 14257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ distanceToPointSquared)
/* harmony export */ });
function distanceToPointSquared(p1, p2) {
    if (p1.length !== p2.length) {
        throw Error('Both points should have the same dimensionality');
    }
    const [x1, y1, z1 = 0] = p1;
    const [x2, y2, z2 = 0] = p2;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    return dx * dx + dy * dy + dz * dz;
}


/***/ }),

/***/ 49131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ mirror)
/* harmony export */ });
function mirror(mirrorPoint, staticPoint) {
    const [x1, y1] = mirrorPoint;
    const [x2, y2] = staticPoint;
    const newX = 2 * x2 - x1;
    const newY = 2 * y2 - y1;
    return [newX, newY];
}


/***/ }),

/***/ 56634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  addCanvasPointsToArray: () => (/* reexport */ polyline_addCanvasPointsToArray),
  containsPoint: () => (/* reexport */ containsPoint),
  containsPoints: () => (/* reexport */ containsPoints),
  decimate: () => (/* reexport */ decimate),
  getAABB: () => (/* reexport */ getAABB/* default */.A),
  getArea: () => (/* reexport */ getArea),
  getClosestLineSegmentIntersection: () => (/* reexport */ getClosestLineSegmentIntersection),
  getFirstLineSegmentIntersectionIndexes: () => (/* reexport */ getFirstLineSegmentIntersectionIndexes),
  getLineSegmentIntersectionsCoordinates: () => (/* reexport */ getLineSegmentIntersectionsCoordinates),
  getLineSegmentIntersectionsIndexes: () => (/* reexport */ getLineSegmentIntersectionsIndexes),
  getNormal2: () => (/* reexport */ getNormal2),
  getNormal3: () => (/* reexport */ getNormal3),
  getSignedArea: () => (/* reexport */ getSignedArea),
  getSubPixelSpacingAndXYDirections: () => (/* reexport */ polyline_getSubPixelSpacingAndXYDirections),
  getWindingDirection: () => (/* reexport */ getWindingDirection),
  intersectPolyline: () => (/* reexport */ intersectPolyline),
  isClosed: () => (/* reexport */ isClosed),
  isPointInsidePolyline3D: () => (/* reexport */ isPointInsidePolyline3D),
  mergePolylines: () => (/* reexport */ mergePolylines),
  pointCanProjectOnLine: () => (/* reexport */ polyline_pointCanProjectOnLine),
  pointsAreWithinCloseContourProximity: () => (/* reexport */ polyline_pointsAreWithinCloseContourProximity),
  projectTo2D: () => (/* reexport */ projectTo2D),
  subtractPolylines: () => (/* reexport */ subtractPolylines)
});

// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/index.js
var math = __webpack_require__(73047);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/isClosed.js


function isClosed(polyline) {
    if (polyline.length < 3) {
        return false;
    }
    const numPolylinePoints = polyline.length;
    const firstPoint = polyline[0];
    const lastPoint = polyline[numPolylinePoints - 1];
    const distFirstToLastPoints = math.point.distanceToPointSquared(firstPoint, lastPoint);
    return esm/* glMatrix.equals */.Fd.equals(0, distFirstToLastPoints);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/containsPoint.js

function containsPoint(polyline, point, options = {
    closed: undefined,
}) {
    if (polyline.length < 3) {
        return false;
    }
    const numPolylinePoints = polyline.length;
    let numIntersections = 0;
    const { closed, holes } = options;
    if (holes?.length) {
        for (const hole of holes) {
            if (containsPoint(hole, point)) {
                return false;
            }
        }
    }
    const shouldClose = !(closed === undefined ? isClosed(polyline) : closed);
    const maxSegmentIndex = polyline.length - (shouldClose ? 1 : 2);
    for (let i = 0; i <= maxSegmentIndex; i++) {
        const p1 = polyline[i];
        const p2Index = i === numPolylinePoints - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const maxX = p1[0] >= p2[0] ? p1[0] : p2[0];
        const maxY = p1[1] >= p2[1] ? p1[1] : p2[1];
        const minY = p1[1] <= p2[1] ? p1[1] : p2[1];
        const mayIntersectLineSegment = point[0] <= maxX && point[1] >= minY && point[1] < maxY;
        if (mayIntersectLineSegment) {
            const isVerticalLine = p1[0] === p2[0];
            let intersects = isVerticalLine;
            if (!intersects) {
                const xIntersection = ((point[1] - p1[1]) * (p2[0] - p1[0])) / (p2[1] - p1[1]) + p1[0];
                intersects = point[0] <= xIntersection;
            }
            numIntersections += intersects ? 1 : 0;
        }
    }
    return !!(numIntersections % 2);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/containsPoints.js

function containsPoints(polyline, points) {
    for (let i = 0, numPoint = points.length; i < numPoint; i++) {
        if (!containsPoint(polyline, points[i])) {
            return false;
        }
    }
    return true;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getAABB.js
var getAABB = __webpack_require__(86970);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getArea.js
function getArea(points) {
    const n = points.length;
    let area = 0.0;
    let j = n - 1;
    for (let i = 0; i < n; i++) {
        area += (points[j][0] + points[i][0]) * (points[j][1] - points[i][1]);
        j = i;
    }
    return Math.abs(area / 2.0);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getSignedArea.js
function getSignedArea(polyline) {
    if (polyline.length < 3) {
        return 0;
    }
    const refPoint = polyline[0];
    let area = 0;
    for (let i = 0, len = polyline.length; i < len; i++) {
        const p1 = polyline[i];
        const p2Index = i === len - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const aX = p1[0] - refPoint[0];
        const aY = p1[1] - refPoint[1];
        const bX = p2[0] - refPoint[0];
        const bY = p2[1] - refPoint[1];
        area += aX * bY - aY * bX;
    }
    area *= 0.5;
    return area;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getWindingDirection.js

function getWindingDirection(polyline) {
    const signedArea = getSignedArea(polyline);
    return signedArea >= 0 ? 1 : -1;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getNormal3.js

function _getAreaVector(polyline) {
    const vecArea = esm/* vec3.create */.eR.create();
    const refPoint = polyline[0];
    for (let i = 0, len = polyline.length; i < len; i++) {
        const p1 = polyline[i];
        const p2Index = i === len - 1 ? 0 : i + 1;
        const p2 = polyline[p2Index];
        const aX = p1[0] - refPoint[0];
        const aY = p1[1] - refPoint[1];
        const aZ = p1[2] - refPoint[2];
        const bX = p2[0] - refPoint[0];
        const bY = p2[1] - refPoint[1];
        const bZ = p2[2] - refPoint[2];
        vecArea[0] += aY * bZ - aZ * bY;
        vecArea[1] += aZ * bX - aX * bZ;
        vecArea[2] += aX * bY - aY * bX;
    }
    esm/* vec3.scale */.eR.scale(vecArea, vecArea, 0.5);
    return vecArea;
}
function getNormal3(polyline) {
    const vecArea = _getAreaVector(polyline);
    return esm/* vec3.normalize */.eR.normalize(vecArea, vecArea);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getNormal2.js

function getNormal2(polyline) {
    const area = getSignedArea(polyline);
    return [0, 0, area / Math.abs(area)];
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/point/index.js
var point = __webpack_require__(14846);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/areLineSegmentsIntersecting.js
function areLineSegmentsIntersecting(p1, q1, p2, q2) {
    let result = false;
    const line1MinX = p1[0] < q1[0] ? p1[0] : q1[0];
    const line1MinY = p1[1] < q1[1] ? p1[1] : q1[1];
    const line1MaxX = p1[0] > q1[0] ? p1[0] : q1[0];
    const line1MaxY = p1[1] > q1[1] ? p1[1] : q1[1];
    const line2MinX = p2[0] < q2[0] ? p2[0] : q2[0];
    const line2MinY = p2[1] < q2[1] ? p2[1] : q2[1];
    const line2MaxX = p2[0] > q2[0] ? p2[0] : q2[0];
    const line2MaxY = p2[1] > q2[1] ? p2[1] : q2[1];
    if (line1MinX > line2MaxX ||
        line1MaxX < line2MinX ||
        line1MinY > line2MaxY ||
        line1MaxY < line2MinY) {
        return false;
    }
    const orient = [
        orientation(p1, q1, p2),
        orientation(p1, q1, q2),
        orientation(p2, q2, p1),
        orientation(p2, q2, q1),
    ];
    if (orient[0] !== orient[1] && orient[2] !== orient[3]) {
        return true;
    }
    if (orient[0] === 0 && onSegment(p1, p2, q1)) {
        result = true;
    }
    else if (orient[1] === 0 && onSegment(p1, q2, q1)) {
        result = true;
    }
    else if (orient[2] === 0 && onSegment(p2, p1, q2)) {
        result = true;
    }
    else if (orient[3] === 0 && onSegment(p2, q1, q2)) {
        result = true;
    }
    return result;
}
function orientation(p, q, r) {
    const orientationValue = (q[1] - p[1]) * (r[0] - q[0]) - (q[0] - p[0]) * (r[1] - q[1]);
    if (orientationValue === 0) {
        return 0;
    }
    return orientationValue > 0 ? 1 : 2;
}
function onSegment(p, q, r) {
    if (q[0] <= Math.max(p[0], r[0]) &&
        q[0] >= Math.min(p[0], r[0]) &&
        q[1] <= Math.max(p[1], r[1]) &&
        q[1] >= Math.min(p[1], r[1])) {
        return true;
    }
    return false;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLineSegmentIntersectionsIndexes.js

function getLineSegmentIntersectionsIndexes(polyline, p1, q1, closed = true) {
    const intersections = [];
    const numPoints = polyline.length;
    const maxI = numPoints - (closed ? 1 : 2);
    for (let i = 0; i <= maxI; i++) {
        const p2 = polyline[i];
        const j = i === numPoints - 1 ? 0 : i + 1;
        const q2 = polyline[j];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            intersections.push([i, j]);
        }
    }
    return intersections;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js + 5 modules
var line = __webpack_require__(21954);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLinesIntersection.js

const PARALLEL_LINES_TOLERANCE = 1e-2;
function getLinesIntersection(p1, q1, p2, q2) {
    const diffQ1P1 = [q1[0] - p1[0], q1[1] - p1[1]];
    const diffQ2P2 = [q2[0] - p2[0], q2[1] - p2[1]];
    const denominator = diffQ2P2[1] * diffQ1P1[0] - diffQ2P2[0] * diffQ1P1[1];
    const absDenominator = denominator >= 0 ? denominator : -denominator;
    if (absDenominator < PARALLEL_LINES_TOLERANCE) {
        const line1AABB = [
            p1[0] < q1[0] ? p1[0] : q1[0],
            p1[0] > q1[0] ? p1[0] : q1[0],
            p1[1] < q1[1] ? p1[1] : q1[1],
            p1[1] > q1[1] ? p1[1] : q1[1],
        ];
        const line2AABB = [
            p2[0] < q2[0] ? p2[0] : q2[0],
            p2[0] > q2[0] ? p2[0] : q2[0],
            p2[1] < q2[1] ? p2[1] : q2[1],
            p2[1] > q2[1] ? p2[1] : q2[1],
        ];
        const aabbIntersects = line1AABB[0] <= line2AABB[1] &&
            line1AABB[1] >= line2AABB[0] &&
            line1AABB[2] <= line2AABB[3] &&
            line1AABB[3] >= line2AABB[2];
        if (!aabbIntersects) {
            return;
        }
        const overlap = line.isPointOnLineSegment(p1, q1, p2) ||
            line.isPointOnLineSegment(p1, q1, q2) ||
            line.isPointOnLineSegment(p2, q2, p1);
        if (!overlap) {
            return;
        }
        const minX = line1AABB[0] > line2AABB[0] ? line1AABB[0] : line2AABB[0];
        const maxX = line1AABB[1] < line2AABB[1] ? line1AABB[1] : line2AABB[1];
        const minY = line1AABB[2] > line2AABB[2] ? line1AABB[2] : line2AABB[2];
        const maxY = line1AABB[3] < line2AABB[3] ? line1AABB[3] : line2AABB[3];
        const midX = (minX + maxX) * 0.5;
        const midY = (minY + maxY) * 0.5;
        return [midX, midY];
    }
    let a = p1[1] - p2[1];
    let b = p1[0] - p2[0];
    const numerator1 = diffQ2P2[0] * a - diffQ2P2[1] * b;
    const numerator2 = diffQ1P1[0] * a - diffQ1P1[1] * b;
    a = numerator1 / denominator;
    b = numerator2 / denominator;
    const resultX = p1[0] + a * diffQ1P1[0];
    const resultY = p1[1] + a * diffQ1P1[1];
    return [resultX, resultY];
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/combinePolyline.js






var PolylinePointType;
(function (PolylinePointType) {
    PolylinePointType[PolylinePointType["Vertex"] = 0] = "Vertex";
    PolylinePointType[PolylinePointType["Intersection"] = 1] = "Intersection";
})(PolylinePointType || (PolylinePointType = {}));
var PolylinePointPosition;
(function (PolylinePointPosition) {
    PolylinePointPosition[PolylinePointPosition["Outside"] = -1] = "Outside";
    PolylinePointPosition[PolylinePointPosition["Edge"] = 0] = "Edge";
    PolylinePointPosition[PolylinePointPosition["Inside"] = 1] = "Inside";
})(PolylinePointPosition || (PolylinePointPosition = {}));
var PolylinePointDirection;
(function (PolylinePointDirection) {
    PolylinePointDirection[PolylinePointDirection["Exiting"] = -1] = "Exiting";
    PolylinePointDirection[PolylinePointDirection["Unknown"] = 0] = "Unknown";
    PolylinePointDirection[PolylinePointDirection["Entering"] = 1] = "Entering";
})(PolylinePointDirection || (PolylinePointDirection = {}));
function ensuresNextPointers(polylinePoints) {
    for (let i = 0, len = polylinePoints.length; i < len; i++) {
        const currentPoint = polylinePoints[i];
        if (!currentPoint.next) {
            currentPoint.next = polylinePoints[i === len - 1 ? 0 : i + 1];
        }
    }
}
function getSourceAndTargetPointsList(targetPolyline, sourcePolyline) {
    const targetPolylinePoints = [];
    const sourcePolylinePoints = [];
    const sourceIntersectionsCache = new Map();
    const isFirstPointInside = containsPoint(sourcePolyline, targetPolyline[0]);
    let intersectionPointDirection = isFirstPointInside
        ? PolylinePointDirection.Exiting
        : PolylinePointDirection.Entering;
    for (let i = 0, len = targetPolyline.length; i < len; i++) {
        const p1 = targetPolyline[i];
        const pointInside = containsPoint(sourcePolyline, p1);
        const vertexPoint = {
            type: PolylinePointType.Vertex,
            coordinates: p1,
            position: pointInside
                ? PolylinePointPosition.Inside
                : PolylinePointPosition.Outside,
            visited: false,
            next: null,
        };
        targetPolylinePoints.push(vertexPoint);
        const q1 = targetPolyline[i === len - 1 ? 0 : i + 1];
        const intersectionsInfo = getLineSegmentIntersectionsIndexes(sourcePolyline, p1, q1).map((intersectedLineSegment) => {
            const sourceLineSegmentId = intersectedLineSegment[0];
            const p2 = sourcePolyline[intersectedLineSegment[0]];
            const q2 = sourcePolyline[intersectedLineSegment[1]];
            const intersectionCoordinate = getLinesIntersection(p1, q1, p2, q2);
            const targetStartPointDistSquared = point.distanceToPointSquared(p1, intersectionCoordinate);
            return {
                sourceLineSegmentId,
                coordinate: intersectionCoordinate,
                targetStartPointDistSquared,
            };
        });
        intersectionsInfo.sort((left, right) => left.targetStartPointDistSquared - right.targetStartPointDistSquared);
        intersectionsInfo.forEach((intersectionInfo) => {
            const { sourceLineSegmentId, coordinate: intersectionCoordinate } = intersectionInfo;
            const targetEdgePoint = {
                type: PolylinePointType.Intersection,
                coordinates: intersectionCoordinate,
                position: PolylinePointPosition.Edge,
                direction: intersectionPointDirection,
                visited: false,
                next: null,
            };
            const sourceEdgePoint = {
                ...targetEdgePoint,
                direction: PolylinePointDirection.Unknown,
                cloned: true,
            };
            if (intersectionPointDirection === PolylinePointDirection.Entering) {
                targetEdgePoint.next = sourceEdgePoint;
            }
            else {
                sourceEdgePoint.next = targetEdgePoint;
            }
            let sourceIntersectionPoints = sourceIntersectionsCache.get(sourceLineSegmentId);
            if (!sourceIntersectionPoints) {
                sourceIntersectionPoints = [];
                sourceIntersectionsCache.set(sourceLineSegmentId, sourceIntersectionPoints);
            }
            targetPolylinePoints.push(targetEdgePoint);
            sourceIntersectionPoints.push(sourceEdgePoint);
            intersectionPointDirection *= -1;
        });
    }
    for (let i = 0, len = sourcePolyline.length; i < len; i++) {
        const lineSegmentId = i;
        const p1 = sourcePolyline[i];
        const vertexPoint = {
            type: PolylinePointType.Vertex,
            coordinates: p1,
            visited: false,
            next: null,
        };
        sourcePolylinePoints.push(vertexPoint);
        const sourceIntersectionPoints = sourceIntersectionsCache.get(lineSegmentId);
        if (!sourceIntersectionPoints?.length) {
            continue;
        }
        sourceIntersectionPoints
            .map((intersectionPoint) => ({
            intersectionPoint,
            lineSegStartDistSquared: point.distanceToPointSquared(p1, intersectionPoint.coordinates),
        }))
            .sort((left, right) => left.lineSegStartDistSquared - right.lineSegStartDistSquared)
            .map(({ intersectionPoint }) => intersectionPoint)
            .forEach((intersectionPoint) => sourcePolylinePoints.push(intersectionPoint));
    }
    ensuresNextPointers(targetPolylinePoints);
    ensuresNextPointers(sourcePolylinePoints);
    return { targetPolylinePoints, sourcePolylinePoints };
}
function getUnvisitedOutsidePoint(polylinePoints) {
    for (let i = 0, len = polylinePoints.length; i < len; i++) {
        const point = polylinePoints[i];
        if (!point.visited && point.position === PolylinePointPosition.Outside) {
            return point;
        }
    }
}
function mergePolylines(targetPolyline, sourcePolyline) {
    const targetNormal = getNormal2(targetPolyline);
    const sourceNormal = getNormal2(sourcePolyline);
    const dotNormals = esm/* vec3.dot */.eR.dot(sourceNormal, targetNormal);
    if (!esm/* glMatrix.equals */.Fd.equals(1, dotNormals)) {
        sourcePolyline = sourcePolyline.slice().reverse();
    }
    const { targetPolylinePoints } = getSourceAndTargetPointsList(targetPolyline, sourcePolyline);
    const startPoint = getUnvisitedOutsidePoint(targetPolylinePoints);
    if (!startPoint) {
        return targetPolyline.slice();
    }
    const mergedPolyline = [startPoint.coordinates];
    let currentPoint = startPoint.next;
    while (currentPoint !== startPoint) {
        if (currentPoint.type === PolylinePointType.Intersection &&
            currentPoint.cloned) {
            currentPoint = currentPoint.next;
            continue;
        }
        mergedPolyline.push(currentPoint.coordinates);
        currentPoint = currentPoint.next;
    }
    return mergedPolyline;
}
function subtractPolylines(targetPolyline, sourcePolyline) {
    const targetNormal = getNormal2(targetPolyline);
    const sourceNormal = getNormal2(sourcePolyline);
    const dotNormals = esm/* vec3.dot */.eR.dot(sourceNormal, targetNormal);
    if (!esm/* glMatrix.equals */.Fd.equals(-1, dotNormals)) {
        sourcePolyline = sourcePolyline.slice().reverse();
    }
    const { targetPolylinePoints } = getSourceAndTargetPointsList(targetPolyline, sourcePolyline);
    let startPoint = null;
    const subtractedPolylines = [];
    while ((startPoint = getUnvisitedOutsidePoint(targetPolylinePoints))) {
        const subtractedPolyline = [startPoint.coordinates];
        let currentPoint = startPoint.next;
        startPoint.visited = true;
        while (currentPoint !== startPoint) {
            currentPoint.visited = true;
            if (currentPoint.type === PolylinePointType.Intersection &&
                currentPoint.cloned) {
                currentPoint = currentPoint.next;
                continue;
            }
            subtractedPolyline.push(currentPoint.coordinates);
            currentPoint = currentPoint.next;
        }
        subtractedPolylines.push(subtractedPolyline);
    }
    return subtractedPolylines;
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getFirstLineSegmentIntersectionIndexes.js

function getFirstLineSegmentIntersectionIndexes(points, p1, q1, closed = true) {
    let initialI;
    let j;
    if (closed) {
        j = points.length - 1;
        initialI = 0;
    }
    else {
        j = 0;
        initialI = 1;
    }
    for (let i = initialI; i < points.length; i++) {
        const p2 = points[j];
        const q2 = points[i];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            return [j, i];
        }
        j = i;
    }
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/intersectPolyline.js

function intersectPolyline(sourcePolyline, targetPolyline) {
    for (let i = 0, sourceLen = sourcePolyline.length; i < sourceLen; i++) {
        const sourceP1 = sourcePolyline[i];
        const sourceP2Index = i === sourceLen - 1 ? 0 : i + 1;
        const sourceP2 = sourcePolyline[sourceP2Index];
        const intersectionPointIndexes = getFirstLineSegmentIntersectionIndexes(targetPolyline, sourceP1, sourceP2);
        if (intersectionPointIndexes?.length === 2) {
            return true;
        }
    }
    return false;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/decimate.js

const DEFAULT_EPSILON = 0.1;
function decimate(polyline, epsilon = DEFAULT_EPSILON) {
    const numPoints = polyline.length;
    if (numPoints < 3) {
        return polyline;
    }
    const epsilonSquared = epsilon * epsilon;
    const partitionQueue = [[0, numPoints - 1]];
    const polylinePointFlags = new Array(numPoints).fill(false);
    let numDecimatedPoints = 2;
    polylinePointFlags[0] = true;
    polylinePointFlags[numPoints - 1] = true;
    while (partitionQueue.length) {
        const [startIndex, endIndex] = partitionQueue.pop();
        if (endIndex - startIndex === 1) {
            continue;
        }
        const startPoint = polyline[startIndex];
        const endPoint = polyline[endIndex];
        let maxDistSquared = -Infinity;
        let maxDistIndex = -1;
        for (let i = startIndex + 1; i < endIndex; i++) {
            const currentPoint = polyline[i];
            const distSquared = line.distanceToPointSquared(startPoint, endPoint, currentPoint);
            if (distSquared > maxDistSquared) {
                maxDistSquared = distSquared;
                maxDistIndex = i;
            }
        }
        if (maxDistSquared < epsilonSquared) {
            continue;
        }
        polylinePointFlags[maxDistIndex] = true;
        numDecimatedPoints++;
        partitionQueue.push([maxDistIndex, endIndex]);
        partitionQueue.push([startIndex, maxDistIndex]);
    }
    const decimatedPolyline = new Array(numDecimatedPoints);
    for (let srcIndex = 0, dstIndex = 0; srcIndex < numPoints; srcIndex++) {
        if (polylinePointFlags[srcIndex]) {
            decimatedPolyline[dstIndex++] = polyline[srcIndex];
        }
    }
    return decimatedPolyline;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getLineSegmentIntersectionsCoordinates.js


function getLineSegmentIntersectionsCoordinates(points, p1, q1, closed = true) {
    const result = [];
    const polylineIndexes = getLineSegmentIntersectionsIndexes(points, p1, q1, closed);
    for (let i = 0; i < polylineIndexes.length; i++) {
        const p2 = points[polylineIndexes[i][0]];
        const q2 = points[polylineIndexes[i][1]];
        const intersection = getLinesIntersection(p1, q1, p2, q2);
        result.push(intersection);
    }
    return result;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getClosestLineSegmentIntersection.js


function getClosestLineSegmentIntersection(points, p1, q1, closed = true) {
    let initialQ2Index;
    let p2Index;
    if (closed) {
        p2Index = points.length - 1;
        initialQ2Index = 0;
    }
    else {
        p2Index = 0;
        initialQ2Index = 1;
    }
    const intersections = [];
    for (let q2Index = initialQ2Index; q2Index < points.length; q2Index++) {
        const p2 = points[p2Index];
        const q2 = points[q2Index];
        if (areLineSegmentsIntersecting(p1, q1, p2, q2)) {
            intersections.push([p2Index, q2Index]);
        }
        p2Index = q2Index;
    }
    if (intersections.length === 0) {
        return;
    }
    const distances = [];
    intersections.forEach((intersection) => {
        const intersectionPoints = [
            points[intersection[0]],
            points[intersection[1]],
        ];
        const midpoint = [
            (intersectionPoints[0][0] + intersectionPoints[1][0]) / 2,
            (intersectionPoints[0][1] + intersectionPoints[1][1]) / 2,
        ];
        distances.push(esm/* vec2.distance */.Zc.distance(midpoint, p1));
    });
    const minDistance = Math.min(...distances);
    const indexOfMinDistance = distances.indexOf(minDistance);
    return {
        segment: intersections[indexOfMinDistance],
        distance: minDistance,
    };
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/getSubPixelSpacingAndXYDirections.js


const EPSILON = 1e-3;
const getSubPixelSpacingAndXYDirections = (viewport, subPixelResolution) => {
    let spacing;
    let xDir;
    let yDir;
    if (viewport instanceof dist_esm.StackViewport) {
        const imageData = viewport.getImageData();
        xDir = imageData.direction.slice(0, 3);
        yDir = imageData.direction.slice(3, 6);
        spacing = imageData.spacing;
    }
    else {
        const imageData = viewport.getImageData();
        const { direction, spacing: volumeSpacing } = imageData;
        const { viewPlaneNormal, viewUp } = viewport.getCamera();
        const iVector = direction.slice(0, 3);
        const jVector = direction.slice(3, 6);
        const kVector = direction.slice(6, 9);
        const viewRight = esm/* vec3.create */.eR.create();
        esm/* vec3.cross */.eR.cross(viewRight, viewUp, viewPlaneNormal);
        const absViewRightDotI = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, iVector));
        const absViewRightDotJ = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, jVector));
        const absViewRightDotK = Math.abs(esm/* vec3.dot */.eR.dot(viewRight, kVector));
        let xSpacing;
        if (Math.abs(1 - absViewRightDotI) < EPSILON) {
            xSpacing = volumeSpacing[0];
            xDir = iVector;
        }
        else if (Math.abs(1 - absViewRightDotJ) < EPSILON) {
            xSpacing = volumeSpacing[1];
            xDir = jVector;
        }
        else if (Math.abs(1 - absViewRightDotK) < EPSILON) {
            xSpacing = volumeSpacing[2];
            xDir = kVector;
        }
        else {
            throw new Error('No support yet for oblique plane planar contours');
        }
        const absViewUpDotI = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, iVector));
        const absViewUpDotJ = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, jVector));
        const absViewUpDotK = Math.abs(esm/* vec3.dot */.eR.dot(viewUp, kVector));
        let ySpacing;
        if (Math.abs(1 - absViewUpDotI) < EPSILON) {
            ySpacing = volumeSpacing[0];
            yDir = iVector;
        }
        else if (Math.abs(1 - absViewUpDotJ) < EPSILON) {
            ySpacing = volumeSpacing[1];
            yDir = jVector;
        }
        else if (Math.abs(1 - absViewUpDotK) < EPSILON) {
            ySpacing = volumeSpacing[2];
            yDir = kVector;
        }
        else {
            throw new Error('No support yet for oblique plane planar contours');
        }
        spacing = [xSpacing, ySpacing];
    }
    const subPixelSpacing = [
        spacing[0] / subPixelResolution,
        spacing[1] / subPixelResolution,
    ];
    return { spacing: subPixelSpacing, xDir, yDir };
};
/* harmony default export */ const polyline_getSubPixelSpacingAndXYDirections = (getSubPixelSpacingAndXYDirections);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/pointsAreWithinCloseContourProximity.js

const pointsAreWithinCloseContourProximity = (p1, p2, closeContourProximity) => {
    return esm/* vec2.dist */.Zc.dist(p1, p2) < closeContourProximity;
};
/* harmony default export */ const polyline_pointsAreWithinCloseContourProximity = (pointsAreWithinCloseContourProximity);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/addCanvasPointsToArray.js


const addCanvasPointsToArray = (element, canvasPoints, newCanvasPoint, commonData) => {
    const { xDir, yDir, spacing } = commonData;
    const enabledElement = (0,dist_esm.getEnabledElement)(element);
    const { viewport } = enabledElement;
    if (!canvasPoints.length) {
        canvasPoints.push(newCanvasPoint);
        console.log('>>>>> !canvasPoints. :: RETURN');
        return 1;
    }
    const lastWorldPos = viewport.canvasToWorld(canvasPoints[canvasPoints.length - 1]);
    const newWorldPos = viewport.canvasToWorld(newCanvasPoint);
    const worldPosDiff = esm/* vec3.create */.eR.create();
    esm/* vec3.subtract */.eR.subtract(worldPosDiff, newWorldPos, lastWorldPos);
    const xDist = Math.abs(esm/* vec3.dot */.eR.dot(worldPosDiff, xDir));
    const yDist = Math.abs(esm/* vec3.dot */.eR.dot(worldPosDiff, yDir));
    const numPointsToAdd = Math.max(Math.floor(xDist / spacing[0]), Math.floor(yDist / spacing[0]));
    if (numPointsToAdd > 1) {
        const lastCanvasPoint = canvasPoints[canvasPoints.length - 1];
        const canvasDist = esm/* vec2.dist */.Zc.dist(lastCanvasPoint, newCanvasPoint);
        const canvasDir = esm/* vec2.create */.Zc.create();
        esm/* vec2.subtract */.Zc.subtract(canvasDir, newCanvasPoint, lastCanvasPoint);
        esm/* vec2.set */.Zc.set(canvasDir, canvasDir[0] / canvasDist, canvasDir[1] / canvasDist);
        const distPerPoint = canvasDist / numPointsToAdd;
        for (let i = 1; i <= numPointsToAdd; i++) {
            canvasPoints.push([
                lastCanvasPoint[0] + distPerPoint * canvasDir[0] * i,
                lastCanvasPoint[1] + distPerPoint * canvasDir[1] * i,
            ]);
        }
    }
    else {
        canvasPoints.push(newCanvasPoint);
    }
    return numPointsToAdd;
};
/* harmony default export */ const polyline_addCanvasPointsToArray = (addCanvasPointsToArray);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/pointCanProjectOnLine.js

const pointCanProjectOnLine = (p, p1, p2, proximity) => {
    const p1p = [p[0] - p1[0], p[1] - p1[1]];
    const p1p2 = [p2[0] - p1[0], p2[1] - p1[1]];
    const dot = p1p[0] * p1p2[0] + p1p[1] * p1p2[1];
    if (dot < 0) {
        return false;
    }
    const p1p2Mag = Math.sqrt(p1p2[0] * p1p2[0] + p1p2[1] * p1p2[1]);
    if (p1p2Mag === 0) {
        return false;
    }
    const projectionVectorMag = dot / p1p2Mag;
    const p1p2UnitVector = [p1p2[0] / p1p2Mag, p1p2[1] / p1p2Mag];
    const projectionVector = [
        p1p2UnitVector[0] * projectionVectorMag,
        p1p2UnitVector[1] * projectionVectorMag,
    ];
    const projectionPoint = [
        p1[0] + projectionVector[0],
        p1[1] + projectionVector[1],
    ];
    const distance = esm/* vec2.distance */.Zc.distance(p, projectionPoint);
    if (distance > proximity) {
        return false;
    }
    if (esm/* vec2.distance */.Zc.distance(p1, projectionPoint) > esm/* vec2.distance */.Zc.distance(p1, p2)) {
        return false;
    }
    return true;
};
/* harmony default export */ const polyline_pointCanProjectOnLine = (pointCanProjectOnLine);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/projectTo2D.js

const epsilon = 1e-6;
function projectTo2D(polyline) {
    let sharedDimensionIndex;
    const testPoints = dist_esm.utilities.getRandomSampleFromArray(polyline, 50);
    for (let i = 0; i < 3; i++) {
        if (testPoints.every((point, index, array) => Math.abs(point[i] - array[0][i]) < epsilon)) {
            sharedDimensionIndex = i;
            break;
        }
    }
    if (sharedDimensionIndex === undefined) {
        throw new Error('Cannot find a shared dimension index for polyline, probably oblique plane');
    }
    const points2D = [];
    const firstDim = (sharedDimensionIndex + 1) % 3;
    const secondDim = (sharedDimensionIndex + 2) % 3;
    for (let i = 0; i < polyline.length; i++) {
        points2D.push([polyline[i][firstDim], polyline[i][secondDim]]);
    }
    return {
        sharedDimensionIndex,
        projectedPolyline: points2D,
    };
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/isPointInsidePolyline3D.js


function isPointInsidePolyline3D(point, polyline, options = {}) {
    const { sharedDimensionIndex, projectedPolyline } = projectTo2D(polyline);
    const { holes } = options;
    const projectedHoles = [];
    if (holes) {
        for (let i = 0; i < holes.length; i++) {
            const hole = holes[i];
            const hole2D = [];
            for (let j = 0; j < hole.length; j++) {
                hole2D.push([
                    hole[j][(sharedDimensionIndex + 1) % 3],
                    hole[j][(sharedDimensionIndex + 2) % 3],
                ]);
            }
            projectedHoles.push(hole2D);
        }
    }
    const point2D = [
        point[(sharedDimensionIndex + 1) % 3],
        point[(sharedDimensionIndex + 2) % 3],
    ];
    return containsPoint(projectedPolyline, point2D, { holes: projectedHoles });
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/index.js

























/***/ }),

/***/ 23345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  distanceToPoint: () => (/* reexport */ distanceToPoint)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/line/index.js + 5 modules
var line = __webpack_require__(21954);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/rectangle/distanceToPoint.js

function rectToLineSegments(left, top, width, height) {
    const topLineStart = [left, top];
    const topLineEnd = [left + width, top];
    const rightLineStart = [left + width, top];
    const rightLineEnd = [left + width, top + height];
    const bottomLineStart = [left + width, top + height];
    const bottomLineEnd = [left, top + height];
    const leftLineStart = [left, top + height];
    const leftLineEnd = [left, top];
    const lineSegments = {
        top: [topLineStart, topLineEnd],
        right: [rightLineStart, rightLineEnd],
        bottom: [bottomLineStart, bottomLineEnd],
        left: [leftLineStart, leftLineEnd],
    };
    return lineSegments;
}
function distanceToPoint(rect, point) {
    if (rect.length !== 4 || point.length !== 2) {
        throw Error('rectangle:[left, top, width, height] or point: [x,y] not defined correctly');
    }
    const [left, top, width, height] = rect;
    let minDistance = 655535;
    const lineSegments = rectToLineSegments(left, top, width, height);
    Object.keys(lineSegments).forEach((segment) => {
        const [lineStart, lineEnd] = lineSegments[segment];
        const distance = line.distanceToPoint(lineStart, lineEnd, point);
        if (distance < minDistance) {
            minDistance = distance;
        }
    });
    return minDistance;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/rectangle/index.js




/***/ }),

/***/ 19096:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  d: () => (/* reexport */ pointInSphere)
});

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/sphere/pointInSphere.js
function pointInSphere(sphere, pointLPS) {
    const { center, radius } = sphere;
    const radius2 = sphere.radius2 || radius * radius;
    return ((pointLPS[0] - center[0]) * (pointLPS[0] - center[0]) +
        (pointLPS[1] - center[1]) * (pointLPS[1] - center[1]) +
        (pointLPS[2] - center[2]) * (pointLPS[2] - center[2]) <=
        radius2);
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/sphere/index.js




/***/ }),

/***/ 73100:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _findClosestPoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87658);
/* harmony import */ var _liangBarksyClip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86981);





/***/ }),

/***/ 86981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ clip)
/* harmony export */ });
const EPSILON = 1e-6;
const INSIDE = 1;
const OUTSIDE = 0;
function clipT(num, denom, c) {
    const [tE, tL] = c;
    if (Math.abs(denom) < EPSILON) {
        return num < 0;
    }
    const t = num / denom;
    if (denom > 0) {
        if (t > tL) {
            return 0;
        }
        if (t > tE) {
            c[0] = t;
        }
    }
    else {
        if (t < tE) {
            return 0;
        }
        if (t < tL) {
            c[1] = t;
        }
    }
    return 1;
}
function clip(a, b, box, da, db) {
    const [x1, y1] = a;
    const [x2, y2] = b;
    const dx = x2 - x1;
    const dy = y2 - y1;
    if (da === undefined || db === undefined) {
        da = a;
        db = b;
    }
    else {
        da[0] = a[0];
        da[1] = a[1];
        db[0] = b[0];
        db[1] = b[1];
    }
    if (Math.abs(dx) < EPSILON &&
        Math.abs(dy) < EPSILON &&
        x1 >= box[0] &&
        x1 <= box[2] &&
        y1 >= box[1] &&
        y1 <= box[3]) {
        return INSIDE;
    }
    const c = [0, 1];
    if (clipT(box[0] - x1, dx, c) &&
        clipT(x1 - box[2], -dx, c) &&
        clipT(box[1] - y1, dy, c) &&
        clipT(y1 - box[3], -dy, c)) {
        const [tE, tL] = c;
        if (tL < 1) {
            db[0] = x1 + tL * dx;
            db[1] = y1 + tL * dy;
        }
        if (tE > 0) {
            da[0] += tE * dx;
            da[1] += tE * dy;
        }
        return INSIDE;
    }
    return OUTSIDE;
}


/***/ }),

/***/ 80393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
function getOrientationStringLPS(vector) {
    let orientation = '';
    const orientationX = vector[0] < 0 ? 'R' : 'L';
    const orientationY = vector[1] < 0 ? 'A' : 'P';
    const orientationZ = vector[2] < 0 ? 'F' : 'H';
    const abs = [Math.abs(vector[0]), Math.abs(vector[1]), Math.abs(vector[2])];
    const MIN = 0.0001;
    for (let i = 0; i < 3; i++) {
        if (abs[0] > MIN && abs[0] > abs[1] && abs[0] > abs[2]) {
            orientation += orientationX;
            abs[0] = 0;
        }
        else if (abs[1] > MIN && abs[1] > abs[0] && abs[1] > abs[2]) {
            orientation += orientationY;
            abs[1] = 0;
        }
        else if (abs[2] > MIN && abs[2] > abs[0] && abs[2] > abs[1]) {
            orientation += orientationZ;
            abs[2] = 0;
        }
        else if (abs[0] > MIN && abs[1] > MIN && abs[0] === abs[1]) {
            orientation += orientationX + orientationY;
            abs[0] = 0;
            abs[1] = 0;
        }
        else if (abs[0] > MIN && abs[2] > MIN && abs[0] === abs[2]) {
            orientation += orientationX + orientationZ;
            abs[0] = 0;
            abs[2] = 0;
        }
        else if (abs[1] > MIN && abs[2] > MIN && abs[1] === abs[2]) {
            orientation += orientationY + orientationZ;
            abs[1] = 0;
            abs[2] = 0;
        }
        else {
            break;
        }
    }
    return orientation;
}


/***/ }),

/***/ 39365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
function invertOrientationStringLPS(orientationString) {
    let inverted = orientationString.replace('H', 'f');
    inverted = inverted.replace('F', 'h');
    inverted = inverted.replace('R', 'l');
    inverted = inverted.replace('L', 'r');
    inverted = inverted.replace('A', 'p');
    inverted = inverted.replace('P', 'a');
    inverted = inverted.toUpperCase();
    return inverted;
}


/***/ }),

/***/ 84797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   filterAnnotationsForDisplay: () => (/* reexport safe */ _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__.A),
/* harmony export */   getPointInLineOfSightWithCriteria: () => (/* reexport safe */ _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__.A),
/* harmony export */   isPlaneIntersectingAABB: () => (/* reexport safe */ _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__.Y)
/* harmony export */ });
/* harmony import */ var _filterAnnotationsWithinSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17926);
/* harmony import */ var _getWorldWidthAndHeightFromCorners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(78609);
/* harmony import */ var _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65826);
/* harmony import */ var _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3895);
/* harmony import */ var _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99706);





/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    filterAnnotationsWithinSlice: _filterAnnotationsWithinSlice__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A,
    getWorldWidthAndHeightFromCorners: _getWorldWidthAndHeightFromCorners__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A,
    filterAnnotationsForDisplay: _filterAnnotationsForDisplay__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A,
    getPointInLineOfSightWithCriteria: _getPointInLineOfSightWithCriteria__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A,
    isPlaneIntersectingAABB: _isPlaneIntersectingAABB__WEBPACK_IMPORTED_MODULE_4__/* .isPlaneIntersectingAABB */ .Y,
});



/***/ }),

/***/ 44074:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _smoothAnnotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(14659);

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    smoothAnnotation: _smoothAnnotation__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A,
});



/***/ }),

/***/ 75403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ pointInShapeCallback)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);

function pointInShapeCallback(imageData, pointInShapeFn, callback, boundsIJK) {
    let iMin, iMax, jMin, jMax, kMin, kMax;
    let scalarData;
    const { numComps } = imageData;
    if (imageData.getScalarData) {
        scalarData = imageData.getScalarData();
    }
    else {
        scalarData = imageData
            .getPointData()
            .getScalars()
            .getData();
    }
    const dimensions = imageData.getDimensions();
    if (!boundsIJK) {
        iMin = 0;
        iMax = dimensions[0];
        jMin = 0;
        jMax = dimensions[1];
        kMin = 0;
        kMax = dimensions[2];
    }
    else {
        [[iMin, iMax], [jMin, jMax], [kMin, kMax]] = boundsIJK;
    }
    const start = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(iMin, jMin, kMin);
    const direction = imageData.getDirection();
    const rowCosines = direction.slice(0, 3);
    const columnCosines = direction.slice(3, 6);
    const scanAxisNormal = direction.slice(6, 9);
    const spacing = imageData.getSpacing();
    const [rowSpacing, columnSpacing, scanAxisSpacing] = spacing;
    const worldPosStart = imageData.indexToWorld(start);
    const rowStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(rowCosines[0] * rowSpacing, rowCosines[1] * rowSpacing, rowCosines[2] * rowSpacing);
    const columnStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(columnCosines[0] * columnSpacing, columnCosines[1] * columnSpacing, columnCosines[2] * columnSpacing);
    const scanAxisStep = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(scanAxisNormal[0] * scanAxisSpacing, scanAxisNormal[1] * scanAxisSpacing, scanAxisNormal[2] * scanAxisSpacing);
    const xMultiple = numComps ||
        scalarData.length / dimensions[2] / dimensions[1] / dimensions[0];
    const yMultiple = dimensions[0] * xMultiple;
    const zMultiple = dimensions[1] * yMultiple;
    const pointsInShape = [];
    const currentPos = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(worldPosStart);
    for (let k = kMin; k <= kMax; k++) {
        const startPosJ = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(currentPos);
        for (let j = jMin; j <= jMax; j++) {
            const startPosI = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.clone */ .eR.clone(currentPos);
            for (let i = iMin; i <= iMax; i++) {
                const pointIJK = [i, j, k];
                if (pointInShapeFn(currentPos, pointIJK)) {
                    const index = k * zMultiple + j * yMultiple + i * xMultiple;
                    let value;
                    if (xMultiple > 2) {
                        value = [
                            scalarData[index],
                            scalarData[index + 1],
                            scalarData[index + 2],
                        ];
                    }
                    else {
                        value = scalarData[index];
                    }
                    pointsInShape.push({
                        value,
                        index,
                        pointIJK,
                        pointLPS: currentPos.slice(),
                    });
                    if (callback) {
                        callback({ value, index, pointIJK, pointLPS: currentPos });
                    }
                }
                gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, rowStep);
            }
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.copy */ .eR.copy(currentPos, startPosI);
            gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, columnStep);
        }
        gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.copy */ .eR.copy(currentPos, startPosJ);
        gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.add */ .eR.add(currentPos, currentPos, scanAxisStep);
    }
    return pointsInShape;
}


/***/ }),

/***/ 5093:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _math_sphere__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19096);
/* harmony import */ var _pointInShapeCallback__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(75403);
/* harmony import */ var _boundingBox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15306);





const { transformWorldToIndex } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
function pointInSurroundingSphereCallback(imageData, circlePoints, callback, viewport) {
    const { boundsIJK, centerWorld, radiusWorld } = _getBounds(circlePoints, imageData, viewport);
    const sphereObj = {
        center: centerWorld,
        radius: radiusWorld,
    };
    pointInShapeCallback(imageData, (pointLPS) => pointInSphere(sphereObj, pointLPS), callback, boundsIJK);
}
function _getBounds(circlePoints, imageData, viewport) {
    const [bottom, top] = circlePoints;
    const centerWorld = vec3.fromValues((bottom[0] + top[0]) / 2, (bottom[1] + top[1]) / 2, (bottom[2] + top[2]) / 2);
    const radiusWorld = vec3.distance(bottom, top) / 2;
    let boundsIJK;
    if (!viewport) {
        const centerIJK = transformWorldToIndex(imageData, centerWorld);
        const spacings = imageData.getSpacing();
        const minSpacing = Math.min(...spacings);
        const maxRadiusIJK = Math.ceil(radiusWorld / minSpacing);
        boundsIJK = [
            [centerIJK[0] - maxRadiusIJK, centerIJK[0] + maxRadiusIJK],
            [centerIJK[1] - maxRadiusIJK, centerIJK[1] + maxRadiusIJK],
            [centerIJK[2] - maxRadiusIJK, centerIJK[2] + maxRadiusIJK],
        ];
        return {
            boundsIJK,
            centerWorld: centerWorld,
            radiusWorld,
        };
    }
    boundsIJK = _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld);
    return {
        boundsIJK,
        centerWorld: centerWorld,
        radiusWorld,
    };
}
function _computeBoundsIJKWithCamera(imageData, viewport, circlePoints, centerWorld, radiusWorld) {
    const [bottom, top] = circlePoints;
    const dimensions = imageData.getDimensions();
    const camera = viewport.getCamera();
    const viewUp = vec3.fromValues(camera.viewUp[0], camera.viewUp[1], camera.viewUp[2]);
    const viewPlaneNormal = vec3.fromValues(camera.viewPlaneNormal[0], camera.viewPlaneNormal[1], camera.viewPlaneNormal[2]);
    const viewRight = vec3.create();
    vec3.cross(viewRight, viewUp, viewPlaneNormal);
    const topLeftWorld = vec3.create();
    const bottomRightWorld = vec3.create();
    vec3.scaleAndAdd(topLeftWorld, top, viewPlaneNormal, radiusWorld);
    vec3.scaleAndAdd(bottomRightWorld, bottom, viewPlaneNormal, -radiusWorld);
    vec3.scaleAndAdd(topLeftWorld, topLeftWorld, viewRight, -radiusWorld);
    vec3.scaleAndAdd(bottomRightWorld, bottomRightWorld, viewRight, radiusWorld);
    const sphereCornersIJK = [
        transformWorldToIndex(imageData, topLeftWorld),
        (transformWorldToIndex(imageData, bottomRightWorld)),
    ];
    const boundsIJK = getBoundingBoxAroundShape(sphereCornersIJK, dimensions);
    return boundsIJK;
}


/***/ }),

/***/ 60438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ pointToString)
/* harmony export */ });
function pointToString(point, decimals = 5) {
    return (parseFloat(point[0]).toFixed(decimals) +
        ',' +
        parseFloat(point[1]).toFixed(decimals) +
        ',' +
        parseFloat(point[2]).toFixed(decimals) +
        ',');
}


/***/ }),

/***/ 46514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPoint: () => (/* binding */ getPoint),
/* harmony export */   getPolyDataPointIndexes: () => (/* binding */ getPolyDataPointIndexes),
/* harmony export */   getPolyDataPoints: () => (/* binding */ getPolyDataPoints)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);

function getPoint(points, idx) {
    const idx3 = idx * 3;
    if (idx3 < points.length) {
        return gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(points[idx3], points[idx3 + 1], points[idx3 + 2]);
    }
}
function getPolyDataPointIndexes(polyData) {
    const linesData = polyData.getLines().getData();
    let idx = 0;
    const lineSegments = new Map();
    while (idx < linesData.length) {
        const segmentSize = linesData[idx++];
        const segment = [];
        for (let i = 0; i < segmentSize; i++) {
            segment.push(linesData[idx + i]);
        }
        lineSegments.set(segment[0], segment);
        idx += segmentSize;
    }
    const contours = [];
    const findStartingPoint = (map) => {
        for (const [key, value] of map.entries()) {
            if (value !== undefined) {
                return key;
            }
        }
        return -1;
    };
    let startPoint = findStartingPoint(lineSegments);
    while (startPoint !== -1) {
        const contour = [startPoint];
        while (lineSegments.has(startPoint)) {
            const nextPoint = lineSegments.get(startPoint)[1];
            if (lineSegments.has(nextPoint)) {
                contour.push(nextPoint);
            }
            lineSegments.delete(startPoint);
            startPoint = nextPoint;
        }
        contours.push(contour);
        startPoint = findStartingPoint(lineSegments);
    }
    return contours.length ? contours : undefined;
}
function getPolyDataPoints(polyData) {
    const contoursIndexes = getPolyDataPointIndexes(polyData);
    if (!contoursIndexes) {
        return;
    }
    const rawPointsData = polyData.getPoints().getData();
    return contoursIndexes.map((contourIndexes) => contourIndexes.map((index) => getPoint(rawPointsData, index)));
}


/***/ }),

/***/ 89786:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14471);
/* harmony import */ var _boundingBox_extend2DBoundingBoxInViewAxis__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42290);



function getBoundsIJKFromRectangleAnnotations(annotations, referenceVolume, options = {}) {
    const AllBoundsIJK = [];
    annotations.forEach((annotation) => {
        const { data } = annotation;
        const { points } = data.handles;
        const { imageData, dimensions } = referenceVolume;
        let pointsToUse = points;
        if (data.cachedStats?.projectionPoints) {
            const { projectionPoints } = data.cachedStats;
            pointsToUse = [].concat(...projectionPoints);
        }
        const rectangleCornersIJK = pointsToUse.map((world) => csUtils.transformWorldToIndex(imageData, world));
        let boundsIJK = getBoundingBoxAroundShapeIJK(rectangleCornersIJK, dimensions);
        if (options.numSlicesToProject && !data.cachedStats?.projectionPoints) {
            boundsIJK = extend2DBoundingBoxInViewAxis(boundsIJK, options.numSlicesToProject);
        }
        AllBoundsIJK.push(boundsIJK);
    });
    if (AllBoundsIJK.length === 1) {
        return AllBoundsIJK[0];
    }
    const boundsIJK = AllBoundsIJK.reduce((accumulator, currentValue) => {
        return {
            iMin: Math.min(accumulator.iMin, currentValue.iMin),
            jMin: Math.min(accumulator.jMin, currentValue.jMin),
            kMin: Math.min(accumulator.kMin, currentValue.kMin),
            iMax: Math.max(accumulator.iMax, currentValue.iMax),
            jMax: Math.max(accumulator.jMax, currentValue.jMax),
            kMax: Math.max(accumulator.kMax, currentValue.kMax),
        };
    }, {
        iMin: Infinity,
        jMin: Infinity,
        kMin: Infinity,
        iMax: -Infinity,
        jMax: -Infinity,
        kMax: -Infinity,
    });
    return boundsIJK;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (getBoundsIJKFromRectangleAnnotations)));


/***/ }),

/***/ 15874:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89786);
/* harmony import */ var _isAxisAlignedRectangle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81952);





/***/ }),

/***/ 81952:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ isAxisAlignedRectangle)
/* harmony export */ });
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);


const { isEqual } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities;
const iAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(1, 0, 0);
const jAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(0, 1, 0);
const kAxis = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.fromValues */ .eR.fromValues(0, 0, 1);
const axisList = [iAxis, jAxis, kAxis];
function isAxisAlignedRectangle(rectangleCornersIJK) {
    const rectangleVec1 = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.subtract */ .eR.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.create */ .eR.create(), rectangleCornersIJK[0], rectangleCornersIJK[1]);
    const rectangleVec2 = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.subtract */ .eR.subtract(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.create */ .eR.create(), rectangleCornersIJK[0], rectangleCornersIJK[2]);
    const anglesVec1 = calculateAnglesWithAxes(rectangleVec1, axisList);
    const anglesVec2 = calculateAnglesWithAxes(rectangleVec2, axisList);
    const isAligned = [...anglesVec1, ...anglesVec2].every((angle) => isEqual(angle, 0) ||
        isEqual(angle, 90) ||
        isEqual(angle, 180) ||
        isEqual(angle, 270));
    return isAligned;
}
function calculateAnglesWithAxes(vec, axes) {
    return axes.map((axis) => (gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec3.angle */ .eR.angle(vec, axis) * 180) / Math.PI);
}



/***/ }),

/***/ 21783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ scroll)
/* harmony export */ });
/* unused harmony export scrollVolume */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function scroll(viewport, options) {
    const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(viewport.element);
    if (!enabledElement) {
        throw new Error('Scroll::Viewport is not enabled (it might be disabled)');
    }
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport &&
        viewport.getImageIds().length === 0) {
        throw new Error('Scroll::Stack Viewport has no images');
    }
    const { type: viewportType } = viewport;
    const { volumeId, delta, scrollSlabs } = options;
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        viewport.scroll(delta, options.debounceLoading, options.loop);
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
        scrollVolume(viewport, volumeId, delta, scrollSlabs);
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VideoViewport) {
        viewport.scroll(delta);
    }
    else {
        throw new Error(`Not implemented for Viewport Type: ${viewportType}`);
    }
}
function scrollVolume(viewport, volumeId, delta, scrollSlabs = false) {
    const useSlabThickness = scrollSlabs;
    const { numScrollSteps, currentStepIndex, sliceRangeInfo } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getVolumeViewportScrollInfo(viewport, volumeId, useSlabThickness);
    if (!sliceRangeInfo) {
        return;
    }
    const { sliceRange, spacingInNormalDirection, camera } = sliceRangeInfo;
    const { focalPoint, viewPlaneNormal, position } = camera;
    const { newFocalPoint, newPosition } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.snapFocalPointToSlice(focalPoint, position, sliceRange, viewPlaneNormal, spacingInNormalDirection, delta);
    viewport.setCamera({
        focalPoint: newFocalPoint,
        position: newPosition,
    });
    viewport.render();
    const desiredStepIndex = currentStepIndex + delta;
    const VolumeScrollEventDetail = {
        volumeId,
        viewport,
        delta,
        desiredStepIndex,
        currentStepIndex,
        numScrollSteps,
        currentImageId: viewport.getCurrentImageId(),
    };
    if ((desiredStepIndex > numScrollSteps || desiredStepIndex < 0) &&
        viewport.getCurrentImageId()) {
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.triggerEvent(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.EVENTS.VOLUME_SCROLL_OUT_OF_BOUNDS, VolumeScrollEventDetail);
    }
    else {
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.triggerEvent(_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget, _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.EVENTS.VOLUME_VIEWPORT_SCROLL, VolumeScrollEventDetail);
    }
}


/***/ }),

/***/ 33836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ InterpolationManager)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45238);
/* harmony import */ var _contours_interpolation_getInterpolationDataCollection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23237);
/* harmony import */ var _contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7727);
/* harmony import */ var _deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20629);
/* harmony import */ var _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42111);
/* harmony import */ var _getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(39490);
/* harmony import */ var _contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32415);








const { uuidv4 } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities;
const ChangeTypesForInterpolation = [
    _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.HandlesUpdated,
    _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.InterpolationUpdated,
];
class InterpolationManager {
    static { this.toolNames = []; }
    static addTool(toolName) {
        if (!this.toolNames.includes(toolName)) {
            this.toolNames.push(toolName);
        }
    }
    static acceptAutoGenerated(annotationGroupSelector, selector = {}) {
        const { toolNames, segmentationId, segmentIndex, sliceIndex } = selector;
        for (const toolName of toolNames || InterpolationManager.toolNames) {
            const annotations = _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_1__.state.getAnnotations(toolName, annotationGroupSelector);
            if (!annotations?.length) {
                continue;
            }
            for (const annotation of annotations) {
                const { interpolationUID, data, autoGenerated, metadata } = annotation;
                if (interpolationUID) {
                    annotation.interpolationCompleted = true;
                }
                if (!autoGenerated) {
                    continue;
                }
                if (segmentIndex && segmentIndex !== data.segmentation.segmentIndex) {
                    continue;
                }
                if (sliceIndex !== undefined &&
                    metadata &&
                    sliceIndex !== metadata.sliceIndex) {
                    continue;
                }
                if (segmentationId &&
                    segmentationId !== data.segmentation.segmentationId) {
                    continue;
                }
                (0,_contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__/* .addContourSegmentationAnnotation */ .V)(annotation);
                annotation.autoGenerated = false;
            }
        }
    }
    static { this.handleAnnotationCompleted = (evt) => {
        const annotation = evt.detail.annotation;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName, originalToolName } = annotation.metadata;
        if (!this.toolNames.includes(toolName) &&
            !this.toolNames.includes(originalToolName)) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn('Unable to find viewport for', annotation);
            return;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
        };
        const hasInterpolationUID = !!annotation.interpolationUID;
        annotation.autoGenerated = false;
        if (hasInterpolationUID) {
            (0,_deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)(viewportData);
            (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
            return;
        }
        const filterData = [
            {
                key: 'segmentIndex',
                value: annotation.data.segmentation.segmentIndex,
                parentKey: (annotation) => annotation.data.segmentation,
            },
            {
                key: 'viewPlaneNormal',
                value: annotation.metadata.viewPlaneNormal,
                parentKey: (annotation) => annotation.metadata,
            },
            {
                key: 'viewUp',
                value: annotation.metadata.viewUp,
                parentKey: (annotation) => annotation.metadata,
            },
        ];
        let interpolationAnnotations = (0,_contours_interpolation_getInterpolationDataCollection__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A)(viewportData, filterData);
        const { sliceIndex } = annotation.metadata;
        const skipUIDs = new Set();
        interpolationAnnotations.forEach((interpolationAnnotation) => {
            if (interpolationAnnotation.interpolationCompleted ||
                interpolationAnnotation.metadata.sliceIndex === sliceIndex) {
                const { interpolationUID } = interpolationAnnotation;
                skipUIDs.add(interpolationUID);
            }
        });
        interpolationAnnotations = interpolationAnnotations.filter((interpolationAnnotation) => !skipUIDs.has(interpolationAnnotation.interpolationUID));
        annotation.interpolationUID =
            interpolationAnnotations[0]?.interpolationUID || uuidv4();
        viewportData.interpolationUID = annotation.interpolationUID;
        (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
    }; }
    static { this.handleAnnotationUpdate = (evt) => {
        const annotation = evt.detail.annotation;
        const { changeType = _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.HandlesUpdated } = evt.detail;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName, originalToolName } = annotation.metadata;
        if ((!this.toolNames.includes(toolName) &&
            !this.toolNames.includes(originalToolName)) ||
            !ChangeTypesForInterpolation.includes(changeType)) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn('Unable to find matching viewport for annotation interpolation', annotation);
            return;
        }
        if (annotation.autoGenerated) {
            (0,_contourSegmentation_addContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_7__/* .addContourSegmentationAnnotation */ .V)(annotation);
            annotation.autoGenerated = false;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
            isInterpolationUpdate: changeType === _enums_ChangeTypes__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .A.InterpolationUpdated,
        };
        (0,_contours_interpolation_interpolate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A)(viewportData);
    }; }
    static { this.handleAnnotationDelete = (evt) => {
        const annotation = evt.detail.annotation;
        if (!annotation?.metadata) {
            return;
        }
        const { toolName } = annotation.metadata;
        if (!this.toolNames.includes(toolName) || annotation.autoGenerated) {
            return;
        }
        const viewport = (0,_getViewportForAnnotation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(annotation);
        if (!viewport) {
            console.warn("No viewport, can't delete interpolated results", annotation);
            return;
        }
        const sliceData = getSliceData(viewport);
        const viewportData = {
            viewport,
            sliceData,
            annotation,
            interpolationUID: annotation.interpolationUID,
        };
        annotation.autoGenerated = false;
        (0,_deleteRelatedAnnotations__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .A)(viewportData);
    }; }
}
function getSliceData(viewport) {
    const sliceData = {
        numberOfSlices: viewport.getNumberOfSlices(),
        imageIndex: viewport.getCurrentImageIdIndex(),
    };
    return sliceData;
}


/***/ }),

/***/ 87590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports setBrushSizeForToolGroup, getBrushSizeForToolGroup */
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function setBrushSizeForToolGroup(toolGroupId, brushSize, toolName) {
    const toolGroup = getToolGroup(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = getBrushToolInstances(toolGroupId, toolName);
    brushBasedToolInstances.forEach((tool) => {
        tool.configuration.brushSize = brushSize;
        tool.invalidateBrushCursor();
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    const viewportsInfoArray = Object.keys(viewportsInfo).map((key) => viewportsInfo[key]);
    if (!viewportsInfoArray.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfoArray[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = getRenderingEngine(renderingEngineId);
    triggerAnnotationRenderForViewportIds(renderingEngine, viewportIds);
}
function getBrushSizeForToolGroup(toolGroupId, toolName) {
    const toolGroup = getToolGroup(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    const brushBasedToolInstances = getBrushToolInstances(toolGroupId, toolName);
    const brushToolInstance = brushBasedToolInstances[0];
    if (!brushToolInstance) {
        return;
    }
    return brushToolInstance.configuration.brushSize;
}


/***/ }),

/***/ 7300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports setBrushThresholdForToolGroup, getBrushThresholdForToolGroup */
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function setBrushThresholdForToolGroup(toolGroupId, threshold, otherArgs = { isDynamic: false }) {
    const toolGroup = getToolGroup(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = getBrushToolInstances(toolGroupId);
    const configuration = {
        ...otherArgs,
        ...(threshold !== undefined && { threshold }),
    };
    brushBasedToolInstances.forEach((tool) => {
        tool.configuration.strategySpecificConfiguration.THRESHOLD = {
            ...tool.configuration.strategySpecificConfiguration.THRESHOLD,
            ...configuration,
        };
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    if (!viewportsInfo.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfo[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = getRenderingEngine(renderingEngineId);
    triggerAnnotationRenderForViewportIds(renderingEngine, viewportIds);
}
function getBrushThresholdForToolGroup(toolGroupId) {
    const toolGroup = getToolGroup(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    const brushBasedToolInstances = getBrushToolInstances(toolGroupId);
    const brushToolInstance = brushBasedToolInstances[0];
    if (!brushToolInstance) {
        return;
    }
    return brushToolInstance.configuration.strategySpecificConfiguration.THRESHOLD
        .threshold;
}


/***/ }),

/***/ 41196:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/contours/index.js + 9 modules
var contours = __webpack_require__(75908);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/SegmentationRepresentations.js
var SegmentationRepresentations = __webpack_require__(83946);
// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var esm = __webpack_require__(44753);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var dist_esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/isLineInSegment.js


function isLineInSegment_isLineInSegment(point1, point2, isInSegment) {
    const ijk1 = isInSegment.toIJK(point1);
    const ijk2 = isInSegment.toIJK(point2);
    const testPoint = vec3.create();
    const { testIJK } = isInSegment;
    const delta = vec3.sub(vec3.create(), ijk1, ijk2);
    const testSize = Math.round(Math.max(...delta.map(Math.abs)));
    if (testSize < 2) {
        return true;
    }
    const unitDelta = vec3.scale(vec3.create(), delta, 1 / testSize);
    for (let i = 1; i < testSize; i++) {
        vec3.scaleAndAdd(testPoint, ijk2, unitDelta, i);
        if (!testIJK(testPoint)) {
            return false;
        }
    }
    return true;
}
function isLineInSegment_createIsInSegment(segVolumeId, segmentIndex, containedSegmentIndices) {
    const vol = cache.getVolume(segVolumeId);
    if (!vol) {
        console.warn(`No volume found for ${segVolumeId}`);
        return;
    }
    const segData = vol.imageData.getPointData().getScalars().getData();
    const width = vol.dimensions[0];
    const pixelsPerSlice = width * vol.dimensions[1];
    return {
        testCenter: (point1, point2) => {
            const point = vec3.add(vec3.create(), point1, point2).map((it) => it / 2);
            const ijk = vol.imageData.worldToIndex(point).map(Math.round);
            const [i, j, k] = ijk;
            const index = i + j * width + k * pixelsPerSlice;
            const value = segData[index];
            return value === segmentIndex || containedSegmentIndices?.has(value);
        },
        toIJK: (point) => vol.imageData.worldToIndex(point),
        testIJK: (ijk) => {
            const [i, j, k] = ijk;
            const index = Math.round(i) + Math.round(j) * width + Math.round(k) * pixelsPerSlice;
            const value = segData[index];
            return value === segmentIndex || containedSegmentIndices?.has(value);
        },
    };
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/findLargestBidirectional.js


const EPSILON = 1e-2;
function findLargestBidirectional_findLargestBidirectional(contours, segVolumeId, segment) {
    const { sliceContours } = contours;
    const { segmentIndex, containedSegmentIndices } = segment;
    let maxBidirectional;
    const isInSegment = createIsInSegment(segVolumeId, segmentIndex, containedSegmentIndices);
    for (const sliceContour of sliceContours) {
        const bidirectional = createBidirectionalForSlice(sliceContour, isInSegment, maxBidirectional);
        if (!bidirectional) {
            continue;
        }
        maxBidirectional = bidirectional;
    }
    if (maxBidirectional) {
        Object.assign(maxBidirectional, segment);
    }
    return maxBidirectional;
}
function createBidirectionalForSlice(sliceContour, isInSegment, currentMax = { maxMajor: 0, maxMinor: 0 }) {
    const { points } = sliceContour.polyData;
    const { maxMinor: currentMaxMinor, maxMajor: currentMaxMajor } = currentMax;
    let maxMajor = currentMaxMajor * currentMaxMajor;
    let maxMinor = currentMaxMinor * currentMaxMinor;
    let maxMajorPoints;
    for (let index1 = 0; index1 < points.length; index1++) {
        for (let index2 = index1 + 1; index2 < points.length; index2++) {
            const point1 = points[index1];
            const point2 = points[index2];
            const distance2 = vec3.sqrDist(point1, point2);
            if (distance2 < maxMajor) {
                continue;
            }
            if (distance2 - EPSILON < maxMajor + EPSILON && maxMajorPoints) {
                continue;
            }
            if (!isInSegment.testCenter(point1, point2)) {
                continue;
            }
            if (!isLineInSegment(point1, point2, isInSegment)) {
                continue;
            }
            maxMajor = distance2 - EPSILON;
            maxMajorPoints = [index1, index2];
            maxMinor = 0;
        }
    }
    if (!maxMajorPoints) {
        return;
    }
    maxMajor = Math.sqrt(maxMajor + EPSILON);
    const handle0 = points[maxMajorPoints[0]];
    const handle1 = points[maxMajorPoints[1]];
    const unitMajor = vec3.sub(vec3.create(), handle0, handle1);
    vec3.scale(unitMajor, unitMajor, 1 / maxMajor);
    let maxMinorPoints;
    for (let index1 = 0; index1 < points.length; index1++) {
        for (let index2 = index1 + 1; index2 < points.length; index2++) {
            const point1 = points[index1];
            const point2 = points[index2];
            const distance2 = vec3.sqrDist(point1, point2);
            if (distance2 <= maxMinor) {
                continue;
            }
            const delta = vec3.sub(vec3.create(), point1, point2);
            const dot = Math.abs(vec3.dot(delta, unitMajor)) / Math.sqrt(distance2);
            if (dot > EPSILON) {
                continue;
            }
            if (!isInSegment.testCenter(point1, point2)) {
                continue;
            }
            if (!isLineInSegment(point1, point2, isInSegment)) {
                continue;
            }
            maxMinor = distance2;
            maxMinorPoints = [index1, index2];
        }
    }
    if (!maxMinorPoints) {
        return;
    }
    maxMinor = Math.sqrt(maxMinor);
    const handle2 = points[maxMinorPoints[0]];
    const handle3 = points[maxMinorPoints[1]];
    const bidirectional = {
        majorAxis: [handle0, handle1],
        minorAxis: [handle2, handle3],
        maxMajor,
        maxMinor,
        ...sliceContour,
    };
    return bidirectional;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/segmentation/contourAndFindLargestBidirectional.js



const { Labelmap } = SegmentationRepresentations/* default */.A;
function contourAndFindLargestBidirectional(segmentation) {
    const contours = generateContourSetsFromLabelmap({
        segmentations: segmentation,
    });
    if (!contours?.length || !contours[0].sliceContours.length) {
        return;
    }
    const { representationData, segments = [
        null,
        { label: 'Unspecified', color: null, containedSegmentIndices: null },
    ], } = segmentation;
    const { volumeId: segVolumeId } = representationData[Labelmap];
    const segmentIndex = segments.findIndex((it) => !!it);
    if (segmentIndex === -1) {
        return;
    }
    segments[segmentIndex].segmentIndex = segmentIndex;
    return findLargestBidirectional(contours[0], segVolumeId, segments[segmentIndex]);
}


/***/ }),

/***/ 96610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
function createBidirectionalToolData(bidirectionalData, viewport) {
    const { majorAxis, minorAxis, label = '', sliceIndex } = bidirectionalData;
    const [major0, major1] = majorAxis;
    const [minor0, minor1] = minorAxis;
    const points = [major0, major1, minor0, minor1];
    const bidirectionalToolData = {
        highlighted: true,
        invalidated: true,
        metadata: {
            toolName: 'Bidirectional',
            ...viewport.getViewReference({ sliceIndex }),
        },
        data: {
            handles: {
                points,
                textBox: {
                    hasMoved: false,
                    worldPosition: [0, 0, 0],
                    worldBoundingBox: {
                        topLeft: [0, 0, 0],
                        topRight: [0, 0, 0],
                        bottomLeft: [0, 0, 0],
                        bottomRight: [0, 0, 0],
                    },
                },
                activeHandleIndex: null,
            },
            label,
            cachedStats: {},
        },
        isLocked: false,
        isVisible: true,
    };
    return bidirectionalToolData;
}


/***/ }),

/***/ 82914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ createImageIdReferenceMap)
/* harmony export */ });
function createImageIdReferenceMap(imageIdsArray, segmentationImageIds) {
    const imageIdReferenceMap = new Map(imageIdsArray.map((imageId, index) => {
        return [imageId, segmentationImageIds[index]];
    }));
    return imageIdReferenceMap;
}



/***/ }),

/***/ 5092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(48463);
/* harmony import */ var lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);


async function createLabelmapVolumeForViewport(input) {
    const { viewportId, renderingEngineId, options } = input;
    let { segmentationId } = input;
    const enabledElement = getEnabledElementByIds(viewportId, renderingEngineId);
    if (!enabledElement) {
        throw new Error('element disabled');
    }
    const { viewport } = enabledElement;
    if (!(viewport instanceof VolumeViewport)) {
        throw new Error('Segmentation only supports VolumeViewport');
    }
    const { uid } = viewport.getDefaultActor();
    if (segmentationId === undefined) {
        segmentationId = `${uid}-based-segmentation-${options?.volumeId ?? csUtils.uuidv4().slice(0, 8)}`;
    }
    if (options) {
        const properties = cloneDeep(options);
        await volumeLoader.createLocalVolume(properties, segmentationId);
    }
    else {
        const { uid: volumeId } = viewport.getDefaultActor();
        await volumeLoader.createAndCacheDerivedSegmentationVolume(volumeId, {
            volumeId: segmentationId,
        });
    }
    return segmentationId;
}


/***/ }),

/***/ 86398:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function createMergedLabelmapForIndex(labelmaps, segmentIndex = 1, volumeId = 'mergedLabelmap') {
    labelmaps.forEach(({ direction, dimensions, origin, spacing }) => {
        if (!csUtils.isEqual(dimensions, labelmaps[0].dimensions) ||
            !csUtils.isEqual(direction, labelmaps[0].direction) ||
            !csUtils.isEqual(spacing, labelmaps[0].spacing) ||
            !csUtils.isEqual(origin, labelmaps[0].origin)) {
            throw new Error('labelmaps must have the same size and shape');
        }
    });
    const labelmap = labelmaps[0];
    const arrayType = labelmap.getScalarData().constructor;
    const outputData = new arrayType(labelmap.getScalarData().length);
    labelmaps.forEach((labelmap) => {
        const scalarData = labelmap.getScalarData();
        for (let i = 0; i < scalarData.length; i++) {
            if (scalarData[i] === segmentIndex) {
                outputData[i] = segmentIndex;
            }
        }
    });
    const options = {
        scalarData: outputData,
        metadata: labelmap.metadata,
        spacing: labelmap.spacing,
        origin: labelmap.origin,
        direction: labelmap.direction,
        dimensions: labelmap.dimensions,
    };
    const preventCache = true;
    const mergedVolume = volumeLoader.createLocalVolume(options, volumeId, preventCache);
    return mergedVolume;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (createMergedLabelmapForIndex)));


/***/ }),

/***/ 27650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function floodFill(getter, seed, options = {}) {
    const onFlood = options.onFlood;
    const onBoundary = options.onBoundary;
    const equals = options.equals;
    const diagonals = options.diagonals || false;
    const startNode = get(seed);
    const permutations = prunedPermutations();
    const stack = [];
    const flooded = [];
    const visits = new Set();
    const bounds = new Map();
    stack.push({ currentArgs: seed });
    while (stack.length > 0) {
        flood(stack.pop());
    }
    return {
        flooded,
        boundaries: boundaries(),
    };
    function flood(job) {
        const getArgs = job.currentArgs;
        const prevArgs = job.previousArgs;
        if (visited(getArgs)) {
            return;
        }
        markAsVisited(getArgs);
        if (member(getArgs)) {
            markAsFlooded(getArgs);
            pushAdjacent(getArgs);
        }
        else {
            markAsBoundary(prevArgs);
        }
    }
    function visited(key) {
        const [x, y, z = 0] = key;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        return visits.has(iKey);
    }
    function markAsVisited(key) {
        const [x, y, z = 0] = key;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        visits.add(iKey);
    }
    function member(getArgs) {
        const node = get(getArgs);
        return equals ? equals(node, startNode) : node === startNode;
    }
    function markAsFlooded(getArgs) {
        flooded.push(getArgs);
        if (onFlood) {
            onFlood(...getArgs);
        }
    }
    function markAsBoundary(prevArgs) {
        const [x, y, z = 0] = prevArgs;
        const iKey = x + 32768 + 65536 * (y + 32768 + 65536 * (z + 32768));
        bounds.set(iKey, prevArgs);
        if (onBoundary) {
            onBoundary(...prevArgs);
        }
    }
    function pushAdjacent(getArgs) {
        for (let i = 0; i < permutations.length; i += 1) {
            const perm = permutations[i];
            const nextArgs = getArgs.slice(0);
            for (let j = 0; j < getArgs.length; j += 1) {
                nextArgs[j] += perm[j];
            }
            stack.push({
                currentArgs: nextArgs,
                previousArgs: getArgs,
            });
        }
    }
    function get(getArgs) {
        return getter(...getArgs);
    }
    function prunedPermutations() {
        const permutations = permute(seed.length);
        return permutations.filter(function (perm) {
            const count = countNonZeroes(perm);
            return count !== 0 && (count === 1 || diagonals);
        });
    }
    function permute(length) {
        const perms = [];
        const permutation = function (string) {
            return string.split('').map(function (c) {
                return parseInt(c, 10) - 1;
            });
        };
        for (let i = 0; i < Math.pow(3, length); i += 1) {
            const string = lpad(i.toString(3), '0', length);
            perms.push(permutation(string));
        }
        return perms;
    }
    function boundaries() {
        const array = Array.from(bounds.values());
        array.reverse();
        return array;
    }
}
function defaultEquals(a, b) {
    return a === b;
}
function countNonZeroes(array) {
    let count = 0;
    for (let i = 0; i < array.length; i += 1) {
        if (array[i] !== 0) {
            count += 1;
        }
    }
    return count;
}
function lpad(string, character, length) {
    const array = new Array(length + 1);
    const pad = array.join(character);
    return (pad + string).slice(-length);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (floodFill);


/***/ }),

/***/ 50969:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var _tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44350);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);


function getDefaultRepresentationConfig(segmentation) {
    const { type: representationType } = segmentation;
    switch (representationType) {
        case SegmentationRepresentation.Labelmap:
            return getDefaultLabelmapConfig();
        default:
            throw new Error(`Unknown representation type: ${representationType}`);
    }
}


/***/ }),

/***/ 4863:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ getHoveredContourSegmentationAnnotation)
/* harmony export */ });
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95778);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30322);


function getHoveredContourSegmentationAnnotation(segmentationId) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentation)(segmentationId);
    const { annotationUIDsMap } = segmentation.representationData.CONTOUR;
    for (const [segmentIndex, annotationUIDs] of annotationUIDsMap.entries()) {
        const highlightedAnnotationUID = Array.from(annotationUIDs).find((annotationUID) => (0,_stateManagement__WEBPACK_IMPORTED_MODULE_0__/* .getAnnotation */ .gw)(annotationUID).highlighted);
        if (highlightedAnnotationUID) {
            return segmentIndex;
        }
    }
    return undefined;
}


/***/ }),

/***/ 54117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   F: () => (/* binding */ getSegmentAtLabelmapBorder)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30322);
/* harmony import */ var _tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16124);



function getSegmentAtLabelmapBorder(segmentationId, worldPoint, { viewport, searchRadius }) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentation)(segmentationId);
    const labelmapData = segmentation.representationData.LABELMAP;
    if ((0,_tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_2__/* .isVolumeSegmentation */ .r)(labelmapData)) {
        const { volumeId } = labelmapData;
        const segmentationVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        if (!segmentationVolume) {
            return;
        }
        const imageData = segmentationVolume.imageData;
        const segmentIndex = imageData.getScalarValueFromWorld(worldPoint);
        const canvasPoint = viewport.worldToCanvas(worldPoint);
        const onEdge = isSegmentOnEdgeCanvas(canvasPoint, segmentIndex, viewport, imageData, searchRadius);
        return onEdge ? segmentIndex : undefined;
    }
    const { imageIdReferenceMap } = labelmapData;
    const currentImageId = viewport.getCurrentImageId();
    const segmentationImageId = imageIdReferenceMap.get(currentImageId);
    const image = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getImage(segmentationImageId);
    if (!image) {
        return;
    }
    const segmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_1__.getSegmentationIdRepresentations)(segmentation.segmentationId);
    const { segmentationRepresentationUID } = segmentationRepresentations[0];
    const segmentationActor = viewport.getActor(segmentationRepresentationUID);
    const imageData = segmentationActor?.actor.getMapper().getInputData();
    const indexIJK = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, worldPoint);
    const dimensions = imageData.getDimensions();
    const voxelManager = (imageData.voxelManager ||
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.VoxelManager.createVolumeVoxelManager(dimensions, imageData.getPointData().getScalars().getData()));
    const segmentIndex = voxelManager.getAtIJKPoint(indexIJK);
    const onEdge = isSegmentOnEdgeIJK(indexIJK, dimensions, voxelManager, segmentIndex);
    return onEdge ? segmentIndex : undefined;
}
function isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius = 1) {
    const neighborRange = Array.from({ length: 2 * searchRadius + 1 }, (_, i) => i - searchRadius);
    for (const deltaI of neighborRange) {
        for (const deltaJ of neighborRange) {
            for (const deltaK of neighborRange) {
                if (deltaI === 0 && deltaJ === 0 && deltaK === 0) {
                    continue;
                }
                const neighborIndex = getNeighborIndex(deltaI, deltaJ, deltaK);
                if (neighborIndex !== undefined && segmentIndex !== neighborIndex) {
                    return true;
                }
            }
        }
    }
    return false;
}
function isSegmentOnEdgeIJK(indexIJK, dimensions, voxelManager, segmentIndex, searchRadius) {
    const getNeighborIndex = (deltaI, deltaJ, deltaK) => {
        const neighborIJK = [
            indexIJK[0] + deltaI,
            indexIJK[1] + deltaJ,
            indexIJK[2] + deltaK,
        ];
        return voxelManager.getAtIJK(...neighborIJK);
    };
    return isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius);
}
function isSegmentOnEdgeCanvas(canvasPoint, segmentIndex, viewport, imageData, searchRadius) {
    const getNeighborIndex = (deltaI, deltaJ) => {
        const neighborCanvas = [canvasPoint[0] + deltaI, canvasPoint[1] + deltaJ];
        const worldPoint = viewport.canvasToWorld(neighborCanvas);
        return imageData.getScalarValueFromWorld(worldPoint);
    };
    return isSegmentOnEdge(getNeighborIndex, segmentIndex, searchRadius);
}


/***/ }),

/***/ 2465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z5: () => (/* binding */ getSegmentAtWorldPoint)
/* harmony export */ });
/* unused harmony exports getSegmentAtWorldForLabelmap, getSegmentAtWorldForContour */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84901);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(30322);
/* harmony import */ var _tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16124);
/* harmony import */ var _stateManagement__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(95778);
/* harmony import */ var _math_polyline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(56634);






function getSegmentAtWorldPoint(segmentationId, worldPoint, options = {}) {
    const segmentation = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__.getSegmentation)(segmentationId);
    const representationData = segmentation.representationData;
    const desiredRepresentation = options?.representationType ?? Object.keys(representationData)[0];
    if (!desiredRepresentation) {
        throw new Error(`Segmentation ${segmentationId} does not have any representations`);
    }
    switch (desiredRepresentation) {
        case _enums__WEBPACK_IMPORTED_MODULE_1__.SegmentationRepresentations.Labelmap:
            return getSegmentAtWorldForLabelmap(segmentation, worldPoint, options);
        case _enums__WEBPACK_IMPORTED_MODULE_1__.SegmentationRepresentations.Contour:
            return getSegmentAtWorldForContour(segmentation, worldPoint, options);
        default:
            return;
    }
}
function getSegmentAtWorldForLabelmap(segmentation, worldPoint, { viewport }) {
    const labelmapData = segmentation.representationData.LABELMAP;
    if ((0,_tools_segmentation_strategies_utils_stackVolumeCheck__WEBPACK_IMPORTED_MODULE_3__/* .isVolumeSegmentation */ .r)(labelmapData)) {
        const { volumeId } = labelmapData;
        const segmentationVolume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        if (!segmentationVolume) {
            return;
        }
        const segmentIndex = segmentationVolume.imageData.getScalarValueFromWorld(worldPoint);
        return segmentIndex;
    }
    const { imageIdReferenceMap } = labelmapData;
    const currentImageId = viewport.getCurrentImageId();
    const segmentationImageId = imageIdReferenceMap.get(currentImageId);
    const image = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getImage(segmentationImageId);
    if (!image) {
        return;
    }
    const segmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_2__.getSegmentationIdRepresentations)(segmentation.segmentationId);
    const { segmentationRepresentationUID } = segmentationRepresentations[0];
    const segmentationActor = viewport.getActor(segmentationRepresentationUID);
    const imageData = segmentationActor?.actor.getMapper().getInputData();
    const indexIJK = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, worldPoint);
    const dimensions = imageData.getDimensions();
    const voxelManager = (imageData.voxelManager ||
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.VoxelManager.createVolumeVoxelManager(dimensions, imageData.getPointData().getScalars().getData()));
    const segmentIndex = voxelManager.getAtIJKPoint(indexIJK);
    return segmentIndex;
}
function getSegmentAtWorldForContour(segmentation, worldPoint, { viewport }) {
    const contourData = segmentation.representationData.CONTOUR;
    const segmentIndices = Array.from(contourData.annotationUIDsMap.keys());
    const { viewPlaneNormal } = viewport.getCamera();
    for (const segmentIndex of segmentIndices) {
        const annotationsSet = contourData.annotationUIDsMap.get(segmentIndex);
        if (!annotationsSet) {
            continue;
        }
        for (const annotationUID of annotationsSet) {
            const annotation = (0,_stateManagement__WEBPACK_IMPORTED_MODULE_4__/* .getAnnotation */ .gw)(annotationUID);
            if (!annotation) {
                continue;
            }
            const { polyline } = annotation.data.contour;
            if (!_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isEqual(viewPlaneNormal, annotation.metadata.viewPlaneNormal)) {
                continue;
            }
            if ((0,_math_polyline__WEBPACK_IMPORTED_MODULE_5__.isPointInsidePolyline3D)(worldPoint, polyline)) {
                return Number(segmentIndex);
            }
        }
    }
}


/***/ }),

/***/ 10351:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createImageIdReferenceMap: () => (/* reexport safe */ _createImageIdReferenceMap__WEBPACK_IMPORTED_MODULE_11__.c),
/* harmony export */   getHoveredContourSegmentationAnnotation: () => (/* reexport safe */ _getHoveredContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_19__.L),
/* harmony export */   getSegmentAtLabelmapBorder: () => (/* reexport safe */ _getSegmentAtLabelmapBorder__WEBPACK_IMPORTED_MODULE_18__.F),
/* harmony export */   getSegmentAtWorldPoint: () => (/* reexport safe */ _getSegmentAtWorldPoint__WEBPACK_IMPORTED_MODULE_17__.Z5),
/* harmony export */   getUniqueSegmentIndices: () => (/* reexport safe */ _getUniqueSegmentIndices__WEBPACK_IMPORTED_MODULE_16__.OX),
/* harmony export */   invalidateBrushCursor: () => (/* reexport safe */ _invalidateBrushCursor__WEBPACK_IMPORTED_MODULE_15__.E),
/* harmony export */   triggerSegmentationRender: () => (/* reexport safe */ _triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_6__.h6)
/* harmony export */ });
/* harmony import */ var _thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32854);
/* harmony import */ var _rectangleROIThresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71411);
/* harmony import */ var _createMergedLabelmapForIndex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(86398);
/* harmony import */ var _isValidRepresentationConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19434);
/* harmony import */ var _getDefaultRepresentationConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50969);
/* harmony import */ var _createLabelmapVolumeForViewport__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5092);
/* harmony import */ var _triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(49521);
/* harmony import */ var _floodFill__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27650);
/* harmony import */ var _brushSizeForToolGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(87590);
/* harmony import */ var _brushThresholdForToolGroup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7300);
/* harmony import */ var _thresholdSegmentationByRange__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(92922);
/* harmony import */ var _createImageIdReferenceMap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(82914);
/* harmony import */ var _contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(41196);
/* harmony import */ var _createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(96610);
/* harmony import */ var _segmentContourAction__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(10032);
/* harmony import */ var _invalidateBrushCursor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(15818);
/* harmony import */ var _getUniqueSegmentIndices__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(94510);
/* harmony import */ var _getSegmentAtWorldPoint__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2465);
/* harmony import */ var _getSegmentAtLabelmapBorder__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(54117);
/* harmony import */ var _getHoveredContourSegmentationAnnotation__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4863);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(77071);
























/***/ }),

/***/ 15818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ invalidateBrushCursor)
/* harmony export */ });
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52610);
/* harmony import */ var _triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23072);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92136);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77071);




function invalidateBrushCursor(toolGroupId) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_0__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const brushBasedToolInstances = (0,_utilities__WEBPACK_IMPORTED_MODULE_3__/* .getBrushToolInstances */ .n7)(toolGroupId);
    brushBasedToolInstances.forEach((tool) => {
        tool.invalidateBrushCursor();
    });
    const viewportsInfo = toolGroup.getViewportsInfo();
    const viewportsInfoArray = Object.keys(viewportsInfo).map((key) => viewportsInfo[key]);
    if (!viewportsInfoArray.length) {
        return;
    }
    const { renderingEngineId } = viewportsInfoArray[0];
    const viewportIds = toolGroup.getViewportIds();
    const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_2__.getRenderingEngine)(renderingEngineId);
    (0,_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(renderingEngine, viewportIds);
}


/***/ }),

/***/ 19434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var _tools_displayTools_Labelmap_labelmapConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44350);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);


function isValidRepresentationConfig(representationType, config) {
    switch (representationType) {
        case SegmentationRepresentation.Labelmap:
            return isValidLabelmapConfig(config);
        default:
            throw new Error(`Unknown representation type: ${representationType}`);
    }
}


/***/ }),

/***/ 71411:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(45238);
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(81848);
/* harmony import */ var _thresholdVolumeByRange__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32854);
/* harmony import */ var _rectangleROITool_getBoundsIJKFromRectangleAnnotations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(89786);




function rectangleROIThresholdVolumeByRange(annotationUIDs, segmentationVolume, thresholdVolumeInformation, options) {
    const annotations = annotationUIDs.map((annotationUID) => {
        return state.getAnnotation(annotationUID);
    });
    _validateAnnotations(annotations);
    let boundsIJK;
    for (let i = 0; i < thresholdVolumeInformation.length; i++) {
        const volumeSize = thresholdVolumeInformation[i].volume.getScalarData().length;
        if (volumeSize === segmentationVolume.getScalarData().length || i === 0) {
            boundsIJK = getBoundsIJKFromRectangleAnnotations(annotations, thresholdVolumeInformation[i].volume, options);
        }
    }
    const outputSegmentationVolume = thresholdVolumeByRange(segmentationVolume, thresholdVolumeInformation, { ...options, boundsIJK });
    outputSegmentationVolume.modified();
    return outputSegmentationVolume;
}
function _validateAnnotations(annotations) {
    const validToolNames = [
        RectangleROIThresholdTool.toolName,
        RectangleROIStartEndThresholdTool.toolName,
    ];
    for (const annotation of annotations) {
        const name = annotation.metadata.toolName;
        if (!validToolNames.includes(name)) {
            throw new Error('rectangleROIThresholdVolumeByRange only supports RectangleROIThreshold and RectangleROIStartEndThreshold annotations');
        }
    }
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (rectangleROIThresholdVolumeByRange)));


/***/ }),

/***/ 10032:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports default, defaultGetSegment */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63421);
/* harmony import */ var _stateManagement_annotation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45238);
/* harmony import */ var _viewport__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(31555);
/* harmony import */ var _contourAndFindLargestBidirectional__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41196);
/* harmony import */ var _createBidirectionalToolData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(96610);
/* harmony import */ var _tools_annotation_BidirectionalTool__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(50720);







function segmentContourAction(element, configuration) {
    const { data: configurationData } = configuration;
    const enabledElement = getEnabledElement(element);
    const segment = (configurationData.getSegment || defaultGetSegment)(enabledElement, configurationData);
    if (!segment) {
        return;
    }
    const FrameOfReferenceUID = enabledElement.viewport.getFrameOfReferenceUID();
    const segmentationsList = segmentation.state.getSegmentations();
    const { segmentIndex, segmentationId } = segment;
    const bidirectionals = annotationState.getAnnotations(this.toolName || BidirectionalTool.toolName, FrameOfReferenceUID);
    let hasExistingActiveSegment = false;
    const existingLargestBidirectionals = bidirectionals.filter((existingBidirectionalItem) => {
        const { segment } = existingBidirectionalItem.data;
        if (!segment) {
            return;
        }
        if (segment.segmentationId === segmentationId &&
            segment.segmentIndex === segmentIndex) {
            hasExistingActiveSegment = true;
            existingBidirectionalItem.data.segment = segment;
        }
        return !!segment;
    });
    if (!hasExistingActiveSegment) {
        existingLargestBidirectionals.push({
            data: { segment },
        });
    }
    let newBidirectional;
    existingLargestBidirectionals.forEach((existingLargestBidirectional) => {
        const segments = [];
        const { segment: updateSegment } = existingLargestBidirectional.data;
        const { segmentIndex, segmentationId } = updateSegment;
        segments[segmentIndex] = updateSegment;
        annotationState.removeAnnotation(existingLargestBidirectional.annotationUID);
        const bidirectionalData = contourAndFindLargestBidirectional({
            ...segmentationsList.find((segmentation) => segmentation.segmentationId === segmentationId),
            segments,
        });
        if (!bidirectionalData) {
            return;
        }
        const bidirectionalToolData = createBidirectionalToolData(bidirectionalData, enabledElement.viewport);
        bidirectionalToolData.annotationUID =
            existingLargestBidirectional.annotationUID;
        bidirectionalToolData.data.segment = updateSegment;
        const annotationUID = annotationState.addAnnotation(bidirectionalToolData, FrameOfReferenceUID);
        if (updateSegment.segmentIndex === segment.segmentIndex &&
            updateSegment.segmentationId === segment.segmentationId) {
            newBidirectional = bidirectionalData;
            const { style } = segment;
            if (style) {
                annotationConfig.style.setAnnotationStyles(annotationUID, style);
            }
        }
    });
    if (newBidirectional) {
        const { sliceIndex } = newBidirectional;
        const imageIds = enabledElement.viewport.getImageIds();
        jumpToSlice(element, {
            imageIndex: imageIds.length - 1 - sliceIndex,
        });
        enabledElement.viewport.render();
    }
    else {
        console.warn('No bidirectional found');
    }
    return newBidirectional;
}
function defaultGetSegment(enabledElement, configuration) {
    const segmentationsList = segmentation.state.getSegmentations();
    if (!segmentationsList.length) {
        return;
    }
    const segmentationId = configuration.segmentationId || segmentationsList[0].segmentationId;
    const segmentIndex = configuration.segmentIndex ??
        segmentation.segmentIndex.getActiveSegmentIndex(segmentationId);
    if (!segmentIndex) {
        return;
    }
    const segmentData = configuration.segmentData?.get(segmentIndex);
    return {
        label: `Segment ${segmentIndex}`,
        segmentIndex,
        segmentationId,
        ...segmentData,
    };
}


/***/ }),

/***/ 92922:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74119);
/* harmony import */ var _stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87682);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77071);



function thresholdSegmentationByRange(segmentationVolume, segmentationIndex, thresholdVolumeInformation, overlapType) {
    const scalarData = segmentationVolume.getScalarData();
    const { baseVolumeIdx, volumeInfoList } = processVolumes(segmentationVolume, thresholdVolumeInformation);
    volumeInfoList.forEach((volumeInfo) => {
        const { volumeSize } = volumeInfo;
        if (volumeSize === scalarData.length) {
            _handleSameSizeVolume(scalarData, segmentationIndex, volumeInfo);
        }
        else {
            _handleDifferentSizeVolume(scalarData, segmentationIndex, volumeInfo, volumeInfoList, baseVolumeIdx, overlapType);
        }
    });
    triggerSegmentationDataModified(segmentationVolume.volumeId);
    return segmentationVolume;
}
function _handleDifferentSizeVolume(scalarData, segmentationIndex, volumeInfo, volumeInfoList, baseVolumeIdx, overlapType) {
    const { imageData, lower, upper, dimensions } = volumeInfo;
    let total, overlaps, range;
    for (let i = 0; i < scalarData.length; i++) {
        if (scalarData[i] === segmentationIndex) {
            const overlapBounds = getVoxelOverlap(imageData, dimensions, volumeInfoList[baseVolumeIdx].spacing, volumeInfoList[baseVolumeIdx].imageData.getPoint(i));
            const callbackOverlap = ({ value }) => {
                total = total + 1;
                if (value >= range.lower && value <= range.upper) {
                    overlaps = overlaps + 1;
                }
            };
            total = 0;
            overlaps = 0;
            range = { lower, upper };
            let overlapTest = false;
            pointInShapeCallback(imageData, () => true, callbackOverlap, overlapBounds);
            overlapTest = overlapType === 0 ? overlaps > 0 : overlaps === total;
            scalarData[i] = overlapTest ? segmentationIndex : 0;
        }
    }
    return { total, range, overlaps };
}
function _handleSameSizeVolume(scalarData, segmentationIndex, volumeInfo) {
    const { referenceValues, lower, upper } = volumeInfo;
    for (let i = 0; i < scalarData.length; i++) {
        if (scalarData[i] === segmentationIndex) {
            const value = referenceValues[i];
            scalarData[i] = value >= lower && value <= upper ? segmentationIndex : 0;
        }
    }
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (thresholdSegmentationByRange)));


/***/ }),

/***/ 32854:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(74119);
/* harmony import */ var _stateManagement_segmentation_triggerSegmentationEvents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87682);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77071);



function thresholdVolumeByRange(segmentationVolume, thresholdVolumeInformation, options) {
    const { imageData: segmentationImageData } = segmentationVolume;
    const scalarData = segmentationVolume.getScalarData();
    const { overwrite, boundsIJK } = options;
    const overlapType = options?.overlapType || 0;
    if (overwrite) {
        for (let i = 0; i < scalarData.length; i++) {
            scalarData[i] = 0;
        }
    }
    const { baseVolumeIdx, volumeInfoList } = processVolumes(segmentationVolume, thresholdVolumeInformation);
    let overlaps, total, range;
    const testOverlapRange = (volumeInfo, voxelSpacing, voxelCenter) => {
        const callbackOverlap = ({ value }) => {
            total = total + 1;
            if (value >= range.lower && value <= range.upper) {
                overlaps = overlaps + 1;
            }
        };
        const { imageData, dimensions, lower, upper } = volumeInfo;
        const overlapBounds = getVoxelOverlap(imageData, dimensions, voxelSpacing, voxelCenter);
        total = 0;
        overlaps = 0;
        range = { lower, upper };
        let overlapTest = false;
        pointInShapeCallback(imageData, () => true, callbackOverlap, overlapBounds);
        if (overlapType === 0) {
            overlapTest = overlaps > 0;
        }
        else if (overlapType == 1) {
            overlapTest = overlaps === total;
        }
        return overlapTest;
    };
    const testRange = (volumeInfo, pointIJK) => {
        const { imageData, referenceValues, lower, upper } = volumeInfo;
        const offset = imageData.computeOffsetIndex(pointIJK);
        const value = referenceValues[offset];
        if (value <= lower || value >= upper) {
            return false;
        }
        else {
            return true;
        }
    };
    const callback = ({ index, pointIJK, pointLPS }) => {
        let insert = volumeInfoList.length > 0;
        for (let i = 0; i < volumeInfoList.length; i++) {
            if (volumeInfoList[i].volumeSize === scalarData.length) {
                insert = testRange(volumeInfoList[i], pointIJK);
            }
            else {
                insert = testOverlapRange(volumeInfoList[i], volumeInfoList[baseVolumeIdx].spacing, pointLPS);
            }
            if (!insert) {
                break;
            }
        }
        if (insert) {
            scalarData[index] = options.segmentIndex || 1;
        }
    };
    pointInShapeCallback(segmentationImageData, () => true, callback, boundsIJK);
    triggerSegmentationDataModified(segmentationVolume.volumeId);
    return segmentationVolume;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (thresholdVolumeByRange)));


/***/ }),

/***/ 77071:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   n7: () => (/* binding */ getBrushToolInstances)
/* harmony export */ });
/* unused harmony exports getVoxelOverlap, processVolumes */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52610);
/* harmony import */ var _tools_segmentation_BrushTool__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53712);
/* harmony import */ var _boundingBox_getBoundingBoxAroundShape__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14471);




function getBrushToolInstances(toolGroupId, toolName) {
    const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_1__.getToolGroup)(toolGroupId);
    if (toolGroup === undefined) {
        return;
    }
    const toolInstances = toolGroup._toolInstances;
    if (!Object.keys(toolInstances).length) {
        return;
    }
    if (toolName && toolInstances[toolName]) {
        return [toolInstances[toolName]];
    }
    const brushBasedToolInstances = Object.values(toolInstances).filter((toolInstance) => toolInstance instanceof _tools_segmentation_BrushTool__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A);
    return brushBasedToolInstances;
}
const equalsCheck = (a, b) => {
    return JSON.stringify(a) === JSON.stringify(b);
};
function getVoxelOverlap(imageData, dimensions, voxelSpacing, voxelCenter) {
    const voxelCornersWorld = [];
    for (let i = 0; i < 2; i++) {
        for (let j = 0; j < 2; j++) {
            for (let k = 0; k < 2; k++) {
                const point = [...voxelCenter];
                point[0] = point[0] + ((i * 2 - 1) * voxelSpacing[0]) / 2;
                point[1] = point[1] + ((j * 2 - 1) * voxelSpacing[1]) / 2;
                point[2] = point[2] + ((k * 2 - 1) * voxelSpacing[2]) / 2;
                voxelCornersWorld.push(point);
            }
        }
    }
    const voxelCornersIJK = voxelCornersWorld.map((world) => csUtils.transformWorldToIndex(imageData, world));
    const overlapBounds = getBoundingBoxAroundShapeIJK(voxelCornersIJK, dimensions);
    return overlapBounds;
}
function processVolumes(segmentationVolume, thresholdVolumeInformation) {
    const { spacing: segmentationSpacing } = segmentationVolume;
    const scalarData = segmentationVolume.getScalarData();
    const volumeInfoList = [];
    let baseVolumeIdx = 0;
    for (let i = 0; i < thresholdVolumeInformation.length; i++) {
        const { imageData, spacing, dimensions } = thresholdVolumeInformation[i].volume;
        const volumeSize = thresholdVolumeInformation[i].volume.getScalarData().length;
        if (volumeSize === scalarData.length &&
            equalsCheck(spacing, segmentationSpacing)) {
            baseVolumeIdx = i;
        }
        const referenceValues = imageData.getPointData().getScalars().getData();
        const lower = thresholdVolumeInformation[i].lower;
        const upper = thresholdVolumeInformation[i].upper;
        volumeInfoList.push({
            imageData,
            referenceValues,
            lower,
            upper,
            spacing,
            dimensions,
            volumeSize,
        });
    }
    return {
        volumeInfoList,
        baseVolumeIdx,
    };
}


/***/ }),

/***/ 90387:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: stackContextPrefetch, stackPrefetch

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/state.js
var state = __webpack_require__(54957);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackPrefetchUtils.js
var stackPrefetchUtils = __webpack_require__(48506);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackPrefetch.js



let configuration = {
    maxImagesToPrefetch: Infinity,
    preserveExistingPool: true,
};
let resetPrefetchTimeout;
const resetPrefetchDelay = 10;
function prefetch(element) {
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (!stackPrefetchData) {
        return;
    }
    const stackPrefetch = stackPrefetchData || {};
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack?.imageIds?.length) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const { currentImageIdIndex } = stack;
    stackPrefetch.enabled &&= stackPrefetch.indicesToRequest?.length;
    if (stackPrefetch.enabled === false) {
        return;
    }
    function removeFromList(imageIdIndex) {
        const index = stackPrefetch.indicesToRequest.indexOf(imageIdIndex);
        if (index > -1) {
            stackPrefetch.indicesToRequest.splice(index, 1);
        }
    }
    stackPrefetchData.indicesToRequest.sort((a, b) => a - b);
    const indicesToRequestCopy = stackPrefetch.indicesToRequest.slice();
    indicesToRequestCopy.forEach(function (imageIdIndex) {
        const imageId = stack.imageIds[imageIdIndex];
        if (!imageId) {
            return;
        }
        const distance = Math.abs(currentImageIdIndex - imageIdIndex);
        const imageCached = distance < 6
            ? esm.cache.getImageLoadObject(imageId)
            : esm.cache.isLoaded(imageId);
        if (imageCached) {
            removeFromList(imageIdIndex);
        }
    });
    if (!stackPrefetch.indicesToRequest.length) {
        return;
    }
    if (!configuration.preserveExistingPool) {
        esm.imageLoadPoolManager.clearRequestStack(stackPrefetchUtils/* requestType */.y9);
    }
    const nearest = (0,stackPrefetchUtils/* nearestIndex */.zo)(stackPrefetch.indicesToRequest, stack.currentImageIdIndex);
    let imageId;
    let nextImageIdIndex;
    const preventCache = false;
    function doneCallback(image) {
        console.log('prefetch done: %s', image.imageId);
        const imageIdIndex = stack.imageIds.indexOf(image.imageId);
        removeFromList(imageIdIndex);
    }
    let lowerIndex = nearest.low;
    let higherIndex = nearest.high;
    const imageIdsToPrefetch = [];
    while (lowerIndex >= 0 ||
        higherIndex < stackPrefetch.indicesToRequest.length) {
        const currentIndex = stack.currentImageIdIndex;
        const shouldSkipLower = currentIndex - stackPrefetch.indicesToRequest[lowerIndex] >
            configuration.maxImagesToPrefetch;
        const shouldSkipHigher = stackPrefetch.indicesToRequest[higherIndex] - currentIndex >
            configuration.maxImagesToPrefetch;
        const shouldLoadLower = !shouldSkipLower && lowerIndex >= 0;
        const shouldLoadHigher = !shouldSkipHigher && higherIndex < stackPrefetch.indicesToRequest.length;
        if (!shouldLoadHigher && !shouldLoadLower) {
            break;
        }
        if (shouldLoadLower) {
            nextImageIdIndex = stackPrefetch.indicesToRequest[lowerIndex--];
            imageId = stack.imageIds[nextImageIdIndex];
            imageIdsToPrefetch.push(imageId);
        }
        if (shouldLoadHigher) {
            nextImageIdIndex = stackPrefetch.indicesToRequest[higherIndex++];
            imageId = stack.imageIds[nextImageIdIndex];
            imageIdsToPrefetch.push(imageId);
        }
    }
    const requestFn = (imageId, options) => esm.imageLoader.loadAndCacheImage(imageId, options);
    const { useNorm16Texture, preferSizeOverAccuracy } = (0,esm.getConfiguration)().rendering;
    const useNativeDataType = useNorm16Texture || preferSizeOverAccuracy;
    imageIdsToPrefetch.forEach((imageId) => {
        const options = {
            targetBuffer: {
                type: useNativeDataType ? undefined : 'Float32Array',
            },
            preScale: {
                enabled: true,
            },
            useNativeDataType,
            requestType: stackPrefetchUtils/* requestType */.y9,
        };
        esm.imageLoadPoolManager.addRequest(requestFn.bind(null, imageId, options), stackPrefetchUtils/* requestType */.y9, {
            imageId,
        }, stackPrefetchUtils/* priority */.Lr);
    });
}
function onImageUpdated(e) {
    clearTimeout(resetPrefetchTimeout);
    resetPrefetchTimeout = setTimeout(function () {
        const element = e.target;
        try {
            prefetch(element);
        }
        catch (error) {
            return;
        }
    }, resetPrefetchDelay);
}
function enable(element) {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const stackPrefetchData = {
        indicesToRequest: (0,stackPrefetchUtils/* range */.y1)(0, stack.imageIds.length - 1),
        enabled: true,
        direction: 1,
    };
    const indexOfCurrentImage = stackPrefetchData.indicesToRequest.indexOf(stack.currentImageIdIndex);
    stackPrefetchData.indicesToRequest.splice(indexOfCurrentImage, 1);
    (0,state/* addToolState */.P)(element, stackPrefetchData);
    prefetch(element);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    element.addEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    esm.eventTarget.addEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
}
function disable(element) {
    clearTimeout(resetPrefetchTimeout);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (stackPrefetchData && stackPrefetchData.indicesToRequest.length) {
        stackPrefetchData.enabled = false;
        esm.imageLoadPoolManager.clearRequestStack(stackPrefetchUtils/* requestType */.y9);
    }
}
function getConfiguration() {
    return configuration;
}
function setConfiguration(config) {
    configuration = config;
}
const stackPrefetch = { enable, disable, getConfiguration, setConfiguration };
/* harmony default export */ const stackPrefetch_stackPrefetch = ((/* unused pure expression or super */ null && (stackPrefetch)));

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js + 1 modules
var utilities = __webpack_require__(74119);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/stackContextPrefetch.js




let stackContextPrefetch_configuration = {
    maxImagesToPrefetch: Infinity,
    minBefore: 2,
    maxAfter: 2,
    directionExtraImages: 10,
    preserveExistingPool: false,
};
let stackContextPrefetch_resetPrefetchTimeout;
const stackContextPrefetch_resetPrefetchDelay = 5;
const stackContextPrefetch_enable = (element) => {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    updateToolState(element);
    stackContextPrefetch_prefetch(element);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    element.addEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    esm.eventTarget.addEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
};
function stackContextPrefetch_prefetch(element) {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack?.imageIds?.length) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (!stackPrefetchData) {
        return;
    }
    const stackPrefetch = stackPrefetchData || {};
    stackPrefetch.enabled &&= stackPrefetch.indicesToRequest?.length;
    if (stackPrefetch.enabled === false) {
        return;
    }
    function removeFromList(imageIdIndex) {
        const index = stackPrefetch.indicesToRequest.indexOf(imageIdIndex);
        if (index > -1) {
            stackPrefetch.indicesToRequest.splice(index, 1);
        }
    }
    const indicesToRequestCopy = stackPrefetch.indicesToRequest.slice();
    const { currentImageIdIndex } = stack;
    indicesToRequestCopy.forEach((imageIdIndex) => {
        const imageId = stack.imageIds[imageIdIndex];
        if (!imageId) {
            return;
        }
        const distance = Math.abs(currentImageIdIndex - imageIdIndex);
        const imageCached = distance < 6
            ? esm.cache.getImageLoadObject(imageId)
            : esm.cache.isLoaded(imageId);
        if (imageCached) {
            removeFromList(imageIdIndex);
        }
    });
    if (!stackPrefetch.indicesToRequest.length) {
        return;
    }
    if (!stackContextPrefetch_configuration.preserveExistingPool) {
        esm.imageLoadPoolManager.filterRequests((0,stackPrefetchUtils/* clearFromImageIds */.Pg)(stack));
    }
    function doneCallback(imageId) {
        const imageIdIndex = stack.imageIds.indexOf(imageId);
        removeFromList(imageIdIndex);
        const image = esm.cache.getCachedImageBasedOnImageURI(imageId);
        const { stats } = stackPrefetch;
        const decodeTimeInMS = image?.image?.decodeTimeInMS || 0;
        if (decodeTimeInMS) {
            stats.imageIds.set(imageId, decodeTimeInMS);
            stats.decodeTimeInMS += decodeTimeInMS;
            const loadTimeInMS = image?.image?.loadTimeInMS || 0;
            stats.loadTimeInMS += loadTimeInMS;
        }
        if (!stackPrefetch.indicesToRequest.length) {
            if (image?.sizeInBytes) {
                const { sizeInBytes } = image;
                const usage = esm.cache.getMaxCacheSize() / 4 / sizeInBytes;
                if (!stackPrefetch.cacheFill) {
                    stats.initialTime = Date.now() - stats.start;
                    stats.initialSize = stats.imageIds.size;
                    updateToolState(element, usage);
                    stackContextPrefetch_prefetch(element);
                }
                else if (stats.imageIds.size) {
                    stats.fillTime = Date.now() - stats.start;
                    const { size } = stats.imageIds;
                    stats.fillSize = size;
                    console.log('Done cache fill', stats.fillTime, 'ms', size, 'items', 'average total time', (0,utilities.roundNumber)(stats.fillTime / size), 'ms', 'average load', (0,utilities.roundNumber)(stats.loadTimeInMS / size), 'ms', 'average decode', (0,utilities.roundNumber)(stats.decodeTimeInMS / size), 'ms');
                }
            }
        }
    }
    const requestFn = (imageId, options) => esm.imageLoader.loadAndCacheImage(imageId, options)
        .then(() => doneCallback(imageId));
    const { useNorm16Texture, preferSizeOverAccuracy } = (0,esm.getConfiguration)().rendering;
    const useNativeDataType = useNorm16Texture || preferSizeOverAccuracy;
    indicesToRequestCopy.forEach((imageIdIndex) => {
        const imageId = stack.imageIds[imageIdIndex];
        const options = {
            targetBuffer: {
                type: useNativeDataType ? undefined : 'Float32Array',
            },
            preScale: {
                enabled: true,
            },
            useNativeDataType,
            requestType: stackPrefetchUtils/* requestType */.y9,
        };
        esm.imageLoadPoolManager.addRequest(requestFn.bind(null, imageId, options), stackPrefetchUtils/* requestType */.y9, {
            imageId,
        }, stackPrefetchUtils/* priority */.Lr);
    });
}
function stackContextPrefetch_onImageUpdated(e) {
    clearTimeout(stackContextPrefetch_resetPrefetchTimeout);
    stackContextPrefetch_resetPrefetchTimeout = setTimeout(function () {
        const element = e.target;
        try {
            updateToolState(element);
            stackContextPrefetch_prefetch(element);
        }
        catch (error) {
            return;
        }
    }, stackContextPrefetch_resetPrefetchDelay);
}
const signum = (x) => (x < 0 ? -1 : 1);
const updateToolState = (element, usage) => {
    const stack = (0,stackPrefetchUtils/* getStackData */.bV)(element);
    if (!stack || !stack.imageIds || stack.imageIds.length === 0) {
        console.warn('CornerstoneTools.stackPrefetch: No images in stack.');
        return;
    }
    const { currentImageIdIndex } = stack;
    let { maxAfter = 2, minBefore = 2 } = stackContextPrefetch_configuration;
    const { directionExtraImages = 10 } = stackContextPrefetch_configuration;
    const stackPrefetchData = (0,state/* getToolState */.k)(element) || {
        indicesToRequest: [],
        currentImageIdIndex,
        stackCount: 0,
        enabled: true,
        direction: 1,
        stats: {
            start: Date.now(),
            imageIds: new Map(),
            decodeTimeInMS: 0,
            loadTimeInMS: 0,
            totalBytes: 0,
        },
    };
    const delta = currentImageIdIndex - stackPrefetchData.currentImageIdIndex;
    stackPrefetchData.direction = signum(delta);
    stackPrefetchData.currentImageIdIndex = currentImageIdIndex;
    stackPrefetchData.enabled = true;
    if (stackPrefetchData.stackCount < 100) {
        stackPrefetchData.stackCount += directionExtraImages;
    }
    if (Math.abs(delta) > maxAfter || !delta) {
        stackPrefetchData.stackCount = 0;
        if (usage) {
            const positionFraction = currentImageIdIndex / stack.imageIds.length;
            minBefore = Math.ceil(usage * positionFraction);
            maxAfter = Math.ceil(usage * (1 - positionFraction));
            stackPrefetchData.cacheFill = true;
        }
        else {
            stackPrefetchData.cacheFill = false;
        }
    }
    else if (delta < 0) {
        minBefore += stackPrefetchData.stackCount;
        maxAfter = 0;
    }
    else {
        maxAfter += stackPrefetchData.stackCount;
        minBefore = 0;
    }
    const minIndex = Math.max(0, currentImageIdIndex - minBefore);
    const maxIndex = Math.min(stack.imageIds.length - 1, currentImageIdIndex + maxAfter);
    const indicesToRequest = [];
    for (let i = currentImageIdIndex + 1; i <= maxIndex; i++) {
        indicesToRequest.push(i);
    }
    for (let i = currentImageIdIndex - 1; i >= minIndex; i--) {
        indicesToRequest.push(i);
    }
    stackPrefetchData.indicesToRequest = indicesToRequest;
    (0,state/* addToolState */.P)(element, stackPrefetchData);
};
function stackContextPrefetch_disable(element) {
    clearTimeout(stackContextPrefetch_resetPrefetchTimeout);
    element.removeEventListener(esm.Enums.Events.STACK_NEW_IMAGE, stackContextPrefetch_onImageUpdated);
    const promiseRemovedHandler = (0,stackPrefetchUtils/* getPromiseRemovedHandler */.m0)(element);
    esm.eventTarget.removeEventListener(esm.Enums.Events.IMAGE_CACHE_IMAGE_REMOVED, promiseRemovedHandler);
    const stackPrefetchData = (0,state/* getToolState */.k)(element);
    if (stackPrefetchData && stackPrefetchData.data.length) {
        stackPrefetchData.enabled = false;
    }
}
function stackContextPrefetch_getConfiguration() {
    return stackContextPrefetch_configuration;
}
function stackContextPrefetch_setConfiguration(config) {
    stackContextPrefetch_configuration = config;
}
const stackContextPrefetch = {
    enable: stackContextPrefetch_enable,
    disable: stackContextPrefetch_disable,
    getConfiguration: stackContextPrefetch_getConfiguration,
    setConfiguration: stackContextPrefetch_setConfiguration,
};
/* harmony default export */ const stackPrefetch_stackContextPrefetch = ((/* unused pure expression or super */ null && (stackContextPrefetch)));

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/stackPrefetch/index.js





/***/ }),

/***/ 21090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _debounce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64857);
/* harmony import */ var _isObject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11857);


function throttle(func, wait, options) {
    let leading = true;
    let trailing = true;
    if (typeof func !== 'function') {
        throw new TypeError('Expected a function');
    }
    if ((0,_isObject__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(options)) {
        leading = 'leading' in options ? Boolean(options.leading) : leading;
        trailing = 'trailing' in options ? Boolean(options.trailing) : trailing;
    }
    return (0,_debounce__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(func, wait, {
        leading,
        trailing,
        maxWait: wait,
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (throttle);


/***/ }),

/***/ 54868:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   copyPoints: () => (/* binding */ copyPoints),
/* harmony export */   copyPointsList: () => (/* binding */ copyPointsList),
/* harmony export */   getDeltaDistance: () => (/* binding */ getDeltaDistance),
/* harmony export */   getDeltaDistanceBetweenIPoints: () => (/* binding */ getDeltaDistanceBetweenIPoints),
/* harmony export */   getDeltaPoints: () => (/* binding */ getDeltaPoints),
/* harmony export */   getMeanTouchPoints: () => (/* binding */ getMeanTouchPoints)
/* harmony export */ });
/* unused harmony exports getMeanPoints, getDeltaRotation */
function getDeltaPoints(currentPoints, lastPoints) {
    const curr = getMeanPoints(currentPoints);
    const last = getMeanPoints(lastPoints);
    return {
        page: _subtractPoints2D(curr.page, last.page),
        client: _subtractPoints2D(curr.client, last.client),
        canvas: _subtractPoints2D(curr.canvas, last.canvas),
        world: _subtractPoints3D(curr.world, last.world),
    };
}
function getDeltaDistance(currentPoints, lastPoints) {
    const curr = getMeanPoints(currentPoints);
    const last = getMeanPoints(lastPoints);
    return {
        page: _getDistance2D(curr.page, last.page),
        client: _getDistance2D(curr.client, last.client),
        canvas: _getDistance2D(curr.canvas, last.canvas),
        world: _getDistance3D(curr.world, last.world),
    };
}
function getDeltaRotation(currentPoints, lastPoints) {
}
function getDeltaDistanceBetweenIPoints(currentPoints, lastPoints) {
    const currentDistance = _getMeanDistanceBetweenAllIPoints(currentPoints);
    const lastDistance = _getMeanDistanceBetweenAllIPoints(lastPoints);
    const deltaDistance = {
        page: currentDistance.page - lastDistance.page,
        client: currentDistance.client - lastDistance.client,
        canvas: currentDistance.canvas - lastDistance.canvas,
        world: currentDistance.world - lastDistance.world,
    };
    return deltaDistance;
}
function copyPointsList(points) {
    return JSON.parse(JSON.stringify(points));
}
function copyPoints(points) {
    return JSON.parse(JSON.stringify(points));
}
function getMeanPoints(points) {
    return points.reduce((prev, curr) => {
        return {
            page: [
                prev.page[0] + curr.page[0] / points.length,
                prev.page[1] + curr.page[1] / points.length,
            ],
            client: [
                prev.client[0] + curr.client[0] / points.length,
                prev.client[1] + curr.client[1] / points.length,
            ],
            canvas: [
                prev.canvas[0] + curr.canvas[0] / points.length,
                prev.canvas[1] + curr.canvas[1] / points.length,
            ],
            world: [
                prev.world[0] + curr.world[0] / points.length,
                prev.world[1] + curr.world[1] / points.length,
                prev.world[2] + curr.world[2] / points.length,
            ],
        };
    }, {
        page: [0, 0],
        client: [0, 0],
        canvas: [0, 0],
        world: [0, 0, 0],
    });
}
function getMeanTouchPoints(points) {
    return points.reduce((prev, curr) => {
        return {
            page: [
                prev.page[0] + curr.page[0] / points.length,
                prev.page[1] + curr.page[1] / points.length,
            ],
            client: [
                prev.client[0] + curr.client[0] / points.length,
                prev.client[1] + curr.client[1] / points.length,
            ],
            canvas: [
                prev.canvas[0] + curr.canvas[0] / points.length,
                prev.canvas[1] + curr.canvas[1] / points.length,
            ],
            world: [
                prev.world[0] + curr.world[0] / points.length,
                prev.world[1] + curr.world[1] / points.length,
                prev.world[2] + curr.world[2] / points.length,
            ],
            touch: {
                identifier: null,
                radiusX: prev.touch.radiusX + curr.touch.radiusX / points.length,
                radiusY: prev.touch.radiusY + curr.touch.radiusY / points.length,
                force: prev.touch.force + curr.touch.force / points.length,
                rotationAngle: prev.touch.rotationAngle + curr.touch.rotationAngle / points.length,
            },
        };
    }, {
        page: [0, 0],
        client: [0, 0],
        canvas: [0, 0],
        world: [0, 0, 0],
        touch: {
            identifier: null,
            radiusX: 0,
            radiusY: 0,
            force: 0,
            rotationAngle: 0,
        },
    });
}
function _subtractPoints2D(point0, point1) {
    return [point0[0] - point1[0], point0[1] - point1[1]];
}
function _subtractPoints3D(point0, point1) {
    return [point0[0] - point1[0], point0[1] - point1[1], point0[2] - point1[2]];
}
function _getMeanDistanceBetweenAllIPoints(points) {
    const pairedDistance = [];
    for (let i = 0; i < points.length; i++) {
        for (let j = 0; j < points.length; j++) {
            if (i < j) {
                pairedDistance.push({
                    page: _getDistance2D(points[i].page, points[j].page),
                    client: _getDistance2D(points[i].client, points[j].client),
                    canvas: _getDistance2D(points[i].canvas, points[j].canvas),
                    world: _getDistance3D(points[i].world, points[j].world),
                });
            }
        }
    }
    return pairedDistance.reduce((prev, curr) => {
        return {
            page: prev.page + curr.page / pairedDistance.length,
            client: prev.client + curr.client / pairedDistance.length,
            canvas: prev.canvas + curr.canvas / pairedDistance.length,
            world: prev.world + curr.world / pairedDistance.length,
        };
    }, {
        page: 0,
        client: 0,
        canvas: 0,
        world: 0,
    });
}
function _getDistance2D(point0, point1) {
    return Math.sqrt(Math.pow(point0[0] - point1[0], 2) + Math.pow(point0[1] - point1[1], 2));
}
function _getDistance3D(point0, point1) {
    return Math.sqrt(Math.pow(point0[0] - point1[0], 2) +
        Math.pow(point0[1] - point1[1], 2) +
        Math.pow(point0[2] - point1[2], 2));
}



/***/ }),

/***/ 27819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export triggerAnnotationRenderForToolGroupIds */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _triggerAnnotationRender__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6805);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52610);



function triggerAnnotationRenderForToolGroupIds(toolGroupIds) {
    toolGroupIds.forEach((toolGroupId) => {
        const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_2__.getToolGroup)(toolGroupId);
        if (!toolGroup) {
            console.warn(`ToolGroup not available for ${toolGroupId}`);
            return;
        }
        const viewportsInfo = toolGroup.getViewportsInfo();
        viewportsInfo.forEach((viewportInfo) => {
            const { renderingEngineId, viewportId } = viewportInfo;
            const renderingEngine = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getRenderingEngine)(renderingEngineId);
            if (!renderingEngine) {
                console.warn(`RenderingEngine not available for ${renderingEngineId}`);
                return;
            }
            const viewport = renderingEngine.getViewport(viewportId);
            (0,_triggerAnnotationRender__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Ay)(viewport.element);
        });
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (triggerAnnotationRenderForToolGroupIds);


/***/ }),

/***/ 31555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isViewportPreScaled: () => (/* reexport safe */ _isViewportPreScaled__WEBPACK_IMPORTED_MODULE_0__.u)
/* harmony export */ });
/* harmony import */ var _isViewportPreScaled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(97022);
/* harmony import */ var _jumpToSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(11666);
/* harmony import */ var _jumpToWorld__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(88240);






/***/ }),

/***/ 97022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   u: () => (/* binding */ isViewportPreScaled)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);

function isViewportPreScaled(viewport, targetId) {
    if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.BaseVolumeViewport) {
        const targetIdTokens = targetId.split('volumeId:');
        const volumeId = targetIdTokens.length > 1
            ? targetIdTokens[1].split('?')[0]
            : targetIdTokens[0];
        const volume = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.cache.getVolume(volumeId);
        return !!volume?.scaling && Object.keys(volume.scaling).length > 0;
    }
    else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
        const { preScale } = viewport.getImageData() || {};
        return !!preScale?.scaled;
    }
    else {
        return false;
    }
}



/***/ }),

/***/ 11666:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _clip__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(88484);
/* harmony import */ var _scroll__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(21783);



async function jumpToSlice(element, options = {}) {
    const { imageIndex, debounceLoading, volumeId } = options;
    const enabledElement = getEnabledElement(element);
    if (!enabledElement) {
        throw new Error('Element has been disabled');
    }
    const { viewport } = enabledElement;
    const { imageIndex: currentImageIndex, numberOfSlices } = _getImageSliceData(viewport, debounceLoading);
    const imageIndexToJump = _getImageIndexToJump(numberOfSlices, imageIndex);
    const delta = imageIndexToJump - currentImageIndex;
    scroll(viewport, { delta, debounceLoading, volumeId });
}
function _getImageSliceData(viewport, debounceLoading) {
    if (viewport instanceof StackViewport) {
        return {
            numberOfSlices: viewport.getImageIds().length,
            imageIndex: debounceLoading
                ? viewport.getTargetImageIdIndex()
                : viewport.getCurrentImageIdIndex(),
        };
    }
    else if (viewport instanceof VolumeViewport) {
        return csUtils.getImageSliceDataForVolumeViewport(viewport);
    }
    else {
        throw new Error('Unsupported viewport type');
    }
}
function _getImageIndexToJump(numberOfSlices, imageIndex) {
    const lastSliceIndex = numberOfSlices - 1;
    return clip(imageIndex, 0, lastSliceIndex);
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (jumpToSlice)));


/***/ }),

/***/ 88240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ jumpToWorld)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);


function jumpToWorld(viewport, jumpWorld) {
    if (!(viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport)) {
        return;
    }
    const { focalPoint } = viewport.getCamera();
    const delta = [0, 0, 0];
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.sub */ .eR.sub(delta, jumpWorld, focalPoint);
    _applyShift(viewport, delta);
    return true;
}
function _applyShift(viewport, delta) {
    const camera = viewport.getCamera();
    const normal = camera.viewPlaneNormal;
    const dotProd = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(delta, normal);
    const projectedDelta = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.fromValues */ .eR.fromValues(normal[0], normal[1], normal[2]);
    gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.scale */ .eR.scale(projectedDelta, projectedDelta, dotProd);
    if (Math.abs(projectedDelta[0]) > 1e-3 ||
        Math.abs(projectedDelta[1]) > 1e-3 ||
        Math.abs(projectedDelta[2]) > 1e-3) {
        const newFocalPoint = [0, 0, 0];
        const newPosition = [0, 0, 0];
        gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.add */ .eR.add(newFocalPoint, camera.focalPoint, projectedDelta);
        gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.add */ .eR.add(newPosition, camera.position, projectedDelta);
        viewport.setCamera({
            focalPoint: newFocalPoint,
            position: newPosition,
        });
        viewport.render();
    }
}


/***/ }),

/***/ 90252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  filterViewportsWithToolEnabled: () => (/* reexport */ filterViewportsWithToolEnabled),
  getViewportIdsWithToolToRender: () => (/* reexport */ getViewportIdsWithToolToRender)
});

// UNUSED EXPORTS: filterViewportsWithFrameOfReferenceUID, filterViewportsWithParallelNormals

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithFrameOfReferenceUID.js
function filterViewportsWithFrameOfReferenceUID(viewports, FrameOfReferenceUID) {
    const numViewports = viewports.length;
    const viewportsWithFrameOfReferenceUID = [];
    for (let vp = 0; vp < numViewports; vp++) {
        const viewport = viewports[vp];
        if (viewport.getFrameOfReferenceUID() === FrameOfReferenceUID) {
            viewportsWithFrameOfReferenceUID.push(viewport);
        }
    }
    return viewportsWithFrameOfReferenceUID;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/index.js + 3 modules
var enums = __webpack_require__(84901);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithToolEnabled.js


const { Active, Passive, Enabled } = enums.ToolModes;
function filterViewportsWithToolEnabled(viewports, toolName) {
    const numViewports = viewports.length;
    const viewportsWithToolEnabled = [];
    for (let vp = 0; vp < numViewports; vp++) {
        const viewport = viewports[vp];
        const toolGroup = store/* ToolGroupManager.getToolGroupForViewport */.dU.getToolGroupForViewport(viewport.id, viewport.renderingEngineId);
        if (!toolGroup) {
            continue;
        }
        const hasTool = _toolGroupHasActiveEnabledOrPassiveTool(toolGroup, toolName);
        if (hasTool) {
            viewportsWithToolEnabled.push(viewport);
        }
    }
    return viewportsWithToolEnabled;
}
function _toolGroupHasActiveEnabledOrPassiveTool(toolGroup, toolName) {
    const { toolOptions } = toolGroup;
    const tool = toolOptions[toolName];
    if (!tool) {
        return false;
    }
    const toolMode = tool.mode;
    return toolMode === Active || toolMode === Passive || toolMode === Enabled;
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/gl-matrix/esm/index.js + 1 modules
var gl_matrix_esm = __webpack_require__(44753);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/filterViewportsWithParallelNormals.js

function filterViewportsWithParallelNormals(viewports, camera, EPS = 0.999) {
    return viewports.filter((viewport) => {
        const vpCamera = viewport.getCamera();
        const isParallel = Math.abs(gl_matrix_esm/* vec3.dot */.eR.dot(vpCamera.viewPlaneNormal, camera.viewPlaneNormal)) >
            EPS;
        return isParallel;
    });
}
/* harmony default export */ const viewportFilters_filterViewportsWithParallelNormals = (filterViewportsWithParallelNormals);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/getViewportIdsWithToolToRender.js




function getViewportIdsWithToolToRender(element, toolName, requireParallelNormals = true) {
    const enabledElement = (0,esm.getEnabledElement)(element);
    const { renderingEngine, FrameOfReferenceUID } = enabledElement;
    let viewports = renderingEngine.getViewports();
    viewports = filterViewportsWithFrameOfReferenceUID(viewports, FrameOfReferenceUID);
    viewports = filterViewportsWithToolEnabled(viewports, toolName);
    const viewport = renderingEngine.getViewport(enabledElement.viewportId);
    if (requireParallelNormals) {
        viewports = viewportFilters_filterViewportsWithParallelNormals(viewports, viewport.getCamera());
    }
    const viewportIds = viewports.map((vp) => vp.id);
    return viewportIds;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/viewportFilters/index.js







/***/ }),

/***/ 50112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ Colorbar)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44753);
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92136);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24284);
/* harmony import */ var _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50614);
/* harmony import */ var _ColorbarCanvas__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(25605);
/* harmony import */ var _ColorbarTicks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4856);
/* harmony import */ var _common_isRangeTextPositionValid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57457);
/* harmony import */ var _widgets_Widget__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38461);








const DEFAULTS = {
    MULTIPLIER: 1,
    RANGE_TEXT_POSITION: _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Right,
    TICKS_BAR_SIZE: 50,
};
class Colorbar extends _widgets_Widget__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .A {
    constructor(props) {
        super(props);
        this._isMouseOver = false;
        this._isInteracting = false;
        this._mouseOverCallback = (evt) => {
            this._isMouseOver = true;
            this.showTicks();
            evt.stopPropagation();
        };
        this._mouseOutCallback = (evt) => {
            this._isMouseOver = false;
            this.hideTicks();
            evt.stopPropagation();
        };
        this._mouseDownCallback = (evt) => {
            this._isInteracting = true;
            this.showTicks();
            this._addVOIEventListeners(evt);
            evt.stopPropagation();
        };
        this._mouseDragCallback = (evt, initialState) => {
            const multipliers = this.getVOIMultipliers();
            const currentPoints = this._getPointsFromMouseEvent(evt);
            const { points: startPoints, voiRange: startVOIRange } = initialState;
            const canvasDelta = gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.sub */ .Zc.sub(gl_matrix__WEBPACK_IMPORTED_MODULE_0__/* .vec2.create */ .Zc.create(), currentPoints.local, startPoints.local);
            const wwDelta = canvasDelta[0] * multipliers[0];
            const wcDelta = canvasDelta[1] * multipliers[1];
            if (!wwDelta && !wcDelta) {
                return;
            }
            const { lower: voiLower, upper: voiUpper } = startVOIRange;
            let { windowWidth, windowCenter } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.windowLevel.toWindowLevel(voiLower, voiUpper);
            windowWidth = Math.max(windowWidth + wwDelta, 1);
            windowCenter += wcDelta;
            const newVoiRange = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.windowLevel.toLowHighRange(windowWidth, windowCenter);
            this.voiRange = newVoiRange;
            evt.stopPropagation();
            evt.preventDefault();
        };
        this._mouseUpCallback = (evt) => {
            this._isInteracting = false;
            this.hideTicks();
            this._removeVOIEventListeners();
            evt.stopPropagation();
        };
        this._eventListenersManager =
            new _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_1__.utilities.eventListener.MultiTargetEventListenerManager();
        this._colormaps = Colorbar.getColormapsMap(props);
        this._activeColormapName = Colorbar.getInitialColormapName(props);
        this._canvas = this._createCanvas(props);
        this._ticksBar = this._createTicksBar(props);
        this._rangeTextPosition =
            props.ticks?.position ?? DEFAULTS.RANGE_TEXT_POSITION;
        this._canvas.appendTo(this.rootElement);
        this._ticksBar.appendTo(this.rootElement);
        this._addRootElementEventListeners();
    }
    get activeColormapName() {
        return this._activeColormapName;
    }
    set activeColormapName(colormapName) {
        if (colormapName === this._activeColormapName) {
            return;
        }
        const colormap = this._colormaps.get(colormapName);
        if (!colormap) {
            console.warn(`Invalid colormap name (${colormapName})`);
            return;
        }
        this._activeColormapName = colormapName;
        this._canvas.colormap = colormap;
    }
    get imageRange() {
        return this._canvas.imageRange;
    }
    set imageRange(imageRange) {
        this._canvas.imageRange = imageRange;
        this._ticksBar.imageRange = imageRange;
    }
    get voiRange() {
        return this._canvas.voiRange;
    }
    set voiRange(voiRange) {
        const { voiRange: currentVoiRange } = this._canvas;
        if (!(0,_common__WEBPACK_IMPORTED_MODULE_2__/* .isRangeValid */ .kB)(voiRange) ||
            (0,_common__WEBPACK_IMPORTED_MODULE_2__/* .areColorbarRangesEqual */ .bh)(voiRange, currentVoiRange)) {
            return;
        }
        this._canvas.voiRange = voiRange;
        this._ticksBar.voiRange = voiRange;
        this.onVoiChange(voiRange);
    }
    get showFullImageRange() {
        return this._canvas.showFullImageRange;
    }
    set showFullImageRange(value) {
        this._canvas.showFullImageRange = value;
        this._ticksBar.showFullPixelValueRange = value;
    }
    destroy() {
        super.destroy();
        this._eventListenersManager.reset();
    }
    createRootElement() {
        const rootElement = document.createElement('div');
        Object.assign(rootElement.style, {
            position: 'relative',
            fontSize: '0',
            width: '100%',
            height: '100%',
        });
        return rootElement;
    }
    onContainerResize() {
        super.onContainerResize();
        this.updateTicksBar();
        this._canvas.size = this.containerSize;
    }
    getVOIMultipliers() {
        return [DEFAULTS.MULTIPLIER, DEFAULTS.MULTIPLIER];
    }
    onVoiChange(voiRange) {
    }
    showTicks() {
        this.updateTicksBar();
        this._ticksBar.visible = true;
    }
    hideTicks() {
        if (this._isInteracting || this._isMouseOver) {
            return;
        }
        this._ticksBar.visible = false;
    }
    static getColormapsMap(props) {
        const { colormaps } = props;
        return colormaps.reduce((items, item) => items.set(item.Name, item), new Map());
    }
    static getInitialColormapName(props) {
        const { activeColormapName, colormaps } = props;
        const colormapExists = !!activeColormapName &&
            colormaps.some((cm) => cm.Name === activeColormapName);
        return colormapExists ? activeColormapName : colormaps[0].Name;
    }
    _createCanvas(props) {
        const { imageRange, voiRange, showFullPixelValueRange } = props;
        const colormap = this._colormaps.get(this._activeColormapName);
        return new _ColorbarCanvas__WEBPACK_IMPORTED_MODULE_4__/* .ColorbarCanvas */ .n({
            colormap,
            imageRange,
            voiRange: voiRange,
            showFullPixelValueRange,
        });
    }
    _createTicksBar(props) {
        const ticksProps = props.ticks;
        return new _ColorbarTicks__WEBPACK_IMPORTED_MODULE_5__/* .ColorbarTicks */ .f({
            imageRange: props.imageRange,
            voiRange: props.voiRange,
            ticks: ticksProps,
            showFullPixelValueRange: props.showFullPixelValueRange,
        });
    }
    _getPointsFromMouseEvent(evt) {
        const { rootElement: element } = this;
        const clientPoint = [evt.clientX, evt.clientY];
        const pagePoint = [evt.pageX, evt.pageY];
        const rect = element.getBoundingClientRect();
        const localPoints = [
            pagePoint[0] - rect.left - window.pageXOffset,
            pagePoint[1] - rect.top - window.pageYOffset,
        ];
        return { client: clientPoint, page: pagePoint, local: localPoints };
    }
    updateTicksBar() {
        const { width: containerWidth, height: containerHeight } = this.containerSize;
        if (containerWidth === 0 && containerHeight === 0) {
            return;
        }
        const { _ticksBar: ticksBar, _rangeTextPosition: rangeTextPosition } = this;
        const isHorizontal = containerWidth >= containerHeight;
        const width = isHorizontal ? containerWidth : DEFAULTS.TICKS_BAR_SIZE;
        const height = isHorizontal ? DEFAULTS.TICKS_BAR_SIZE : containerHeight;
        if (!(0,_common_isRangeTextPositionValid__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(containerWidth, containerHeight, rangeTextPosition)) {
            throw new Error('Invalid rangeTextPosition value for the current colobar orientation');
        }
        let ticksBarTop;
        let ticksBarLeft;
        ticksBar.size = { width, height };
        if (isHorizontal) {
            ticksBarLeft = 0;
            ticksBarTop =
                rangeTextPosition === _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Top
                    ? -height
                    : containerHeight;
        }
        else {
            ticksBarTop = 0;
            ticksBarLeft =
                rangeTextPosition === _enums_ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_3__/* .ColorbarRangeTextPosition */ .U.Left
                    ? -width
                    : containerWidth;
        }
        ticksBar.top = ticksBarTop;
        ticksBar.left = ticksBarLeft;
    }
    _addRootElementEventListeners() {
        const { _eventListenersManager: manager } = this;
        const { rootElement: element } = this;
        manager.addEventListener(element, 'mouseover', this._mouseOverCallback);
        manager.addEventListener(element, 'mouseout', this._mouseOutCallback);
        manager.addEventListener(element, 'mousedown', this._mouseDownCallback);
    }
    _addVOIEventListeners(evt) {
        const { _eventListenersManager: manager } = this;
        const points = this._getPointsFromMouseEvent(evt);
        const voiRange = { ...this._canvas.voiRange };
        const initialDragState = { points, voiRange };
        this._removeVOIEventListeners();
        manager.addEventListener(document, 'voi.mouseup', this._mouseUpCallback);
        manager.addEventListener(document, 'voi.mousemove', (evt) => this._mouseDragCallback(evt, initialDragState));
    }
    _removeVOIEventListeners() {
        const { _eventListenersManager: manager } = this;
        manager.removeEventListener(document, 'voi.mouseup');
        manager.removeEventListener(document, 'voi.mousemove');
    }
}



/***/ }),

/***/ 81034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports default, ViewportColorbar */
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _Colorbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50112);
/* harmony import */ var _getVOIMultipliers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(51954);



const { Events } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.Enums;
const defaultImageRange = { lower: -1000, upper: 1000 };
class ViewportColorbar extends _Colorbar__WEBPACK_IMPORTED_MODULE_1__/* .Colorbar */ .P {
    constructor(props) {
        const { element, volumeId } = props;
        const imageRange = ViewportColorbar._getImageRange(element, volumeId);
        const voiRange = ViewportColorbar._getVOIRange(element, volumeId);
        super({ ...props, imageRange, voiRange });
        this.autoHideTicks = () => {
            if (this._hideTicksTimeoutId) {
                return;
            }
            const timeLeft = this._hideTicksTime - Date.now();
            if (timeLeft <= 0) {
                this.hideTicks();
            }
            else {
                this._hideTicksTimeoutId = window.setTimeout(() => {
                    this._hideTicksTimeoutId = 0;
                    this.autoHideTicks();
                }, timeLeft);
            }
        };
        this._stackNewImageCallback = () => {
            this.imageRange = ViewportColorbar._getImageRange(this._element);
        };
        this._imageVolumeModifiedCallback = (evt) => {
            const { volumeId } = evt.detail.imageVolume;
            if (volumeId !== this._volumeId) {
                return;
            }
            const { _element: element } = this;
            this.imageRange = ViewportColorbar._getImageRange(element, volumeId);
        };
        this._viewportVOIModifiedCallback = (evt) => {
            const { viewportId, volumeId, range: voiRange, colormap } = evt.detail;
            const { viewport } = this.enabledElement;
            if (viewportId !== viewport.id || volumeId !== this._volumeId) {
                return;
            }
            this.voiRange = voiRange;
            if (colormap) {
                this.activeColormapName = colormap.name;
            }
            this.showAndAutoHideTicks();
        };
        this._viewportColormapModifiedCallback = (evt) => {
            const { viewportId, colormap, volumeId } = evt.detail;
            const { viewport } = this.enabledElement;
            if (viewportId !== viewport.id || volumeId !== this._volumeId) {
                return;
            }
            this.activeColormapName = colormap.name;
        };
        this._element = element;
        this._volumeId = volumeId;
        this._addCornerstoneEventListener();
    }
    get element() {
        return this._element;
    }
    get enabledElement() {
        return (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(this._element);
    }
    getVOIMultipliers() {
        const { viewport } = this.enabledElement;
        return (0,_getVOIMultipliers__WEBPACK_IMPORTED_MODULE_2__/* .getVOIMultipliers */ .j)(viewport, this._volumeId);
    }
    onVoiChange(voiRange) {
        super.onVoiChange(voiRange);
        const { viewport } = this.enabledElement;
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.StackViewport) {
            viewport.setProperties({
                voiRange: voiRange,
            });
            viewport.render();
        }
        else if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
            const { _volumeId: volumeId } = this;
            const viewportsContainingVolumeUID = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getViewportsWithVolumeId(volumeId, viewport.renderingEngineId);
            viewport.setProperties({ voiRange }, volumeId);
            viewportsContainingVolumeUID.forEach((vp) => vp.render());
        }
    }
    static _getImageRange(element, volumeId) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const actor = volumeId
            ? viewport.getActor(volumeId)
            : viewport.getDefaultActor();
        if (!actor) {
            return defaultImageRange;
        }
        const imageData = actor.actor.getMapper().getInputData();
        const imageRange = imageData.getPointData().getScalars().getRange();
        return imageRange[0] === 0 && imageRange[1] === 0
            ? defaultImageRange
            : { lower: imageRange[0], upper: imageRange[1] };
    }
    static _getVOIRange(element, volumeId) {
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        const volumeActor = volumeId
            ? viewport.getActor(volumeId)
            : viewport.getDefaultActor();
        if (!volumeActor || !_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.isImageActor(volumeActor)) {
            return defaultImageRange;
        }
        const voiRange = volumeActor.actor
            .getProperty()
            .getRGBTransferFunction(0)
            .getRange();
        return voiRange[0] === 0 && voiRange[1] === 0
            ? defaultImageRange
            : { lower: voiRange[0], upper: voiRange[1] };
    }
    showAndAutoHideTicks(interval = 1000) {
        this._hideTicksTime = Date.now() + interval;
        this.showTicks();
        this.autoHideTicks();
    }
    _addCornerstoneEventListener() {
        const { _element: element } = this;
        _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.eventTarget.addEventListener(Events.IMAGE_VOLUME_MODIFIED, this._imageVolumeModifiedCallback);
        element.addEventListener(Events.STACK_NEW_IMAGE, this._stackNewImageCallback);
        element.addEventListener(Events.VOI_MODIFIED, this._viewportVOIModifiedCallback);
        element.addEventListener(Events.COLORMAP_MODIFIED, this._viewportColormapModifiedCallback);
    }
}



/***/ }),

/***/ 50614:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   U: () => (/* binding */ ColorbarRangeTextPosition)
/* harmony export */ });
var ColorbarRangeTextPosition;
(function (ColorbarRangeTextPosition) {
    ColorbarRangeTextPosition["Top"] = "top";
    ColorbarRangeTextPosition["Left"] = "left";
    ColorbarRangeTextPosition["Bottom"] = "bottom";
    ColorbarRangeTextPosition["Right"] = "right";
})(ColorbarRangeTextPosition || (ColorbarRangeTextPosition = {}));


/***/ }),

/***/ 73231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ColorbarRangeTextPosition: () => (/* reexport safe */ _ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_0__.U)
/* harmony export */ });
/* harmony import */ var _ColorbarRangeTextPosition__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50614);



/***/ }),

/***/ 64690:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(73231);
/* harmony import */ var _Colorbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(50112);
/* harmony import */ var _ViewportColorbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(81034);






/***/ }),

/***/ 14149:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  windowLevel: () => (/* reexport */ windowlevel_namespaceObject)
});

// UNUSED EXPORTS: colorbar

// NAMESPACE OBJECT: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/index.js
var windowlevel_namespaceObject = {};
__webpack_require__.r(windowlevel_namespaceObject);
__webpack_require__.d(windowlevel_namespaceObject, {
  calculateMinMaxMean: () => (calculateMinMaxMean),
  extractWindowLevelRegionToolData: () => (extractWindowLevelRegionToolData),
  getLuminanceFromRegion: () => (getLuminanceFromRegion)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/colorbar/index.js
var colorbar = __webpack_require__(64690);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/getLuminanceFromRegion.js
function getLuminanceFromRegion(imageData, x, y, width, height) {
    const luminance = [];
    let index = 0;
    const pixelData = imageData.scalarData;
    let spIndex, row, column;
    if (imageData.color) {
        for (row = 0; row < height; row++) {
            for (column = 0; column < width; column++) {
                spIndex = ((row + y) * imageData.columns + (column + x)) * 4;
                const red = pixelData[spIndex];
                const green = pixelData[spIndex + 1];
                const blue = pixelData[spIndex + 2];
                luminance[index++] = 0.2126 * red + 0.7152 * green + 0.0722 * blue;
            }
        }
    }
    else {
        for (row = 0; row < height; row++) {
            for (column = 0; column < width; column++) {
                spIndex = (row + y) * imageData.columns + (column + x);
                luminance[index++] = pixelData[spIndex];
            }
        }
    }
    return luminance;
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/calculateMinMaxMean.js
function calculateMinMaxMean(pixelLuminance, globalMin, globalMax) {
    const numPixels = pixelLuminance.length;
    let min = globalMax;
    let max = globalMin;
    let sum = 0;
    if (numPixels < 2) {
        return {
            min,
            max,
            mean: (globalMin + globalMax) / 2,
        };
    }
    for (let index = 0; index < numPixels; index++) {
        const spv = pixelLuminance[index];
        min = Math.min(min, spv);
        max = Math.max(max, spv);
        sum += spv;
    }
    return {
        min,
        max,
        mean: sum / numPixels,
    };
}


// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/extractWindowLevelRegionToolData.js

function extractWindowLevelRegionToolData(viewport) {
    if (viewport instanceof esm.VolumeViewport) {
        return extractImageDataVolume(viewport);
    }
    if (viewport instanceof esm.StackViewport) {
        return extractImageDataStack(viewport);
    }
    throw new Error('Viewport not supported');
}
function extractImageDataVolume(viewport) {
    const { scalarData, width, height } = esm.utilities.getCurrentVolumeViewportSlice(viewport);
    const { min: minPixelValue, max: maxPixelValue } = esm.utilities.getMinMax(scalarData);
    const volumeId = viewport.getVolumeId();
    const volume = esm.cache.getVolume(volumeId);
    const { metadata, cornerstoneImageMetaData } = volume;
    const { Rows: rows, Columns: columns } = metadata;
    const { color } = cornerstoneImageMetaData;
    return {
        scalarData,
        width,
        height,
        minPixelValue,
        maxPixelValue,
        rows,
        columns,
        color,
    };
}
function extractImageDataStack(viewport) {
    const imageData = viewport.getImageData();
    const { scalarData } = imageData;
    const { min: minPixelValue, max: maxPixelValue } = esm.utilities.getMinMax(scalarData);
    const width = imageData.dimensions[0];
    const height = imageData.dimensions[1];
    const { rows, columns, color } = viewport.getCornerstoneImage();
    return {
        scalarData,
        width,
        height,
        minPixelValue,
        maxPixelValue,
        rows,
        columns,
        color,
    };
}


;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/windowlevel/index.js





;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/voi/index.js





/***/ }),

/***/ 95989:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// EXTERNAL MODULE: ../../../node_modules/comlink/dist/esm/comlink.mjs
var comlink = __webpack_require__(99178);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/DataModel/ImageData.js
var ImageData = __webpack_require__(51250);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/Core/DataArray.js
var DataArray = __webpack_require__(45128);
;// CONCATENATED MODULE: ../../../node_modules/@icr/polyseg-wasm/dist/ICRPolySeg.js

var ICRPolySegApp = (() => {
  var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;
  
  return (
function(ICRPolySegApp) {
  ICRPolySegApp = ICRPolySegApp || {};

var Module=typeof ICRPolySegApp!="undefined"?ICRPolySegApp:{};var readyPromiseResolve,readyPromiseReject;Module["ready"]=new Promise(function(resolve,reject){readyPromiseResolve=resolve;readyPromiseReject=reject});var moduleOverrides=Object.assign({},Module);var arguments_=[];var thisProgram="./this.program";var quit_=(status,toThrow)=>{throw toThrow};var ENVIRONMENT_IS_WEB=true;var ENVIRONMENT_IS_WORKER=false;var scriptDirectory="";function locateFile(path){if(Module["locateFile"]){return Module["locateFile"](path,scriptDirectory)}return scriptDirectory+path}var read_,readAsync,readBinary,setWindowTitle;if(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER){if(ENVIRONMENT_IS_WORKER){scriptDirectory=self.location.href}else if(typeof document!="undefined"&&document.currentScript){scriptDirectory=document.currentScript.src}if(_scriptDir){scriptDirectory=_scriptDir}if(scriptDirectory.indexOf("blob:")!==0){scriptDirectory=scriptDirectory.substr(0,scriptDirectory.replace(/[?#].*/,"").lastIndexOf("/")+1)}else{scriptDirectory=""}{read_=url=>{var xhr=new XMLHttpRequest;xhr.open("GET",url,false);xhr.send(null);return xhr.responseText};if(ENVIRONMENT_IS_WORKER){readBinary=url=>{var xhr=new XMLHttpRequest;xhr.open("GET",url,false);xhr.responseType="arraybuffer";xhr.send(null);return new Uint8Array(xhr.response)}}readAsync=(url,onload,onerror)=>{var xhr=new XMLHttpRequest;xhr.open("GET",url,true);xhr.responseType="arraybuffer";xhr.onload=()=>{if(xhr.status==200||xhr.status==0&&xhr.response){onload(xhr.response);return}onerror()};xhr.onerror=onerror;xhr.send(null)}}setWindowTitle=title=>document.title=title}else{}var out=Module["print"]||console.log.bind(console);var err=Module["printErr"]||console.warn.bind(console);Object.assign(Module,moduleOverrides);moduleOverrides=null;if(Module["arguments"])arguments_=Module["arguments"];if(Module["thisProgram"])thisProgram=Module["thisProgram"];if(Module["quit"])quit_=Module["quit"];var POINTER_SIZE=4;var wasmBinary;if(Module["wasmBinary"])wasmBinary=Module["wasmBinary"];var noExitRuntime=Module["noExitRuntime"]||true;if(typeof WebAssembly!="object"){abort("no native wasm support detected")}var wasmMemory;var ABORT=false;var EXITSTATUS;var UTF8Decoder=typeof TextDecoder!="undefined"?new TextDecoder("utf8"):undefined;function UTF8ArrayToString(heapOrArray,idx,maxBytesToRead){var endIdx=idx+maxBytesToRead;var endPtr=idx;while(heapOrArray[endPtr]&&!(endPtr>=endIdx))++endPtr;if(endPtr-idx>16&&heapOrArray.buffer&&UTF8Decoder){return UTF8Decoder.decode(heapOrArray.subarray(idx,endPtr))}var str="";while(idx<endPtr){var u0=heapOrArray[idx++];if(!(u0&128)){str+=String.fromCharCode(u0);continue}var u1=heapOrArray[idx++]&63;if((u0&224)==192){str+=String.fromCharCode((u0&31)<<6|u1);continue}var u2=heapOrArray[idx++]&63;if((u0&240)==224){u0=(u0&15)<<12|u1<<6|u2}else{u0=(u0&7)<<18|u1<<12|u2<<6|heapOrArray[idx++]&63}if(u0<65536){str+=String.fromCharCode(u0)}else{var ch=u0-65536;str+=String.fromCharCode(55296|ch>>10,56320|ch&1023)}}return str}function UTF8ToString(ptr,maxBytesToRead){return ptr?UTF8ArrayToString(HEAPU8,ptr,maxBytesToRead):""}function stringToUTF8Array(str,heap,outIdx,maxBytesToWrite){if(!(maxBytesToWrite>0))return 0;var startIdx=outIdx;var endIdx=outIdx+maxBytesToWrite-1;for(var i=0;i<str.length;++i){var u=str.charCodeAt(i);if(u>=55296&&u<=57343){var u1=str.charCodeAt(++i);u=65536+((u&1023)<<10)|u1&1023}if(u<=127){if(outIdx>=endIdx)break;heap[outIdx++]=u}else if(u<=2047){if(outIdx+1>=endIdx)break;heap[outIdx++]=192|u>>6;heap[outIdx++]=128|u&63}else if(u<=65535){if(outIdx+2>=endIdx)break;heap[outIdx++]=224|u>>12;heap[outIdx++]=128|u>>6&63;heap[outIdx++]=128|u&63}else{if(outIdx+3>=endIdx)break;heap[outIdx++]=240|u>>18;heap[outIdx++]=128|u>>12&63;heap[outIdx++]=128|u>>6&63;heap[outIdx++]=128|u&63}}heap[outIdx]=0;return outIdx-startIdx}function stringToUTF8(str,outPtr,maxBytesToWrite){return stringToUTF8Array(str,HEAPU8,outPtr,maxBytesToWrite)}function lengthBytesUTF8(str){var len=0;for(var i=0;i<str.length;++i){var c=str.charCodeAt(i);if(c<=127){len++}else if(c<=2047){len+=2}else if(c>=55296&&c<=57343){len+=4;++i}else{len+=3}}return len}var buffer,HEAP8,HEAPU8,HEAP16,HEAPU16,HEAP32,HEAPU32,HEAPF32,HEAPF64;function updateGlobalBufferAndViews(buf){buffer=buf;Module["HEAP8"]=HEAP8=new Int8Array(buf);Module["HEAP16"]=HEAP16=new Int16Array(buf);Module["HEAP32"]=HEAP32=new Int32Array(buf);Module["HEAPU8"]=HEAPU8=new Uint8Array(buf);Module["HEAPU16"]=HEAPU16=new Uint16Array(buf);Module["HEAPU32"]=HEAPU32=new Uint32Array(buf);Module["HEAPF32"]=HEAPF32=new Float32Array(buf);Module["HEAPF64"]=HEAPF64=new Float64Array(buf)}var INITIAL_MEMORY=Module["INITIAL_MEMORY"]||16777216;var wasmTable;var __ATPRERUN__=[];var __ATINIT__=[];var __ATMAIN__=[];var __ATPOSTRUN__=[];var runtimeInitialized=false;function keepRuntimeAlive(){return noExitRuntime}function preRun(){if(Module["preRun"]){if(typeof Module["preRun"]=="function")Module["preRun"]=[Module["preRun"]];while(Module["preRun"].length){addOnPreRun(Module["preRun"].shift())}}callRuntimeCallbacks(__ATPRERUN__)}function initRuntime(){runtimeInitialized=true;callRuntimeCallbacks(__ATINIT__)}function preMain(){callRuntimeCallbacks(__ATMAIN__)}function postRun(){if(Module["postRun"]){if(typeof Module["postRun"]=="function")Module["postRun"]=[Module["postRun"]];while(Module["postRun"].length){addOnPostRun(Module["postRun"].shift())}}callRuntimeCallbacks(__ATPOSTRUN__)}function addOnPreRun(cb){__ATPRERUN__.unshift(cb)}function addOnInit(cb){__ATINIT__.unshift(cb)}function addOnPostRun(cb){__ATPOSTRUN__.unshift(cb)}var runDependencies=0;var runDependencyWatcher=null;var dependenciesFulfilled=null;function addRunDependency(id){runDependencies++;if(Module["monitorRunDependencies"]){Module["monitorRunDependencies"](runDependencies)}}function removeRunDependency(id){runDependencies--;if(Module["monitorRunDependencies"]){Module["monitorRunDependencies"](runDependencies)}if(runDependencies==0){if(runDependencyWatcher!==null){clearInterval(runDependencyWatcher);runDependencyWatcher=null}if(dependenciesFulfilled){var callback=dependenciesFulfilled;dependenciesFulfilled=null;callback()}}}function abort(what){if(Module["onAbort"]){Module["onAbort"](what)}what="Aborted("+what+")";err(what);ABORT=true;EXITSTATUS=1;what+=". Build with -sASSERTIONS for more info.";var e=new WebAssembly.RuntimeError(what);readyPromiseReject(e);throw e}var dataURIPrefix="data:application/octet-stream;base64,";function isDataURI(filename){return filename.startsWith(dataURIPrefix)}var wasmBinaryFile;wasmBinaryFile="ICRPolySeg.wasm";if(!isDataURI(wasmBinaryFile)){wasmBinaryFile=locateFile(wasmBinaryFile)}function getBinary(file){try{if(file==wasmBinaryFile&&wasmBinary){return new Uint8Array(wasmBinary)}if(readBinary){return readBinary(file)}throw"both async and sync fetching of the wasm failed"}catch(err){abort(err)}}function getBinaryPromise(){if(!wasmBinary&&(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER)){if(typeof fetch=="function"){return fetch(wasmBinaryFile,{credentials:"same-origin"}).then(function(response){if(!response["ok"]){throw"failed to load wasm binary file at '"+wasmBinaryFile+"'"}return response["arrayBuffer"]()}).catch(function(){return getBinary(wasmBinaryFile)})}}return Promise.resolve().then(function(){return getBinary(wasmBinaryFile)})}function createWasm(){var info={"a":asmLibraryArg};function receiveInstance(instance,module){var exports=instance.exports;Module["asm"]=exports;wasmMemory=Module["asm"]["Q"];updateGlobalBufferAndViews(wasmMemory.buffer);wasmTable=Module["asm"]["T"];addOnInit(Module["asm"]["R"]);removeRunDependency("wasm-instantiate")}addRunDependency("wasm-instantiate");function receiveInstantiationResult(result){receiveInstance(result["instance"])}function instantiateArrayBuffer(receiver){return getBinaryPromise().then(function(binary){return WebAssembly.instantiate(binary,info)}).then(function(instance){return instance}).then(receiver,function(reason){err("failed to asynchronously prepare wasm: "+reason);abort(reason)})}function instantiateAsync(){if(!wasmBinary&&typeof WebAssembly.instantiateStreaming=="function"&&!isDataURI(wasmBinaryFile)&&typeof fetch=="function"){return fetch(wasmBinaryFile,{credentials:"same-origin"}).then(function(response){var result=WebAssembly.instantiateStreaming(response,info);return result.then(receiveInstantiationResult,function(reason){err("wasm streaming compile failed: "+reason);err("falling back to ArrayBuffer instantiation");return instantiateArrayBuffer(receiveInstantiationResult)})})}else{return instantiateArrayBuffer(receiveInstantiationResult)}}if(Module["instantiateWasm"]){try{var exports=Module["instantiateWasm"](info,receiveInstance);return exports}catch(e){err("Module.instantiateWasm callback failed with error: "+e);readyPromiseReject(e)}}instantiateAsync().catch(readyPromiseReject);return{}}var ASM_CONSTS={638383:$0=>{if(Module.updateProgress){Module.updateProgress($0)}}};function ExitStatus(status){this.name="ExitStatus";this.message="Program terminated with exit("+status+")";this.status=status}function callRuntimeCallbacks(callbacks){while(callbacks.length>0){callbacks.shift()(Module)}}function ExceptionInfo(excPtr){this.excPtr=excPtr;this.ptr=excPtr-24;this.set_type=function(type){HEAPU32[this.ptr+4>>2]=type};this.get_type=function(){return HEAPU32[this.ptr+4>>2]};this.set_destructor=function(destructor){HEAPU32[this.ptr+8>>2]=destructor};this.get_destructor=function(){return HEAPU32[this.ptr+8>>2]};this.set_refcount=function(refcount){HEAP32[this.ptr>>2]=refcount};this.set_caught=function(caught){caught=caught?1:0;HEAP8[this.ptr+12>>0]=caught};this.get_caught=function(){return HEAP8[this.ptr+12>>0]!=0};this.set_rethrown=function(rethrown){rethrown=rethrown?1:0;HEAP8[this.ptr+13>>0]=rethrown};this.get_rethrown=function(){return HEAP8[this.ptr+13>>0]!=0};this.init=function(type,destructor){this.set_adjusted_ptr(0);this.set_type(type);this.set_destructor(destructor);this.set_refcount(0);this.set_caught(false);this.set_rethrown(false)};this.add_ref=function(){var value=HEAP32[this.ptr>>2];HEAP32[this.ptr>>2]=value+1};this.release_ref=function(){var prev=HEAP32[this.ptr>>2];HEAP32[this.ptr>>2]=prev-1;return prev===1};this.set_adjusted_ptr=function(adjustedPtr){HEAPU32[this.ptr+16>>2]=adjustedPtr};this.get_adjusted_ptr=function(){return HEAPU32[this.ptr+16>>2]};this.get_exception_ptr=function(){var isPointer=___cxa_is_pointer_type(this.get_type());if(isPointer){return HEAPU32[this.excPtr>>2]}var adjusted=this.get_adjusted_ptr();if(adjusted!==0)return adjusted;return this.excPtr}}var exceptionLast=0;var uncaughtExceptionCount=0;function ___cxa_throw(ptr,type,destructor){var info=new ExceptionInfo(ptr);info.init(type,destructor);exceptionLast=ptr;uncaughtExceptionCount++;throw ptr}var SYSCALLS={varargs:undefined,get:function(){SYSCALLS.varargs+=4;var ret=HEAP32[SYSCALLS.varargs-4>>2];return ret},getStr:function(ptr){var ret=UTF8ToString(ptr);return ret}};function ___syscall_getcwd(buf,size){}function ___syscall_getdents64(fd,dirp,count){}function ___syscall_openat(dirfd,path,flags,varargs){SYSCALLS.varargs=varargs}function ___syscall_readlinkat(dirfd,path,buf,bufsize){}function ___syscall_stat64(path,buf){}var structRegistrations={};function runDestructors(destructors){while(destructors.length){var ptr=destructors.pop();var del=destructors.pop();del(ptr)}}function simpleReadValueFromPointer(pointer){return this["fromWireType"](HEAP32[pointer>>2])}var awaitingDependencies={};var registeredTypes={};var typeDependencies={};var char_0=48;var char_9=57;function makeLegalFunctionName(name){if(undefined===name){return"_unknown"}name=name.replace(/[^a-zA-Z0-9_]/g,"$");var f=name.charCodeAt(0);if(f>=char_0&&f<=char_9){return"_"+name}return name}function createNamedFunction(name,body){name=makeLegalFunctionName(name);return new Function("body","return function "+name+"() {\n"+'    "use strict";'+"    return body.apply(this, arguments);\n"+"};\n")(body)}function extendError(baseErrorType,errorName){var errorClass=createNamedFunction(errorName,function(message){this.name=errorName;this.message=message;var stack=new Error(message).stack;if(stack!==undefined){this.stack=this.toString()+"\n"+stack.replace(/^Error(:[^\n]*)?\n/,"")}});errorClass.prototype=Object.create(baseErrorType.prototype);errorClass.prototype.constructor=errorClass;errorClass.prototype.toString=function(){if(this.message===undefined){return this.name}else{return this.name+": "+this.message}};return errorClass}var InternalError=undefined;function throwInternalError(message){throw new InternalError(message)}function whenDependentTypesAreResolved(myTypes,dependentTypes,getTypeConverters){myTypes.forEach(function(type){typeDependencies[type]=dependentTypes});function onComplete(typeConverters){var myTypeConverters=getTypeConverters(typeConverters);if(myTypeConverters.length!==myTypes.length){throwInternalError("Mismatched type converter count")}for(var i=0;i<myTypes.length;++i){registerType(myTypes[i],myTypeConverters[i])}}var typeConverters=new Array(dependentTypes.length);var unregisteredTypes=[];var registered=0;dependentTypes.forEach((dt,i)=>{if(registeredTypes.hasOwnProperty(dt)){typeConverters[i]=registeredTypes[dt]}else{unregisteredTypes.push(dt);if(!awaitingDependencies.hasOwnProperty(dt)){awaitingDependencies[dt]=[]}awaitingDependencies[dt].push(()=>{typeConverters[i]=registeredTypes[dt];++registered;if(registered===unregisteredTypes.length){onComplete(typeConverters)}})}});if(0===unregisteredTypes.length){onComplete(typeConverters)}}function __embind_finalize_value_object(structType){var reg=structRegistrations[structType];delete structRegistrations[structType];var rawConstructor=reg.rawConstructor;var rawDestructor=reg.rawDestructor;var fieldRecords=reg.fields;var fieldTypes=fieldRecords.map(field=>field.getterReturnType).concat(fieldRecords.map(field=>field.setterArgumentType));whenDependentTypesAreResolved([structType],fieldTypes,fieldTypes=>{var fields={};fieldRecords.forEach((field,i)=>{var fieldName=field.fieldName;var getterReturnType=fieldTypes[i];var getter=field.getter;var getterContext=field.getterContext;var setterArgumentType=fieldTypes[i+fieldRecords.length];var setter=field.setter;var setterContext=field.setterContext;fields[fieldName]={read:ptr=>{return getterReturnType["fromWireType"](getter(getterContext,ptr))},write:(ptr,o)=>{var destructors=[];setter(setterContext,ptr,setterArgumentType["toWireType"](destructors,o));runDestructors(destructors)}}});return[{name:reg.name,"fromWireType":function(ptr){var rv={};for(var i in fields){rv[i]=fields[i].read(ptr)}rawDestructor(ptr);return rv},"toWireType":function(destructors,o){for(var fieldName in fields){if(!(fieldName in o)){throw new TypeError('Missing field:  "'+fieldName+'"')}}var ptr=rawConstructor();for(fieldName in fields){fields[fieldName].write(ptr,o[fieldName])}if(destructors!==null){destructors.push(rawDestructor,ptr)}return ptr},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:rawDestructor}]})}function __embind_register_bigint(primitiveType,name,size,minRange,maxRange){}function getShiftFromSize(size){switch(size){case 1:return 0;case 2:return 1;case 4:return 2;case 8:return 3;default:throw new TypeError("Unknown type size: "+size)}}function embind_init_charCodes(){var codes=new Array(256);for(var i=0;i<256;++i){codes[i]=String.fromCharCode(i)}embind_charCodes=codes}var embind_charCodes=undefined;function readLatin1String(ptr){var ret="";var c=ptr;while(HEAPU8[c]){ret+=embind_charCodes[HEAPU8[c++]]}return ret}var BindingError=undefined;function throwBindingError(message){throw new BindingError(message)}function registerType(rawType,registeredInstance,options={}){if(!("argPackAdvance"in registeredInstance)){throw new TypeError("registerType registeredInstance requires argPackAdvance")}var name=registeredInstance.name;if(!rawType){throwBindingError('type "'+name+'" must have a positive integer typeid pointer')}if(registeredTypes.hasOwnProperty(rawType)){if(options.ignoreDuplicateRegistrations){return}else{throwBindingError("Cannot register type '"+name+"' twice")}}registeredTypes[rawType]=registeredInstance;delete typeDependencies[rawType];if(awaitingDependencies.hasOwnProperty(rawType)){var callbacks=awaitingDependencies[rawType];delete awaitingDependencies[rawType];callbacks.forEach(cb=>cb())}}function __embind_register_bool(rawType,name,size,trueValue,falseValue){var shift=getShiftFromSize(size);name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(wt){return!!wt},"toWireType":function(destructors,o){return o?trueValue:falseValue},"argPackAdvance":8,"readValueFromPointer":function(pointer){var heap;if(size===1){heap=HEAP8}else if(size===2){heap=HEAP16}else if(size===4){heap=HEAP32}else{throw new TypeError("Unknown boolean type size: "+name)}return this["fromWireType"](heap[pointer>>shift])},destructorFunction:null})}var emval_free_list=[];var emval_handle_array=[{},{value:undefined},{value:null},{value:true},{value:false}];function __emval_decref(handle){if(handle>4&&0===--emval_handle_array[handle].refcount){emval_handle_array[handle]=undefined;emval_free_list.push(handle)}}function count_emval_handles(){var count=0;for(var i=5;i<emval_handle_array.length;++i){if(emval_handle_array[i]!==undefined){++count}}return count}function get_first_emval(){for(var i=5;i<emval_handle_array.length;++i){if(emval_handle_array[i]!==undefined){return emval_handle_array[i]}}return null}function init_emval(){Module["count_emval_handles"]=count_emval_handles;Module["get_first_emval"]=get_first_emval}var Emval={toValue:handle=>{if(!handle){throwBindingError("Cannot use deleted val. handle = "+handle)}return emval_handle_array[handle].value},toHandle:value=>{switch(value){case undefined:return 1;case null:return 2;case true:return 3;case false:return 4;default:{var handle=emval_free_list.length?emval_free_list.pop():emval_handle_array.length;emval_handle_array[handle]={refcount:1,value:value};return handle}}}};function __embind_register_emval(rawType,name){name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(handle){var rv=Emval.toValue(handle);__emval_decref(handle);return rv},"toWireType":function(destructors,value){return Emval.toHandle(value)},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:null})}function floatReadValueFromPointer(name,shift){switch(shift){case 2:return function(pointer){return this["fromWireType"](HEAPF32[pointer>>2])};case 3:return function(pointer){return this["fromWireType"](HEAPF64[pointer>>3])};default:throw new TypeError("Unknown float type: "+name)}}function __embind_register_float(rawType,name,size){var shift=getShiftFromSize(size);name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":function(value){return value},"toWireType":function(destructors,value){return value},"argPackAdvance":8,"readValueFromPointer":floatReadValueFromPointer(name,shift),destructorFunction:null})}function new_(constructor,argumentList){if(!(constructor instanceof Function)){throw new TypeError("new_ called with constructor type "+typeof constructor+" which is not a function")}var dummy=createNamedFunction(constructor.name||"unknownFunctionName",function(){});dummy.prototype=constructor.prototype;var obj=new dummy;var r=constructor.apply(obj,argumentList);return r instanceof Object?r:obj}function craftInvokerFunction(humanName,argTypes,classType,cppInvokerFunc,cppTargetFunc){var argCount=argTypes.length;if(argCount<2){throwBindingError("argTypes array size mismatch! Must at least get return value and 'this' types!")}var isClassMethodFunc=argTypes[1]!==null&&classType!==null;var needsDestructorStack=false;for(var i=1;i<argTypes.length;++i){if(argTypes[i]!==null&&argTypes[i].destructorFunction===undefined){needsDestructorStack=true;break}}var returns=argTypes[0].name!=="void";var argsList="";var argsListWired="";for(var i=0;i<argCount-2;++i){argsList+=(i!==0?", ":"")+"arg"+i;argsListWired+=(i!==0?", ":"")+"arg"+i+"Wired"}var invokerFnBody="return function "+makeLegalFunctionName(humanName)+"("+argsList+") {\n"+"if (arguments.length !== "+(argCount-2)+") {\n"+"throwBindingError('function "+humanName+" called with ' + arguments.length + ' arguments, expected "+(argCount-2)+" args!');\n"+"}\n";if(needsDestructorStack){invokerFnBody+="var destructors = [];\n"}var dtorStack=needsDestructorStack?"destructors":"null";var args1=["throwBindingError","invoker","fn","runDestructors","retType","classParam"];var args2=[throwBindingError,cppInvokerFunc,cppTargetFunc,runDestructors,argTypes[0],argTypes[1]];if(isClassMethodFunc){invokerFnBody+="var thisWired = classParam.toWireType("+dtorStack+", this);\n"}for(var i=0;i<argCount-2;++i){invokerFnBody+="var arg"+i+"Wired = argType"+i+".toWireType("+dtorStack+", arg"+i+"); // "+argTypes[i+2].name+"\n";args1.push("argType"+i);args2.push(argTypes[i+2])}if(isClassMethodFunc){argsListWired="thisWired"+(argsListWired.length>0?", ":"")+argsListWired}invokerFnBody+=(returns?"var rv = ":"")+"invoker(fn"+(argsListWired.length>0?", ":"")+argsListWired+");\n";if(needsDestructorStack){invokerFnBody+="runDestructors(destructors);\n"}else{for(var i=isClassMethodFunc?1:2;i<argTypes.length;++i){var paramName=i===1?"thisWired":"arg"+(i-2)+"Wired";if(argTypes[i].destructorFunction!==null){invokerFnBody+=paramName+"_dtor("+paramName+"); // "+argTypes[i].name+"\n";args1.push(paramName+"_dtor");args2.push(argTypes[i].destructorFunction)}}}if(returns){invokerFnBody+="var ret = retType.fromWireType(rv);\n"+"return ret;\n"}else{}invokerFnBody+="}\n";args1.push(invokerFnBody);var invokerFunction=new_(Function,args1).apply(null,args2);return invokerFunction}function ensureOverloadTable(proto,methodName,humanName){if(undefined===proto[methodName].overloadTable){var prevFunc=proto[methodName];proto[methodName]=function(){if(!proto[methodName].overloadTable.hasOwnProperty(arguments.length)){throwBindingError("Function '"+humanName+"' called with an invalid number of arguments ("+arguments.length+") - expects one of ("+proto[methodName].overloadTable+")!")}return proto[methodName].overloadTable[arguments.length].apply(this,arguments)};proto[methodName].overloadTable=[];proto[methodName].overloadTable[prevFunc.argCount]=prevFunc}}function exposePublicSymbol(name,value,numArguments){if(Module.hasOwnProperty(name)){if(undefined===numArguments||undefined!==Module[name].overloadTable&&undefined!==Module[name].overloadTable[numArguments]){throwBindingError("Cannot register public name '"+name+"' twice")}ensureOverloadTable(Module,name,name);if(Module.hasOwnProperty(numArguments)){throwBindingError("Cannot register multiple overloads of a function with the same number of arguments ("+numArguments+")!")}Module[name].overloadTable[numArguments]=value}else{Module[name]=value;if(undefined!==numArguments){Module[name].numArguments=numArguments}}}function heap32VectorToArray(count,firstElement){var array=[];for(var i=0;i<count;i++){array.push(HEAPU32[firstElement+i*4>>2])}return array}function replacePublicSymbol(name,value,numArguments){if(!Module.hasOwnProperty(name)){throwInternalError("Replacing nonexistant public symbol")}if(undefined!==Module[name].overloadTable&&undefined!==numArguments){Module[name].overloadTable[numArguments]=value}else{Module[name]=value;Module[name].argCount=numArguments}}function dynCallLegacy(sig,ptr,args){var f=Module["dynCall_"+sig];return args&&args.length?f.apply(null,[ptr].concat(args)):f.call(null,ptr)}var wasmTableMirror=[];function getWasmTableEntry(funcPtr){var func=wasmTableMirror[funcPtr];if(!func){if(funcPtr>=wasmTableMirror.length)wasmTableMirror.length=funcPtr+1;wasmTableMirror[funcPtr]=func=wasmTable.get(funcPtr)}return func}function dynCall(sig,ptr,args){if(sig.includes("j")){return dynCallLegacy(sig,ptr,args)}var rtn=getWasmTableEntry(ptr).apply(null,args);return rtn}function getDynCaller(sig,ptr){var argCache=[];return function(){argCache.length=0;Object.assign(argCache,arguments);return dynCall(sig,ptr,argCache)}}function embind__requireFunction(signature,rawFunction){signature=readLatin1String(signature);function makeDynCaller(){if(signature.includes("j")){return getDynCaller(signature,rawFunction)}return getWasmTableEntry(rawFunction)}var fp=makeDynCaller();if(typeof fp!="function"){throwBindingError("unknown function pointer with signature "+signature+": "+rawFunction)}return fp}var UnboundTypeError=undefined;function getTypeName(type){var ptr=___getTypeName(type);var rv=readLatin1String(ptr);_free(ptr);return rv}function throwUnboundTypeError(message,types){var unboundTypes=[];var seen={};function visit(type){if(seen[type]){return}if(registeredTypes[type]){return}if(typeDependencies[type]){typeDependencies[type].forEach(visit);return}unboundTypes.push(type);seen[type]=true}types.forEach(visit);throw new UnboundTypeError(message+": "+unboundTypes.map(getTypeName).join([", "]))}function __embind_register_function(name,argCount,rawArgTypesAddr,signature,rawInvoker,fn){var argTypes=heap32VectorToArray(argCount,rawArgTypesAddr);name=readLatin1String(name);rawInvoker=embind__requireFunction(signature,rawInvoker);exposePublicSymbol(name,function(){throwUnboundTypeError("Cannot call "+name+" due to unbound types",argTypes)},argCount-1);whenDependentTypesAreResolved([],argTypes,function(argTypes){var invokerArgsArray=[argTypes[0],null].concat(argTypes.slice(1));replacePublicSymbol(name,craftInvokerFunction(name,invokerArgsArray,null,rawInvoker,fn),argCount-1);return[]})}function integerReadValueFromPointer(name,shift,signed){switch(shift){case 0:return signed?function readS8FromPointer(pointer){return HEAP8[pointer]}:function readU8FromPointer(pointer){return HEAPU8[pointer]};case 1:return signed?function readS16FromPointer(pointer){return HEAP16[pointer>>1]}:function readU16FromPointer(pointer){return HEAPU16[pointer>>1]};case 2:return signed?function readS32FromPointer(pointer){return HEAP32[pointer>>2]}:function readU32FromPointer(pointer){return HEAPU32[pointer>>2]};default:throw new TypeError("Unknown integer type: "+name)}}function __embind_register_integer(primitiveType,name,size,minRange,maxRange){name=readLatin1String(name);if(maxRange===-1){maxRange=4294967295}var shift=getShiftFromSize(size);var fromWireType=value=>value;if(minRange===0){var bitshift=32-8*size;fromWireType=value=>value<<bitshift>>>bitshift}var isUnsignedType=name.includes("unsigned");var checkAssertions=(value,toTypeName)=>{};var toWireType;if(isUnsignedType){toWireType=function(destructors,value){checkAssertions(value,this.name);return value>>>0}}else{toWireType=function(destructors,value){checkAssertions(value,this.name);return value}}registerType(primitiveType,{name:name,"fromWireType":fromWireType,"toWireType":toWireType,"argPackAdvance":8,"readValueFromPointer":integerReadValueFromPointer(name,shift,minRange!==0),destructorFunction:null})}function __embind_register_memory_view(rawType,dataTypeIndex,name){var typeMapping=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array];var TA=typeMapping[dataTypeIndex];function decodeMemoryView(handle){handle=handle>>2;var heap=HEAPU32;var size=heap[handle];var data=heap[handle+1];return new TA(buffer,data,size)}name=readLatin1String(name);registerType(rawType,{name:name,"fromWireType":decodeMemoryView,"argPackAdvance":8,"readValueFromPointer":decodeMemoryView},{ignoreDuplicateRegistrations:true})}function __embind_register_std_string(rawType,name){name=readLatin1String(name);var stdStringIsUTF8=name==="std::string";registerType(rawType,{name:name,"fromWireType":function(value){var length=HEAPU32[value>>2];var payload=value+4;var str;if(stdStringIsUTF8){var decodeStartPtr=payload;for(var i=0;i<=length;++i){var currentBytePtr=payload+i;if(i==length||HEAPU8[currentBytePtr]==0){var maxRead=currentBytePtr-decodeStartPtr;var stringSegment=UTF8ToString(decodeStartPtr,maxRead);if(str===undefined){str=stringSegment}else{str+=String.fromCharCode(0);str+=stringSegment}decodeStartPtr=currentBytePtr+1}}}else{var a=new Array(length);for(var i=0;i<length;++i){a[i]=String.fromCharCode(HEAPU8[payload+i])}str=a.join("")}_free(value);return str},"toWireType":function(destructors,value){if(value instanceof ArrayBuffer){value=new Uint8Array(value)}var length;var valueIsOfTypeString=typeof value=="string";if(!(valueIsOfTypeString||value instanceof Uint8Array||value instanceof Uint8ClampedArray||value instanceof Int8Array)){throwBindingError("Cannot pass non-string to std::string")}if(stdStringIsUTF8&&valueIsOfTypeString){length=lengthBytesUTF8(value)}else{length=value.length}var base=_malloc(4+length+1);var ptr=base+4;HEAPU32[base>>2]=length;if(stdStringIsUTF8&&valueIsOfTypeString){stringToUTF8(value,ptr,length+1)}else{if(valueIsOfTypeString){for(var i=0;i<length;++i){var charCode=value.charCodeAt(i);if(charCode>255){_free(ptr);throwBindingError("String has UTF-16 code units that do not fit in 8 bits")}HEAPU8[ptr+i]=charCode}}else{for(var i=0;i<length;++i){HEAPU8[ptr+i]=value[i]}}}if(destructors!==null){destructors.push(_free,base)}return base},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:function(ptr){_free(ptr)}})}var UTF16Decoder=typeof TextDecoder!="undefined"?new TextDecoder("utf-16le"):undefined;function UTF16ToString(ptr,maxBytesToRead){var endPtr=ptr;var idx=endPtr>>1;var maxIdx=idx+maxBytesToRead/2;while(!(idx>=maxIdx)&&HEAPU16[idx])++idx;endPtr=idx<<1;if(endPtr-ptr>32&&UTF16Decoder)return UTF16Decoder.decode(HEAPU8.subarray(ptr,endPtr));var str="";for(var i=0;!(i>=maxBytesToRead/2);++i){var codeUnit=HEAP16[ptr+i*2>>1];if(codeUnit==0)break;str+=String.fromCharCode(codeUnit)}return str}function stringToUTF16(str,outPtr,maxBytesToWrite){if(maxBytesToWrite===undefined){maxBytesToWrite=2147483647}if(maxBytesToWrite<2)return 0;maxBytesToWrite-=2;var startPtr=outPtr;var numCharsToWrite=maxBytesToWrite<str.length*2?maxBytesToWrite/2:str.length;for(var i=0;i<numCharsToWrite;++i){var codeUnit=str.charCodeAt(i);HEAP16[outPtr>>1]=codeUnit;outPtr+=2}HEAP16[outPtr>>1]=0;return outPtr-startPtr}function lengthBytesUTF16(str){return str.length*2}function UTF32ToString(ptr,maxBytesToRead){var i=0;var str="";while(!(i>=maxBytesToRead/4)){var utf32=HEAP32[ptr+i*4>>2];if(utf32==0)break;++i;if(utf32>=65536){var ch=utf32-65536;str+=String.fromCharCode(55296|ch>>10,56320|ch&1023)}else{str+=String.fromCharCode(utf32)}}return str}function stringToUTF32(str,outPtr,maxBytesToWrite){if(maxBytesToWrite===undefined){maxBytesToWrite=2147483647}if(maxBytesToWrite<4)return 0;var startPtr=outPtr;var endPtr=startPtr+maxBytesToWrite-4;for(var i=0;i<str.length;++i){var codeUnit=str.charCodeAt(i);if(codeUnit>=55296&&codeUnit<=57343){var trailSurrogate=str.charCodeAt(++i);codeUnit=65536+((codeUnit&1023)<<10)|trailSurrogate&1023}HEAP32[outPtr>>2]=codeUnit;outPtr+=4;if(outPtr+4>endPtr)break}HEAP32[outPtr>>2]=0;return outPtr-startPtr}function lengthBytesUTF32(str){var len=0;for(var i=0;i<str.length;++i){var codeUnit=str.charCodeAt(i);if(codeUnit>=55296&&codeUnit<=57343)++i;len+=4}return len}function __embind_register_std_wstring(rawType,charSize,name){name=readLatin1String(name);var decodeString,encodeString,getHeap,lengthBytesUTF,shift;if(charSize===2){decodeString=UTF16ToString;encodeString=stringToUTF16;lengthBytesUTF=lengthBytesUTF16;getHeap=()=>HEAPU16;shift=1}else if(charSize===4){decodeString=UTF32ToString;encodeString=stringToUTF32;lengthBytesUTF=lengthBytesUTF32;getHeap=()=>HEAPU32;shift=2}registerType(rawType,{name:name,"fromWireType":function(value){var length=HEAPU32[value>>2];var HEAP=getHeap();var str;var decodeStartPtr=value+4;for(var i=0;i<=length;++i){var currentBytePtr=value+4+i*charSize;if(i==length||HEAP[currentBytePtr>>shift]==0){var maxReadBytes=currentBytePtr-decodeStartPtr;var stringSegment=decodeString(decodeStartPtr,maxReadBytes);if(str===undefined){str=stringSegment}else{str+=String.fromCharCode(0);str+=stringSegment}decodeStartPtr=currentBytePtr+charSize}}_free(value);return str},"toWireType":function(destructors,value){if(!(typeof value=="string")){throwBindingError("Cannot pass non-string to C++ string type "+name)}var length=lengthBytesUTF(value);var ptr=_malloc(4+length+charSize);HEAPU32[ptr>>2]=length>>shift;encodeString(value,ptr+4,length+charSize);if(destructors!==null){destructors.push(_free,ptr)}return ptr},"argPackAdvance":8,"readValueFromPointer":simpleReadValueFromPointer,destructorFunction:function(ptr){_free(ptr)}})}function __embind_register_value_object(rawType,name,constructorSignature,rawConstructor,destructorSignature,rawDestructor){structRegistrations[rawType]={name:readLatin1String(name),rawConstructor:embind__requireFunction(constructorSignature,rawConstructor),rawDestructor:embind__requireFunction(destructorSignature,rawDestructor),fields:[]}}function __embind_register_value_object_field(structType,fieldName,getterReturnType,getterSignature,getter,getterContext,setterArgumentType,setterSignature,setter,setterContext){structRegistrations[structType].fields.push({fieldName:readLatin1String(fieldName),getterReturnType:getterReturnType,getter:embind__requireFunction(getterSignature,getter),getterContext:getterContext,setterArgumentType:setterArgumentType,setter:embind__requireFunction(setterSignature,setter),setterContext:setterContext})}function __embind_register_void(rawType,name){name=readLatin1String(name);registerType(rawType,{isVoid:true,name:name,"argPackAdvance":0,"fromWireType":function(){return undefined},"toWireType":function(destructors,o){return undefined}})}function requireRegisteredType(rawType,humanName){var impl=registeredTypes[rawType];if(undefined===impl){throwBindingError(humanName+" has unknown type "+getTypeName(rawType))}return impl}function __emval_as(handle,returnType,destructorsRef){handle=Emval.toValue(handle);returnType=requireRegisteredType(returnType,"emval::as");var destructors=[];var rd=Emval.toHandle(destructors);HEAPU32[destructorsRef>>2]=rd;return returnType["toWireType"](destructors,handle)}var emval_symbols={};function getStringOrSymbol(address){var symbol=emval_symbols[address];if(symbol===undefined){return readLatin1String(address)}return symbol}var emval_methodCallers=[];function __emval_call_void_method(caller,handle,methodName,args){caller=emval_methodCallers[caller];handle=Emval.toValue(handle);methodName=getStringOrSymbol(methodName);caller(handle,methodName,null,args)}function emval_get_global(){if(typeof globalThis=="object"){return globalThis}return function(){return Function}()("return this")()}function __emval_get_global(name){if(name===0){return Emval.toHandle(emval_get_global())}else{name=getStringOrSymbol(name);return Emval.toHandle(emval_get_global()[name])}}function emval_addMethodCaller(caller){var id=emval_methodCallers.length;emval_methodCallers.push(caller);return id}function emval_lookupTypes(argCount,argTypes){var a=new Array(argCount);for(var i=0;i<argCount;++i){a[i]=requireRegisteredType(HEAPU32[argTypes+i*POINTER_SIZE>>2],"parameter "+i)}return a}var emval_registeredMethods=[];function __emval_get_method_caller(argCount,argTypes){var types=emval_lookupTypes(argCount,argTypes);var retType=types[0];var signatureName=retType.name+"_$"+types.slice(1).map(function(t){return t.name}).join("_")+"$";var returnId=emval_registeredMethods[signatureName];if(returnId!==undefined){return returnId}var params=["retType"];var args=[retType];var argsList="";for(var i=0;i<argCount-1;++i){argsList+=(i!==0?", ":"")+"arg"+i;params.push("argType"+i);args.push(types[1+i])}var functionName=makeLegalFunctionName("methodCaller_"+signatureName);var functionBody="return function "+functionName+"(handle, name, destructors, args) {\n";var offset=0;for(var i=0;i<argCount-1;++i){functionBody+="    var arg"+i+" = argType"+i+".readValueFromPointer(args"+(offset?"+"+offset:"")+");\n";offset+=types[i+1]["argPackAdvance"]}functionBody+="    var rv = handle[name]("+argsList+");\n";for(var i=0;i<argCount-1;++i){if(types[i+1]["deleteObject"]){functionBody+="    argType"+i+".deleteObject(arg"+i+");\n"}}if(!retType.isVoid){functionBody+="    return retType.toWireType(destructors, rv);\n"}functionBody+="};\n";params.push(functionBody);var invokerFunction=new_(Function,params).apply(null,args);returnId=emval_addMethodCaller(invokerFunction);emval_registeredMethods[signatureName]=returnId;return returnId}function __emval_get_property(handle,key){handle=Emval.toValue(handle);key=Emval.toValue(key);return Emval.toHandle(handle[key])}function __emval_incref(handle){if(handle>4){emval_handle_array[handle].refcount+=1}}function craftEmvalAllocator(argCount){var argsList="";for(var i=0;i<argCount;++i){argsList+=(i!==0?", ":"")+"arg"+i}var getMemory=()=>HEAPU32;var functionBody="return function emval_allocator_"+argCount+"(constructor, argTypes, args) {\n"+"  var HEAPU32 = getMemory();\n";for(var i=0;i<argCount;++i){functionBody+="var argType"+i+" = requireRegisteredType(HEAPU32[((argTypes)>>2)], 'parameter "+i+"');\n"+"var arg"+i+" = argType"+i+".readValueFromPointer(args);\n"+"args += argType"+i+"['argPackAdvance'];\n"+"argTypes += 4;\n"}functionBody+="var obj = new constructor("+argsList+");\n"+"return valueToHandle(obj);\n"+"}\n";return new Function("requireRegisteredType","Module","valueToHandle","getMemory",functionBody)(requireRegisteredType,Module,Emval.toHandle,getMemory)}var emval_newers={};function __emval_new(handle,argCount,argTypes,args){handle=Emval.toValue(handle);var newer=emval_newers[argCount];if(!newer){newer=craftEmvalAllocator(argCount);emval_newers[argCount]=newer}return newer(handle,argTypes,args)}function __emval_new_cstring(v){return Emval.toHandle(getStringOrSymbol(v))}function __emval_run_destructors(handle){var destructors=Emval.toValue(handle);runDestructors(destructors);__emval_decref(handle)}function __emval_take_value(type,arg){type=requireRegisteredType(type,"_emval_take_value");var v=type["readValueFromPointer"](arg);return Emval.toHandle(v)}function _abort(){abort("")}var readEmAsmArgsArray=[];function readEmAsmArgs(sigPtr,buf){readEmAsmArgsArray.length=0;var ch;buf>>=2;while(ch=HEAPU8[sigPtr++]){buf+=ch!=105&buf;readEmAsmArgsArray.push(ch==105?HEAP32[buf]:HEAPF64[buf++>>1]);++buf}return readEmAsmArgsArray}function runEmAsmFunction(code,sigPtr,argbuf){var args=readEmAsmArgs(sigPtr,argbuf);return ASM_CONSTS[code].apply(null,args)}function _emscripten_asm_const_int(code,sigPtr,argbuf){return runEmAsmFunction(code,sigPtr,argbuf)}function getHeapMax(){return 2147483648}function _emscripten_get_heap_max(){return getHeapMax()}function _emscripten_memcpy_big(dest,src,num){HEAPU8.copyWithin(dest,src,src+num)}function emscripten_realloc_buffer(size){try{wasmMemory.grow(size-buffer.byteLength+65535>>>16);updateGlobalBufferAndViews(wasmMemory.buffer);return 1}catch(e){}}function _emscripten_resize_heap(requestedSize){var oldSize=HEAPU8.length;requestedSize=requestedSize>>>0;var maxHeapSize=getHeapMax();if(requestedSize>maxHeapSize){return false}let alignUp=(x,multiple)=>x+(multiple-x%multiple)%multiple;for(var cutDown=1;cutDown<=4;cutDown*=2){var overGrownHeapSize=oldSize*(1+.2/cutDown);overGrownHeapSize=Math.min(overGrownHeapSize,requestedSize+100663296);var newSize=Math.min(maxHeapSize,alignUp(Math.max(requestedSize,overGrownHeapSize),65536));var replacement=emscripten_realloc_buffer(newSize);if(replacement){return true}}return false}var ENV={};function getExecutableName(){return thisProgram||"./this.program"}function getEnvStrings(){if(!getEnvStrings.strings){var lang=(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8";var env={"USER":"web_user","LOGNAME":"web_user","PATH":"/","PWD":"/","HOME":"/home/web_user","LANG":lang,"_":getExecutableName()};for(var x in ENV){if(ENV[x]===undefined)delete env[x];else env[x]=ENV[x]}var strings=[];for(var x in env){strings.push(x+"="+env[x])}getEnvStrings.strings=strings}return getEnvStrings.strings}function writeAsciiToMemory(str,buffer,dontAddNull){for(var i=0;i<str.length;++i){HEAP8[buffer++>>0]=str.charCodeAt(i)}if(!dontAddNull)HEAP8[buffer>>0]=0}function _environ_get(__environ,environ_buf){var bufSize=0;getEnvStrings().forEach(function(string,i){var ptr=environ_buf+bufSize;HEAPU32[__environ+i*4>>2]=ptr;writeAsciiToMemory(string,ptr);bufSize+=string.length+1});return 0}function _environ_sizes_get(penviron_count,penviron_buf_size){var strings=getEnvStrings();HEAPU32[penviron_count>>2]=strings.length;var bufSize=0;strings.forEach(function(string){bufSize+=string.length+1});HEAPU32[penviron_buf_size>>2]=bufSize;return 0}function _fd_close(fd){return 52}function _fd_read(fd,iov,iovcnt,pnum){return 52}function _fd_seek(fd,offset_low,offset_high,whence,newOffset){return 70}var printCharBuffers=[null,[],[]];function printChar(stream,curr){var buffer=printCharBuffers[stream];if(curr===0||curr===10){(stream===1?out:err)(UTF8ArrayToString(buffer,0));buffer.length=0}else{buffer.push(curr)}}function _fd_write(fd,iov,iovcnt,pnum){var num=0;for(var i=0;i<iovcnt;i++){var ptr=HEAPU32[iov>>2];var len=HEAPU32[iov+4>>2];iov+=8;for(var j=0;j<len;j++){printChar(fd,HEAPU8[ptr+j])}num+=len}HEAPU32[pnum>>2]=num;return 0}function __isLeapYear(year){return year%4===0&&(year%100!==0||year%400===0)}function __arraySum(array,index){var sum=0;for(var i=0;i<=index;sum+=array[i++]){}return sum}var __MONTH_DAYS_LEAP=[31,29,31,30,31,30,31,31,30,31,30,31];var __MONTH_DAYS_REGULAR=[31,28,31,30,31,30,31,31,30,31,30,31];function __addDays(date,days){var newDate=new Date(date.getTime());while(days>0){var leap=__isLeapYear(newDate.getFullYear());var currentMonth=newDate.getMonth();var daysInCurrentMonth=(leap?__MONTH_DAYS_LEAP:__MONTH_DAYS_REGULAR)[currentMonth];if(days>daysInCurrentMonth-newDate.getDate()){days-=daysInCurrentMonth-newDate.getDate()+1;newDate.setDate(1);if(currentMonth<11){newDate.setMonth(currentMonth+1)}else{newDate.setMonth(0);newDate.setFullYear(newDate.getFullYear()+1)}}else{newDate.setDate(newDate.getDate()+days);return newDate}}return newDate}function intArrayFromString(stringy,dontAddNull,length){var len=length>0?length:lengthBytesUTF8(stringy)+1;var u8array=new Array(len);var numBytesWritten=stringToUTF8Array(stringy,u8array,0,u8array.length);if(dontAddNull)u8array.length=numBytesWritten;return u8array}function writeArrayToMemory(array,buffer){HEAP8.set(array,buffer)}function _strftime(s,maxsize,format,tm){var tm_zone=HEAP32[tm+40>>2];var date={tm_sec:HEAP32[tm>>2],tm_min:HEAP32[tm+4>>2],tm_hour:HEAP32[tm+8>>2],tm_mday:HEAP32[tm+12>>2],tm_mon:HEAP32[tm+16>>2],tm_year:HEAP32[tm+20>>2],tm_wday:HEAP32[tm+24>>2],tm_yday:HEAP32[tm+28>>2],tm_isdst:HEAP32[tm+32>>2],tm_gmtoff:HEAP32[tm+36>>2],tm_zone:tm_zone?UTF8ToString(tm_zone):""};var pattern=UTF8ToString(format);var EXPANSION_RULES_1={"%c":"%a %b %d %H:%M:%S %Y","%D":"%m/%d/%y","%F":"%Y-%m-%d","%h":"%b","%r":"%I:%M:%S %p","%R":"%H:%M","%T":"%H:%M:%S","%x":"%m/%d/%y","%X":"%H:%M:%S","%Ec":"%c","%EC":"%C","%Ex":"%m/%d/%y","%EX":"%H:%M:%S","%Ey":"%y","%EY":"%Y","%Od":"%d","%Oe":"%e","%OH":"%H","%OI":"%I","%Om":"%m","%OM":"%M","%OS":"%S","%Ou":"%u","%OU":"%U","%OV":"%V","%Ow":"%w","%OW":"%W","%Oy":"%y"};for(var rule in EXPANSION_RULES_1){pattern=pattern.replace(new RegExp(rule,"g"),EXPANSION_RULES_1[rule])}var WEEKDAYS=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];var MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];function leadingSomething(value,digits,character){var str=typeof value=="number"?value.toString():value||"";while(str.length<digits){str=character[0]+str}return str}function leadingNulls(value,digits){return leadingSomething(value,digits,"0")}function compareByDay(date1,date2){function sgn(value){return value<0?-1:value>0?1:0}var compare;if((compare=sgn(date1.getFullYear()-date2.getFullYear()))===0){if((compare=sgn(date1.getMonth()-date2.getMonth()))===0){compare=sgn(date1.getDate()-date2.getDate())}}return compare}function getFirstWeekStartDate(janFourth){switch(janFourth.getDay()){case 0:return new Date(janFourth.getFullYear()-1,11,29);case 1:return janFourth;case 2:return new Date(janFourth.getFullYear(),0,3);case 3:return new Date(janFourth.getFullYear(),0,2);case 4:return new Date(janFourth.getFullYear(),0,1);case 5:return new Date(janFourth.getFullYear()-1,11,31);case 6:return new Date(janFourth.getFullYear()-1,11,30)}}function getWeekBasedYear(date){var thisDate=__addDays(new Date(date.tm_year+1900,0,1),date.tm_yday);var janFourthThisYear=new Date(thisDate.getFullYear(),0,4);var janFourthNextYear=new Date(thisDate.getFullYear()+1,0,4);var firstWeekStartThisYear=getFirstWeekStartDate(janFourthThisYear);var firstWeekStartNextYear=getFirstWeekStartDate(janFourthNextYear);if(compareByDay(firstWeekStartThisYear,thisDate)<=0){if(compareByDay(firstWeekStartNextYear,thisDate)<=0){return thisDate.getFullYear()+1}return thisDate.getFullYear()}return thisDate.getFullYear()-1}var EXPANSION_RULES_2={"%a":function(date){return WEEKDAYS[date.tm_wday].substring(0,3)},"%A":function(date){return WEEKDAYS[date.tm_wday]},"%b":function(date){return MONTHS[date.tm_mon].substring(0,3)},"%B":function(date){return MONTHS[date.tm_mon]},"%C":function(date){var year=date.tm_year+1900;return leadingNulls(year/100|0,2)},"%d":function(date){return leadingNulls(date.tm_mday,2)},"%e":function(date){return leadingSomething(date.tm_mday,2," ")},"%g":function(date){return getWeekBasedYear(date).toString().substring(2)},"%G":function(date){return getWeekBasedYear(date)},"%H":function(date){return leadingNulls(date.tm_hour,2)},"%I":function(date){var twelveHour=date.tm_hour;if(twelveHour==0)twelveHour=12;else if(twelveHour>12)twelveHour-=12;return leadingNulls(twelveHour,2)},"%j":function(date){return leadingNulls(date.tm_mday+__arraySum(__isLeapYear(date.tm_year+1900)?__MONTH_DAYS_LEAP:__MONTH_DAYS_REGULAR,date.tm_mon-1),3)},"%m":function(date){return leadingNulls(date.tm_mon+1,2)},"%M":function(date){return leadingNulls(date.tm_min,2)},"%n":function(){return"\n"},"%p":function(date){if(date.tm_hour>=0&&date.tm_hour<12){return"AM"}return"PM"},"%S":function(date){return leadingNulls(date.tm_sec,2)},"%t":function(){return"\t"},"%u":function(date){return date.tm_wday||7},"%U":function(date){var days=date.tm_yday+7-date.tm_wday;return leadingNulls(Math.floor(days/7),2)},"%V":function(date){var val=Math.floor((date.tm_yday+7-(date.tm_wday+6)%7)/7);if((date.tm_wday+371-date.tm_yday-2)%7<=2){val++}if(!val){val=52;var dec31=(date.tm_wday+7-date.tm_yday-1)%7;if(dec31==4||dec31==5&&__isLeapYear(date.tm_year%400-1)){val++}}else if(val==53){var jan1=(date.tm_wday+371-date.tm_yday)%7;if(jan1!=4&&(jan1!=3||!__isLeapYear(date.tm_year)))val=1}return leadingNulls(val,2)},"%w":function(date){return date.tm_wday},"%W":function(date){var days=date.tm_yday+7-(date.tm_wday+6)%7;return leadingNulls(Math.floor(days/7),2)},"%y":function(date){return(date.tm_year+1900).toString().substring(2)},"%Y":function(date){return date.tm_year+1900},"%z":function(date){var off=date.tm_gmtoff;var ahead=off>=0;off=Math.abs(off)/60;off=off/60*100+off%60;return(ahead?"+":"-")+String("0000"+off).slice(-4)},"%Z":function(date){return date.tm_zone},"%%":function(){return"%"}};pattern=pattern.replace(/%%/g,"\0\0");for(var rule in EXPANSION_RULES_2){if(pattern.includes(rule)){pattern=pattern.replace(new RegExp(rule,"g"),EXPANSION_RULES_2[rule](date))}}pattern=pattern.replace(/\0\0/g,"%");var bytes=intArrayFromString(pattern,false);if(bytes.length>maxsize){return 0}writeArrayToMemory(bytes,s);return bytes.length-1}function _strftime_l(s,maxsize,format,tm,loc){return _strftime(s,maxsize,format,tm)}function _proc_exit(code){EXITSTATUS=code;if(!keepRuntimeAlive()){if(Module["onExit"])Module["onExit"](code);ABORT=true}quit_(code,new ExitStatus(code))}function exitJS(status,implicit){EXITSTATUS=status;_proc_exit(status)}function handleException(e){if(e instanceof ExitStatus||e=="unwind"){return EXITSTATUS}quit_(1,e)}InternalError=Module["InternalError"]=extendError(Error,"InternalError");embind_init_charCodes();BindingError=Module["BindingError"]=extendError(Error,"BindingError");init_emval();UnboundTypeError=Module["UnboundTypeError"]=extendError(Error,"UnboundTypeError");var asmLibraryArg={"b":___cxa_throw,"J":___syscall_getcwd,"F":___syscall_getdents64,"L":___syscall_openat,"E":___syscall_readlinkat,"G":___syscall_stat64,"x":__embind_finalize_value_object,"A":__embind_register_bigint,"O":__embind_register_bool,"N":__embind_register_emval,"v":__embind_register_float,"g":__embind_register_function,"d":__embind_register_integer,"c":__embind_register_memory_view,"u":__embind_register_std_string,"m":__embind_register_std_wstring,"y":__embind_register_value_object,"e":__embind_register_value_object_field,"P":__embind_register_void,"r":__emval_as,"i":__emval_call_void_method,"a":__emval_decref,"p":__emval_get_global,"j":__emval_get_method_caller,"s":__emval_get_property,"f":__emval_incref,"o":__emval_new,"w":__emval_new_cstring,"q":__emval_run_destructors,"k":__emval_take_value,"n":_abort,"h":_emscripten_asm_const_int,"D":_emscripten_get_heap_max,"M":_emscripten_memcpy_big,"C":_emscripten_resize_heap,"H":_environ_get,"I":_environ_sizes_get,"l":_fd_close,"K":_fd_read,"z":_fd_seek,"t":_fd_write,"B":_strftime_l};var asm=createWasm();var ___wasm_call_ctors=Module["___wasm_call_ctors"]=function(){return(___wasm_call_ctors=Module["___wasm_call_ctors"]=Module["asm"]["R"]).apply(null,arguments)};var _main=Module["_main"]=function(){return(_main=Module["_main"]=Module["asm"]["S"]).apply(null,arguments)};var _malloc=Module["_malloc"]=function(){return(_malloc=Module["_malloc"]=Module["asm"]["U"]).apply(null,arguments)};var _free=Module["_free"]=function(){return(_free=Module["_free"]=Module["asm"]["V"]).apply(null,arguments)};var ___getTypeName=Module["___getTypeName"]=function(){return(___getTypeName=Module["___getTypeName"]=Module["asm"]["W"]).apply(null,arguments)};var __embind_initialize_bindings=Module["__embind_initialize_bindings"]=function(){return(__embind_initialize_bindings=Module["__embind_initialize_bindings"]=Module["asm"]["X"]).apply(null,arguments)};var ___cxa_is_pointer_type=Module["___cxa_is_pointer_type"]=function(){return(___cxa_is_pointer_type=Module["___cxa_is_pointer_type"]=Module["asm"]["Y"]).apply(null,arguments)};var dynCall_viij=Module["dynCall_viij"]=function(){return(dynCall_viij=Module["dynCall_viij"]=Module["asm"]["Z"]).apply(null,arguments)};var dynCall_vij=Module["dynCall_vij"]=function(){return(dynCall_vij=Module["dynCall_vij"]=Module["asm"]["_"]).apply(null,arguments)};var dynCall_iij=Module["dynCall_iij"]=function(){return(dynCall_iij=Module["dynCall_iij"]=Module["asm"]["$"]).apply(null,arguments)};var dynCall_viji=Module["dynCall_viji"]=function(){return(dynCall_viji=Module["dynCall_viji"]=Module["asm"]["aa"]).apply(null,arguments)};var dynCall_jiji=Module["dynCall_jiji"]=function(){return(dynCall_jiji=Module["dynCall_jiji"]=Module["asm"]["ba"]).apply(null,arguments)};var dynCall_viijii=Module["dynCall_viijii"]=function(){return(dynCall_viijii=Module["dynCall_viijii"]=Module["asm"]["ca"]).apply(null,arguments)};var dynCall_iiiiij=Module["dynCall_iiiiij"]=function(){return(dynCall_iiiiij=Module["dynCall_iiiiij"]=Module["asm"]["da"]).apply(null,arguments)};var dynCall_iiiiijj=Module["dynCall_iiiiijj"]=function(){return(dynCall_iiiiijj=Module["dynCall_iiiiijj"]=Module["asm"]["ea"]).apply(null,arguments)};var dynCall_iiiiiijj=Module["dynCall_iiiiiijj"]=function(){return(dynCall_iiiiiijj=Module["dynCall_iiiiiijj"]=Module["asm"]["fa"]).apply(null,arguments)};var ___start_em_js=Module["___start_em_js"]=638316;var ___stop_em_js=Module["___stop_em_js"]=638383;var calledRun;dependenciesFulfilled=function runCaller(){if(!calledRun)run();if(!calledRun)dependenciesFulfilled=runCaller};function callMain(args){var entryFunction=Module["_main"];var argc=0;var argv=0;try{var ret=entryFunction(argc,argv);exitJS(ret,true);return ret}catch(e){return handleException(e)}}function run(args){args=args||arguments_;if(runDependencies>0){return}preRun();if(runDependencies>0){return}function doRun(){if(calledRun)return;calledRun=true;Module["calledRun"]=true;if(ABORT)return;initRuntime();preMain();readyPromiseResolve(Module);if(Module["onRuntimeInitialized"])Module["onRuntimeInitialized"]();if(shouldRunNow)callMain(args);postRun()}if(Module["setStatus"]){Module["setStatus"]("Running...");setTimeout(function(){setTimeout(function(){Module["setStatus"]("")},1);doRun()},1)}else{doRun()}}if(Module["preInit"]){if(typeof Module["preInit"]=="function")Module["preInit"]=[Module["preInit"]];while(Module["preInit"].length>0){Module["preInit"].pop()()}}var shouldRunNow=true;if(Module["noInitialRun"])shouldRunNow=false;run();


  return ICRPolySegApp.ready
}
);
})();
/* harmony default export */ const dist_ICRPolySeg = (ICRPolySegApp);
;// CONCATENATED MODULE: ../../../node_modules/@icr/polyseg-wasm/dist/ICRPolySeg.wasm
const dist_ICRPolySeg_namespaceObject = __webpack_require__.p + "17dd54813d5acc10bf8f.wasm";
;// CONCATENATED MODULE: ../../../node_modules/@icr/polyseg-wasm/dist/index.js



class ICRPolySeg {
  constructor() {
    this._instance;
  }

  get instance() {
    if (this._instance) {
      return this._instance;
    }

    throw new Error('ICRPolySeg is not initialized.');
  }

  async initialize(params = {}) {
    this._instance = await dist_ICRPolySeg({
      locateFile: (f) => {
        if (f.endsWith('.wasm')) {
          return dist_ICRPolySeg_namespaceObject;
        }
        return f;
      },
      ...params
    });
  }
}

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/DataModel/Plane.js
var Plane = __webpack_require__(84441);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Common/DataModel/PolyData.js + 9 modules
var PolyData = __webpack_require__(27398);
// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/macros2.js
var macros2 = __webpack_require__(50906);
;// CONCATENATED MODULE: ../../../node_modules/@kitware/vtk.js/Filters/General/ContourLoopExtraction.js



const Dir = {
  Forward: 1,
  Backward: -1
};
const visited = new Set();
function vtkContourLoopExtraction(publicAPI, model) {
  publicAPI.requestData = (inData, outData) => {
    const [input] = inData;
    if (!outData[0]) {
      outData[0] = PolyData/* default.newInstance */.Ay.newInstance();
    }
    const [output] = outData;
    publicAPI.extractContours(input, output);
    output.modified();
  };
  publicAPI.traverseLoop = (pd, dir, startLineId, startPtId, loopPoints) => {
    let lineId = startLineId;
    let lastPtId = startPtId;
    let terminated = false;
    let numInserted = 0;
    while (!terminated) {
      const {
        cellPointIds
      } = pd.getCellPoints(lineId);
      if (!cellPointIds) {
        // eslint-disable-next-line no-continue
        continue;
      }
      lastPtId = cellPointIds[0] !== lastPtId ? cellPointIds[0] : cellPointIds[1];
      numInserted++;

      // parametric point value
      const t = dir * numInserted;
      loopPoints.push({
        t,
        ptId: lastPtId
      });
      const lineCell = pd.getPointCells(lastPtId);
      if (lineCell.length !== 2 || lastPtId === startPtId) {
        // looped
        return lastPtId;
      }
      if (lineCell.length === 2) {
        // continue along loop
        lineId = lineCell[0] !== lineId ? lineCell[0] : lineCell[1];
        visited.add(lineId);
      } else {
        // empty or invalid cell
        terminated = true;
      }
    }
    return lastPtId;
  };
  publicAPI.extractContours = (input, output) => {
    const loops = [];
    visited.clear();
    const inLines = input.getLines();
    output.getPoints().setData(Float32Array.from(input.getPoints().getData()));

    // TODO skip if cached input mtime hasn't changed.
    // iterate over input lines
    for (let li = 0; li < inLines.getNumberOfCells(); li++) {
      if (visited.has(li)) {
        // eslint-disable-next-line no-continue
        continue;
      }
      const {
        cellPointIds
      } = input.getCellPoints(li);
      if (!cellPointIds) {
        // eslint-disable-next-line no-continue
        continue;
      }
      visited.add(li);
      const startPtId = cellPointIds[0];
      const loopPoints = [];
      loopPoints.push({
        t: 0,
        ptId: startPtId
      });
      const endPtId = publicAPI.traverseLoop(input, Dir.Forward, li, startPtId, loopPoints);
      if (startPtId !== endPtId) {
        // didn't find a loop. Go other direction to see where we end up
        publicAPI.traverseLoop(input, Dir.Backward, li, startPtId, loopPoints);
        loopPoints.sort((a, b) => a.t < b.t ? -1 : 1);
        // make closed contour
        if (loopPoints.length && loopPoints[0].ptId !== loopPoints[loopPoints.length - 1]?.ptId) {
          loopPoints.push({
            ...loopPoints[loopPoints.length - 1]
          });
        }
      }
      if (loopPoints.length) {
        loops.push(loopPoints);
      }
    }

    // clear output lines
    const outLines = output.getLines();
    outLines.resize(0);
    loops.forEach(loop => {
      outLines.insertNextCell(loop.map(pt => pt.ptId));
    });
  };
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);
  macros2.m.obj(publicAPI, model);
  macros2.m.algo(publicAPI, model, 1, 1);
  vtkContourLoopExtraction(publicAPI);
}

// ----------------------------------------------------------------------------

const newInstance = macros2.m.newInstance(extend, 'vtkContourLoopExtraction');

// ----------------------------------------------------------------------------

var ContourLoopExtraction_index = {
  newInstance,
  extend
};



// EXTERNAL MODULE: ../../../node_modules/@kitware/vtk.js/Filters/Core/Cutter.js
var Cutter = __webpack_require__(64976);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/boundingBox/index.js
var boundingBox = __webpack_require__(15306);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/index.js + 1 modules
var utilities = __webpack_require__(74119);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/math/polyline/index.js + 23 modules
var math_polyline = __webpack_require__(56634);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/utilities/planar/index.js
var planar = __webpack_require__(84797);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/workers/polySegConverters.js













const polySegConverters = {
    polySeg: null,
    polySegInitializing: false,
    polySegInitializingPromise: null,
    async initializePolySeg(progressCallback) {
        if (this.polySegInitializing) {
            await this.polySegInitializingPromise;
            return;
        }
        if (this.polySeg?.instance) {
            return;
        }
        this.polySegInitializing = true;
        this.polySegInitializingPromise = new Promise((resolve) => {
            this.polySeg = new ICRPolySeg();
            this.polySeg
                .initialize({
                updateProgress: progressCallback,
            })
                .then(() => {
                this.polySegInitializing = false;
                resolve();
            });
        });
        await this.polySegInitializingPromise;
    },
    async convertContourToSurface(args, ...callbacks) {
        const { polylines, numPointsArray } = args;
        const [progressCallback] = callbacks;
        await this.initializePolySeg(progressCallback);
        const results = await this.polySeg.instance.convertContourRoiToSurface(polylines, numPointsArray);
        return results;
    },
    async convertLabelmapToSurface(args, ...callbacks) {
        const [progressCallback] = callbacks;
        await this.initializePolySeg(progressCallback);
        const results = this.polySeg.instance.convertLabelmapToSurface(args.scalarData, args.dimensions, args.spacing, args.direction, args.origin, [args.segmentIndex]);
        return results;
    },
    async convertContourToVolumeLabelmap(args, ...callbacks) {
        const [progressCallback] = callbacks;
        const polySeg = await new ICRPolySeg();
        await polySeg.initialize({
            updateProgress: progressCallback,
        });
        const { segmentIndices, scalarData, annotationUIDsInSegmentMap, dimensions, origin, direction, spacing, } = args;
        const segmentationVoxelManager = esm.utilities.VoxelManager.createVolumeVoxelManager(dimensions, scalarData);
        const imageData = ImageData/* default.newInstance */.Ay.newInstance();
        imageData.setDimensions(dimensions);
        imageData.setOrigin(origin);
        imageData.setDirection(direction);
        imageData.setSpacing(spacing);
        const scalarArray = DataArray/* default.newInstance */.Ay.newInstance({
            name: 'Pixels',
            numberOfComponents: 1,
            values: scalarData,
        });
        imageData.getPointData().setScalars(scalarArray);
        imageData.modified();
        for (const index of segmentIndices) {
            const annotations = annotationUIDsInSegmentMap.get(index);
            for (const annotation of annotations) {
                if (!annotation.polyline) {
                    continue;
                }
                const { polyline, holesPolyline } = annotation;
                const bounds = (0,boundingBox.getBoundingBoxAroundShapeWorld)(polyline);
                const [iMin, jMin, kMin] = esm.utilities.transformWorldToIndex(imageData, [
                    bounds[0][0],
                    bounds[1][0],
                    bounds[2][0],
                ]);
                const [iMax, jMax, kMax] = esm.utilities.transformWorldToIndex(imageData, [
                    bounds[0][1],
                    bounds[1][1],
                    bounds[2][1],
                ]);
                const { projectedPolyline, sharedDimensionIndex } = (0,math_polyline.projectTo2D)(polyline);
                const holes = holesPolyline?.map((hole) => {
                    const { projectedPolyline: projectedHole } = (0,math_polyline.projectTo2D)(hole);
                    return projectedHole;
                });
                const firstDim = (sharedDimensionIndex + 1) % 3;
                const secondDim = (sharedDimensionIndex + 2) % 3;
                (0,utilities.pointInShapeCallback)(imageData, (pointLPS) => {
                    const point2D = [pointLPS[firstDim], pointLPS[secondDim]];
                    const isInside = (0,math_polyline.containsPoint)(projectedPolyline, point2D, {
                        holes,
                    });
                    return isInside;
                }, ({ pointIJK }) => {
                    segmentationVoxelManager.setAtIJKPoint(pointIJK, index);
                }, [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ]);
            }
        }
        return segmentationVoxelManager.scalarData;
    },
    async convertContourToStackLabelmap(args, ...callbacks) {
        const [progressCallback] = callbacks;
        const polySeg = await new ICRPolySeg();
        await polySeg.initialize({
            updateProgress: progressCallback,
        });
        const { segmentationsInfo, annotationUIDsInSegmentMap, segmentIndices } = args;
        const segmentationVoxelManagers = new Map();
        segmentationsInfo.forEach((segmentationInfo, referencedImageId) => {
            const { dimensions, scalarData, direction, spacing, origin } = segmentationInfo;
            const manager = esm.utilities.VoxelManager.createVolumeVoxelManager(dimensions, scalarData);
            const imageData = ImageData/* default.newInstance */.Ay.newInstance();
            imageData.setDimensions(dimensions);
            imageData.setOrigin(origin);
            imageData.setDirection(direction);
            imageData.setSpacing(spacing);
            const scalarArray = DataArray/* default.newInstance */.Ay.newInstance({
                name: 'Pixels',
                numberOfComponents: 1,
                values: scalarData,
            });
            imageData.getPointData().setScalars(scalarArray);
            imageData.modified();
            segmentationVoxelManagers.set(referencedImageId, { manager, imageData });
        });
        for (const index of segmentIndices) {
            const annotations = annotationUIDsInSegmentMap.get(index);
            for (const annotation of annotations) {
                if (!annotation.polyline) {
                    continue;
                }
                const { polyline, holesPolyline, referencedImageId } = annotation;
                const bounds = (0,boundingBox.getBoundingBoxAroundShapeWorld)(polyline);
                const { manager: segmentationVoxelManager, imageData } = segmentationVoxelManagers.get(referencedImageId);
                const [iMin, jMin, kMin] = esm.utilities.transformWorldToIndex(imageData, [
                    bounds[0][0],
                    bounds[1][0],
                    bounds[2][0],
                ]);
                const [iMax, jMax, kMax] = esm.utilities.transformWorldToIndex(imageData, [
                    bounds[0][1],
                    bounds[1][1],
                    bounds[2][1],
                ]);
                const { projectedPolyline, sharedDimensionIndex } = (0,math_polyline.projectTo2D)(polyline);
                const holes = holesPolyline?.map((hole) => {
                    const { projectedPolyline: projectedHole } = (0,math_polyline.projectTo2D)(hole);
                    return projectedHole;
                });
                const firstDim = (sharedDimensionIndex + 1) % 3;
                const secondDim = (sharedDimensionIndex + 2) % 3;
                (0,utilities.pointInShapeCallback)(imageData, (pointLPS) => {
                    const point2D = [pointLPS[firstDim], pointLPS[secondDim]];
                    const isInside = (0,math_polyline.containsPoint)(projectedPolyline, point2D, {
                        holes,
                    });
                    return isInside;
                }, ({ pointIJK }) => {
                    segmentationVoxelManager.setAtIJKPoint(pointIJK, index);
                }, [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ]);
            }
        }
        segmentationsInfo.forEach((segmentationInfo, referencedImageId) => {
            const { manager: segmentationVoxelManager } = segmentationVoxelManagers.get(referencedImageId);
            segmentationInfo.scalarData = segmentationVoxelManager.scalarData;
        });
        return segmentationsInfo;
    },
    async convertSurfaceToVolumeLabelmap(args, ...callbacks) {
        const [progressCallback] = callbacks;
        await this.initializePolySeg(progressCallback);
        const results = this.polySeg.instance.convertSurfaceToLabelmap(args.points, args.polys, args.dimensions, args.spacing, args.direction, args.origin);
        return results;
    },
    async convertSurfacesToVolumeLabelmap(args, ...callbacks) {
        const [progressCallback] = callbacks;
        await this.initializePolySeg(progressCallback);
        const { segmentsInfo } = args;
        const promises = Array.from(segmentsInfo.keys()).map((segmentIndex) => {
            const { points, polys } = segmentsInfo.get(segmentIndex);
            const result = this.polySeg.instance.convertSurfaceToLabelmap(points, polys, args.dimensions, args.spacing, args.direction, args.origin);
            return {
                ...result,
                segmentIndex,
            };
        });
        const results = await Promise.all(promises);
        const targetImageData = ImageData/* default.newInstance */.Ay.newInstance();
        targetImageData.setDimensions(args.dimensions);
        targetImageData.setOrigin(args.origin);
        targetImageData.setSpacing(args.spacing);
        targetImageData.setDirection(args.direction);
        const totalSize = args.dimensions[0] * args.dimensions[1] * args.dimensions[2];
        const scalarArray = DataArray/* default.newInstance */.Ay.newInstance({
            name: 'Pixels',
            numberOfComponents: 1,
            values: new Uint8Array(totalSize),
        });
        targetImageData.getPointData().setScalars(scalarArray);
        targetImageData.modified();
        const segmentationVoxelManager = esm.utilities.VoxelManager.createVolumeVoxelManager(args.dimensions, targetImageData.getPointData().getScalars().getData());
        const outputVolumesInfo = results.map((result) => {
            const { data, dimensions, direction, origin, spacing } = result;
            const volume = ImageData/* default.newInstance */.Ay.newInstance();
            volume.setDimensions(dimensions);
            volume.setOrigin(origin);
            volume.setSpacing(spacing);
            volume.setDirection(direction);
            const scalarArray = DataArray/* default.newInstance */.Ay.newInstance({
                name: 'Pixels',
                numberOfComponents: 1,
                values: data,
            });
            volume.getPointData().setScalars(scalarArray);
            volume.modified();
            const voxelManager = esm.utilities.VoxelManager.createVolumeVoxelManager(dimensions, data);
            const extent = volume.getExtent();
            return {
                volume,
                voxelManager,
                extent,
                scalarData: data,
                segmentIndex: result.segmentIndex,
            };
        });
        (0,utilities.pointInShapeCallback)(targetImageData, () => true, ({ pointIJK, pointLPS }) => {
            try {
                for (const volumeInfo of outputVolumesInfo) {
                    const { volume, extent, voxelManager, segmentIndex } = volumeInfo;
                    const index = volume.worldToIndex(pointLPS);
                    if (index[0] < extent[0] ||
                        index[0] > extent[1] ||
                        index[1] < extent[2] ||
                        index[1] > extent[3] ||
                        index[2] < extent[4] ||
                        index[2] > extent[5]) {
                        continue;
                    }
                    const roundedIndex = index.map(Math.round);
                    const value = voxelManager.getAtIJK(...roundedIndex);
                    if (value > 0) {
                        segmentationVoxelManager.setAtIJKPoint(pointIJK, segmentIndex);
                        break;
                    }
                }
            }
            catch (error) {
            }
        });
        return segmentationVoxelManager.scalarData;
    },
    getSurfacesAABBs({ surfacesInfo }) {
        const aabbs = new Map();
        for (const { points, id } of surfacesInfo) {
            const aabb = (0,math_polyline.getAABB)(points, { numDimensions: 3 });
            aabbs.set(id, aabb);
        }
        return aabbs;
    },
    cutSurfacesIntoPlanes({ planesInfo, surfacesInfo, surfacesAABB = new Map() }, progressCallback, updateCacheCallback) {
        const numberOfPlanes = planesInfo.length;
        const cutter = Cutter/* default.newInstance */.Ay.newInstance();
        const plane1 = Plane/* default.newInstance */.Ay.newInstance();
        cutter.setCutFunction(plane1);
        const surfacePolyData = PolyData/* default.newInstance */.Ay.newInstance();
        try {
            for (const [index, planeInfo] of planesInfo.entries()) {
                const { sliceIndex, planes } = planeInfo;
                const polyDataResults = new Map();
                for (const polyDataInfo of surfacesInfo) {
                    const { points, polys, id } = polyDataInfo;
                    const aabb3 = surfacesAABB.get(id) || (0,math_polyline.getAABB)(points, { numDimensions: 3 });
                    if (!surfacesAABB.has(id)) {
                        surfacesAABB.set(id, aabb3);
                    }
                    const { minX, minY, minZ, maxX, maxY, maxZ } = aabb3;
                    const { origin, normal } = planes[0];
                    if (!(0,planar.isPlaneIntersectingAABB)(origin, normal, minX, minY, minZ, maxX, maxY, maxZ)) {
                        continue;
                    }
                    surfacePolyData.getPoints().setData(points, 3);
                    surfacePolyData.getPolys().setData(polys, 3);
                    surfacePolyData.modified();
                    cutter.setInputData(surfacePolyData);
                    plane1.setOrigin(origin);
                    plane1.setNormal(normal);
                    try {
                        cutter.update();
                    }
                    catch (e) {
                        console.warn('Error during clipping', e);
                        continue;
                    }
                    const polyData = cutter.getOutputData();
                    const cutterOutput = polyData;
                    cutterOutput.buildLinks();
                    const loopExtraction = ContourLoopExtraction_index.newInstance();
                    loopExtraction.setInputData(cutterOutput);
                    const loopOutput = loopExtraction.getOutputData();
                    if (polyData) {
                        polyDataResults.set(id, {
                            points: loopOutput.getPoints().getData(),
                            lines: loopOutput.getLines().getData(),
                            numberOfCells: loopOutput.getLines().getNumberOfCells(),
                        });
                    }
                }
                progressCallback({ progress: (index + 1) / numberOfPlanes });
                updateCacheCallback({ sliceIndex, polyDataResults });
            }
        }
        catch (e) {
            console.warn('Error during processing', e);
        }
        finally {
            surfacesInfo = null;
            plane1.delete();
        }
    },
};
(0,comlink/* expose */.p)(polySegConverters);


/***/ }),

/***/ 51250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ay: () => (/* binding */ vtkImageData$1)
/* harmony export */ });
/* unused harmony exports extend, newInstance */
/* harmony import */ var _macros2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50906);
/* harmony import */ var _Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68680);
/* harmony import */ var _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52662);
/* harmony import */ var _DataSet_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(32090);
/* harmony import */ var _StructuredData_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(89780);
/* harmony import */ var _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13422);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(44753);








const {
  vtkErrorMacro
} = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m;

// ----------------------------------------------------------------------------
// vtkImageData methods
// ----------------------------------------------------------------------------

function vtkImageData(publicAPI, model) {
  // Set our className
  model.classHierarchy.push('vtkImageData');
  publicAPI.setExtent = function () {
    if (model.deleted) {
      vtkErrorMacro('instance deleted - cannot call any method');
      return false;
    }
    for (var _len = arguments.length, inExtent = new Array(_len), _key = 0; _key < _len; _key++) {
      inExtent[_key] = arguments[_key];
    }
    const extentArray = inExtent.length === 1 ? inExtent[0] : inExtent;
    if (extentArray.length !== 6) {
      return false;
    }
    const changeDetected = model.extent.some((item, index) => item !== extentArray[index]);
    if (changeDetected) {
      model.extent = extentArray.slice();
      model.dataDescription = _StructuredData_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"].getDataDescriptionFromExtent */ .A.getDataDescriptionFromExtent(model.extent);
      publicAPI.modified();
    }
    return changeDetected;
  };
  publicAPI.setDimensions = function () {
    let i;
    let j;
    let k;
    if (model.deleted) {
      vtkErrorMacro('instance deleted - cannot call any method');
      return;
    }
    if (arguments.length === 1) {
      const array = arguments.length <= 0 ? undefined : arguments[0];
      i = array[0];
      j = array[1];
      k = array[2];
    } else if (arguments.length === 3) {
      i = arguments.length <= 0 ? undefined : arguments[0];
      j = arguments.length <= 1 ? undefined : arguments[1];
      k = arguments.length <= 2 ? undefined : arguments[2];
    } else {
      vtkErrorMacro('Bad dimension specification');
      return;
    }
    publicAPI.setExtent(0, i - 1, 0, j - 1, 0, k - 1);
  };
  publicAPI.getDimensions = () => [model.extent[1] - model.extent[0] + 1, model.extent[3] - model.extent[2] + 1, model.extent[5] - model.extent[4] + 1];
  publicAPI.getNumberOfCells = () => {
    const dims = publicAPI.getDimensions();
    let nCells = 1;
    for (let i = 0; i < 3; i++) {
      if (dims[i] === 0) {
        return 0;
      }
      if (dims[i] > 1) {
        nCells *= dims[i] - 1;
      }
    }
    return nCells;
  };
  publicAPI.getNumberOfPoints = () => {
    const dims = publicAPI.getDimensions();
    return dims[0] * dims[1] * dims[2];
  };
  publicAPI.getPoint = index => {
    const dims = publicAPI.getDimensions();
    if (dims[0] === 0 || dims[1] === 0 || dims[2] === 0) {
      vtkErrorMacro('Requesting a point from an empty image.');
      return null;
    }
    const ijk = new Float64Array(3);
    switch (model.dataDescription) {
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.EMPTY:
        return null;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.SINGLE_POINT:
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.X_LINE:
        ijk[0] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.Y_LINE:
        ijk[1] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.Z_LINE:
        ijk[2] = index;
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XY_PLANE:
        ijk[0] = index % dims[0];
        ijk[1] = index / dims[0];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.YZ_PLANE:
        ijk[1] = index % dims[1];
        ijk[2] = index / dims[1];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XZ_PLANE:
        ijk[0] = index % dims[0];
        ijk[2] = index / dims[0];
        break;
      case _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.XYZ_GRID:
        ijk[0] = index % dims[0];
        ijk[1] = index / dims[0] % dims[1];
        ijk[2] = index / (dims[0] * dims[1]);
        break;
      default:
        vtkErrorMacro('Invalid dataDescription');
        break;
    }
    const coords = [0, 0, 0];
    publicAPI.indexToWorld(ijk, coords);
    return coords;
  };

  // vtkCell *GetCell(vtkIdType cellId) VTK_OVERRIDE;
  // void GetCell(vtkIdType cellId, vtkGenericCell *cell) VTK_OVERRIDE;
  // void GetCellBounds(vtkIdType cellId, double bounds[6]) VTK_OVERRIDE;
  // virtual vtkIdType FindPoint(double x, double y, double z)
  // {
  //   return this->vtkDataSet::FindPoint(x, y, z);
  // }
  // vtkIdType FindPoint(double x[3]) VTK_OVERRIDE;
  // vtkIdType FindCell(
  //   double x[3], vtkCell *cell, vtkIdType cellId, double tol2,
  //   int& subId, double pcoords[3], double *weights) VTK_OVERRIDE;
  // vtkIdType FindCell(
  //   double x[3], vtkCell *cell, vtkGenericCell *gencell,
  //   vtkIdType cellId, double tol2, int& subId,
  //   double pcoords[3], double *weights) VTK_OVERRIDE;
  // vtkCell *FindAndGetCell(double x[3], vtkCell *cell, vtkIdType cellId,
  //                                 double tol2, int& subId, double pcoords[3],
  //                                 double *weights) VTK_OVERRIDE;
  // int GetCellType(vtkIdType cellId) VTK_OVERRIDE;
  // void GetCellPoints(vtkIdType cellId, vtkIdList *ptIds) VTK_OVERRIDE
  //   {vtkStructuredData::GetCellPoints(cellId,ptIds,this->DataDescription,
  //                                     this->GetDimensions());}
  // void GetPointCells(vtkIdType ptId, vtkIdList *cellIds) VTK_OVERRIDE
  //   {vtkStructuredData::GetPointCells(ptId,cellIds,this->GetDimensions());}
  // void ComputeBounds() VTK_OVERRIDE;
  // int GetMaxCellSize() VTK_OVERRIDE {return 8;}; //voxel is the largest

  publicAPI.getBounds = () => publicAPI.extentToBounds(publicAPI.getSpatialExtent());
  publicAPI.extentToBounds = ex => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(ex, model.indexToWorld);
  publicAPI.getSpatialExtent = () => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].inflate */ .Ay.inflate([...model.extent], 0.5);

  // Internal, shouldn't need to call this manually.
  publicAPI.computeTransforms = () => {
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.fromTranslation */ .pB.fromTranslation(model.indexToWorld, model.origin);
    model.indexToWorld[0] = model.direction[0];
    model.indexToWorld[1] = model.direction[1];
    model.indexToWorld[2] = model.direction[2];
    model.indexToWorld[4] = model.direction[3];
    model.indexToWorld[5] = model.direction[4];
    model.indexToWorld[6] = model.direction[5];
    model.indexToWorld[8] = model.direction[6];
    model.indexToWorld[9] = model.direction[7];
    model.indexToWorld[10] = model.direction[8];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.scale */ .pB.scale(model.indexToWorld, model.indexToWorld, model.spacing);
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat4.invert */ .pB.invert(model.worldToIndex, model.indexToWorld);
  };
  publicAPI.indexToWorld = function (ain) {
    let aout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .vec3.transformMat4 */ .eR.transformMat4(aout, ain, model.indexToWorld);
    return aout;
  };
  publicAPI.indexToWorldVec3 = publicAPI.indexToWorld;
  publicAPI.worldToIndex = function (ain) {
    let aout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .vec3.transformMat4 */ .eR.transformMat4(aout, ain, model.worldToIndex);
    return aout;
  };
  publicAPI.worldToIndexVec3 = publicAPI.worldToIndex;
  publicAPI.indexToWorldBounds = function (bin) {
    let bout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    return _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(bin, model.indexToWorld, bout);
  };
  publicAPI.worldToIndexBounds = function (bin) {
    let bout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
    return _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].transformBounds */ .Ay.transformBounds(bin, model.worldToIndex, bout);
  };

  // Make sure the transform is correct
  publicAPI.onModified(publicAPI.computeTransforms);
  publicAPI.computeTransforms();
  publicAPI.getCenter = () => _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getCenter */ .Ay.getCenter(publicAPI.getBounds());
  publicAPI.computeHistogram = function (worldBounds) {
    let voxelFunc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    const bounds = [0, 0, 0, 0, 0, 0];
    publicAPI.worldToIndexBounds(worldBounds, bounds);
    const point1 = [0, 0, 0];
    const point2 = [0, 0, 0];
    _BoundingBox_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"].computeCornerPoints */ .Ay.computeCornerPoints(bounds, point1, point2);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.b)(point1, point1);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.b)(point2, point2);
    const dimensions = publicAPI.getDimensions();
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.c)(point1, [0, 0, 0], [dimensions[0] - 1, dimensions[1] - 1, dimensions[2] - 1], point1);
    (0,_Core_Math_index_js__WEBPACK_IMPORTED_MODULE_1__.c)(point2, [0, 0, 0], [dimensions[0] - 1, dimensions[1] - 1, dimensions[2] - 1], point2);
    const yStride = dimensions[0];
    const zStride = dimensions[0] * dimensions[1];
    const pixels = publicAPI.getPointData().getScalars().getData();
    let maximum = -Infinity;
    let minimum = Infinity;
    let sumOfSquares = 0;
    let isum = 0;
    let inum = 0;
    for (let z = point1[2]; z <= point2[2]; z++) {
      for (let y = point1[1]; y <= point2[1]; y++) {
        let index = point1[0] + y * yStride + z * zStride;
        for (let x = point1[0]; x <= point2[0]; x++) {
          if (!voxelFunc || voxelFunc([x, y, z], bounds)) {
            const pixel = pixels[index];
            if (pixel > maximum) maximum = pixel;
            if (pixel < minimum) minimum = pixel;
            sumOfSquares += pixel * pixel;
            isum += pixel;
            inum += 1;
          }
          ++index;
        }
      }
    }
    const average = inum > 0 ? isum / inum : 0;
    const variance = inum ? Math.abs(sumOfSquares / inum - average * average) : 0;
    const sigma = Math.sqrt(variance);
    return {
      minimum,
      maximum,
      average,
      variance,
      sigma,
      count: inum
    };
  };

  // TODO: use the unimplemented `vtkDataSetAttributes` for scalar length, that is currently also a TODO (GetNumberOfComponents).
  // Scalar data could be tuples for color information?
  publicAPI.computeIncrements = function (extent) {
    let numberOfComponents = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    const increments = [];
    let incr = numberOfComponents;

    // Calculate array increment offsets
    // similar to c++ vtkImageData::ComputeIncrements
    for (let idx = 0; idx < 3; ++idx) {
      increments[idx] = incr;
      incr *= extent[idx * 2 + 1] - extent[idx * 2] + 1;
    }
    return increments;
  };

  /**
   * @param {Number[]} index the localized `[i,j,k]` pixel array position. Float values will be rounded.
   * @return {Number} the corresponding flattened index in the scalar array
   */
  publicAPI.computeOffsetIndex = _ref => {
    let [i, j, k] = _ref;
    const extent = publicAPI.getExtent();
    const numberOfComponents = publicAPI.getPointData().getScalars().getNumberOfComponents();
    const increments = publicAPI.computeIncrements(extent, numberOfComponents);
    // Use the array increments to find the pixel index
    // similar to c++ vtkImageData::GetArrayPointer
    // Math.floor to catch "practically 0" e^-15 scenarios.
    return Math.floor((Math.round(i) - extent[0]) * increments[0] + (Math.round(j) - extent[2]) * increments[1] + (Math.round(k) - extent[4]) * increments[2]);
  };

  /**
   * @param {Number[]} xyz the [x,y,z] Array in world coordinates
   * @return {Number|NaN} the corresponding pixel's index in the scalar array
   */
  publicAPI.getOffsetIndexFromWorld = xyz => {
    const extent = publicAPI.getExtent();
    const index = publicAPI.worldToIndex(xyz);

    // Confirm indexed i,j,k coords are within the bounds of the volume
    for (let idx = 0; idx < 3; ++idx) {
      if (index[idx] < extent[idx * 2] || index[idx] > extent[idx * 2 + 1]) {
        vtkErrorMacro(`GetScalarPointer: Pixel ${index} is not in memory. Current extent = ${extent}`);
        return NaN;
      }
    }

    // Assumed the index here is within 0 <-> scalarData.length, but doesn't hurt to check upstream
    return publicAPI.computeOffsetIndex(index);
  };
  /**
   * @param {Number[]} xyz the [x,y,z] Array in world coordinates
   * @param {Number?} comp the scalar component index for multi-component scalars
   * @return {Number|NaN} the corresponding pixel's scalar value
   */
  publicAPI.getScalarValueFromWorld = function (xyz) {
    let comp = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    const numberOfComponents = publicAPI.getPointData().getScalars().getNumberOfComponents();
    if (comp < 0 || comp >= numberOfComponents) {
      vtkErrorMacro(`GetScalarPointer: Scalar Component ${comp} is not within bounds. Current Scalar numberOfComponents: ${numberOfComponents}`);
      return NaN;
    }
    const offsetIndex = publicAPI.getOffsetIndexFromWorld(xyz);
    if (Number.isNaN(offsetIndex)) {
      // VTK Error Macro will have been tripped already, no need to do it again,
      return offsetIndex;
    }
    return publicAPI.getPointData().getScalars().getComponent(offsetIndex, comp);
  };
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {
  direction: null,
  // a mat3
  indexToWorld: null,
  // a mat4
  worldToIndex: null,
  // a mat4
  spacing: [1.0, 1.0, 1.0],
  origin: [0.0, 0.0, 0.0],
  extent: [0, -1, 0, -1, 0, -1],
  dataDescription: _StructuredData_Constants_js__WEBPACK_IMPORTED_MODULE_5__/* .StructuredType */ .e.EMPTY
};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);

  // Inheritance
  _DataSet_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"].extend */ .Ay.extend(publicAPI, model, initialValues);
  if (!model.direction) {
    model.direction = gl_matrix__WEBPACK_IMPORTED_MODULE_6__/* .mat3.identity */ .w0.identity(new Float64Array(9));
  } else if (Array.isArray(model.direction)) {
    model.direction = new Float64Array(model.direction.slice(0, 9));
  }
  model.indexToWorld = new Float64Array(16);
  model.worldToIndex = new Float64Array(16);

  // Set/Get methods
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.get(publicAPI, model, ['indexToWorld', 'worldToIndex']);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGetArray(publicAPI, model, ['origin', 'spacing'], 3);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGetArray(publicAPI, model, ['direction'], 9);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.getArray(publicAPI, model, ['extent'], 6);

  // Object specific methods
  vtkImageData(publicAPI, model);
}

// ----------------------------------------------------------------------------

const newInstance = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.newInstance(extend, 'vtkImageData');

// ----------------------------------------------------------------------------

var vtkImageData$1 = {
  newInstance,
  extend
};




/***/ }),

/***/ 52754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports default, extend, newInstance */
/* harmony import */ var _macros2_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(50906);
/* harmony import */ var _Common_DataModel_PolyData_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27398);
/* harmony import */ var _Common_DataModel_EdgeLocator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23410);
/* harmony import */ var _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68749);





const {
  vtkErrorMacro,
  vtkDebugMacro
} = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m;

// ----------------------------------------------------------------------------
// vtkImageMarchingSquares methods
// ----------------------------------------------------------------------------

function vtkImageMarchingSquares(publicAPI, model) {
  /**
   * Get the X,Y kernels based on the set slicing mode.
   * @returns {[number, number]}
   */
  function getKernels() {
    let kernelX = 0; // default K slicing mode
    let kernelY = 1;
    if (model.slicingMode === 1) {
      kernelX = 0;
      kernelY = 2;
    } else if (model.slicingMode === 0) {
      kernelX = 1;
      kernelY = 2;
    }
    return [kernelX, kernelY];
  }

  // Set our className
  model.classHierarchy.push('vtkImageMarchingSquares');

  /**
   * Get the list of contour values.
   * @returns {number[]}
   */
  publicAPI.getContourValues = () => model.contourValues;

  /**
   * Set the list contour values.
   * @param {number[]} cValues
   */
  publicAPI.setContourValues = cValues => {
    model.contourValues = cValues;
    publicAPI.modified();
  };
  const ids = [];
  const pixelScalars = [];
  const pixelPts = [];
  const edgeLocator = _Common_DataModel_EdgeLocator_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.newInstance();

  /**
   * Retrieve scalars and pixel coordinates.
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} dims dimensions of the image
   * @param {TypedArray} scalars list of scalar values
   * @param {Vector3} increments IJK slice increments
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.getPixelScalars = (ijk, dims, scalars, increments, kernelX, kernelY) => {
    const [i, j, k] = ijk;

    // First get the indices for the pixel
    ids[0] = k * dims[1] * dims[0] + j * dims[0] + i; // i, j, k
    ids[1] = ids[0] + increments[kernelX]; // i+1, j, k
    ids[2] = ids[0] + increments[kernelY]; // i, j+1, k
    ids[3] = ids[2] + increments[kernelX]; // i+1, j+1, k

    // Now retrieve the scalars
    for (let ii = 0; ii < 4; ++ii) {
      pixelScalars[ii] = scalars[ids[ii]];
    }
  };

  /**
   * Retrieve pixel coordinates.
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} origin origin of the image
   * @param {Vector3} spacing spacing of the image
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.getPixelPoints = (ijk, origin, spacing, kernelX, kernelY) => {
    const i = ijk[kernelX];
    const j = ijk[kernelY];

    // (i,i+1),(j,j+1),(k,k+1) - i varies fastest; then j; then k
    pixelPts[0] = origin[kernelX] + i * spacing[kernelX]; // 0
    pixelPts[1] = origin[kernelY] + j * spacing[kernelY];
    pixelPts[2] = pixelPts[0] + spacing[kernelX]; // 1
    pixelPts[3] = pixelPts[1];
    pixelPts[4] = pixelPts[0]; // 2
    pixelPts[5] = pixelPts[1] + spacing[kernelY];
    pixelPts[6] = pixelPts[2]; // 3
    pixelPts[7] = pixelPts[5];
  };

  /**
   * Produce points and lines for the polydata.
   * @param {number[]} cVal list of contour values
   * @param {Vector3} ijk origin of the pixel
   * @param {Vector3} dims dimensions of the image
   * @param {Vector3} origin origin of the image
   * @param {Vector3} spacing sapcing of the image
   * @param {TypedArray} scalars list of scalar values
   * @param {number[]} points list of points
   * @param {number[]} lines list of lines
   * @param {Vector3} increments IJK slice increments
   * @param {number} kernelX index of the X element
   * @param {number} kernelY index of the Y element
   */
  publicAPI.produceLines = (cVal, ijk, dims, origin, spacing, scalars, points, lines, increments, kernelX, kernelY) => {
    const k = ijk[model.slicingMode];
    const CASE_MASK = [1, 2, 8, 4]; // case table is actually for quad
    const xyz = [];
    let pId;
    publicAPI.getPixelScalars(ijk, dims, scalars, increments, kernelX, kernelY);
    let index = 0;
    for (let idx = 0; idx < 4; idx++) {
      if (pixelScalars[idx] >= cVal) {
        index |= CASE_MASK[idx]; // eslint-disable-line no-bitwise
      }
    }

    const pixelLines = _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.getCase(index);
    if (pixelLines[0] < 0) {
      return; // don't get the pixel coordinates, nothing to do
    }

    publicAPI.getPixelPoints(ijk, origin, spacing, kernelX, kernelY);
    const z = origin[model.slicingMode] + k * spacing[model.slicingMode];
    for (let idx = 0; pixelLines[idx] >= 0; idx += 2) {
      lines.push(2);
      for (let eid = 0; eid < 2; eid++) {
        const edgeVerts = _ImageMarchingSquares_caseTable_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.getEdge(pixelLines[idx + eid]);
        pId = undefined;
        if (model.mergePoints) {
          pId = edgeLocator.isInsertedEdge(ids[edgeVerts[0]], ids[edgeVerts[1]])?.value;
        }
        if (pId === undefined) {
          const t = (cVal - pixelScalars[edgeVerts[0]]) / (pixelScalars[edgeVerts[1]] - pixelScalars[edgeVerts[0]]);
          const x0 = pixelPts.slice(edgeVerts[0] * 2, (edgeVerts[0] + 1) * 2);
          const x1 = pixelPts.slice(edgeVerts[1] * 2, (edgeVerts[1] + 1) * 2);
          xyz[kernelX] = x0[0] + t * (x1[0] - x0[0]);
          xyz[kernelY] = x0[1] + t * (x1[1] - x0[1]);
          xyz[model.slicingMode] = z;
          pId = points.length / 3;
          points.push(xyz[0], xyz[1], xyz[2]);
          if (model.mergePoints) {
            edgeLocator.insertEdge(ids[edgeVerts[0]], ids[edgeVerts[1]], pId);
          }
        }
        lines.push(pId);
      }
    }
  };
  publicAPI.requestData = (inData, outData) => {
    // implement requestData
    const input = inData[0];
    if (!input) {
      vtkErrorMacro('Invalid or missing input');
      return;
    }
    if (model.slicingMode == null || model.slicingMode < 0 || model.slicingMode > 2) {
      vtkErrorMacro('Invalid or missing slicing mode');
      return;
    }
    console.time('msquares');

    // Retrieve output and volume data
    const origin = input.getOrigin();
    const spacing = input.getSpacing();
    const dims = input.getDimensions();
    const extent = input.getExtent();
    const increments = input.computeIncrements(extent);
    const scalars = input.getPointData().getScalars().getData();
    const [kernelX, kernelY] = getKernels();

    // Points - dynamic array
    const points = [];

    // Cells - dynamic array
    const lines = [];

    // Ensure slice is valid
    let k = Math.round(model.slice);
    if (k >= dims[model.slicingMode]) {
      k = 0;
    }

    // Loop over all contour values, and then pixels, determine case and process
    const ijk = [0, 0, 0];
    ijk[model.slicingMode] = k;
    for (let cv = 0; cv < model.contourValues.length; ++cv) {
      for (let j = 0; j < dims[kernelY] - 1; ++j) {
        ijk[kernelY] = j;
        for (let i = 0; i < dims[kernelX] - 1; ++i) {
          ijk[kernelX] = i;
          publicAPI.produceLines(model.contourValues[cv], ijk, dims, origin, spacing, scalars, points, lines, increments, kernelX, kernelY);
        }
      }
      edgeLocator.initialize();
    }

    // Update output
    const polydata = _Common_DataModel_PolyData_js__WEBPACK_IMPORTED_MODULE_1__/* ["default"].newInstance */ .Ay.newInstance();
    polydata.getPoints().setData(new Float32Array(points), 3);
    polydata.getLines().setData(new Uint32Array(lines));
    outData[0] = polydata;
    vtkDebugMacro('Produced output');
    console.timeEnd('msquares');
  };
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {
  contourValues: [],
  slicingMode: 2,
  slice: 0,
  mergePoints: false
};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);

  // Make this a VTK object
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.obj(publicAPI, model);

  // Also make it an algorithm with one input and one output
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.algo(publicAPI, model, 1, 1);
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.setGet(publicAPI, model, ['slicingMode', 'slice', 'mergePoints']);

  // Object specific methods
  _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.algo(publicAPI, model, 1, 1);
  vtkImageMarchingSquares(publicAPI, model);
}

// ----------------------------------------------------------------------------

const newInstance = _macros2_js__WEBPACK_IMPORTED_MODULE_0__.m.newInstance(extend, 'vtkImageMarchingSquares');

// ----------------------------------------------------------------------------

var vtkImageMarchingSquares$1 = {
  newInstance,
  extend
};




/***/ }),

/***/ 99178:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A2: () => (/* binding */ releaseProxy),
/* harmony export */   BX: () => (/* binding */ proxy),
/* harmony export */   LV: () => (/* binding */ wrap),
/* harmony export */   p: () => (/* binding */ expose)
/* harmony export */ });
/* unused harmony exports createEndpoint, finalizer, proxyMarker, transfer, transferHandlers, windowEndpoint */
/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const proxyMarker = Symbol("Comlink.proxy");
const createEndpoint = Symbol("Comlink.endpoint");
const releaseProxy = Symbol("Comlink.releaseProxy");
const finalizer = Symbol("Comlink.finalizer");
const throwMarker = Symbol("Comlink.thrown");
const isObject = (val) => (typeof val === "object" && val !== null) || typeof val === "function";
/**
 * Internal transfer handle to handle objects marked to proxy.
 */
const proxyTransferHandler = {
    canHandle: (val) => isObject(val) && val[proxyMarker],
    serialize(obj) {
        const { port1, port2 } = new MessageChannel();
        expose(obj, port1);
        return [port2, [port2]];
    },
    deserialize(port) {
        port.start();
        return wrap(port);
    },
};
/**
 * Internal transfer handler to handle thrown exceptions.
 */
const throwTransferHandler = {
    canHandle: (value) => isObject(value) && throwMarker in value,
    serialize({ value }) {
        let serialized;
        if (value instanceof Error) {
            serialized = {
                isError: true,
                value: {
                    message: value.message,
                    name: value.name,
                    stack: value.stack,
                },
            };
        }
        else {
            serialized = { isError: false, value };
        }
        return [serialized, []];
    },
    deserialize(serialized) {
        if (serialized.isError) {
            throw Object.assign(new Error(serialized.value.message), serialized.value);
        }
        throw serialized.value;
    },
};
/**
 * Allows customizing the serialization of certain values.
 */
const transferHandlers = new Map([
    ["proxy", proxyTransferHandler],
    ["throw", throwTransferHandler],
]);
function isAllowedOrigin(allowedOrigins, origin) {
    for (const allowedOrigin of allowedOrigins) {
        if (origin === allowedOrigin || allowedOrigin === "*") {
            return true;
        }
        if (allowedOrigin instanceof RegExp && allowedOrigin.test(origin)) {
            return true;
        }
    }
    return false;
}
function expose(obj, ep = globalThis, allowedOrigins = ["*"]) {
    ep.addEventListener("message", function callback(ev) {
        if (!ev || !ev.data) {
            return;
        }
        if (!isAllowedOrigin(allowedOrigins, ev.origin)) {
            console.warn(`Invalid origin '${ev.origin}' for comlink proxy`);
            return;
        }
        const { id, type, path } = Object.assign({ path: [] }, ev.data);
        const argumentList = (ev.data.argumentList || []).map(fromWireValue);
        let returnValue;
        try {
            const parent = path.slice(0, -1).reduce((obj, prop) => obj[prop], obj);
            const rawValue = path.reduce((obj, prop) => obj[prop], obj);
            switch (type) {
                case "GET" /* MessageType.GET */:
                    {
                        returnValue = rawValue;
                    }
                    break;
                case "SET" /* MessageType.SET */:
                    {
                        parent[path.slice(-1)[0]] = fromWireValue(ev.data.value);
                        returnValue = true;
                    }
                    break;
                case "APPLY" /* MessageType.APPLY */:
                    {
                        returnValue = rawValue.apply(parent, argumentList);
                    }
                    break;
                case "CONSTRUCT" /* MessageType.CONSTRUCT */:
                    {
                        const value = new rawValue(...argumentList);
                        returnValue = proxy(value);
                    }
                    break;
                case "ENDPOINT" /* MessageType.ENDPOINT */:
                    {
                        const { port1, port2 } = new MessageChannel();
                        expose(obj, port2);
                        returnValue = transfer(port1, [port1]);
                    }
                    break;
                case "RELEASE" /* MessageType.RELEASE */:
                    {
                        returnValue = undefined;
                    }
                    break;
                default:
                    return;
            }
        }
        catch (value) {
            returnValue = { value, [throwMarker]: 0 };
        }
        Promise.resolve(returnValue)
            .catch((value) => {
            return { value, [throwMarker]: 0 };
        })
            .then((returnValue) => {
            const [wireValue, transferables] = toWireValue(returnValue);
            ep.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
            if (type === "RELEASE" /* MessageType.RELEASE */) {
                // detach and deactive after sending release response above.
                ep.removeEventListener("message", callback);
                closeEndPoint(ep);
                if (finalizer in obj && typeof obj[finalizer] === "function") {
                    obj[finalizer]();
                }
            }
        })
            .catch((error) => {
            // Send Serialization Error To Caller
            const [wireValue, transferables] = toWireValue({
                value: new TypeError("Unserializable return value"),
                [throwMarker]: 0,
            });
            ep.postMessage(Object.assign(Object.assign({}, wireValue), { id }), transferables);
        });
    });
    if (ep.start) {
        ep.start();
    }
}
function isMessagePort(endpoint) {
    return endpoint.constructor.name === "MessagePort";
}
function closeEndPoint(endpoint) {
    if (isMessagePort(endpoint))
        endpoint.close();
}
function wrap(ep, target) {
    return createProxy(ep, [], target);
}
function throwIfProxyReleased(isReleased) {
    if (isReleased) {
        throw new Error("Proxy has been released and is not useable");
    }
}
function releaseEndpoint(ep) {
    return requestResponseMessage(ep, {
        type: "RELEASE" /* MessageType.RELEASE */,
    }).then(() => {
        closeEndPoint(ep);
    });
}
const proxyCounter = new WeakMap();
const proxyFinalizers = "FinalizationRegistry" in globalThis &&
    new FinalizationRegistry((ep) => {
        const newCount = (proxyCounter.get(ep) || 0) - 1;
        proxyCounter.set(ep, newCount);
        if (newCount === 0) {
            releaseEndpoint(ep);
        }
    });
function registerProxy(proxy, ep) {
    const newCount = (proxyCounter.get(ep) || 0) + 1;
    proxyCounter.set(ep, newCount);
    if (proxyFinalizers) {
        proxyFinalizers.register(proxy, ep, proxy);
    }
}
function unregisterProxy(proxy) {
    if (proxyFinalizers) {
        proxyFinalizers.unregister(proxy);
    }
}
function createProxy(ep, path = [], target = function () { }) {
    let isProxyReleased = false;
    const proxy = new Proxy(target, {
        get(_target, prop) {
            throwIfProxyReleased(isProxyReleased);
            if (prop === releaseProxy) {
                return () => {
                    unregisterProxy(proxy);
                    releaseEndpoint(ep);
                    isProxyReleased = true;
                };
            }
            if (prop === "then") {
                if (path.length === 0) {
                    return { then: () => proxy };
                }
                const r = requestResponseMessage(ep, {
                    type: "GET" /* MessageType.GET */,
                    path: path.map((p) => p.toString()),
                }).then(fromWireValue);
                return r.then.bind(r);
            }
            return createProxy(ep, [...path, prop]);
        },
        set(_target, prop, rawValue) {
            throwIfProxyReleased(isProxyReleased);
            // FIXME: ES6 Proxy Handler `set` methods are supposed to return a
            // boolean. To show good will, we return true asynchronously ¯\_(ツ)_/¯
            const [value, transferables] = toWireValue(rawValue);
            return requestResponseMessage(ep, {
                type: "SET" /* MessageType.SET */,
                path: [...path, prop].map((p) => p.toString()),
                value,
            }, transferables).then(fromWireValue);
        },
        apply(_target, _thisArg, rawArgumentList) {
            throwIfProxyReleased(isProxyReleased);
            const last = path[path.length - 1];
            if (last === createEndpoint) {
                return requestResponseMessage(ep, {
                    type: "ENDPOINT" /* MessageType.ENDPOINT */,
                }).then(fromWireValue);
            }
            // We just pretend that `bind()` didn’t happen.
            if (last === "bind") {
                return createProxy(ep, path.slice(0, -1));
            }
            const [argumentList, transferables] = processArguments(rawArgumentList);
            return requestResponseMessage(ep, {
                type: "APPLY" /* MessageType.APPLY */,
                path: path.map((p) => p.toString()),
                argumentList,
            }, transferables).then(fromWireValue);
        },
        construct(_target, rawArgumentList) {
            throwIfProxyReleased(isProxyReleased);
            const [argumentList, transferables] = processArguments(rawArgumentList);
            return requestResponseMessage(ep, {
                type: "CONSTRUCT" /* MessageType.CONSTRUCT */,
                path: path.map((p) => p.toString()),
                argumentList,
            }, transferables).then(fromWireValue);
        },
    });
    registerProxy(proxy, ep);
    return proxy;
}
function myFlat(arr) {
    return Array.prototype.concat.apply([], arr);
}
function processArguments(argumentList) {
    const processed = argumentList.map(toWireValue);
    return [processed.map((v) => v[0]), myFlat(processed.map((v) => v[1]))];
}
const transferCache = new WeakMap();
function transfer(obj, transfers) {
    transferCache.set(obj, transfers);
    return obj;
}
function proxy(obj) {
    return Object.assign(obj, { [proxyMarker]: true });
}
function windowEndpoint(w, context = globalThis, targetOrigin = "*") {
    return {
        postMessage: (msg, transferables) => w.postMessage(msg, targetOrigin, transferables),
        addEventListener: context.addEventListener.bind(context),
        removeEventListener: context.removeEventListener.bind(context),
    };
}
function toWireValue(value) {
    for (const [name, handler] of transferHandlers) {
        if (handler.canHandle(value)) {
            const [serializedValue, transferables] = handler.serialize(value);
            return [
                {
                    type: "HANDLER" /* WireValueType.HANDLER */,
                    name,
                    value: serializedValue,
                },
                transferables,
            ];
        }
    }
    return [
        {
            type: "RAW" /* WireValueType.RAW */,
            value,
        },
        transferCache.get(value) || [],
    ];
}
function fromWireValue(value) {
    switch (value.type) {
        case "HANDLER" /* WireValueType.HANDLER */:
            return transferHandlers.get(value.name).deserialize(value.value);
        case "RAW" /* WireValueType.RAW */:
            return value.value;
    }
}
function requestResponseMessage(ep, msg, transfers) {
    return new Promise((resolve) => {
        const id = generateUUID();
        ep.addEventListener("message", function l(ev) {
            if (!ev.data || !ev.data.id || ev.data.id !== id) {
                return;
            }
            ep.removeEventListener("message", l);
            resolve(ev.data);
        });
        if (ep.start) {
            ep.start();
        }
        ep.postMessage(Object.assign({ id }, msg), transfers);
    });
}
function generateUUID() {
    return new Array(4)
        .fill(0)
        .map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16))
        .join("-");
}


//# sourceMappingURL=comlink.mjs.map


/***/ }),

/***/ 1201:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (/* binding */ bisector)
/* harmony export */ });
/* harmony import */ var _ascending_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(89370);
/* harmony import */ var _descending_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(43768);



function bisector(f) {
  let compare1, compare2, delta;

  // If an accessor is specified, promote it to a comparator. In this case we
  // can test whether the search value is (self-) comparable. We can’t do this
  // for a comparator (except for specific, known comparators) because we can’t
  // tell if the comparator is symmetric, and an asymmetric comparator can’t be
  // used to test whether a single value is comparable.
  if (f.length !== 2) {
    compare1 = _ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A;
    compare2 = (d, x) => (0,_ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A)(f(d), x);
    delta = (d, x) => f(d) - x;
  } else {
    compare1 = f === _ascending_js__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A || f === _descending_js__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A ? f : zero;
    compare2 = f;
    delta = f;
  }

  function left(a, x, lo = 0, hi = a.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = (lo + hi) >>> 1;
        if (compare2(a[mid], x) < 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }

  function right(a, x, lo = 0, hi = a.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = (lo + hi) >>> 1;
        if (compare2(a[mid], x) <= 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }

  function center(a, x, lo = 0, hi = a.length) {
    const i = left(a, x, lo, hi - 1);
    return i > lo && delta(a[i - 1], x) > -delta(a[i], x) ? i - 1 : i;
  }

  return {left, center, right};
}

function zero() {
  return 0;
}


/***/ })

}]);